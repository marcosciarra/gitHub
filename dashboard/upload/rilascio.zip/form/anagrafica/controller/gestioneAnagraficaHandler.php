<?php

require_once '../../../conf/conf.php';
require_once '../../../src/function/functionLogin.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';
require_once '../../../src/model/DrakkarTraceLog.php';

require_once '../../../src/model/Anagrafiche.php';
require_once '../../../src/model/AnagraficheSocietarie.php';
require_once '../../../src/model/TipiSoggetto.php';
require_once '../../../src/model/Comuni.php';
require_once '../../../src/model/Banche.php';
require_once '../../../src/model/ContiCorrenti.php';
require_once '../../../src/model/Login.php';
require_once '../../../src/model/UnitaImmobiliari.php';
require_once '../../../src/model/Contratti.php';
require_once '../../../src/model/RegimeFiscale.php';

//require_once '../../../src/function/upload.php';

use Click\Affitti\TblBase\Anagrafiche;
use Click\Affitti\TblBase\TipiSoggetto;
use Click\Affitti\TblBase\Comuni;
use Click\Affitti\TblBase\ContiCorrenti;
use Click\Affitti\TblBase\Login;
use Click\Affitti\TblBase\UnitaImmobiliari;
use Click\Affitti\TblBase\Contratti;
use Click\Affitti\TblBase\RegimeFiscal;

//---------------------- COMUNI --------------------------
function getListaComuniCorti($request)
{
    $con = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
    $anagrafiche = new \Click\Affitti\TblBase\Comuni($con);
    $result = $anagrafiche->getListaComuniCorti(Comuni::FETCH_KEYARRAY);

    return json_encode($result);
}

function aggiornaCitta($request)
{
    $con = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
    $anagrafiche = new \Click\Affitti\TblBase\Comuni($con);
    $result = $anagrafiche->getLista2($request->c);

    return json_encode($result);
}

function caricaDatiComune($request)
{
    $con = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
    $anagrafiche = new \Click\Affitti\TblBase\Comuni($con);
    $result = $anagrafiche->getInfoComuneById($request->id);

    return json_encode($result);
}

//---------------------- BANCHE --------------------------
function caricaDatiBanca($request)
{
    $con = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
    $banca = new \Click\Affitti\TblBase\ContiCorrenti($con);
    $result = $banca->getInfoBancaByAbi($request->abi);

    return json_encode($result);
}

//---------------------- CARICA DATI --------------------------
function caricaDati($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);

        $result = array();
        $anagrafica = new Anagrafiche($con);
        $utenti = new Login($con);

        $tipiSoggetto = new TipiSoggetto($con);
        // CARICO SELECT
        $regimeFiscale=new RegimeFiscal($conExt);
        $result['regimeFiscale'] = $regimeFiscale->findAll(false, RegimeFiscal::FETCH_KEYARRAY);
        $result['elencoTipiSoggetto'] = $tipiSoggetto->findAll(false, TipiSoggetto::FETCH_KEYARRAY);
        $result['elencoTipiSoggetto'] = $tipiSoggetto->findAll(false, TipiSoggetto::FETCH_KEYARRAY);
        $result['tipiSoggettoPersonaFisicaDefault'] =
            TipiSoggetto::getTipoSoggettoDefaultStatic($con, 'Persona fisica');
        $result['tipiSoggettoSocietaDefault'] = TipiSoggetto::getTipoSoggettoDefaultStatic($con, 'Azienda');
        $result['tipiSoggettoDittaIndividualeDefault'] =
            TipiSoggetto::getTipoSoggettoDefaultStatic($con, 'Ditta individuale');

        $result['nuovoIndirizzo'] = $anagrafica->getEmptyIndirizzo();
        $result['nuovoTelefono'] = $anagrafica->getEmptyTelefono();
        $result['nuovoCellulare'] = $anagrafica->getEmptyCellulare();
        $result['nuovoEmail'] = $anagrafica->getEmptyEmail();
        $result['nuovoPec'] = $anagrafica->getEmptyPec();

        $utenti->setWhereBase(" tipo_utente='A' OR tipo_utente='U' AND bloccato=0");
        $result['elencoUtenti'] = $utenti->findAll(true, Login::FETCH_KEYARRAY);

        $immobili = new UnitaImmobiliari($con);
        $immobili->setOrderBase(' descrizione ASC ');
        $result['immobili'] = $immobili->elencoImmobiliPerAnagrafica($request->idAnagrafica, UnitaImmobiliari::FETCH_KEYARRAY);


        $contoCorrente = new ContiCorrenti($con);
        $result['nuovoContoCorrente'] = $contoCorrente->getEmptyDbKeyArray();

        if ($request->idAnagrafica) {
            $result['anagrafica'] = $anagrafica->findByPkFull($request->idAnagrafica, Anagrafiche::FETCH_KEYARRAY);
            $result['anagrafica']['tipoGruppo'] =
                TipiSoggetto::getTipoGruppoByIdStatic($con, $result['anagrafica']['id_tipi_soggetto']);

            $result['anagrafica']['elencoCC'] = [];
            $contoCorrente->setOrderBase(' intestatario ASC ');
            foreach ($contoCorrente->findByIdAnagrafica($request->idAnagrafica, Anagrafiche::FETCH_KEYARRAY) as $cc) {
                (ContiCorrenti::controllaUsoContoCorrenteStatic($con, $cc['id']) > 0) ? $cc['bloccato'] = true : $cc['bloccato'] = false;
                if (is_null($cc['abi'])) {
                    $cc['intestatario'] = $cc['intestatario'];
                    $cc['nomeBanca'] = $cc['agenzia'];
                    $cc['display'] = '';
                    $cc['abi'] = '';
                } else {
                    $banca = new \Click\Affitti\TblBase\Banche($conExt);
                    /** @var \Click\Affitti\TblBase\Banche $banca */
                    foreach ($banca->findByAbi($cc['abi']) as $banca) {
                        break;
                    }
                    $cc['abi'] = $banca->getAbi();
                    $cc['nomeBanca'] = $banca->getDescrizione();
                    $cc['display'] =
                        $cc['nazione'] . ' ' . $cc['ckdigit'] . ' ' . $cc['cin'] . ' ' . $cc['abi'] . ' ' .
                        $cc['cab'] . ' ' . $cc['conto'];
                }
                $result['anagrafica']['elencoCC'][] = $cc;
                $contratto = new Contratti($con);
                $contratto->setWhereBase(' cestino=0 ');
                $result['contrattiAttivi'] = count($contratto->findByIdAgenziaImmobiliare($request->idAnagrafica, Contratti::FETCH_KEYARRAY));
            }
        } else {
            $result['anagrafica'] = $anagrafica->getEmptyDbKeyArrayFull();
            $result['anagrafica']['tipoGruppo'] = "1";
            $result['elencoAnagrafica'] = null;
            $result['anagrafica']['contrattiAttivi'] = 0;
        }
        // carico elenco anagrafiche per selezionare rappr.legale
        $anagrafica->setOrderBase(' descrizione ASC ');
        $result['elencoAnagrafica'] = $anagrafica->findAllPerSelect(Anagrafiche::FETCH_KEYARRAY);

        $result['status'] = 'ok';
        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

//---------------------- SALVA DATI --------------------------
function salvaDati($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $schedaAnagrafica = new Anagrafiche($con);
        if ($request->object->id != null)
            $schedaAnagrafica->findByPk($request->object->id);
        $request->object->nascita_data = date("Y-m-d", strtotime($request->object->nascita_data));

        //CONTROLLO CARICAMENTO FILE
        if ($schedaAnagrafica->getFileLogo() != $request->object->file_logo) {
            if ($schedaAnagrafica->getFileLogo() != '') {
                $fileDaControllare =
                    UPLOAD_URL .
                    DIRECTORY_SEPARATOR . $schedaAnagrafica->getFileLogo();
                if (file_exists($fileDaControllare)) {
                    unlink($fileDaControllare);
                }
            }

            if ($request->object->file_logo != '')
                rename(
                    UPLOAD_URL . DIRECTORY_SEPARATOR . 'temp' .
                    DIRECTORY_SEPARATOR . $request->object->file_logo
                    ,
                    UPLOAD_URL .
                    DIRECTORY_SEPARATOR . $request->object->file_logo
                );
        }
        if ($schedaAnagrafica->getFileFirma() != $request->object->file_firma) {
            if ($schedaAnagrafica->getFileFirma() != '') {
                $fileDaControllare =
                    UPLOAD_URL .
                    DIRECTORY_SEPARATOR . $schedaAnagrafica->getFileFirma();
                if (file_exists($fileDaControllare)) {
                    unlink($fileDaControllare);
                }
            }
            if ($request->object->file_firma != '')
                rename(
                    UPLOAD_URL . DIRECTORY_SEPARATOR . 'temp' .
                    DIRECTORY_SEPARATOR . $request->object->file_firma
                    ,
                    UPLOAD_URL .
                    DIRECTORY_SEPARATOR . $request->object->file_firma

                );
        }

        $schedaAnagrafica->creaObjJson($request->object, true);

        //gestisco il login dell'utente che modifica i dati
        $schedaAnagrafica->setUltimaModificaUtente(getLoginDataFromSession('id'));

        $schedaAnagrafica->saveOrUpdate();
        $result['status'] = $schedaAnagrafica->getId();

        if ($request->object->datiSocieta != null) {
            $ds = new \Click\Affitti\TblBase\AnagraficheSocietarie($con);
            $ds->creaObjJson($request->object->datiSocieta, true);
            if ($ds->isFlagObjectDataValorized()) {
                $ds->setId($schedaAnagrafica->getId());
                $ds->saveOrUpdate(true);
            }
            $result['valorized'] = $ds->isFlagObjectDataValorized();
        }

        //CONTROLLE SE CI SONO CC DA ELIMINARE
        $cc = new ContiCorrenti($con);
        /** @var ContiCorrenti $cc */
        foreach ($cc->findByIdxIdAnagrafica($request->object->id) as $cc) {
            $flag = false;
            foreach ($request->cc as $c) {
                if ($c->id > 0) {
                    if ($c->id == $cc->getId()) {
                        $flag = true;
                        break;
                    }
                } else {
                    $flag = true;
                    break;
                }
            }
            if ($flag == false) {
                $cc->deleteByPk($cc->getId());
            }
        }

        foreach ($request->cc as $c) {
            $conto = new ContiCorrenti($con);
            $conto->creaObjJson($c, true);
            $conto->setIdAnagrafica($schedaAnagrafica->getId());
            $conto->setCodiceFiscale($schedaAnagrafica->getCodiceFiscale());
            $conto->saveOrUpdate();
        }
        $con->commit();
        new \Drakkar\Log\DrakkarTraceLog(getLoginDataFromSession('id', 1));

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarIntegrityConstrainException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::integrityConstrainException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


//---------------------- CARICA MOVIMENTI --------------------------

/**/
ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
