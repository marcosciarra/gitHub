<?php

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';
require_once '../../../src/model/DrakkarTraceLog.php';
require_once '../../../src/function/functionLogin.php';

require_once '../../../src/model/Anagrafiche.php';
require_once '../../../src/model/TipiSoggetto.php';

use Click\Affitti\TblBase\Anagrafiche;
use Click\Affitti\TblBase\TipiSoggetto;

function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        // CARICO DATI
        $anagrafiche = new Anagrafiche($con);
        $anagrafiche->setOrderBase(' nome ASC');
        $result['anagrafiche'] = $anagrafiche->getElencoAnagrafiche(false, Anagrafiche::FETCH_KEYARRAY);

        $result['status'] = 'ok';

        return json_encode($result);
    }
    catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    }
    catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

function findElenchiPerSelect($request){
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        $tipiSoggetto = new TipiSoggetto($con);
        $result['elencoTipiSoggetto'] = $tipiSoggetto->findTipiSoggetoPerSelect(TipiSoggetto::FETCH_KEYARRAY);

        return json_encode($result);
    }catch(Drakkar\Exception\DrakkarException $e){
        $con->rollBack();
        return $e;
    }
}

function gestisciStatoAnagrafica($request) {
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $anagrafica = new Anagrafiche($con);
        $anagrafica->findByPk($request->id);
        $anagrafica->setCestino(!$anagrafica->getCestino());
        //$anagrafica->saveOrUpdate();
        $anagrafica->saveOrUpdateAndLog(getLoginDataFromSession('id'));
        $con->commit();
        $result['status'] = 'ok';
        return json_encode($result);
    }catch(Drakkar\Exception\DrakkarException $e){
        $con->rollBack();
        return $e;
    }
}

/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
