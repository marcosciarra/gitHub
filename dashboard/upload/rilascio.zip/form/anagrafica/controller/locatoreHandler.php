<?php

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';

require_once '../../../src/model/Anagrafiche.php';
require_once '../../../src/model/Contratti.php';
require_once '../../../src/model/ContrattoAffitto.php';

use Click\Affitti\TblBase\Anagrafiche;
use Click\Affitti\TblBase\Contratti;
use Click\Affitti\Viste\ContrattoAffitto;

function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $contrattoAffitto = new ContrattoAffitto($con);

        // CARICO DATI
        $contratti = new Contratti($con, $request->cestino);

        $result['contratti'] = $contratti->getElencoContratti(false, Contratti::FETCH_KEYARRAY);
        $contratti = new Contratti($con, 'T');
        $result['range'] = $contratti->getCanoneMaxMin(false, Contratti::FETCH_KEYARRAY);

        // CARICO SELECT
        $temp = $contrattoAffitto->getTipoContratto()->getEmptyDbKeyArray();
        $temp['id'] = 0;
        $temp['descrizione'] = 'Tutti i contratti';
        $result['elencoTipiContratto'] = $contrattoAffitto->getTipoContratto()->findAllConDescrizione(ContrattoAffitto::FETCH_KEYARRAY);
        array_unshift($result['elencoTipiContratto'], $temp);

        $result['status'] = 'ok';


        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

function gestisciStatoAnagrafica($request) {
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $anagrafica = new Anagrafiche($con);
        $anagrafica->findByPk($request->id);
        $anagrafica->setCestino(!$anagrafica->getCestino());
        $anagrafica->saveOrUpdate();
        $con->commit();
        return ($anagrafica->getCestino());
    }catch(Drakkar\Exception\DrakkarException $e){
        $con->rollBack();
        return $e;
    }
}


/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
