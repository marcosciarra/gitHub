ngApp.controller('gestioneAnagraficaController', ['$scope', '$http', '$filter', function ($scope, $http, $filter) {

    var params = decodeUrl(window.location.href, ['id_anagrafica']);
    $scope.showRefresh = true;
    $scope.showIndietro = true;
    $scope.showOptionsButtons = true;

    //sostituisce l'onload, da richiamare nel tag in cui si definisce il controller
    $scope.init = function () {
        $scope.getStrutturaAnagrafica();
        $scope.caricaComuniCorti();
        // SET sigla nazione a 'IT'
        $scope.statoBanca = 'IT';
        $scope.elencoCC = [];
        $scope.tipoCassa = '0';
        $scope.mostraFormBanca = false;
        $scope.indirizzoSpedizionePresente = 0;
    };

    // SELECT tipo [] - titolo[]
    //$scope.tipoPrivato = true;
    $scope.titoliDisponibili = ['sig', 'sig.ra', 'dott', 'spett.le'];
    // END SELECT tipo [] - titolo[]

    /* =========================================== MODIFICA ========================================== */
    $scope.modifica = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("anagrafica", "gestioneAnagrafica", id);
    };
    /* =========================================== /MODIFICA ========================================= */

    /* =========================================== BANCHE ========================================== */

    $scope.ricercaBanca = function (abi) {
        $scope.abiCorretto = false;
        if (abi != undefined || abi.length > 4) {
            $http.post($scope.params['form'] + '/anagrafica/controller/gestioneAnagraficaHandler.php',
                {'function': 'caricaDatiBanca', 'abi': abi}
            ).then(function (data, status, headers, config) {
                stampalog(data.data);
                if (data.data.abi == abi) {
                    $scope.nuovoContoCorrente.nomeBanca = data.data.descrizione;
                    $scope.nuovoContoCorrente.id_banca = data.data.abi;
                    $scope.nuovoContoCorrente.abi = data.data.abi;
                    $scope.abiCorretto = true;
                } else {
                    $scope.nuovoContoCorrente.nomeBanca = null;
                    $scope.nuovoContoCorrente.id_banca = null;
                    $scope.abiCorretto = false;
                }
            })
        }
    };

    $scope.controllaIban = function () {
        var tmp = $scope.nuovoContoCorrente.nazione + $scope.nuovoContoCorrente.ckdigit + $scope.nuovoContoCorrente.cin
            + $scope.nuovoContoCorrente.abi + $scope.nuovoContoCorrente.cab + $scope.nuovoContoCorrente.conto;
        if (controllaIbanIT(tmp) && $scope.abiCorretto) {

            $scope.nuovoContoCorrente.display = $scope.nuovoContoCorrente.nazione + ' ' + $scope.nuovoContoCorrente.ckdigit + ' '
                + $scope.nuovoContoCorrente.cin + ' ' + $scope.nuovoContoCorrente.abi + ' '
                + $scope.nuovoContoCorrente.cab + ' ' + $scope.nuovoContoCorrente.conto;

            if($scope.nuovoContoCorrente.agenzia != null) {
                $scope.nuovoContoCorrente.nomeBanca = $scope.nuovoContoCorrente.nomeBanca + ' - ' + $scope.nuovoContoCorrente.agenzia;
            }
            if ($scope.nuovoCCIndice > -1) {
                $scope.elencoCC [$scope.nuovoCCIndice] = angular.copy($scope.nuovoContoCorrente);
            } else {
                $scope.elencoCC.push($scope.nuovoContoCorrente);
                $scope.nuovoContoCorrente = angular.copy($scope.nuovoContoCorrenteApp);
            }
            $scope.resetCC();
        }
    };

    $scope.salvaDatiCassa = function () {
        if ($scope.nuovoContoCorrente.agenzia.length > 0) {

            $scope.nuovoContoCorrente.nomeBanca = $scope.nuovoContoCorrente.agenzia;
            if ($scope.nuovoCCIndice > -1) {
                $scope.elencoCC [$scope.nuovoCCIndice] = angular.copy($scope.nuovoContoCorrente);
            } else {
                $scope.elencoCC.push($scope.nuovoContoCorrente);
                $scope.nuovoContoCorrente = angular.copy($scope.nuovoContoCorrenteApp);
            }
            $scope.resetCC();
        }
    };

    $scope.eliminaCC = function (i) {
        $scope.elencoCC.splice(i, 1);
    };

    $scope.modificaCC = function (obj, i) {
        $scope.nuovoCCIndice = i;

        $scope.mostraFormBanca = true;
        $scope.nuovoContoCorrente = angular.copy(obj);
        $scope.ricercaBanca(obj.abi);
        if ($scope.nuovoContoCorrente.abi != null) {
            $scope.tipoCassa = '0';
        } else {
            $scope.tipoCassa = '1';
        }
        stampalog($scope.nuovoContoCorrente);
    };

    $scope.resetCC = function () {
        $scope.nuovoContoCorrente = angular.copy($scope.nuovoContoCorrenteApp);
        $scope.mostraFormBanca = false;
        $scope.nuovoCCIndice = -1;
    };

    /* =========================================== /BANCHE ========================================== */

    /* =========================================== COMUNI ========================================= */
    $scope.caricaComuniCorti = function () {
        $http.post($scope.params['form'] + '/anagrafica/controller/gestioneAnagraficaHandler.php',
            {'function': 'getListaComuniCorti'}
        ).then(function (data, status, headers, config) {
            $scope.listaComuni = data.data;
            $scope.listaComuniApp = data.data;
        })
    };

    $scope.ricercaCitta = function (c, idForm) {
        //var indice = $scope.listaComuni.indexOf(c);
        //stampalog($scope.listaComuni);
        //stampalog(indice);
        var appoggio = $filter('filter')($scope.listaComuni, {denominazione: c}, true)[0];

        if (c.length > 4 || appoggio != undefined) {
            $http.post($scope.params['form'] + '/anagrafica/controller/gestioneAnagraficaHandler.php',
                {'function': 'aggiornaCitta', 'c': c}
            ).then(function (data, status, headers, config) {
                if (c.length > 4) {
                    $scope.listaComuni = $scope.listaComuni.concat(data.data);
                }
                appoggio = $filter('filter')($scope.listaComuni, {denominazione: c}, true)[0];
                if (appoggio != undefined) {
                    $http.post($scope.params['form'] + '/anagrafica/controller/gestioneAnagraficaHandler.php',
                        {'function': 'caricaDatiComune', 'id': appoggio.id}
                    ).then(function (data, status, headers, config) {
                        // setto campi
                        if (idForm == 1) {
                            $scope.nuovaSchedaAnagrafica.nascita_provincia = data.data.sigla_automobilistica;
                            $scope.nuovaSchedaAnagrafica.nascita_stato = data.data.alpha2;
                            $scope.listaComuni = $scope.listaComuniApp;
                            $scope.campiCFCompilati();
                            $scope.controllaDati();
                        } else {
                            $scope.nuovoIndirizzo.cap = data.data.cap;
                            $scope.nuovoIndirizzo.provincia = data.data.sigla_automobilistica;
                            $scope.nuovoIndirizzo.stato = data.data.alpha2;
                            $scope.controllaIndirizzo();
                        }

                    })
                }

                //se non trova nessun comune con quel nome setta stato a 'EE'
                if ($scope.listaComuni.length == 0) {
                    $scope.nuovaSchedaAnagrafica.nascita_stato = 'EE';
                }
            })
        }
    };
    /* =========================================== /COMUNI ========================================= */


    /* =========================================== STRUTTURA NUOVO CLIENTE ========================================== */

    $scope.getStrutturaAnagrafica = function () {

        var idAnagrafica = 0;
        if (params['id_anagrafica'] !== undefined)
            idAnagrafica = params['id_anagrafica'];

        $http.post($scope.params['form'] + '/anagrafica/controller/gestioneAnagraficaHandler.php',
            {'function': 'caricaDati', 'idAnagrafica': idAnagrafica}
        ).then(function (data, status, headers, config) {

            if (data.data.status == "ko") {
                swal("Errore", "Caricamento non riuscito", "error");
                return;
            }

            $scope.nuovaSchedaAnagrafica = data.data.anagrafica;
            $scope.presettaDatiDefault(data);

            stampalog(data.data);

            if (data.data.anagrafica.id != null) {
                (data.data.anagrafica.indirizzi != null) ?
                    $scope.nuovaSchedaAnagrafica.indirizzi = jsonParse(data.data.anagrafica.indirizzi) :
                    $scope.nuovaSchedaAnagrafica.indirizzi = [];
                (data.data.anagrafica.telefoni != null) ?
                    $scope.nuovaSchedaAnagrafica.telefoni = jsonParse(data.data.anagrafica.telefoni) :
                    $scope.nuovaSchedaAnagrafica.telefoni = [];
                (data.data.anagrafica.cellulari != null) ?
                    $scope.nuovaSchedaAnagrafica.cellulari = jsonParse(data.data.anagrafica.cellulari) :
                    $scope.nuovaSchedaAnagrafica.cellulari = [];
                (data.data.anagrafica.email != null) ?
                    $scope.nuovaSchedaAnagrafica.email = jsonParse(data.data.anagrafica.email) :
                    $scope.nuovaSchedaAnagrafica.email = [];

                $scope.nuovaSchedaAnagrafica.nascita_data = new Date($scope.nuovaSchedaAnagrafica.nascita_data);
                $scope.nuovaSchedaAnagrafica.tipoGruppo = '' + data.data.anagrafica.tipoGruppo;
                $scope.elencoCC = data.data.anagrafica.elencoCC;

            } else {
                $scope.selectTipoPersone($scope.nuovaSchedaAnagrafica.tipoGruppo);
                $scope.nuovaSchedaAnagrafica.indirizzi = [];
                $scope.nuovaSchedaAnagrafica.telefoni = [];
                $scope.nuovaSchedaAnagrafica.cellulari = [];
                $scope.nuovaSchedaAnagrafica.email = [];
                $scope.contoCorrente = [];
            }

            $scope.tipiDisponibili = data.data.elencoTipiSoggetto;

            $scope.nuovoIndirizzo = data.data.nuovoIndirizzo;
            $scope.nuovoIndirizzoApp = angular.copy(data.data.nuovoIndirizzo);
            $scope.nuovoIndirizzoIndice = -1;
            $scope.nuovoTelefono = data.data.nuovoTelefono;
            $scope.nuovoTelefonoApp = angular.copy(data.data.nuovoTelefono);
            $scope.nuovoTelefonoIndice = -1;
            $scope.nuovoCellulare = data.data.nuovoCellulare;
            $scope.nuovoCellulareApp = angular.copy(data.data.nuovoCellulare);
            $scope.nuovoCellulareIndice = -1;
            $scope.nuovoEmail = data.data.nuovoEmail;
            $scope.nuovoEmailApp = angular.copy(data.data.nuovoEmail);
            $scope.nuovoEmailIndice = -1;

            $scope.nuovoContoCorrente = data.data.nuovoContoCorrente;
            $scope.nuovoContoCorrenteApp = angular.copy(data.data.nuovoContoCorrente);

            $scope.controllaDati();
        });

        $scope.caricamentoCompletato = true;
    };

    $scope.presettaDatiDefault = function (data) {
        $scope.tipiSoggettoPersonaFisicaDefault = data.data.tipiSoggettoPersonaFisicaDefault;
        $scope.tipiSoggettoSocietaDefault = data.data.tipiSoggettoSocietaDefault;
        $scope.tipiSoggettoDittaIndividualeDefault = data.data.tipiSoggettoDittaIndividualeDefault;
    };

    $scope.selectTipoPersone = function () {
        $scope.datiCorretti = false;
        $scope.calcolaCF = false;
        if ($scope.nuovaSchedaAnagrafica.tipoGruppo == '1') {
            $scope.nuovaSchedaAnagrafica.id_tipi_soggetto = $scope.tipiSoggettoPersonaFisicaDefault;
            $scope.nuovaSchedaAnagrafica.titolo = 'sig';
            $scope.nuovaSchedaAnagrafica.partita_iva_nazione = null;
            //$scope.tipoPrivato = true;
        } else if ($scope.nuovaSchedaAnagrafica.tipoGruppo == '2') {
            $scope.nuovaSchedaAnagrafica.id_tipi_soggetto = $scope.tipiSoggettoSocietaDefault;
            $scope.nuovaSchedaAnagrafica.titolo = 'spett.le';
            $scope.nuovaSchedaAnagrafica.partita_iva_nazione = "IT";
            //$scope.tipoPrivato = false;
        } else if ($scope.nuovaSchedaAnagrafica.tipoGruppo == '3') {
            $scope.nuovaSchedaAnagrafica.id_tipi_soggetto = $scope.tipiSoggettoDittaIndividualeDefault;
            $scope.nuovaSchedaAnagrafica.titolo = 'spett.le';
            $scope.nuovaSchedaAnagrafica.partita_iva_nazione = "IT";
            //$scope.tipoPrivato = false;
        }
        $scope.controllaDati();
    };

    // INDIRIZZI
    $scope.aggiungiIndirizzo = function () {
        if ($scope.nuovoIndirizzoIndice != -1) {
            $scope.nuovaSchedaAnagrafica.indirizzi [$scope.nuovoIndirizzoIndice] = angular.copy($scope.nuovoIndirizzo);
        } else {
            $scope.nuovaSchedaAnagrafica.indirizzi.push($scope.nuovoIndirizzo);
        }
        $scope.resetIndirizzo();
    };

    $scope.resetIndirizzo = function () {
        $scope.nuovoIndirizzo = angular.copy($scope.nuovoIndirizzoApp);
        $scope.nuovoIndirizzoIndice = -1;
    };

    $scope.modificaIndirizzo = function (obj, i) {
        $scope.nuovoIndirizzo = angular.copy(obj);
        $scope.nuovoIndirizzoIndice = i;
        $scope.contaIndirizziSpedizione();
    };

    $scope.eliminaIndirizzo = function (i) {
        $scope.nuovaSchedaAnagrafica.indirizzi.splice(i, 1);
    };

    $scope.controllaIndirizzo = function () {
        if ($scope.nuovoIndirizzo === undefined) {
            return false;
        }
        return (
            $scope.nuovoIndirizzo.descrizione != "" &&
            $scope.nuovoIndirizzo.via != "" &&
            $scope.nuovoIndirizzo.civico != "" &&
            $scope.nuovoIndirizzo.cap != "" &&
            $scope.nuovoIndirizzo.citta != "" &&
            $scope.nuovoIndirizzo.provincia != "" &&
            $scope.nuovoIndirizzo.stato != ""
        );
    };

    $scope.contaIndirizziSpedizione = function () {
        $scope.indirizzoSpedizionePresente=0;
        for (var i = 0; i < $scope.nuovaSchedaAnagrafica.indirizzi.length; i++) {
            if ($scope.nuovaSchedaAnagrafica.indirizzi[i].indirizzo_spedizione) {
                $scope.indirizzoSpedizionePresente++;
                //stampalog(i+':'+$scope.nuovaSchedaAnagrafica.indirizzi[i].indirizzo_spedizione);
                //return;
            }
        }

    };

    // TELEFONI
    $scope.aggiungiTelefono = function () {
        if ($scope.nuovoTelefonoIndice != -1) {
            $scope.nuovaSchedaAnagrafica.telefoni [$scope.nuovoTelefonoIndice] = angular.copy($scope.nuovoTelefono);
        } else {
            $scope.nuovaSchedaAnagrafica.telefoni.push($scope.nuovoTelefono);
        }
        $scope.resetTelefono();
    };

    $scope.resetTelefono = function () {
        $scope.nuovoTelefono = angular.copy($scope.nuovoTelefonoApp);
        $scope.nuovoTelefonoIndice = -1;
    };

    $scope.modificaTelefono = function (obj, i) {
        $scope.nuovoTelefono = angular.copy(obj);
        $scope.nuovoTelefonoIndice = i;
    };

    $scope.eliminaTelefono = function (i) {
        $scope.nuovaSchedaAnagrafica.telefoni.splice(i, 1);
    };

    $scope.controllaTelefono = function () {
        if ($scope.nuovoTelefono === undefined)
            return false;

        if (
            $scope.nuovoTelefono.descrizione != "" &&
            $scope.nuovoTelefono.telefono != ""
        ) {
            return true;
        } else {
            return false;
        }
    };

    // CELLULARI
    $scope.aggiungiCellulare = function () {
        if ($scope.nuovoCellulareIndice != -1) {
            $scope.nuovaSchedaAnagrafica.cellulari [$scope.nuovoCellulareIndice] = angular.copy($scope.nuovoCellulare);
        } else {
            $scope.nuovaSchedaAnagrafica.cellulari.push($scope.nuovoCellulare);
        }
        $scope.resetCellulare();
    };

    $scope.resetCellulare = function () {
        $scope.nuovoCellulare = angular.copy($scope.nuovoCellulareApp);
        $scope.nuovoCellulareIndice = -1;
    };

    $scope.modificaCellulare = function (obj, i) {
        $scope.nuovoCellulare = angular.copy(obj);
        $scope.nuovoCellulareIndice = i;
    };

    $scope.eliminaCellulare = function (i) {
        $scope.nuovaSchedaAnagrafica.cellulari.splice(i, 1);
    };

    $scope.controllaCellulare = function () {
        if ($scope.nuovoCellulare === undefined)
            return false;

        if (
            $scope.nuovoCellulare.descrizione != "" &&
            $scope.nuovoCellulare.cellulare != ""
        ) {
            return true;
        } else {
            return false;
        }
    };

    // EMAIL
    $scope.aggiungiEmail = function () {
        if ($scope.nuovoEmailIndice != -1) {
            $scope.nuovaSchedaAnagrafica.email [$scope.nuovoEmailIndice] = angular.copy($scope.nuovoEmail);
        } else {
            $scope.nuovaSchedaAnagrafica.email.push($scope.nuovoEmail);
        }
        $scope.resetEmail();
    };

    $scope.resetEmail = function () {
        $scope.emailCorretta = false;
        $scope.nuovoEmail = angular.copy($scope.nuovoEmailApp);
        $scope.nuovoEmailIndice = -1;
    };

    $scope.modificaEmail = function (obj, i) {
        $scope.nuovoEmail = angular.copy(obj);
        $scope.nuovoEmailIndice = i;
    };

    $scope.eliminaEmail = function (i) {
        $scope.nuovaSchedaAnagrafica.email.splice(i, 1);
    };

    $scope.controllaEmail = function () {
        if ($scope.nuovoEmail === undefined)
            $scope.emailCorretta = false;

        if (
            $scope.nuovoEmail.descrizione != "" &&
            controllaEmail($scope.nuovoEmail.email)
        ) {
            $scope.emailCorretta = true;
        } else {
            $scope.emailCorretta = false;
        }
    };

    /* =============================================== CODICE FISCALE =============================================== */

    $scope.calcolaCF = false;

    $scope.campiCFCompilati = function () {
        if ($scope.nuovaSchedaAnagrafica.nome != "" && $scope.nuovaSchedaAnagrafica.nome != null &&
            $scope.nuovaSchedaAnagrafica.cognome != "" && $scope.nuovaSchedaAnagrafica.cognome != null &&
            $scope.nuovaSchedaAnagrafica.sesso != "" && $scope.nuovaSchedaAnagrafica.sesso != null &&
            $scope.nuovaSchedaAnagrafica.nascita_data != "" && $scope.nuovaSchedaAnagrafica.nascita_data != null &&
            $scope.nuovaSchedaAnagrafica.nascita_luogo != "" && $scope.nuovaSchedaAnagrafica.nascita_luogo != null
        ) {
            $scope.calcolaCF = true;
        } else {
            $scope.calcolaCF = false;
        }
    };

    $scope.calcolaCodiceFiscale = function () {
        if($scope.nuovaSchedaAnagrafica) {
            $scope.campiCFCompilati();
            if ($scope.calcolaCF) {
                var nome = $scope.nuovaSchedaAnagrafica.nome;
                var cognome = $scope.nuovaSchedaAnagrafica.cognome;
                var sesso = $scope.nuovaSchedaAnagrafica.sesso;
                var tmp = formattaDataHtml5($scope.nuovaSchedaAnagrafica.nascita_data);
                var giorno = tmp['day'];
                var mese = tmp['month'];
                var anno = tmp['year'];
                var luogoNascita = $scope.nuovaSchedaAnagrafica.nascita_luogo;

                $scope.nuovaSchedaAnagrafica.codice_fiscale = CFisc.calcola_codice(nome, cognome, sesso, giorno, mese, anno, luogoNascita);
            }
            return controllaCF($scope.nuovaSchedaAnagrafica.codice_fiscale);
        }
        return false;
    };

    $scope.controllaDataNascita = function () {
        if($scope.nuovaSchedaAnagrafica) {
            if (
                $scope.nuovaSchedaAnagrafica.nascita_data != "" &&
                $scope.nuovaSchedaAnagrafica.nascita_data != null &&
                isValidDate(getYYYYMMGGFromJsDate($scope.nuovaSchedaAnagrafica.nascita_data))
            ) {
                return true;
            }
        }
        return false;
    };

    /* =============================================== CONTROLLI =============================================== */
    $scope.datiCorretti = false;
    $scope.cfCorretto = false;
    $scope.dataNascitaCorretta = false;

    function controllaDatiPFisica () {
        $scope.cfCorretto = controllaCF($scope.nuovaSchedaAnagrafica.codice_fiscale);
        $scope.dataNascitaCorretta = $scope.controllaDataNascita();

        if(
            $scope.nuovaSchedaAnagrafica.nome != "" && $scope.nuovaSchedaAnagrafica.nome != null &&
            $scope.nuovaSchedaAnagrafica.cognome != "" && $scope.nuovaSchedaAnagrafica.cognome != null &&
            $scope.nuovaSchedaAnagrafica.sesso != "" && $scope.nuovaSchedaAnagrafica.sesso != null &&
            $scope.nuovaSchedaAnagrafica.nascita_luogo != "" && $scope.nuovaSchedaAnagrafica.nascita_luogo != null &&
            $scope.dataNascitaCorretta &&
            $scope.cfCorretto
        ){
            $scope.datiCorretti = true;
        } else {
            $scope.datiCorretti = false;
            $scope.datiCorrettiString = 'Mancanza di dati e/o Codice Fiscale non corretto o assente';
        }
    }

    function controllaDatiDittaIndiv () {
        $scope.cfCorretto = controllaCF($scope.nuovaSchedaAnagrafica.codice_fiscale);

        if(
            $scope.nuovaSchedaAnagrafica.nome != "" && $scope.nuovaSchedaAnagrafica.nome != null &&
            $scope.nuovaSchedaAnagrafica.cognome != "" && $scope.nuovaSchedaAnagrafica.cognome != null &&
            $scope.nuovaSchedaAnagrafica.sesso != "" && $scope.nuovaSchedaAnagrafica.sesso != null &&
            $scope.nuovaSchedaAnagrafica.nascita_data != "" && $scope.nuovaSchedaAnagrafica.nascita_data != null &&
            isValidDate(getYYYYMMGGFromJsDate($scope.nuovaSchedaAnagrafica.nascita_data)) &&
            $scope.nuovaSchedaAnagrafica.nascita_luogo != "" && $scope.nuovaSchedaAnagrafica.nascita_luogo != null &&
            $scope.nuovaSchedaAnagrafica.ragione_sociale != "" && $scope.nuovaSchedaAnagrafica.ragione_sociale != null &&
            ($scope.nuovaSchedaAnagrafica.partita_iva != "" && $scope.nuovaSchedaAnagrafica.partita_iva != null &&
            $scope.nuovaSchedaAnagrafica.partita_iva.length == 11) &&
            $scope.cfCorretto
        ){
            $scope.datiCorretti = true;
        } else {
            $scope.datiCorretti = false;
            $scope.datiCorrettiString = 'Mancanza di dati e/o Codice Fiscale non corretto o assente';
        }
    }

    function controllaDatiSocieta () {
        $scope.cfCorretto = (
            $scope.nuovaSchedaAnagrafica.codice_fiscale.length == 11 &&
            $scope.nuovaSchedaAnagrafica.partita_iva.length == 11
        );

        if(
            $scope.nuovaSchedaAnagrafica.ragione_sociale != "" && $scope.nuovaSchedaAnagrafica.ragione_sociale != null &&
            $scope.nuovaSchedaAnagrafica.datiSocieta.rea != "" && $scope.nuovaSchedaAnagrafica.datiSocieta.rea != null &&
            $scope.nuovaSchedaAnagrafica.datiSocieta.cdc_numero != "" && $scope.nuovaSchedaAnagrafica.datiSocieta.cdc_numero != null &&
            $scope.nuovaSchedaAnagrafica.datiSocieta.cdc_citta != "" && $scope.nuovaSchedaAnagrafica.datiSocieta.cdc_citta != null &&
            $scope.nuovaSchedaAnagrafica.datiSocieta.capitale_sociale != "" && $scope.nuovaSchedaAnagrafica.datiSocieta.capitale_sociale != null &&
            $scope.cfCorretto
        ){
            $scope.datiCorretti = true;
        } else {
            $scope.datiCorretti = false;
            $scope.datiCorrettiString = 'Mancanza di dati e/o Codice Fiscale non corretto o assente';
        }
    }

    $scope.controllaDati = function () {
        switch ($scope.nuovaSchedaAnagrafica.tipoGruppo) {
            case '1':
                controllaDatiPFisica();
                break;
            case '2':
                controllaDatiSocieta();
                break;
            case '3':
                controllaDatiDittaIndiv();
                break;
        }
    };

    /******************
     *   SALVADATI   * ================================================================================================
     ******************/

    $scope.salvaDati = function () {
        $scope.contaIndirizziSpedizione();
        if ($scope.indirizzoSpedizionePresente > 1) {
            swal("Errore", 'Sono stati inseriti più indirizzi di spedizione', "error");
            return;
        }

        if (!$scope.datiCorretti) {
            swal("Errore", $scope.datiCorrettiString, "error");
            return;
        } else {
            //var tmp = formattaDataHtml5($scope.nuovaSchedaAnagrafica.nascita_data);
            //$scope.nuovaSchedaAnagrafica.nascita_data = tmp['year'] + "-" + tmp['month'] + "-" + tmp['day'];

            stampalog('---salva---');
            stampalog($scope.nuovaSchedaAnagrafica);
            stampalog($scope.elencoCC);
            stampalog('---fine salva---');

            /*
            $http.post(params['form'] + '/anagrafica/controller/gestioneAnagraficaHandler.php',
                {'function': 'salvaDati', 'object': $scope.nuovaSchedaAnagrafica, 'cc': $scope.elencoCC}
            ).then(function (data, status, headers, config) {
                stampalog(data);

                if (data.data.status == "ko") {
                    swal(data.data.error.title, data.data.error.message, "error");
                } else {
                    stampalog(data.data);
                    swal({
                        title: "Salvataggio eseguito",
                        text: '',
                        type: "success"
                    }, function () {
                        window.location.href = $scope.params['home'] + encodeUrl("anagrafica", "anagrafica");
                    });
                }

            });
            */
        }
    };

}]);


/* ------- DA SISTEMARE --------- */
function importaStrutturaAnagrafica() {
    return {
        intestazione: {id_tipi_soggetto: "1", titolo: "sig", nome: "", ragione_sociale: ""},
        datiAnagrafici: {sesso: "", nascita_data: "", nascita_luogo: "", nascita_provincia: "", nascita_stato: ""},
        datiCliente: {partita_iva_nazione: "", partita_iva: "", codice_fiscale: ""},
        contatti: {telefoni: "", cellulari: "", elencoEmail: [], indirizzi: ""}
    }
}