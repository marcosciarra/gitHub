ngApp.controller("stampeAnagraficheController", ["$scope", "$http", "$filter", function ($scope, $http, $filter) {

    var url = window.location.href;
    var params = decodeUrl(url, ['data_inizio', 'data_fine']);
    stampalog(params);

    $scope.caricamentoCompletato = false;
    $scope.filtro = false;
    $scope.elencoUtenti = [];
    $scope.elencoStabili = [];
    $scope.elencoLocatori = [];
    $scope.elencoConduttori = [];
    $scope.filtroUtenti = [];
    $scope.filtroStabili = [];
    $scope.filtroLocatori = [];
    $scope.filtroConduttori = [];

    $scope.tipoAnagrafica = '-1';
    $scope.tipoanagrafica = [
        {id: '-1', descrizione: 'Tutti'},
        {id: 'L', descrizione: 'Locatori'},
        {id: 'C', descrizione: 'Conduttori'}
    ];


    $scope.etichette =
        [
            {id: '0', descrizione: '8 Righe x 3 Colonne'},
            {id: '1', descrizione: '8 Righe x 2 Colonne'},
            {id: '2', descrizione: '7 Righe x 2 Colonne'}
        ];

    /*--------------------------------------------------CARICA DATI---------------------------------------------------*/

    $scope.init = function () {
        $scope.selezionatiTutti = true;
        $scope.visualizzaArretrati = false;

        $scope.caricaDati();
    };

    $scope.caricaDati = function () {
        $scope.caricamentoCompletato = false;
        $scope.caricaFiltri();
        $http.post(params['form'] + '/anagrafica/controller/stampeAnagraficheHandler.php',
            {
                'function': 'caricaDati'
            }
        ).then(function (data, status, headers, config) {

            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }

            $scope.anagrafiche = data.data.anagrafiche;

            for (var i = 0; i < $scope.anagrafiche.length; i++) {
                $scope.anagrafiche[i].selezionato = true;
                //Normalizzo il nome e cognome / ragione sociale
                // if ($scope.anagrafiche[i].ragione_sociale != null) {
                //     $scope.anagrafiche[i].descrizione =
                //         $scope.anagrafiche[i].ragione_sociale;
                // }
                // else {
                //     $scope.anagrafiche[i].descrizione =
                //         $scope.anagrafiche[i].cognome + ' ' + $scope.anagrafiche[i].nome;
                // }

                //Indirizzo
                $scope.anagrafiche[i].indirizzi = jsonParse($scope.anagrafiche[i].indirizzi);
                for (var j = 0; j < $scope.anagrafiche[i].indirizzi.length; j++) {
                    $scope.anagrafiche[i].indirizzi[j].id = j;
                    $scope.anagrafiche[i].indirizzi[j].descrizione =
                        $scope.anagrafiche[i].indirizzi[j].via + ' ' + $scope.anagrafiche[i].indirizzi[j].civico +
                        ' - ' + $scope.anagrafiche[i].indirizzi[j].citta;

                    if ($scope.anagrafiche[i].indirizzi[j].indirizzo_spedizione) {
                        $scope.anagrafiche[i].indirizzo_selezionato =
                            j;
                    }
                }

            }
            $scope.backupAnagrafiche = angular.copy($scope.anagrafiche);
            stampalog(data.data.anagrafiche);

            $scope.filtro = false;


            $scope.modelloEtichetta = '0';

            $scope.caricamentoCompletato = true;
        });
    };


    $scope.caricaDettagliModale = function (elenco, etichetta) {
        $scope.elencoModale = elenco;
        $scope.etichettaModale = etichetta;
    };


    /*----------------------------------------------------STAMPA------------------------------------------------------*/
    $scope.stampaEtichette = function () {
        if ($scope.primaEtichetta == undefined)
            $scope.primaEtichetta = 1;
        var primoId = true;
        var indirizzi = [];
        if ($scope.anagraficheFiltrate != null) {
            var app = '';
            for (var i = 0; i < $scope.anagraficheFiltrate.length; i++) {
                if ($scope.anagraficheFiltrate[i].selezionato) {
                    var appIndirizzi = {
                        'i': $scope.anagraficheFiltrate[i].anagrafica_id,
                        'n': $scope.anagraficheFiltrate[i].indirizzo_selezionato
                    };
                    indirizzi.push(appIndirizzi);
                }
            }
        }

        window.open(
            params['baseurl'] +
            '/stampe/anagrafica/etichettePdf.php?modello=' +
            $scope.modelloEtichetta + '&posizione=' +
            $scope.primaEtichetta + '&idAnagrafica=' +
            JSON.stringify(indirizzi)
        );
    };

    /* =================================== FILTRI E ORDINAMENTI ===================================================== */

    $scope.selezionaDeselezionaTutti = function (flag) {
        $scope.selezionatiTutti = flag;
        for (var i = 0; i < $scope.anagrafiche.length; i++) {
            $scope.anagrafiche[i].selezionato = flag;
        }
    };

    //---------------------------------------------------SEZIONE FILTRI-----------------------------------------------//
    $scope.caricaFiltri = function () {
        $http.post($scope.params['form'] + "/template/controller/homeHandler.php",
            {'function': 'caricaFiltri'}
        ).then(function (data, status, headers, config) {
            // stampalog(data.data);
            $scope.filtriSelectPagina = data.data;
        });
    };
    $scope.settings = {
        dynamicTitle: true,
        enableSearch: true,
        showSelectAll: false,
        keyboardControls: true,
        scrollable: true,
        showCheckAll: false,
        showUncheckAll: true,
        closeOnSelect: false,
        scrollableHeight: '300px',
        externalIdProp: '', //PERMETTE DI AGGIUNGERE ALL'ARRAY DEI SELEZIONATI TUTTO L'OGGETTO
        idProp: 'id', //definisco i campi di cui è composto l'oggetto
        displayProp: 'descrizione' //definisco i campi di cui è composto l'oggetto
    };
    $scope.customTextUtenti = {
        buttonDefaultText: 'Utenti',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextStabili = {
        buttonDefaultText: 'Proprietari degli Stabili',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextLocatori = {
        buttonDefaultText: 'Locatori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextConduttori = {
        buttonDefaultText: 'Conduttori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.multiSelectEventUtenti = {
        onItemSelect: function (obj) {
            $scope.filtroUtenti.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroUtenti.length; i++) {
                if ($scope.filtroUtenti[i] == obj.id) {
                    $scope.filtroUtenti.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function () {
            $scope.filtroUtenti = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventStabili = {
        onItemSelect: function (obj) {
            $scope.filtroStabili.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroStabili.length; i++) {
                if ($scope.filtroStabili[i] == obj.id) {
                    $scope.filtroStabili.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroStabili = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventLocatori = {
        onItemSelect: function (obj) {
            $scope.filtroLocatori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroLocatori.length; i++) {
                if ($scope.filtroLocatori[i] == obj.id) {
                    $scope.filtroLocatori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroLocatori = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventConduttori = {
        onItemSelect: function (obj) {
            $scope.filtroConduttori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroConduttori.length; i++) {
                if ($scope.filtroConduttori[i] == obj.id) {
                    $scope.filtroConduttori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroConduttori = [];
            $scope.filtriGenerici();
        }
    };


    $scope.filtriGenerici = function () {
        $scope.anagrafiche = [];
        var flag;
        for (var i = 0; i < $scope.backupAnagrafiche.length; i++) {
            flag = false;

            if ($scope.filtroUtenti.length == 0) {
                flag = true;
            }
            else {
                for (var k = 0; k < $scope.filtroUtenti.length; k++) {
                    if ($scope.backupAnagrafiche[i].id_utente == $scope.filtroUtenti[k]) {
                        flag = true;
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroStabili.length == 0) {
                    flag = true;
                }
                else {
                    flag = false;
                    for (var j = 0; j < $scope.backupAnagrafiche[i].immobili.length; j++) {
                        for (var k = 0; k < $scope.filtroStabili.length; k++) {
                            if ($scope.backupAnagrafiche[i].immobili[j].id_stabili == $scope.filtroStabili[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroLocatori.length == 0) {
                    flag = true;
                }
                else {
                    flag = false;
                    for (var j = 0; j < $scope.backupAnagrafiche[i].elenco_proprietari.length; j++) {
                        for (var k = 0; k < $scope.filtroLocatori.length; k++) {
                            if ($scope.backupAnagrafiche[i].elenco_proprietari[j].id == $scope.filtroLocatori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroConduttori.length == 0) {
                    flag = true;
                }
                else {
                    flag = false;
                    for (var j = 0; j < $scope.backupAnagrafiche[i].elenco_inquilini.length; j++) {
                        for (var k = 0; k < $scope.filtroConduttori.length; k++) {
                            if ($scope.backupAnagrafiche[i].elenco_inquilini[j].id == $scope.filtroConduttori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                var flag = false;
                if ($scope.tipoAnagrafica == '-1') {
                    flag = true;
                }
                else {
                    if ($scope.tipoAnagrafica == 'L' && $scope.backupAnagrafiche[i].proprietario > 0) {
                        flag = true;
                    }
                    if ($scope.tipoAnagrafica == 'C' && $scope.backupAnagrafiche[i].inquilino > 0) {
                        flag = true;
                    }
                }
                if (flag == true) {
                    $scope.anagrafiche.push($scope.backupAnagrafiche[i]);
                }
            }
        }
    };

}])
;