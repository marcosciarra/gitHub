<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 05/01/18
 * Time: 9.10
 */

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';

require_once '../../../src/function/functionGeneric.php';
require_once '../../../src/function/functionDate.php';

require_once '../../../src/model/Anagrafiche.php';
require_once '../../../src/model/UnitaImmobiliari.php';

use Click\Affitti\TblBase\Anagrafiche;
use Click\Affitti\TblBase\UnitaImmobiliari;

function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        // CARICO DATI
        $anagrafiche = new Anagrafiche($con);
        $anagrafiche->setWhereBase(' cestino=0 ');
        $result['anagrafiche'] = [];
        foreach ($anagrafiche->getElencoAnagrafiche(true, Anagrafiche::FETCH_KEYARRAY) as $ana) {
            $imm = new UnitaImmobiliari($con);
            $ana['immobili'] = $imm->elencoImmobiliPerAnagrafica($ana['anagrafica_id'], UnitaImmobiliari::FETCH_KEYARRAY);
            $ana['elenco_proprietari'] = $anagrafiche->elencoProprietariPerInquilini($ana['anagrafica_id'], Anagrafiche::FETCH_KEYARRAY);
            $ana['elenco_inquilini'] = $anagrafiche->elencoInquiliniPerProprietario($ana['anagrafica_id'], Anagrafiche::FETCH_KEYARRAY);
            $result['anagrafiche'][] = $ana;
        }

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
