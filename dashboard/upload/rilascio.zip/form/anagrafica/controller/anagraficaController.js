ngApp.controller("anagraficaController", ["$scope", "$http", function ($scope, $http) {

    var url = window.location.href;
    var params = decodeUrl(url);
    stampalog(params);

    $scope.elencoStatiUtente = [{id: '0', descrizione: 'Attivo'}, {id: '1', descrizione: 'Bloccato'}];
    $scope.statoUtenteFiltri = '0';
    $scope.tipoAnagrafica = '-1';
    $scope.tipoanagrafica = [
        {id: '-1', descrizione: 'Tutti'},
        {id: 'S', descrizione: 'Gestore'},
        {id: 'L', descrizione: 'Locatore'},
        {id: 'C', descrizione: 'Conduttore'},
        {id: 'F', descrizione: 'Fornitore'},
        {id: 'A', descrizione: 'Amministratore'}
    ];

    $scope.caricamentoCompletato = false;

    /***********************************
     *   SOSPENDI/RIATTIVA ANAGRAFICA  * ================================================================================================
     ***********************************/

    $scope.sospendi = function (id) {

        swal({
                title: "Confermi modifica alla scheda anagrafica?",
                text: "",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: "btn-danger",
                confirmButtonText: "Si",
                cancelButtonText: "No",
                closeOnConfirm: false,
                closeOnCancel: true
            },
            function (isConfirm) {
                if (isConfirm) {
                    $http.post(params['form'] + '/anagrafica/controller/anagraficaHandler.php',
                        {'function': 'gestisciStatoAnagrafica', 'id': id}
                    ).then(function (data, status, headers, config) {
                        stampalog(data.data);
                        if (data.data.status == "ok") {
                            swal({title: "Modifica eseguita!", text: "", type: "success"},
                                function () {
                                    window.location.reload();
                                }
                            );
                        }
                        else {
                            swal("Errore durante l'operazione", "", "error");
                        }
                    });
                }
            });
    };

    /******************
     *   CARICADATI   * ================================================================================================
     ******************/

    $scope.init = function () {
        $scope.caricaDati();
    };

    $scope.caricaDati = function () {
        $http.post(params['form'] + '/anagrafica/controller/anagraficaHandler.php',
            {'function': 'caricaDati'}
        ).then(function (data, status, headers, config) {

            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }
            $scope.anagrafiche = data.data.anagrafiche;


            if ($scope.anagrafiche != null) {
                for (var i = 0; i < $scope.anagrafiche.length; i++) {
                    $scope.anagrafiche[i].cellulari = jsonParse($scope.anagrafiche[i].cellulari);
                    if ($scope.anagrafiche[i].cellulari != null) {
                        $scope.anagrafiche[i].primoCellulare = $scope.anagrafiche[i].cellulari[0];
                    }
                    else {
                        $scope.anagrafiche[i].primoCellulare = '';
                    }

                    $scope.anagrafiche[i].email = jsonParse($scope.anagrafiche[i].email);
                    if ($scope.anagrafiche[i].email != null) {
                        for (var j = 0; j < $scope.anagrafiche[i].email.length; j++) {
                            if ($scope.anagrafiche[i].email[j].predefinito == true) {
                                $scope.anagrafiche[i].primaEmail = $scope.anagrafiche[i].email[j];
                            }
                        }
                    }
                    else {
                        $scope.anagrafiche[i].primaEmail = '';
                    }

                    $scope.anagrafiche[i].indirizzi = jsonParse($scope.anagrafiche[i].indirizzi);
                    if ($scope.anagrafiche[i].indirizzi != null) {
                        for (var j = 0; j < $scope.anagrafiche[i].indirizzi.length; j++) {
                            if ($scope.anagrafiche[i].indirizzi[j].indirizzo_spedizione == true) {
                                $scope.anagrafiche[i].primoIndirizzo =
                                    $scope.anagrafiche[i].indirizzi[j].via + ' ' +
                                    $scope.anagrafiche[i].indirizzi[j].civico + ' - ' +
                                    $scope.anagrafiche[i].indirizzi[j].citta
                                ;
                            }
                        }
                    }
                    else {
                        $scope.anagrafiche[i].primoIndirizzo = '';
                    }

                    $scope.anagrafiche[i].telefoni = jsonParse($scope.anagrafiche[i].telefoni);
                    if ($scope.anagrafiche[i].telefoni != null) {
                        $scope.anagrafiche[i].primoTelefono = $scope.anagrafiche[i].telefoni[0];
                    }
                    else {
                        $scope.anagrafiche[i].primoTelefono = '';
                    }
                }
            }
            $scope.anagraficheAppoggio = angular.copy($scope.anagrafiche);
            stampalog($scope.anagrafiche);
            $scope.caricamentoCompletato = true;
        });
        $http.post(params['form'] + '/anagrafica/controller/anagraficaHandler.php',
            {'function': 'findElenchiPerSelect'}
        ).then(function (data, status, headers, config) {
            $scope.elencoTipiSoggetto = data.data.elencoTipiSoggetto;
            if ($scope.elencoTipiSoggetto != null) {
                $scope.elencoTipiSoggetto.push({id: -1, descrizione: "Tutti"});
                $scope.tipoSoggettoSelezionato = -1;
                $scope.filtri();
            }
        });

    };

    $scope.filtri = function () {
        $scope.anagrafiche = [];

        for (var i = 0; i < $scope.anagraficheAppoggio.length; i++) {
            var flag = false;
            if ($scope.tipoSoggettoSelezionato == -1 || $scope.anagraficheAppoggio[i].tipi_soggetto_id == $scope.tipoSoggettoSelezionato) {
                if ($scope.anagraficheAppoggio[i].cestino == $scope.statoUtenteFiltri) {
                    if ($scope.tipoAnagrafica == '-1') {
                        flag = true;
                    }
                    else {
                        if ($scope.tipoAnagrafica == 'S' && $scope.anagraficheAppoggio[i].societa_fatturazione > 0) {
                            flag = true;
                        }
                        if ($scope.tipoAnagrafica == 'L' && $scope.anagraficheAppoggio[i].proprietario > 0) {
                            flag = true;
                        }
                        if ($scope.tipoAnagrafica == 'C' && $scope.anagraficheAppoggio[i].inquilino > 0) {
                            flag = true;
                        }
                        if ($scope.tipoAnagrafica == 'F' && $scope.anagraficheAppoggio[i].fornitore > 0) {
                            flag = true;
                        }
                        if ($scope.tipoAnagrafica == 'A' && $scope.anagraficheAppoggio[i].amministratore_condominio > 0) {
                            flag = true;
                        }
                    }
                }
            }
            if (flag == true) {
                $scope.anagrafiche.push($scope.anagraficheAppoggio[i]);
            }
        }
        //
        //
        // if ($scope.tipoSoggettoSelezionato == -1) {
        //     angular.forEach($scope.anagraficheAppoggio, function (value) {
        //         if (value.cestino == $scope.statoUtenteFiltri) {
        //             $scope.anagrafiche.push(value);
        //         }
        //     });
        // } else {
        //     angular.forEach($scope.anagraficheAppoggio, function (value) {
        //         if (value.tipi_soggetto_id == $scope.tipoSoggettoSelezionato) {
        //             if (value.cestino == $scope.statoUtenteFiltri) {
        //                 $scope.anagrafiche.push(value);
        //             }
        //         }
        //     });
        // }
    };

    $scope.modifica = function (id) {
        window.location.href = params['home'] + encodeUrl('anagrafica', 'gestioneAnagrafica', id);
    };

    $scope.caricaDettagliModale = function (indice, etichetta) {
        $scope.dataTarget = null;
        switch (etichetta) {
            case 'Telefoni':
                $scope.dataTarget = '#modaleDettagliTelefoni';
                $scope.elencoModaleCellulari = $scope.anagrafiche[indice].cellulari;
                $scope.elencoModaleTelefoni = $scope.anagrafiche[indice].telefoni;
                break;
            case 'Email':
                $scope.dataTarget = '#modaleDettagliEmail';
                $scope.elencoModale = $scope.anagrafiche[indice].email;
                break;
            case 'Indirizzi':
                $scope.dataTarget = '#modaleDettagliIndirizzi';
                $scope.elencoModale = $scope.anagrafiche[indice].indirizzi;
                break;
        }

        $scope.etichettaModale = etichetta;
    };

    /*******************
     *   ESPORTA PDF   * ================================================================================================
     *******************/

    $scope.visualizzaImpoStampa = false;
    $scope.showImpostazioniStampa = function () {
        $scope.visualizzaImpoStampa = !$scope.visualizzaImpoStampa;
    };

    $scope.stampa = getStrutturaBasePDF();
    $scope.stampa.nomeFile = "anagrafica";

    $scope.getHeaderTable = function () {
        return ["TIPO SOGGETTO", "NOME", "CF", "P.IVA"];
    };

    $scope.creaFileDaScaricare = function () {
        $scope.fileExport = new Array();

        for (i = 0; i < $scope.anagraficheFiltrate.length; i++) {

            app = new Array();
            $scope.anagraficheFiltrate[i].descrizione != null ? app.push("" + $scope.anagraficheFiltrate[i].descrizione) : app.push("");
            $scope.anagraficheFiltrate[i].nome != null ? app.push("" + $scope.anagraficheFiltrate[i].nome) : app.push("");
            $scope.anagraficheFiltrate[i].codice_fiscale != null ? app.push("" + $scope.anagraficheFiltrate[i].codice_fiscale) : app.push("");
            $scope.anagraficheFiltrate[i].partita_iva != null ? app.push("" + $scope.anagraficheFiltrate[i].partita_iva) : app.push("");
            // $scope.anagraficheFiltrate[i].nascita_data != null ? app.push(""+$scope.anagraficheFiltrate[i].nascita_data) : app.push("");

            $scope.fileExport.push(app);
        }

        //stampalog("File da scaricare:");
        //stampalog($scope.fileExport);

        return $scope.fileExport;
    };

    $scope.scaricaPDF = function () {
        scaricaPDF($scope.stampa, $scope.getHeaderTable(), $scope.creaFileDaScaricare());
    };

}]);