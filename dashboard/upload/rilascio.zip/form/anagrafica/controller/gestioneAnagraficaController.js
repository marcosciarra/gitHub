ngApp.controller('gestioneAnagraficaController', ['$scope', '$http', '$filter', 'FileUploader', "ngToast", function ($scope, $http, $filter, FileUploader, $ngToast) {

    var params = decodeUrl(window.location.href, ['id_anagrafica']);
    $scope.showRefresh = true;
    $scope.showIndietro = true;
    $scope.showOptionsButtons = true;

    var uploader = $scope.uploader = new FileUploader({
        url: '../src/function/upload.php'
    });


    uploader.onCompleteItem = function (fileItem, response, status, headers) {
        if ($scope.caricaLogo == true) {
            $scope.nuovaSchedaAnagrafica.file_logo = response['fileName'];
            $ngToast.create({className: 'success', content: 'Logo caricato', dismissButton: true, timeout: 1500});
        }
        if ($scope.caricaFirma == true) {
            $scope.nuovaSchedaAnagrafica.file_firma = response['fileName'];
            $ngToast.create({className: 'success', content: 'Firma caricata', dismissButton: true, timeout: 1500});
        }
        $scope.caricaLogo = false;
        $scope.caricaFirma = false;
    };


    //sostituisce l'onload, da richiamare nel tag in cui si definisce il controller
    $scope.init = function () {
        $scope.caricamentoCompletato = false;
        $scope.getStrutturaAnagrafica();
        $scope.caricaComuniCorti();
        // SET sigla nazione a 'IT'
        $scope.statoBanca = 'IT';
        $scope.elencoCC = [];
        $scope.tipoCassa = '0';
        $scope.mostraFormBanca = false;
        $scope.indirizzoSpedizionePresente = 0;
        $scope.nomeFileLogo = '';
        $scope.nomeFileFirma = '';
        $scope.caricaLogo = false;
        $scope.caricaFirma = false;
        $scope.fileUpload = '';
        $scope.visualizza = 'datiAnagrafici';
        $scope.mostraFormIndirizzo = false;
        $scope.mostraFormEmail = false;
        $scope.mostraFormTelefono = false;
        $scope.mostraFormCellulare = false;
        $scope.indirizzoCorretto = false;
        $scope.ccCorretto = false;
        $scope.ccFormalmenteValido = false;
    };


    // SELECT tipo [] - titolo[]
    //$scope.tipoPrivato = true;
    $scope.titoliDisponibili = ['Sig', 'Sig.ra', 'Sigg.', 'Ing.', 'Dott.', 'Dott.ssa', 'Avv.', 'Cav.', 'On.', 'Sen.', 'Spett.le'];
    // END SELECT tipo [] - titolo[]


    $scope.immobileCorrispondente = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("immobili", "gestioneUnitaImmobiliari", id);
    };

    $scope.mostraSezione = function (tab) {
        $scope.visualizza = tab;
    };

    /* =========================================== MODIFICA ========================================== */
    $scope.modifica = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("anagrafica", "gestioneAnagrafica", id);
    };
    /* =========================================== /MODIFICA ========================================= */

    /* =========================================== BANCHE ========================================== */

    $scope.$watchGroup(["tipoCassa", "nuovoContoCorrente.nazione", "nuovoContoCorrente.ckdigit",
        "nuovoContoCorrente.cin", "nuovoContoCorrente.abi", "nuovoContoCorrente.cab",
        "nuovoContoCorrente.conto", "nuovoContoCorrente.agenzia", "nuovoContoCorrente.intestatario",
        "nuovoContoCorrente.sia", "nuovoContoCorrente.cuc", "nuovoContoCorrente.spese_incasso"], function () {
        if ($scope.nuovoContoCorrente) {
            if ($scope.tipoCassa == "0") {
                $scope.ccTmp = $scope.nuovoContoCorrente.nazione + $scope.nuovoContoCorrente.ckdigit + $scope.nuovoContoCorrente.cin
                    + $scope.nuovoContoCorrente.abi + $scope.nuovoContoCorrente.cab + $scope.nuovoContoCorrente.conto;
                $scope.ccFormalmenteValido = controllaIbanIT($scope.ccTmp);
                if ($scope.ccFormalmenteValido && $scope.abiCorretto &&
                    $scope.nuovoContoCorrente.agenzia != "" && $scope.nuovoContoCorrente.agenzia != null) {
                    $scope.ccCorretto = true;
                } else {
                    $scope.ccCorretto = false;
                }
            } else {
                if ($scope.nuovoContoCorrente.agenzia != "" && $scope.nuovoContoCorrente.agenzia != null) {
                    $scope.ccCorretto = true;
                } else {
                    $scope.ccCorretto = false;
                }
            }
        }
    });

    $scope.ricercaBanca = function (abi) {
        $scope.abiCorretto = false;
        if (abi != undefined || abi.length > 4) {
            $http.post($scope.params['form'] + '/anagrafica/controller/gestioneAnagraficaHandler.php',
                {'function': 'caricaDatiBanca', 'abi': abi}
            ).then(function (data, status, headers, config) {
                stampalog(data.data);
                if (data.data.abi == abi) {
                    $scope.nuovoContoCorrente.nomeBanca = data.data.descrizione;
                    $scope.nuovoContoCorrente.id_banca = data.data.abi;
                    $scope.nuovoContoCorrente.abi = data.data.abi;
                    $scope.abiCorretto = true;
                } else {
                    $scope.nuovoContoCorrente.nomeBanca = null;
                    $scope.nuovoContoCorrente.id_banca = null;
                    $scope.abiCorretto = false;
                }
            })
        }
    };

    $scope.controllaIban = function () {
        var tmp = $scope.nuovoContoCorrente.nazione + $scope.nuovoContoCorrente.ckdigit + $scope.nuovoContoCorrente.cin
            + $scope.nuovoContoCorrente.abi + $scope.nuovoContoCorrente.cab + $scope.nuovoContoCorrente.conto;

        $scope.nuovoContoCorrente.display = $scope.nuovoContoCorrente.nazione + ' ' + $scope.nuovoContoCorrente.ckdigit + ' '
            + $scope.nuovoContoCorrente.cin + ' ' + $scope.nuovoContoCorrente.abi + ' '
            + $scope.nuovoContoCorrente.cab + ' ' + $scope.nuovoContoCorrente.conto;
        if ($scope.nuovoContoCorrente.intestatario == '')
            $scope.nuovoContoCorrente.intestatario = $scope.nuovoContoCorrente.agenzia;

        if ($scope.nuovoContoCorrente.agenzia != null) {
            $scope.nuovoContoCorrente.nomeBanca = $scope.nuovoContoCorrente.nomeBanca + ' - ' + $scope.nuovoContoCorrente.agenzia;
        }
        if ($scope.nuovoCCIndice > -1) {
            $scope.elencoCC [$scope.nuovoCCIndice] = angular.copy($scope.nuovoContoCorrente);
        } else {
            $scope.elencoCC.push($scope.nuovoContoCorrente);
            $scope.nuovoContoCorrente = angular.copy($scope.nuovoContoCorrenteApp);
        }
        $scope.resetCC();
        $scope.mostraFormBanca = false;
    };

    $scope.salvaDatiCassa = function () {
        if ($scope.nuovoContoCorrente.agenzia.length > 0) {
            $scope.nuovoContoCorrente.intestatario = $scope.nuovoContoCorrente.agenzia;
            $scope.nuovoContoCorrente.nomeBanca = $scope.nuovoContoCorrente.agenzia;
            if ($scope.nuovoCCIndice > -1) {
                $scope.elencoCC [$scope.nuovoCCIndice] = angular.copy($scope.nuovoContoCorrente);
            } else {
                $scope.elencoCC.push($scope.nuovoContoCorrente);
                $scope.nuovoContoCorrente = angular.copy($scope.nuovoContoCorrenteApp);
            }
            $scope.resetCC();
            $scope.mostraFormBanca = false;
        }
    };

    $scope.eliminaCC = function (i) {
        $scope.elencoCC.splice(i, 1);
    };
    $scope.modificaCC = function (obj, i) {
        $scope.nuovoCCIndice = i;
        $scope.mostraFormBanca = true;
        $scope.nuovoContoCorrente = angular.copy(obj);
        $scope.ricercaBanca(obj.abi);
        if ($scope.nuovoContoCorrente.abi == null || $scope.nuovoContoCorrente.abi == '') {
            $scope.tipoCassa = '1';
        } else {
            $scope.tipoCassa = '0';
        }
        $scope.ccCorretto = true;
    };

    $scope.resetCC = function () {
        $scope.nuovoContoCorrente = angular.copy($scope.nuovoContoCorrenteApp);
        //$scope.mostraFormBanca = false;
        $scope.nuovoCCIndice = -1;
    };

    /* =========================================== COMUNI ========================================= */
    $scope.caricaComuniCorti = function () {
        $http.post($scope.params['form'] + '/anagrafica/controller/gestioneAnagraficaHandler.php',
            {'function': 'getListaComuniCorti'}
        ).then(function (data, status, headers, config) {
            $scope.listaComuni = data.data;
            $scope.listaComuniApp = data.data;
        })
    };

    $scope.ricercaCitta = function (c, idForm) {
        //var indice = $scope.listaComuni.indexOf(c);
        //stampalog($scope.listaComuni);
        //stampalog(indice);
        var appoggio = $filter('filter')($scope.listaComuni, {denominazione: c}, true)[0];

        if (c.length > 4 || appoggio != undefined) {
            $http.post($scope.params['form'] + '/anagrafica/controller/gestioneAnagraficaHandler.php',
                {'function': 'aggiornaCitta', 'c': c}
            ).then(function (data, status, headers, config) {
                if (c.length > 4) {
                    $scope.listaComuni = $scope.listaComuni.concat(data.data);
                }
                appoggio = $filter('filter')($scope.listaComuni, {denominazione: c}, true)[0];
                if (appoggio != undefined) {
                    $http.post($scope.params['form'] + '/anagrafica/controller/gestioneAnagraficaHandler.php',
                        {'function': 'caricaDatiComune', 'id': appoggio.id}
                    ).then(function (data, status, headers, config) {
                        // setto campi
                        if (idForm == 1) {
                            $scope.nuovaSchedaAnagrafica.nascita_provincia = data.data.sigla_automobilistica;
                            $scope.nuovaSchedaAnagrafica.nascita_stato = data.data.alpha2;
                            $scope.listaComuni = $scope.listaComuniApp;
                            $scope.codiceCatastalePerCF = data.data.codice_catastale;
                            //$scope.campiCFCompilati();
                            //$scope.controllaDati();
                        } else {
                            $scope.nuovoIndirizzo.cap = data.data.cap;
                            $scope.nuovoIndirizzo.provincia = data.data.sigla_automobilistica;
                            $scope.nuovoIndirizzo.stato = data.data.alpha2;
                            $scope.controllaIndirizzo();
                        }

                    })
                }

                //se non trova nessun comune con quel nome setta stato a 'EE'
                if ($scope.listaComuni.length == 0) {
                    $scope.nuovaSchedaAnagrafica.nascita_stato = 'EE';
                }
            })
        }
    };


    /* =========================================== STRUTTURA NUOVO CLIENTE ========================================== */

    $scope.getStrutturaAnagrafica = function () {

        var idAnagrafica = 0;
        if (params['id_anagrafica'] !== undefined)
            idAnagrafica = params['id_anagrafica'];

        $http.post($scope.params['form'] + '/anagrafica/controller/gestioneAnagraficaHandler.php',
            {'function': 'caricaDati', 'idAnagrafica': idAnagrafica}
        ).then(function (data, status, headers, config) {

            if (data.data.status == "ko") {
                swal("Errore", "Caricamento non riuscito", "error");
                return;
            }
            $scope.elencoAnagrafica = data.data.elencoAnagrafica;
            //$scope.elencoAnagrafica.unshift({id:0,descrizione:"nessuno"});

            $scope.nuovaSchedaAnagrafica = data.data.anagrafica;
            if (data.data.anagrafica.file_logo != null) {
                if (data.data.anagrafica.file_logo.length > 0) {
                    $scope.percorso_file_logo = '../upload/' + data.data.anagrafica.file_logo;
                } else {
                    $scope.percorso_file_logo = '';
                }
            }

            $scope.presettaDatiDefault(data);

            $scope.elencoUtenti = data.data.elencoUtenti;
            $scope.immobili = data.data.immobili;
            for (var i = 0; i < $scope.immobili.length; i++) {
                $scope.immobili[i].indirizzo = jsonParse($scope.immobili[i].indirizzo);
            }


            if (data.data.anagrafica.id != null) {
                (data.data.anagrafica.indirizzi != null) ?
                    $scope.nuovaSchedaAnagrafica.indirizzi = jsonParse(data.data.anagrafica.indirizzi) :
                    $scope.nuovaSchedaAnagrafica.indirizzi = [];
                (data.data.anagrafica.telefoni != null) ?
                    $scope.nuovaSchedaAnagrafica.telefoni = jsonParse(data.data.anagrafica.telefoni) :
                    $scope.nuovaSchedaAnagrafica.telefoni = [];
                (data.data.anagrafica.cellulari != null) ?
                    $scope.nuovaSchedaAnagrafica.cellulari = jsonParse(data.data.anagrafica.cellulari) :
                    $scope.nuovaSchedaAnagrafica.cellulari = [];
                (data.data.anagrafica.email != null) ?
                    $scope.nuovaSchedaAnagrafica.email = jsonParse(data.data.anagrafica.email) :
                    $scope.nuovaSchedaAnagrafica.email = [];
                (data.data.anagrafica.pec != null) ?
                    $scope.nuovaSchedaAnagrafica.pec = jsonParse(data.data.anagrafica.pec) :
                    $scope.nuovaSchedaAnagrafica.pec = [];

                $scope.nuovaSchedaAnagrafica.nascita_data = new Date($scope.nuovaSchedaAnagrafica.nascita_data);
                $scope.nuovaSchedaAnagrafica.tipoGruppo = '' + data.data.anagrafica.tipoGruppo;
                $scope.elencoCC = data.data.anagrafica.elencoCC;
                $scope.rappresentanteLegale = [];
                if (data.data.anagrafica.id_rappresentante > 0 && data.data.anagrafica.id_rappresentante != null) {
                    $scope.rappresentanteLegale = [$filter('filter')($scope.elencoAnagrafica, {id: data.data.anagrafica.id_rappresentante}, true)[0]];
                }
                if (data.data.anagrafica.codice_fiscale.length == 16) {
                    $scope.codiceCatastalePerCF = data.data.anagrafica.codice_fiscale.substr(11, 4)
                }

            } else {
                $scope.selectTipoPersone($scope.nuovaSchedaAnagrafica.tipoGruppo);
                $scope.nuovaSchedaAnagrafica.indirizzi = [];
                $scope.nuovaSchedaAnagrafica.telefoni = [];
                $scope.nuovaSchedaAnagrafica.cellulari = [];
                $scope.nuovaSchedaAnagrafica.email = [];
                $scope.nuovaSchedaAnagrafica.pec = [];
                $scope.contoCorrente = [];
                $scope.rappresentanteLegale = [];
            }

            $scope.regimeFiscaleSelect = data.data.regimeFiscale;

            $scope.tipiDisponibili = data.data.elencoTipiSoggetto;

            $scope.nuovoIndirizzo = data.data.nuovoIndirizzo;
            $scope.nuovoIndirizzoApp = angular.copy(data.data.nuovoIndirizzo);
            $scope.nuovoIndirizzoIndice = -1;
            $scope.nuovoTelefono = data.data.nuovoTelefono;
            $scope.nuovoTelefonoApp = angular.copy(data.data.nuovoTelefono);
            $scope.nuovoTelefonoIndice = -1;
            $scope.nuovoCellulare = data.data.nuovoCellulare;
            $scope.nuovoCellulareApp = angular.copy(data.data.nuovoCellulare);
            $scope.nuovoCellulareIndice = -1;
            $scope.nuovoEmail = data.data.nuovoEmail;
            $scope.nuovoEmailApp = angular.copy(data.data.nuovoEmail);
            $scope.nuovoEmailIndice = -1;
            $scope.nuovoPec = data.data.nuovoPec;
            $scope.nuovoPecApp = angular.copy(data.data.nuovoPec);
            $scope.nuovoPecIndice = -1;

            $scope.nuovoContoCorrente = data.data.nuovoContoCorrente;
            $scope.nuovoContoCorrenteApp = angular.copy(data.data.nuovoContoCorrente);
            $scope.contrattiAttivi = data.data.contrattiAttivi;
            $scope.contrattiAttivi == 0 ? $scope.avvisoGestore = '' : $scope.avvisoGestore = 'Uno o più contratti attivi';
            //$scope.controllaDati();

            stampalog($scope.nuovaSchedaAnagrafica);
        });

        $scope.caricamentoCompletato = true;
    };

    $scope.presettaDatiDefault = function (data) {
        $scope.tipiSoggettoPersonaFisicaDefault = data.data.tipiSoggettoPersonaFisicaDefault;
        $scope.tipiSoggettoSocietaDefault = data.data.tipiSoggettoSocietaDefault;
        $scope.tipiSoggettoDittaIndividualeDefault = data.data.tipiSoggettoDittaIndividualeDefault;
    };

    $scope.selectTipoPersone = function () {
        $scope.datiCorretti = false;
        $scope.calcolaCF = false;
        if ($scope.nuovaSchedaAnagrafica.tipoGruppo == '1') {
            $scope.nuovaSchedaAnagrafica.id_tipi_soggetto = $scope.tipiSoggettoPersonaFisicaDefault;
            $scope.nuovaSchedaAnagrafica.partita_iva_nazione = null;
            //$scope.tipoPrivato = true;
        } else if ($scope.nuovaSchedaAnagrafica.tipoGruppo == '2') {
            $scope.nuovaSchedaAnagrafica.id_tipi_soggetto = $scope.tipiSoggettoSocietaDefault;
            $scope.nuovaSchedaAnagrafica.partita_iva_nazione = "IT";
            //$scope.tipoPrivato = false;
        } else if ($scope.nuovaSchedaAnagrafica.tipoGruppo == '3') {
            $scope.nuovaSchedaAnagrafica.id_tipi_soggetto = $scope.tipiSoggettoDittaIndividualeDefault;
            $scope.nuovaSchedaAnagrafica.partita_iva_nazione = "IT";
            //$scope.tipoPrivato = false;
        }
        //$scope.controllaDati();
    };

    // INDIRIZZI
    $scope.$watchGroup(["nuovoIndirizzo.citta", "nuovoIndirizzo.civico", "nuovoIndirizzo.cap",
        "nuovoIndirizzo.provincia", "nuovoIndirizzo.stato", "nuovoIndirizzo.via"], function () {
        if ($scope.nuovoIndirizzo) {
            if ($scope.nuovoIndirizzo.via != "" &&
                $scope.nuovoIndirizzo.citta != "" &&
                $scope.nuovoIndirizzo.stato != "" &&
                $scope.nuovoIndirizzo.civico != ""
            ) {
                if ($scope.nuovoIndirizzo.stato == "IT") {
                    if ($scope.nuovoIndirizzo.cap == "" || $scope.nuovoIndirizzo.provincia == "") {
                        $scope.indirizzoCorretto = false;
                    } else {
                        $scope.indirizzoCorretto = true;
                    }
                } else {
                    $scope.nuovoIndirizzo.provincia = "EE";
                    $scope.indirizzoCorretto = true;
                }
            } else {
                $scope.indirizzoCorretto = false;
            }
        }
    });

    $scope.aggiungiIndirizzo = function () {
        if ($scope.nuovoIndirizzo.descrizione == "") {
            $scope.nuovoIndirizzo.descrizione = $scope.nuovoIndirizzo.via + ' ' + $scope.nuovoIndirizzo.civico;
        }
        if ($scope.nuovoIndirizzoIndice != -1) {
            $scope.nuovaSchedaAnagrafica.indirizzi [$scope.nuovoIndirizzoIndice] = angular.copy($scope.nuovoIndirizzo);
        } else {
            $scope.nuovaSchedaAnagrafica.indirizzi.push($scope.nuovoIndirizzo);
        }
        $scope.resetIndirizzo();
    };

    $scope.resetIndirizzo = function () {
        $scope.mostraFormIndirizzo = false;
        $scope.nuovoIndirizzo = angular.copy($scope.nuovoIndirizzoApp);
        if ($scope.nuovaSchedaAnagrafica.indirizzi.length == 0) {
            $scope.nuovoIndirizzo.domicilio_fiscale = true;
            $scope.nuovoIndirizzo.indirizzo_spedizione = true;
        }
        $scope.nuovoIndirizzoIndice = -1;
    };

    $scope.modificaIndirizzo = function (obj, i) {
        $scope.mostraFormIndirizzo = true;
        $scope.nuovoIndirizzo = angular.copy(obj);
        $scope.nuovoIndirizzoIndice = i;
        $scope.contaIndirizziSpedizione();
    };

    $scope.eliminaIndirizzo = function (i) {
        $scope.nuovaSchedaAnagrafica.indirizzi.splice(i, 1);
    };

    $scope.controllaIndirizzo = function () {
        if ($scope.nuovoIndirizzo === undefined) {
            return false;
        }
        return (
            $scope.nuovoIndirizzo.descrizione != "" &&
            $scope.nuovoIndirizzo.via != "" &&
            $scope.nuovoIndirizzo.civico != "" &&
            $scope.nuovoIndirizzo.cap != "" &&
            $scope.nuovoIndirizzo.citta != "" &&
            $scope.nuovoIndirizzo.provincia != "" &&
            $scope.nuovoIndirizzo.stato != ""
        );
    };

    $scope.contaIndirizziSpedizione = function () {
        $scope.indirizzoSpedizionePresente = 0;
        for (var i = 0; i < $scope.nuovaSchedaAnagrafica.indirizzi.length; i++) {
            if ($scope.nuovaSchedaAnagrafica.indirizzi[i].indirizzo_spedizione == true) {
                $scope.indirizzoSpedizionePresente++;
            }
        }
    };

    $scope.contaDomicilioFiscale = function () {
        $scope.indirizzoDomicilioFiscale = 0;
        for (var i = 0; i < $scope.nuovaSchedaAnagrafica.indirizzi.length; i++) {
            if ($scope.nuovaSchedaAnagrafica.indirizzi[i].domicilio_fiscale == true) {
                $scope.indirizzoDomicilioFiscale++;
            }
        }
    };

    // TELEFONI
    $scope.$watchGroup(["nuovoTelefono.descrizione", "nuovoTelefono.telefono"], function () {
        if ($scope.nuovoTelefono) {
            if ($scope.nuovoTelefono.descrizione != "" &&
                $scope.nuovoTelefono.telefono != ""
            ) {
                $scope.telefonoValido = true;
            } else {
                $scope.telefonoValido = false;
            }
        }
    });

    $scope.aggiungiTelefono = function () {
        if ($scope.nuovoTelefonoIndice != -1) {
            $scope.nuovaSchedaAnagrafica.telefoni [$scope.nuovoTelefonoIndice] = angular.copy($scope.nuovoTelefono);
        } else {
            $scope.nuovaSchedaAnagrafica.telefoni.push($scope.nuovoTelefono);
        }
        $scope.resetTelefono();
    };

    $scope.resetTelefono = function () {
        $scope.mostraFormTelefono = false;
        $scope.nuovoTelefono = angular.copy($scope.nuovoTelefonoApp);
        $scope.nuovoTelefonoIndice = -1;
    };

    $scope.modificaTelefono = function (obj, i) {
        $scope.mostraFormTelefono = true;
        $scope.nuovoTelefono = angular.copy(obj);
        $scope.nuovoTelefonoIndice = i;
    };

    $scope.eliminaTelefono = function (i) {
        $scope.nuovaSchedaAnagrafica.telefoni.splice(i, 1);
    };

    // CELLULARI
    $scope.$watchGroup(["nuovoCellulare.descrizione", "nuovoCellulare.cellulare"], function () {
        if ($scope.nuovoCellulare) {
            if ($scope.nuovoCellulare.descrizione != "" &&
                $scope.nuovoCellulare.cellulare != ""
            ) {
                $scope.cellulareValido = true;
            } else {
                $scope.cellulareValido = false;
            }
        }
    });

    $scope.aggiungiCellulare = function () {
        if ($scope.nuovoCellulareIndice != -1) {
            $scope.nuovaSchedaAnagrafica.cellulari [$scope.nuovoCellulareIndice] = angular.copy($scope.nuovoCellulare);
        } else {
            $scope.nuovaSchedaAnagrafica.cellulari.push($scope.nuovoCellulare);
        }
        $scope.resetCellulare();
    };

    $scope.resetCellulare = function () {
        $scope.mostraFormCellulare = false;
        $scope.nuovoCellulare = angular.copy($scope.nuovoCellulareApp);
        $scope.nuovoCellulareIndice = -1;
    };

    $scope.modificaCellulare = function (obj, i) {
        $scope.mostraFormCellulare = true;
        $scope.nuovoCellulare = angular.copy(obj);
        $scope.nuovoCellulareIndice = i;
    };

    $scope.eliminaCellulare = function (i) {
        $scope.nuovaSchedaAnagrafica.cellulari.splice(i, 1);
    };

    // EMAIL
    $scope.$watchGroup(["nuovoEmail.descrizione", "nuovoEmail.email"], function () {
        if ($scope.nuovoEmail) {
            //var predefinite = $scope.contaEmailPredefinite();
            /*
                        if ($scope.nuovoEmail.predefinito && predefinite > 0) {
                            swal("Errore", 'Indirizzo predefinito già selezionato', "error");
                            return;
                        } else {

                            if ($scope.nuovoEmailIndice != -1) {
                                $scope.nuovaSchedaAnagrafica.email [$scope.nuovoEmailIndice] = angular.copy($scope.nuovoEmail);
                            } else {
                                $scope.nuovaSchedaAnagrafica.email.push($scope.nuovoEmail);
                            }
                            $scope.resetEmail();
                        }
            */
            if ($scope.nuovoEmail === undefined)
                $scope.emailCorretta = false;

            if ($scope.nuovoEmail.descrizione != "" && controllaEmail($scope.nuovoEmail.email)) {
                $scope.emailCorretta = true;
            } else {
                $scope.emailCorretta = false;
            }
        }
    });

    $scope.$watchGroup(["nuovoPec.descrizione", "nuovoPec.pec"], function () {
        if ($scope.nuovoPec) {
            if ($scope.nuovoPec === undefined)
                $scope.pecCorretta = false;

            if ($scope.nuovoPec.descrizione != "" && controllaEmail($scope.nuovoPec.pec)) {
                $scope.pecCorretta = true;
            } else {
                $scope.pecCorretta = false;
            }
        }
    });

    $scope.aggiungiEmail = function () {
        var predefinite = $scope.contaEmailPredefinite();

        if ($scope.nuovoEmail.predefinito && predefinite > 0) {
            swal("Errore", 'Indirizzo predefinito già selezionato', "error");
            return;
        } else {

            if ($scope.nuovoEmailIndice != -1) {
                $scope.nuovaSchedaAnagrafica.email [$scope.nuovoEmailIndice] = angular.copy($scope.nuovoEmail);
            } else {
                $scope.nuovaSchedaAnagrafica.email.push($scope.nuovoEmail);
            }
            $scope.resetEmail();
        }
    };

    $scope.aggiungiPec = function () {
        var predefinitePec = $scope.contaPecPredefinite();

        if ($scope.nuovoPec.predefinitoPec && predefinitePec > 0) {
            swal("Errore", 'Indirizzo predefinito già selezionato', "error");
            return;
        } else {
            if ($scope.nuovoPecIndice != -1) {
                //Se modifico una Pec usata per la fatturazione elettronica, modifico anche l'indirizzo nella sezione fatturazione elettronica
                if ($scope.nuovaSchedaAnagrafica.pec [$scope.nuovoPecIndice].pec == $scope.nuovaSchedaAnagrafica.fattura_elettronica_mittente_pec)
                    $scope.nuovaSchedaAnagrafica.fattura_elettronica_mittente_pec = $scope.nuovoPec.pec;
                if ($scope.nuovaSchedaAnagrafica.pec [$scope.nuovoPecIndice].pec == $scope.nuovaSchedaAnagrafica.fattura_elettronica_destinatario_pec)
                    $scope.nuovaSchedaAnagrafica.fattura_elettronica_destinatario_pec = $scope.nuovoPec.pec;

                $scope.nuovaSchedaAnagrafica.pec [$scope.nuovoPecIndice] = angular.copy($scope.nuovoPec);
            } else {
                $scope.nuovaSchedaAnagrafica.pec.push($scope.nuovoPec);
            }
            $scope.resetPec();
        }
        stampalog($scope.nuovaSchedaAnagrafica);
    };

    $scope.resetEmail = function () {
        $scope.mostraFormEmail = false;
        $scope.emailCorretta = false;
        $scope.nuovoEmail = angular.copy($scope.nuovoEmailApp);
        if ($scope.nuovaSchedaAnagrafica.email.length == 0) {
            $scope.nuovoEmail.predefinito = true;
        }
        $scope.nuovoEmailIndice = -1;
    };

    $scope.resetPec = function () {
        $scope.mostraFormPec = false;
        $scope.pecCorretta = false;
        $scope.nuovoPec = angular.copy($scope.nuovoPecApp);
        if ($scope.nuovaSchedaAnagrafica.pec.length == 0) {
            $scope.nuovoPec.predefinitoPec = true;
        }
        $scope.nuovoPecIndice = -1;
    };

    $scope.modificaEmail = function (obj, i) {
        $scope.mostraFormEmail = true;
        $scope.nuovoEmail = angular.copy(obj);
        $scope.controllaEmail();
        $scope.nuovoEmailIndice = i;
    };

    $scope.modificaPec = function (obj, i) {
        $scope.mostraFormPec = true;
        $scope.nuovoPec = angular.copy(obj);
        $scope.controllaPec();
        $scope.nuovoPecIndice = i;
    };

    $scope.eliminaEmail = function (i) {
        $scope.nuovaSchedaAnagrafica.email.splice(i, 1);
    };

    $scope.eliminaPec = function (i) {
        if (
            $scope.nuovaSchedaAnagrafica.pec[i].pec != $scope.nuovaSchedaAnagrafica.fattura_elettronica_mittente_pec &&
            $scope.nuovaSchedaAnagrafica.pec[i].pec != $scope.nuovaSchedaAnagrafica.fattura_elettronica_destinatario_pec
        ) {
            $scope.nuovaSchedaAnagrafica.pec.splice(i, 1);
        } else {
            swal("Impossibile eliminare la PEC", 'Indirizzo già usato per le fatture elettroniche!', "error");
        }
    };

    $scope.controllaEmail = function () {

    };

    $scope.controllaPec = function () {

    };

    $scope.contaEmailPredefinite = function () {
        $scope.indirizzoEmailPredefinitoPresente = 0;
        for (var i = 0; i < $scope.nuovaSchedaAnagrafica.email.length; i++) {
            if ($scope.nuovaSchedaAnagrafica.email[i].predefinito == true) {
                stampalog($scope.nuovaSchedaAnagrafica.email[i]);
                $scope.indirizzoEmailPredefinitoPresente++;
            }
        }
        return $scope.indirizzoEmailPredefinitoPresente;
    };

    $scope.contaPecPredefinite = function () {
        $scope.indirizzoPecPredefinitoPresente = 0;
        for (var i = 0; i < $scope.nuovaSchedaAnagrafica.pec.length; i++) {
            if ($scope.nuovaSchedaAnagrafica.pec[i].predefinitoPec == true) {
                stampalog($scope.nuovaSchedaAnagrafica.pec[i]);
                $scope.indirizzoPecPredefinitoPresente++;
            }
        }
        return $scope.indirizzoPecPredefinitoPresente;
    };

    /* =============================================== CODICE FISCALE =============================================== */

    $scope.$watchGroup(["nuovaSchedaAnagrafica.nome", "nuovaSchedaAnagrafica.cognome", "nuovaSchedaAnagrafica.sesso",
        "nuovaSchedaAnagrafica.nascita_data", "nuovaSchedaAnagrafica.nascita_luogo"], function () {

        if ($scope.nuovaSchedaAnagrafica) {
            if ($scope.nuovaSchedaAnagrafica.tipoGruppo != "2") {
                if ($scope.nuovaSchedaAnagrafica.nome != "" && $scope.nuovaSchedaAnagrafica.nome != null &&
                    $scope.nuovaSchedaAnagrafica.cognome != "" && $scope.nuovaSchedaAnagrafica.cognome != null &&
                    $scope.nuovaSchedaAnagrafica.sesso != "" && $scope.nuovaSchedaAnagrafica.sesso != null &&
                    $scope.nuovaSchedaAnagrafica.nascita_data != "" && $scope.nuovaSchedaAnagrafica.nascita_data != null &&
                    $scope.nuovaSchedaAnagrafica.nascita_luogo != "" && $scope.nuovaSchedaAnagrafica.nascita_luogo != null &&
                    $scope.codiceCatastalePerCF != "" && $scope.codiceCatastalePerCF != null
                ) {
                    $scope.campiCFValidi = true;
                    if ($scope.nuovaSchedaAnagrafica.codice_fiscale.length == 0)
                        $scope.calcolaCodiceFiscale();
                } else {
                    $scope.campiCFValidi = false;
                    $scope.nuovaSchedaAnagrafica.codice_fiscale = '';
                }
            }
        }
    });

    $scope.$watch("nuovaSchedaAnagrafica.codice_fiscale", function () {
        if ($scope.nuovaSchedaAnagrafica) {
            if ($scope.nuovaSchedaAnagrafica.tipoGruppo == "2") {
                $scope.cfCorretto = controllaPIVA($scope.nuovaSchedaAnagrafica.codice_fiscale);
            } else {
                $scope.cfCorretto = controllaCF($scope.nuovaSchedaAnagrafica.codice_fiscale);
            }
        }
    });

    $scope.$watch("nuovaSchedaAnagrafica.partita_iva", function () {
        if ($scope.nuovaSchedaAnagrafica) {
            if ($scope.nuovaSchedaAnagrafica.tipoGruppo != 1) {
                $scope.pivaValida = controllaPIVA($scope.nuovaSchedaAnagrafica.partita_iva);
            }
        }
    });

    $scope.calcolaCF = false;

    $scope.campiCFCompilati = function () {
        if ($scope.nuovaSchedaAnagrafica.nome != "" && $scope.nuovaSchedaAnagrafica.nome != null &&
            $scope.nuovaSchedaAnagrafica.cognome != "" && $scope.nuovaSchedaAnagrafica.cognome != null &&
            $scope.nuovaSchedaAnagrafica.sesso != "" && $scope.nuovaSchedaAnagrafica.sesso != null &&
            $scope.nuovaSchedaAnagrafica.nascita_data != "" && $scope.nuovaSchedaAnagrafica.nascita_data != null &&
            $scope.nuovaSchedaAnagrafica.nascita_luogo != "" && $scope.nuovaSchedaAnagrafica.nascita_luogo != null &&
            $scope.codiceCatastalePerCF != "" && $scope.codiceCatastalePerCF != null
        ) {
            $scope.calcolaCF = true;
        } else {
            $scope.calcolaCF = false;
        }
    };

    $scope.calcolaCodiceFiscale = function () {
        if ($scope.nuovaSchedaAnagrafica) {
            $scope.campiCFCompilati();
            if ($scope.calcolaCF) {
                var nome = $scope.nuovaSchedaAnagrafica.nome;
                var cognome = $scope.nuovaSchedaAnagrafica.cognome;
                var sesso = $scope.nuovaSchedaAnagrafica.sesso;
                var tmp = formattaDataHtml5($scope.nuovaSchedaAnagrafica.nascita_data);
                var giorno = tmp['day'];
                var mese = tmp['month'];
                var anno = tmp['year'];
                var luogoNascita = $scope.nuovaSchedaAnagrafica.nascita_luogo;

                $scope.nuovaSchedaAnagrafica.codice_fiscale = CFisc.calcola_codice(nome, cognome, sesso, giorno, mese, anno, luogoNascita, $scope.codiceCatastalePerCF);
            }
        }
    };

    $scope.controllaDataNascita = function () {
        if ($scope.nuovaSchedaAnagrafica) {
            if (
                $scope.nuovaSchedaAnagrafica.nascita_data != "" &&
                $scope.nuovaSchedaAnagrafica.nascita_data != null &&
                isValidDate(getYYYYMMGGFromJsDate($scope.nuovaSchedaAnagrafica.nascita_data))
            ) {
                return true;
            }
        }
        return false;
    };

    /* =============================================== CONTROLLI =============================================== */
    $scope.datiCorretti = false;
    $scope.cfCorretto = false;
    $scope.dataNascitaCorretta = false;

    $scope.controllaDati = function () {
        switch ($scope.nuovaSchedaAnagrafica.tipoGruppo) {
            case '1':
                controllaDatiPFisica();
                break;
            case '2':
                controllaDatiSocieta();
                break;
            case '3':
                controllaDatiDittaIndiv();
                break;
        }
    };

    function controllaDatiPFisica() {
        if (
            $scope.nuovaSchedaAnagrafica.nome != "" && $scope.nuovaSchedaAnagrafica.nome != null &&
            $scope.nuovaSchedaAnagrafica.cognome != "" && $scope.nuovaSchedaAnagrafica.cognome != null &&
            $scope.nuovaSchedaAnagrafica.sesso != "" && $scope.nuovaSchedaAnagrafica.sesso != null &&
            $scope.nuovaSchedaAnagrafica.nascita_luogo != "" && $scope.nuovaSchedaAnagrafica.nascita_luogo != null &&
            $scope.nuovaSchedaAnagrafica.codice_fiscale != "" && $scope.nuovaSchedaAnagrafica.codice_fiscale != null &&
            $scope.nuovaSchedaAnagrafica.codice_fiscale != undefined
        ) {
            $scope.cfCorretto = controllaCF($scope.nuovaSchedaAnagrafica.codice_fiscale);
            $scope.dataNascitaCorretta = $scope.controllaDataNascita();
            if ($scope.dataNascitaCorretta && $scope.nuovaSchedaAnagrafica.nascita_data != undefined && $scope.cfCorretto) {
                $scope.datiCorretti = true;
            } else {
                $scope.datiCorretti = false;
                $scope.datiCorrettiString = 'Mancanza di dati e/o Codice Fiscale non corretto o assente';
            }
        } else {
            $scope.datiCorretti = false;
            $scope.datiCorrettiString = 'Mancanza di dati e/o Codice Fiscale non corretto o assente';
        }
    }

    function controllaDatiDittaIndiv() {
        if (
            $scope.nuovaSchedaAnagrafica.nome != "" && $scope.nuovaSchedaAnagrafica.nome != null &&
            $scope.nuovaSchedaAnagrafica.cognome != "" && $scope.nuovaSchedaAnagrafica.cognome != null &&
            $scope.nuovaSchedaAnagrafica.sesso != "" && $scope.nuovaSchedaAnagrafica.sesso != null &&
            $scope.nuovaSchedaAnagrafica.nascita_luogo != "" && $scope.nuovaSchedaAnagrafica.nascita_luogo != null &&
            $scope.nuovaSchedaAnagrafica.ragione_sociale != "" && $scope.nuovaSchedaAnagrafica.ragione_sociale != null &&
            $scope.nuovaSchedaAnagrafica.codice_fiscale != "" && $scope.nuovaSchedaAnagrafica.codice_fiscale != null &&
            $scope.nuovaSchedaAnagrafica.codice_fiscale != undefined &&
            $scope.nuovaSchedaAnagrafica.partita_iva != "" && $scope.nuovaSchedaAnagrafica.partita_iva != null &&
            $scope.nuovaSchedaAnagrafica.partita_iva != undefined
        ) {
            $scope.pivaValida = controllaPIVA($scope.nuovaSchedaAnagrafica.partita_iva);
            $scope.cfCorretto = controllaCF($scope.nuovaSchedaAnagrafica.codice_fiscale);
            $scope.dataNascitaCorretta = $scope.controllaDataNascita();
            if ($scope.pivaValida && $scope.cfCorretto && $scope.dataNascitaCorretta && $scope.nuovaSchedaAnagrafica.nascita_data != undefined) {
                $scope.datiCorretti = true;
            } else {
                $scope.datiCorretti = false;
                $scope.datiCorrettiString = 'Mancanza di dati e/o Codice Fiscale non corretto o assente';
            }
        } else {
            $scope.datiCorretti = false;
            $scope.datiCorrettiString = 'Mancanza di dati e/o Codice Fiscale non corretto o assente';
        }
    }

    function controllaDatiSocieta() {
        if ($scope.nuovaSchedaAnagrafica.ragione_sociale != "" && $scope.nuovaSchedaAnagrafica.ragione_sociale &&
            ($scope.nuovaSchedaAnagrafica.societa_fatturazione == 0 || $scope.nuovaSchedaAnagrafica.societa_fatturazione == null || (
                $scope.nuovaSchedaAnagrafica.societa_fatturazione == 1 &&
                $scope.nuovaSchedaAnagrafica.datiSocieta.rea != "" && $scope.nuovaSchedaAnagrafica.datiSocieta.rea != null &&
                $scope.nuovaSchedaAnagrafica.datiSocieta.cdc_numero != "" && $scope.nuovaSchedaAnagrafica.datiSocieta.cdc_numero != null &&
                $scope.nuovaSchedaAnagrafica.datiSocieta.cdc_citta != "" && $scope.nuovaSchedaAnagrafica.datiSocieta.cdc_citta != null &&
                $scope.nuovaSchedaAnagrafica.datiSocieta.capitale_sociale != "" && $scope.nuovaSchedaAnagrafica.datiSocieta.capitale_sociale != null
            ))
        ) {
            $scope.pivaValida = controllaPIVA($scope.nuovaSchedaAnagrafica.partita_iva);
            $scope.cfCorretto = controllaPIVA($scope.nuovaSchedaAnagrafica.codice_fiscale);
            if ($scope.pivaValida && $scope.cfCorretto) {
                $scope.datiCorretti = true;
            } else {
                $scope.datiCorretti = false;
                $scope.datiCorrettiString = 'Mancanza di dati e/o Codice Fiscale non corretto o assente';
            }
        } else {
            $scope.datiCorretti = false;
            $scope.datiCorrettiString = 'Mancanza di dati e/o Codice Fiscale non corretto o assente';
        }
    }

    /******************
     *   SALVADATI   * ================================================================================================
     ******************/

    $scope.salvaDati = function () {

        stampalog('Dati da salvare');
        stampalog($scope.nuovaSchedaAnagrafica);

        //check indirizzi spedizione
        $scope.contaIndirizziSpedizione();
        if ($scope.indirizzoSpedizionePresente == 0) {
            swal("Errore", 'Inserire almeno un indirizzo di spedizione', "error");
            return;
        }
        if ($scope.indirizzoSpedizionePresente > 1) {
            swal("Errore", 'Sono stati inseriti più indirizzi di spedizione', "error");
            return;
        }
        //check domicilio fiscale
        $scope.contaDomicilioFiscale();
        if ($scope.indirizzoDomicilioFiscale == 0) {
            swal("Errore", 'Inserire almeno un domicilio fiscale', "error");
            return;
        }
        if ($scope.indirizzoDomicilioFiscale > 1) {
            swal("Errore", 'Non è possibile selezionare più di un domicilio fiscale', "error");
            return;
        }
        //check mail predefinite
        if ($scope.nuovaSchedaAnagrafica.email.length > 0) {
            $scope.contaEmailPredefinite();
            if ($scope.indirizzoEmailPredefinitoPresente == 0) {
                swal("Errore", 'Impostare una email predefinita', "error");
                return;
            }
            if ($scope.indirizzoEmailPredefinitoPresente > 1) {
                swal("Errore", 'Non è possibile selezionare più di una email predefinita', "error");
                return;
            }
        }
        if ($scope.nuovaSchedaAnagrafica.pec.length > 0) {
            $scope.contaPecPredefinite();
            if ($scope.indirizzoPecPredefinitoPresente == 0) {
                swal("Errore", 'Impostare una email PEC predefinita', "error");
                return;
            }
            if ($scope.indirizzoPecPredefinitoPresente > 1) {
                swal("Errore", 'Non è possibile selezionare più di una email PEC predefinita', "error");
                return;
            }
        }

        $scope.controllaDati();

        //Normalizzazione delle date
        $scope.nuovaSchedaAnagrafica.nascita_data = getYYYYMMGGFromJsDate($scope.nuovaSchedaAnagrafica.nascita_data);

        if (!$scope.datiCorretti) {
            swal("Errore", $scope.datiCorrettiString, "error");
            return;
        } else {
            //var tmp = formattaDataHtml5($scope.nuovaSchedaAnagrafica.nascita_data);
            //$scope.nuovaSchedaAnagrafica.nascita_data = tmp['year'] + "-" + tmp['month'] + "-" + tmp['day'];

            $http.post(params['form'] + '/anagrafica/controller/gestioneAnagraficaHandler.php',
                {'function': 'salvaDati', 'object': $scope.nuovaSchedaAnagrafica, 'cc': $scope.elencoCC}
            ).then(function (data, status, headers, config) {
                stampalog(data);

                if (data.data.status == "ko") {
                    swal(data.data.error.title, data.data.error.message, "error");
                } else {
                    stampalog(data.data);
                    swal({
                        title: "Salvataggio eseguito",
                        text: '',
                        type: "success"
                    }, function () {
                        window.location.href = $scope.params['home'] + encodeUrl("anagrafica", "anagrafica");
                    });
                }

            });
        }
    };


    $scope.caricaFileAgenzia = function (tipoCaricamentoFile) {
        if (tipoCaricamentoFile == 'logo') {
            $scope.caricaLogo = true;
            $scope.caricaFirma = false;
        } else {
            $scope.caricaLogo = false;
            $scope.caricaFirma = true;
        }
        for (var i = 0; i < uploader.queue.length; i++) {
            uploader.queue[i].remove();
        }
    };

    $scope.eliminaFileAgenzia = function (tipoCaricamentoFile) {
        if (tipoCaricamentoFile == 'logo') {
            $scope.nuovaSchedaAnagrafica.file_logo = '';
            $scope.caricaLogo = false;
            $scope.caricaFirma = false;
        } else {
            $scope.nuovaSchedaAnagrafica.file_firma = '';
            $scope.caricaLogo = false;
            $scope.caricaFirma = false;
        }
    };

    /* CARICA ANAGRAFICA rappr. legale *********************************************/
    $scope.caricaAnagrafica = function (idAnagrafica) {
        window.location.href = params['home'] + encodeUrl('anagrafica', 'gestioneAnagrafica', idAnagrafica);
    };
    /* MULTISELECT rappr. legale *********************************************/
    $scope.settings = {
        selectionLimit: 1,
        //dynamicTitle: true,
        enableSearch: true,
        //showSelectAll: false,
        keyboardControls: true,
        scrollable: true,
        //showCheckAll: false,
        //showUncheckAll: true,
        closeOnSelect: true,
        scrollableHeight: '200px',
        externalIdProp: '', //PERMETTE DI AGGIUNGERE ALL'ARRAY DEI SELEZIONATI TUTTO L'OGGETTO
        idProp: 'id', //definisco i campi di cui è composto l'oggetto
        displayProp: 'descrizione', //definisco i campi di cui è composto l'oggetto
        smartButtonMaxItems: 1,
        smartButtonTextConverter: function (itemText) {
            return itemText;
        }
    };

    $scope.customTextRapprLegale = {
        buttonDefaultText: 'Nessun rappresentante legale',
        uncheckAll: 'Deseleziona',
        searchPlaceholder: 'Cerca..'
    };

    $scope.multiSelectEvent = {
        onItemSelect: function (obj) {
            //$scope.idRappLegale = obj.id;
            $scope.nuovaSchedaAnagrafica.id_rappresentante = obj.id;
        },
        onItemDeselect: function (obj) {
            //$scope.idRappLegale = null;
            $scope.nuovaSchedaAnagrafica.id_rappresentante = 0;
        },
        onDeselectAll: function (obj) {
            //$scope.idRappLegale = null;
            $scope.nuovaSchedaAnagrafica.id_rappresentante = 0;
        }

    };

    $scope.modificaFeMittente = function (tipo) {
        if (tipo == 'pec') {
            $scope.nuovaSchedaAnagrafica.fattura_elettronica_mittente_codice = '';
        } else {
            $scope.nuovaSchedaAnagrafica.fattura_elettronica_mittente_pec = '';
        }
    };

    $scope.modificaFeDestinatario = function (tipo, gruppo) {
        if (tipo == 'pec') {
            if (gruppo == 1) {
                $scope.nuovaSchedaAnagrafica.fattura_elettronica_destinatario_codice = '0000000';
            }
            else {
                // $scope.nuovaSchedaAnagrafica.fattura_elettronica_destinatario_codice = '';
            }
        } else {
            $scope.nuovaSchedaAnagrafica.fattura_elettronica_destinatario_pec = '';
        }
    };

}]);


/* ------- DA SISTEMARE --------- */
function importaStrutturaAnagrafica() {
    return {
        intestazione: {id_tipi_soggetto: "1", titolo: "sig", nome: "", ragione_sociale: ""},
        datiAnagrafici: {sesso: "", nascita_data: "", nascita_luogo: "", nascita_provincia: "", nascita_stato: ""},
        datiCliente: {partita_iva_nazione: "", partita_iva: "", codice_fiscale: ""},
        contatti: {telefoni: "", cellulari: "", elencoEmail: [], indirizzi: ""}
    }
}