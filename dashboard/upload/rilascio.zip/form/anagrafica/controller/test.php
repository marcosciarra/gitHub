<?php

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';

require_once '../../../src/model/UnitaImmobiliari.php';
require_once '../../../src/model/Comuni.php';

use Click\Affitti\TblBase\UnitaImmobiliari;
use Click\Affitti\TblBase\Comuni;


    $result = array();
    try {

        // CARICO DATI
        $con = new \Drakkar\DrakkarDbConnector();
        echo $con->getSkema();
        $ui = new \Click\Affitti\TblBase\UnitaImmobiliari($con);
       //$app=$anagrafiche->findAll(false, Anagrafiche::FETCH_KEYARRAY,1,0);

        $idUI = 4;
        if($idUI != 0)
            $result['ui'] = $ui->findByPk($idUI,UnitaImmobiliari::FETCH_KEYARRAY);
        else {
            $result['ui'] = $ui->getEmptyDbKeyArray();
            $result['indirizzo'] = $ui->getEmptyIndirizzo();
        }
        var_dump($result);

       $con = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
        echo $con->getSkema();
        $anagrafiche = new \Click\Affitti\TblBase\Comuni($con);
       //$app=$anagrafiche->findAll(false, Anagrafiche::FETCH_KEYARRAY,1,0);
        $app=$anagrafiche->getLista();
       var_dump($app);

    }
    catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        echo json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    }
    catch (\Drakkar\Exception\DrakkarException $e) {
        echo json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }

