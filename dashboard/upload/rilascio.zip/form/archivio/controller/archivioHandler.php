<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 05/01/18
 * Time: 9.10
 */

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';

require_once '../../../src/function/functionGeneric.php';

require_once '../../../src/model/Contratti.php';
require_once '../../../src/model/ContrattiConAnagrafiche.php';
require_once '../../../src/model/AggiornamentoIstat.php';
require_once '../../../src/model/FatturazioneTesta.php';
require_once '../../../src/model/AggiornamentoF24.php';
require_once '../../../src/model/Rate.php';
require_once '../../../src/model/ImpostaRegistro.php';

use Click\Affitti\TblBase\Contratti;
use Click\Affitti\TblBase\AggiornamentoIstat;
use Click\Affitti\TblBase\FatturazioneTesta;
use Click\Affitti\TblBase\Rate;
use Click\Affitti\TblBase\AggiornamentoF24;
use Click\Affitti\Viste\ContrattiConAnagrafiche;
use Click\Affitti\TblBase\ImpostaRegistro;

function caricaDati()
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $result['elenco'] = [];
        $aggIstat = new AggiornamentoIstat($con);
        foreach ($aggIstat->getElencoOperazioni(5, 0) as $a) {
            $a['sezione'] = 'istat';
            $a['tipo'] = 'Aggiornamento ISTAT ';
            $a['bloccato'] = 0;

            $a['dettagli'] = [];
            foreach ($aggIstat->findByIdxCodiceGruppo($a['codice_gruppo'], AggiornamentoIstat::FETCH_KEYARRAY) as $app) {
                $contratto = new Contratti($con, 'T');
                $contratto->findByPk($app['id_contratto']);
                if ($contratto->getCestino() == 0)
                    $a['dettagli'][] = $app;
            }
            if (count($a['dettagli']) > 0)
                $result['elenco'][] = $a;
        }

        $fatture = new FatturazioneTesta($con);
        foreach ($fatture->getElencoOperazioni(5, 0) as $a) {
            $a['sezione'] = 'fatture';
            $a['tipo'] = 'Riscossione Canone ';
            $a['bloccato'] = 0;

            $a['dettagli'] = [];
            foreach ($fatture->findByIdxCodiceGruppo($a['codice_gruppo'], FatturazioneTesta::FETCH_KEYARRAY) as $app) {
                $rate = new Rate($con);
                $idContratto = $rate->findIdContrattoByIdRata($app['id_rata']);
                $contratto = new Contratti($con, 'T');
                $contratto->findByPk($idContratto);
                if ($contratto->getCestino() == 0)
                    $a['dettagli'][] = $app;
                if ($app['flusso_inviato'] == 1)
                    $a['bloccato'] = 1;

            }
            if (count($a['dettagli']) > 0)
                $result['elenco'][] = $a;

        }

        $proroghe = new AggiornamentoF24($con);
        foreach ($proroghe->getElencoOperazioni() as $a) {
            $a['sezione'] = 'f24';
            $a['tipo'] = 'Proroghe (F24) ';
            $a['bloccato'] = 0;
            $a['codice_gruppo'] = $a['codice_flusso'];
            $a['data_flusso'] =
                substr($a['codice_flusso'], 9, 2) . '/' .
                substr($a['codice_flusso'], 7, 2) . '/' .
                substr($a['codice_flusso'], 3, 4);

            $a['dettagli'] = [];
            foreach ($proroghe->findByIdxCodiceFlusso($a['codice_flusso'], AggiornamentoF24::FETCH_KEYARRAY) as $app) {
                $impReg = new ImpostaRegistro($con);
                $impReg->findByPk($app['id_imposta_registro']);
                $idContratto = $impReg->getIdContratto();
                $contratto = new Contratti($con, 'T');
                $contratto->findByPk($idContratto);
                if ($contratto->getCestino() == 0)
                    $a['dettagli'][] = $app;
            }
            if (count($a['dettagli']) > 0)
                $result['elenco'][] = $a;

        }
        if (count($result['elenco']) > 0) {
            array_sort_by_column($result['elenco'], 'codice_gruppo', SORT_DESC);
        }

        /*--------------------------------------------FLUSSI------------------------------------------------------*/
        if ($handle = opendir(UPLOAD_URL)) {
            $flag = false;
            while (false !== ($file = readdir($handle))) {
                if (
                    $file != "." &&
                    $file != ".." &&
                    substr($file, 0, 3) == 'F24' &&
                    strtolower(substr($file, strrpos($file, '.') + 1)) == 'cbi'
                ) {
                    $flag = true;
                    $result['flussi'][] =
                        array(
                            "tipo_file" => "F24 Elide",
                            "data_file" => substr($file, 3, 4) . '-' . substr($file, 7, 2) . '-' . substr($file, 9, 2),
                            "nome_file" => DOWNLOAD_URL . DIRECTORY_SEPARATOR . $file
                        );
                    if (count($result['flussi']) > 10)
                        break;
                }
            }
            closedir($handle);
        }
        if (count($result['flussi']) > 0 && $flag == true) {
            array_sort_by_column($result['flussi'], 'data_file', SORT_DESC);
        }


        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
