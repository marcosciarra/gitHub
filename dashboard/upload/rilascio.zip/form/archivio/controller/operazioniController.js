ngApp.controller("operazioniController", ["$scope", "$http", "$filter", "ngToast", function ($scope, $http, $filter, $ngToast) {

    var url = window.location.href;
    var params = decodeUrl(url, 'id');

    $scope.tipoFlusso = 'fatture';

    $scope.caricamentoCompletato = false;

    $scope.init = function () {
        $scope.codiceSelezionato = 0;
        $scope.caricaDati();
    };

    $scope.seleziona = function (codiceGruppo) {
        $scope.codiceSelezionato = codiceGruppo;
    };

    /******************
     *   CARICADATI   * ================================================================================================
     ******************/

    $scope.caricaDati = function () {
        $scope.caricamentoCompletato = false;
        $http.post(params['form'] + '/archivio/controller/operazioniHandler.php',
            {'function': 'caricaDati', 'tipoFlusso': $scope.tipoFlusso}
        ).then(function (data, status, headers, config) {
            $scope.elenco = data.data.elenco;
            if ($scope.elenco != null) {
                for (var i = 0; i < $scope.elenco.length; i++) {
                    if ($scope.elenco[i].dettagli!=null) {
                        var invio=0;
                        for (var j = 0; j < $scope.elenco[i].dettagli.length; j++) {
                            if ($scope.elenco[i].dettagli[j].dettagliContratto.anagrafica_conduttori != null) {
                                for (var m = 0; m < $scope.elenco[i].dettagli[j].dettagliContratto.anagrafica_conduttori.length; m++) {
                                    $scope.elenco[i].dettagli[j].dettagliContratto.anagrafica_conduttori[m].indirizzi =
                                        jsonParse($scope.elenco[i].dettagli[j].dettagliContratto.anagrafica_conduttori[m].indirizzi);
                                }
                            }
                            if ($scope.elenco[i].dettagli[j].dettagliContratto.anagrafica_locatori != null) {
                                for (var m = 0; m < $scope.elenco[i].dettagli[j].dettagliContratto.anagrafica_locatori.length; m++) {
                                    $scope.elenco[i].dettagli[j].dettagliContratto.anagrafica_locatori[m].indirizzi =
                                        jsonParse($scope.elenco[i].dettagli[j].dettagliContratto.anagrafica_locatori[m].indirizzi);
                                }
                            }
                            if ($scope.elenco[i].dettagli[j].dettagliContratto.unita_immobiliari != null) {
                                for (var m = 0; m < $scope.elenco[i].dettagli[j].dettagliContratto.unita_immobiliari.length; m++) {
                                    $scope.elenco[i].dettagli[j].dettagliContratto.unita_immobiliari[m].indirizzo =
                                        jsonParse($scope.elenco[i].dettagli[j].dettagliContratto.unita_immobiliari[m].indirizzo);
                                }
                            }

                            if ($scope.tipoFlusso=='f24'){
                                $scope.elenco[i].dettagli[j].codice_gruppo=
                                    $scope.elenco[i].dettagli[j].codice_flusso;
                            }
                            if ($scope.elenco[i].dettagli[j].flusso_inviato == 1) {
                                invio++;
                            }
                        }
                        if(invio>0){
                            $scope.elenco[i].flusso_inviato=1;
                        }
                        else{
                            $scope.elenco[i].flusso_inviato=0;
                        }
                    }
                }
            }

            stampalog(data.data);

            $scope.caricamentoCompletato = true;
        });
    };

    $scope.stampaTabulato = function (codiceGruppo) {
        switch ($scope.tipoFlusso) {
            case 'istat':
                window.open(params['baseurl'] + '/stampe/istat/tabultatoIstatPdf.php?codiceGruppo=' + codiceGruppo);
                break;
            case 'fatture':
                window.open(params['baseurl'] + '/stampe/avvisiPagamento/tabulatoRiepilogativoPdf.php?codiceGruppo=' + codiceGruppo);
                break;
            case 'f24':
                window.open(params['baseurl'] + '/stampe/proroghe/tabulatoF24Pdf.php?codiceFlusso=' + codiceGruppo);
                break;
        }
    };


    $scope.stampaPagina = function (codiceGruppo) {
        switch ($scope.tipoFlusso) {
            case 'istat':
                window.open(params['baseurl'] + '/stampe/istat/variazioneIstatPdf.php?codiceGruppo=' + codiceGruppo);
                break;
            case 'fatture':
                window.open(params['baseurl'] + '/stampe/avvisiPagamento/avvisoPagamentoPdf.php?codiceGruppo=' + codiceGruppo);
                break;
            case 'f24':
                window.open(params['baseurl'] + '/stampe/proroghe/f24Pdf.php?codiceFlusso=' + codiceGruppo);
                break;
        }
    };


    $scope.stampaDettaglio = function (codiceGruppo, id) {
        switch ($scope.tipoFlusso) {
            case 'istat':
                window.open(params['baseurl'] + '/stampe/istat/variazioneIstatPdf.php?codiceGruppo=' + codiceGruppo + '&id=' + id);
                break;
            case 'fatture':
                window.open(params['baseurl'] + '/stampe/avvisiPagamento/avvisoPagamentoPdf.php?idFattura=' + id);
                break;
            case 'f24':
                window.open(params['baseurl'] + '/stampe/proroghe/f24Pdf.php?id=' + id);
                break;
        }
    };



    $scope.eliminaGruppo = function (codiceGruppo) {
        $http.post(params['form'] + '/archivio/controller/operazioniHandler.php',
            {'function': 'eliminaGruppo', 'tipoFlusso': $scope.tipoFlusso, 'codiceGruppo': codiceGruppo}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                swal({
                        title: "Eliminazione eseguita",
                        text: "",
                        type: "success",
                        showCancelButton: false,
                        confirmButtonClass: "btn-success",
                        confirmButtonText: "Ok",
                        showLoaderOnConfirm: true,
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });
            } else {
                swal({
                        title: "Errore",
                        text: "Impossibile eliminare.",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });
            }
        });
    };


    $scope.eliminaDettaglio = function (id) {
        $http.post(params['form'] + '/archivio/controller/operazioniHandler.php',
            {'function': 'eliminaDettaglio', 'tipoFlusso': $scope.tipoFlusso, 'id': id}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                swal({
                        title: "Eliminazione eseguita",
                        text: "",
                        type: "success",
                        showCancelButton: false,
                        confirmButtonClass: "btn-success",
                        confirmButtonText: "Ok",
                        showLoaderOnConfirm: true,
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });
            } else {
                swal({
                        title: "Errore",
                        text: "Impossibile eliminare.",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });
            }

        });
    };


    $scope.eliminaFlusso = function (codiceGruppo, id) {


        swal({
                title: "Procedere con l'eliminazione?",
                text: "",
                type: "info",
                showCancelButton: false,
                confirmButtonClass: "btn-success",
                confirmButtonText: "Si",
                cancelButtonText: "No",
                showLoaderOnConfirm: true,
                showCancelButton: true,
                closeOnConfirm: false,
                closeOnCancel: false
            },
            function (isConfirm) {
                if (isConfirm) {
                    $http.post(params['form'] + '/archivio/controller/operazioniHandler.php',
                        {
                            'function': 'eliminaFlusso',
                            'tipoFlusso': $scope.tipoFlusso,
                            'codiceGruppo': codiceGruppo,
                            'id': id
                        }
                    ).then(function (data, status, headers, config) {
                        if (data.data == 'ok') {
                            swal({
                                    title: "Eliminazione eseguita",
                                    text: "",
                                    type: "success",
                                    showCancelButton: false,
                                    confirmButtonClass: "btn-success",
                                    confirmButtonText: "Ok",
                                    showLoaderOnConfirm: true,
                                    closeOnConfirm: false
                                },
                                function () {
                                    window.location.reload();
                                });
                        }
                    });
                }
                else {
                    swal({
                        title: "Operazione annullata",
                        text: '',
                        type: "error"
                    }, function () {
                        location.reload();
                    });
                }
            });
    };
}]);


ngApp.filter('formattaDataDaTimestamp', function () {
    return function (x) {
        var a = new Date(x * 1000);
        var year = a.getFullYear();
        var month = a.getMonth() + 1;
        var date = a.getDate();
        return (date + '/' + month + '/' + year);
    };
});

ngApp.filter('formattaOraDaTimestamp', function () {
    return function (x) {
        var a = new Date(x * 1000);
        var ore = a.getHours();
        var minuti = a.getMinutes();
        return (ore + ':' + minuti);
    };
});