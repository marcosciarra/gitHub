<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 16/06/18
 * Time: 14.29
 */

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';

require_once '../../../src/function/functionGeneric.php';
require_once '../../../src/function/functionLogin.php';

require_once '../../../src/model/ContrattiConAnagrafiche.php';
require_once '../../../src/model/Banche.php';

use Click\Affitti\TblBase\AggiornamentoIstat;
use Click\Affitti\Viste\ContrattiConAnagrafiche;
use Click\Affitti\TblBase\Banche;


function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);

        // CARICO DATI
        switch ($request->tipoFlusso) {
            case 'f24':
                if ($handle = opendir(UPLOAD_URL)) {
                    while (false !== ($file = readdir($handle))) {
                        if (
                            $file != "." &&
                            $file != ".." &&
                            substr($file, 0, 3) == 'F24' &&
                            strtolower(substr($file, strrpos($file, '.') + 1)) == 'cbi'
                        ) {
                            $appFile = explode('.', $file);
                            $abi = substr($appFile[0], -5);
                            $banca = new Banche($conExt);
                            $nomeBanca = '';
                            /** @var Banche $banca */
                            foreach ($banca->findByPrimary4($abi) as $banca) {
                                break;
                            }
                            $nomeBanca = $banca->getDescrizione();

                            $result['elenco'][] =
                                array(
                                    "tipo_file" => "F24 Elide",
                                    "data_file" => substr($file, 3, 4) . '-' . substr($file, 7, 2) . '-' . substr($file, 9, 2),
                                    "nome_file" => DOWNLOAD_URL . DIRECTORY_SEPARATOR . $file,
                                    "abi" => $abi,
                                    "nome_banca" => $nomeBanca
                                );
                        }
                    }
                    closedir($handle);
                    if (count($result['elenco']) > 0) {
                        array_sort_by_column($result['elenco'], 'data_file', SORT_DESC);
                    }

                }
                break;
        }

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;