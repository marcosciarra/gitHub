ngApp.controller("operazioniController", ["$scope", "$http", "$filter", "ngToast", function ($scope, $http, $filter, $ngToast) {

    var url = window.location.href;
    var params = decodeUrl(url, 'id');

    $scope.tipoFlusso = 'f24';

    $scope.caricamentoCompletato = false;

    $scope.init = function () {
        $scope.codiceSelezionato = 0;
        $scope.caricaDati();
    };

    $scope.seleziona = function (codiceGruppo) {
        $scope.codiceSelezionato = codiceGruppo;
    };

    /******************
     *   CARICADATI   * ================================================================================================
     ******************/

    $scope.caricaDati = function () {
        $http.post(params['form'] + '/archivio/controller/flussiHandler.php',
            {'function': 'caricaDati', 'tipoFlusso': $scope.tipoFlusso}
        ).then(function (data, status, headers, config) {
            $scope.elenco = data.data.elenco;

            stampalog($scope.elenco);

            $scope.caricamentoCompletato = true;
        });
    };
}]);