ngApp.controller("archivioController", ["$scope", "$http", "$filter", function ($scope, $http, $filter) {

    var url = window.location.href;
    var params = decodeUrl(url);
    stampalog(params);

    // $scope.caricamentoCompletato = false;
    $scope.caricamentoCompletato = false;
    $scope.filtroCerca = false;

    /******************
     *   CARICADATI   * ================================================================================================
     ******************/

    $scope.init = function () {
        $scope.caricaDati();
    };


    $scope.caricaDati = function () {
        $http.post(params['form'] + '/archivio/controller/archivioHandler.php',
            {'function': 'caricaDati'}
        ).then(function (data, status, headers, config) {
            $scope.elenco = data.data.elenco;
            $scope.flussi = data.data.flussi;
            stampalog(data.data);

            $scope.caricamentoCompletato = true;
        });
    };


    $scope.stampaTabulato = function (codiceGruppo, tipo) {
        switch (tipo) {
            case 'istat':
                window.open(params['baseurl'] + '/stampe/istat/tabultatoIstatPdf.php?codiceGruppo=' + codiceGruppo);
                break;
            case 'fatture':
                window.open(params['baseurl'] + '/stampe/avvisiPagamento/tabulatoRiepilogativoPdf.php?codiceGruppo=' + codiceGruppo);
                break;
            case 'f24':
                window.open(params['baseurl'] + '/stampe/proroghe/tabulatoF24Pdf.php?codiceFlusso=' + codiceGruppo);
                break;
        }
    };


    $scope.stampaPagina = function (codiceGruppo, tipo) {
        switch (tipo) {
            case 'istat':
                window.open(params['baseurl'] + '/stampe/istat/variazioneIstatPdf.php?codiceGruppo=' + codiceGruppo);
                break;
            case 'fatture':
                window.open(params['baseurl'] + '/stampe/avvisiPagamento/avvisoPagamentoPdf.php?codiceGruppo=' + codiceGruppo);
                break;
            case 'f24':
                window.open(params['baseurl'] + '/stampe/proroghe/f24Pdf.php?codiceFlusso=' + codiceGruppo);
                break;
        }
    };


    $scope.eliminaFlusso = function (sezione,codiceGruppo, id) {


        swal({
                title: "Procedere con l'eliminazione?",
                text: "",
                type: "info",
                showCancelButton: false,
                confirmButtonClass: "btn-success",
                confirmButtonText: "Si",
                cancelButtonText: "No",
                showLoaderOnConfirm: true,
                showCancelButton: true,
                closeOnConfirm: false,
                closeOnCancel: false
            },
            function (isConfirm) {
                if (isConfirm) {
                    $http.post(params['form'] + '/archivio/controller/operazioniHandler.php',
                        {
                            'function': 'eliminaFlusso',
                            'tipoFlusso': sezione,
                            'codiceGruppo': codiceGruppo,
                            'id': id
                        }
                    ).then(function (data, status, headers, config) {
                        if (data.data == 'ok') {
                            swal({
                                    title: "Eliminazione eseguita",
                                    text: "",
                                    type: "success",
                                    showCancelButton: false,
                                    confirmButtonClass: "btn-success",
                                    confirmButtonText: "Ok",
                                    showLoaderOnConfirm: true,
                                    closeOnConfirm: false
                                },
                                function () {
                                    window.location.reload();
                                });
                        }
                    });
                }
                else {
                    swal({
                        title: "Operazione annullata",
                        text: '',
                        type: "error"
                    }, function () {
                        location.reload();
                    });
                }
            });
    };
}]);


ngApp.filter('formattaDataDaTimestamp', function () {
    return function (x) {
        var a = new Date(x * 1000);
        var year = a.getFullYear();
        var month = a.getMonth() + 1;
        var date = a.getDate();
        return (date + '/' + month + '/' + year);
    };
});