<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 16/06/18
 * Time: 14.29
 */

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';
require_once '../../../src/function/functionLogin.php';
require_once '../../../src/model/AggiornamentoIstat.php';
require_once '../../../src/model/Contratti.php';
require_once '../../../src/model/ContrattiConAnagrafiche.php';
require_once '../../../src/model/FatturazioneTesta.php';
require_once '../../../src/model/FatturazioneDettagli.php';
require_once '../../../src/model/Rate.php';
require_once '../../../src/model/RateDettagli.php';
require_once '../../../src/model/AggiornaContratto.php';
require_once '../../../src/model/PianoRateTesta.php';
require_once '../../../src/model/CanoniOneri.php';
require_once '../../../src/model/Gestioni.php';
require_once '../../../src/model/TipiIva.php';
require_once '../../../src/model/AggiornamentoF24.php';
require_once '../../../src/model/ImpostaRegistro.php';
require_once '../../../src/model/Anagrafiche.php';


use Click\Affitti\TblBase\AggiornamentoIstat;
use Click\Affitti\Viste\ContrattiConAnagrafiche;
use Click\Affitti\TblBase\Contratti;
use Click\Affitti\TblBase\FatturazioneTesta;
use Click\Affitti\TblBase\Rate;
use Click\Affitti\TblBase\FatturazioneDettagli;
use Click\Affitti\Viste\AggiornaContratto;
use Click\Affitti\TblBase\PianoRateTesta;
use Click\Affitti\TblBase\CanoniOneri;
use Click\Affitti\TblBase\Gestioni;
use Click\Affitti\TblBase\TipiIva;
use Click\Affitti\TblBase\AggiornamentoF24;
use Click\Affitti\TblBase\ImpostaRegistro;
use Click\Affitti\TblBase\RateDettagli;
use Click\Affitti\TblBase\Anagrafiche;


function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $contratto = new Contratti($con);
        $anagrafiche = new Anagrafiche($con);

        // CARICO DATI
        switch ($request->tipoFlusso) {
            case 'istat':
                $aggIstat = new AggiornamentoIstat($con);
                foreach ($aggIstat->getElencoOperazioni() as $a) {
                    $contratto = new ContrattiConAnagrafiche($con);
                    $a['sezione'] = 'istat';
                    $a['tipo'] = 'Aggiornamento ISTAT ';
                    $a['dettagli'] = [];
                    foreach ($aggIstat->findByIdxCodiceGruppo($a['codice_gruppo'], AggiornamentoIstat::FETCH_KEYARRAY) as $app) {
                        $contr = new Contratti($con, 'T');
                        $contr->findByPk($app['id_contratto']);
                        if ($contr->getCestino() == 0)
                            $a['dettagli'][] = $app;
                    }
                    for ($i = 0; $i < count($a['dettagli']); $i++) {
                        $a['dettagli'][$i]['dettagliContratto'] = $contratto->findByPk($a['dettagli'][$i]['id_contratto'], ContrattiConAnagrafiche::FETCH_KEYARRAY);
                        $anagrafiche->findByPk($a['dettagli'][$i]['dettagliContratto']['anagrafica_locatori'][0]['id']);
                        $a['dettagli'][$i]['locatore'] = $anagrafiche->getNominativo();
                        $anagrafiche->findByPk($a['dettagli'][$i]['dettagliContratto']['anagrafica_conduttori'][0]['id']);
                        $a['dettagli'][$i]['conduttore'] = $anagrafiche->getNominativo();
                    }

                    if (count($a['dettagli']) > 0)
                        $result['elenco'][] = $a;
                }
                break;

            case 'fatture':
                $fatture = new FatturazioneTesta($con);
                foreach ($fatture->getElencoOperazioni() as $a) {
                    $contratto = new ContrattiConAnagrafiche($con);
                    $a['sezione'] = 'fatture';
                    $a['tipo'] = 'Riscossione Canone ';
                    $a['dettagli'] = [];
                    foreach ($fatture->findByIdxCodiceGruppo($a['codice_gruppo'], FatturazioneTesta::FETCH_KEYARRAY) as $app) {
                        $rate = new Rate($con);
                        $idContratto = $rate->findIdContrattoByIdRata($app['id_rata']);
                        $contr = new Contratti($con, 'T');
                        $contr->findByPk($idContratto);
                        if ($contr->getCestino() == 0)
                            $a['dettagli'][] = $app;
                    }
                    for ($i = 0; $i < count($a['dettagli']); $i++) {
                        $rate = new Rate($con);
                        $idContratto = $rate->findIdContrattoByIdRata($a['dettagli'][$i]['id_rata']);
                        $a['dettagli'][$i]['dettagliContratto'] = $contratto->findByPk($idContratto, ContrattiConAnagrafiche::FETCH_KEYARRAY);
                        $anagrafiche->findByPk($a['dettagli'][$i]['id_locatore_fattura']);
                        $a['dettagli'][$i]['locatore'] = $anagrafiche->getNominativo();
                        $anagrafiche->findByPk($a['dettagli'][$i]['id_conduttore_fattura']);
                        $a['dettagli'][$i]['conduttore'] = $anagrafiche->getNominativo();
                    }

                    if (count($a['dettagli']) > 0)
                        $result['elenco'][] = $a;
                }
                break;

            case 'f24':
                $proroghe = new AggiornamentoF24($con);
                foreach ($proroghe->getElencoOperazioni() as $a) {
                    $contratto = new ContrattiConAnagrafiche($con);
                    $a['sezione'] = 'f24';
                    $a['tipo'] = 'Proroghe (F24) ';
                    $a['codice_gruppo'] = $a['codice_flusso'];
                    $a['data_flusso'] =
                        substr($a['codice_flusso'], 9, 2) . '/' .
                        substr($a['codice_flusso'], 7, 2) . '/' .
                        substr($a['codice_flusso'], 3, 4);
                    $a['dettagli'] = [];
                    foreach ($proroghe->findByIdxCodiceFlusso($a['codice_flusso'], AggiornamentoF24::FETCH_KEYARRAY) as $app) {
                        $impReg = new ImpostaRegistro($con);
                        $impReg->findByPk($app['id_imposta_registro']);
                        $idContratto = $impReg->getIdContratto();
                        $contr = new Contratti($con, 'T');
                        $contr->findByPk($idContratto);
                        if ($contr->getCestino() == 0)
                            $a['dettagli'][] = $app;
                    }
                    for ($i = 0; $i < count($a['dettagli']); $i++) {
                        $agg = new AggiornamentoF24($con);
                        $idContratto = $agg->findIdContrattoByIdAggiornamento($a['dettagli'][$i]['id']);
                        $a['dettagli'][$i]['dettagliContratto'] = $contratto->findByPk($idContratto, ContrattiConAnagrafiche::FETCH_KEYARRAY);
                        $anagrafiche->findByPk($a['dettagli'][$i]['dettagliContratto']['anagrafica_locatori'][0]['id']);
                        $a['dettagli'][$i]['locatore'] = $anagrafiche->getNominativo();
                        $anagrafiche->findByPk($a['dettagli'][$i]['dettagliContratto']['anagrafica_conduttori'][0]['id']);
                        $a['dettagli'][$i]['conduttore'] = $anagrafiche->getNominativo();
                    }

                    if (count($a['dettagli']) > 0)
                        $result['elenco'][] = $a;
                }
                break;

        }

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

/*--------------------------------------------------------ELIMINAZIONE------------------------------------------------*/


function eliminaFlusso($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
        $con->beginTransaction();
        switch ($request->tipoFlusso) {
            case 'istat':
                eliminaIstat($con, $conExt, $request->codiceGruppo, $request->id);
                break;
            case 'fatture':
                eliminaFatture($con, $request->codiceGruppo, $request->id);
                break;
            case 'f24':
                eliminaF24($con, $request->codiceGruppo, $request->id);
                break;
        }
        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

/*-----------------------------------------------ELIMINAZIONE ISTAT---------------------------------------------------*/


function eliminaIstat($con, $conExt, $codiceGruppo, $id)
{
    if ($id == null) {
        eliminaGruppoIstat($codiceGruppo, $con, $conExt);
    } else {
        eliminaDettaglioIstat($id, $con, $conExt);
    }

}


function eliminaGruppoIstat($gruppoIstat, $con, $conExt)
{
    $istat = new AggiornamentoIstat($con);
    /** @var AggiornamentoIstat $appIstat */
    foreach ($istat->findByIdxCodiceGruppo($gruppoIstat) as $appIstat) {
        eliminaDettaglioIstat($appIstat->getId(), $con, $conExt);
    }
}


function eliminaDettaglioIstat($id, $con, $conExt)
{
    $istat = new AggiornamentoIstat($con);
    $istat->findByPk($id);

    $pianoRateT = new PianoRateTesta($con);
    $pianoRateT->findByPk($istat->getIdPianoRateTesta());
    $canoniOneri = new CanoniOneri($con);
    $canoniOneri->findByPk($pianoRateT->getIdCanoniOneri());
    $gest = new Gestioni($con);
    $gest->findByPk($pianoRateT->getIdGestione());

    $tipiIva = new TipiIva($con);
    $newImponibile = $tipiIva->calcolaImponibileDaImporto(
        $pianoRateT->getIdTipoIva(),
        $istat->getCanone()
    );

    //Setto i valori del PianoRateTesta
    $pianoRateT->setImponibile($newImponibile);
    $pianoRateT->setImporto($istat->getCanone());
    $pianoRateT->setConguaglio($pianoRateT::NULL_VALUE);
    $pianoRateT->setPercentualeIstat($pianoRateT::NULL_VALUE);
    $pianoRateT->setDataAggiornamentoIstat($pianoRateT::NULL_VALUE);
    $pianoRateT->saveOrUpdate();

    //Aggiorno tutte le rate e tutti i PianoRateTesta successivi
    $aggiornaContratto = new AggiornaContratto($con, $conExt);
    $aggiornaContratto->cambioImporti(
        $newImponibile,
        $istat->getIdContratto(),
        $canoniOneri->getId(),
        $gest->getDataInizio(),
        true
    );

    //Elimino i conguagli dalla rata
    $rataConguaglio = $istat->getIdRata();
    $rateD = new RateDettagli($con);
    /** @var RateDettagli $rateD */
    foreach ($rateD->findByIdRata($rataConguaglio) as $rateD) {
        if ($rateD->getIdCategoriaSpesa() == 'T') {
            $rateD->deleteByPk($rateD->getId());
        }
    }

    $istat->deleteByPk($id);
}

/*-----------------------------------------------ELIMINAZIONE FATTURE-------------------------------------------------*/


function eliminaFatture($con, $codiceGruppo, $id)
{
    if ($id == null) {
        eliminaGruppoFatture($codiceGruppo, $con);
    } else {
        eliminaDettaglioFatture($id, $con);
    }
}


function eliminaGruppoFatture($gruppoFatture, $con)
{
    $fatT = new FatturazioneTesta($con);
    /** @var FatturazioneTesta $appFatT */
    foreach ($fatT->findByIdxCodiceGruppo($gruppoFatture) as $appFatT) {
        eliminaDettaglioFatture($appFatT->getId(), $con);
    }
}


function eliminaDettaglioFatture($id, $con)
{
    /*-----------------------------------------------ELIMINO DETTAGLI FATTURA-----------------------------------------*/
    $fatD = new FatturazioneDettagli($con);
    /** @var FatturazioneDettagli $appFatD */
    foreach ($fatD->findByIdxIdFatturazioneTesta($id) as $appFatD) {
        $fatD->deleteByPk($appFatD->getId());
    }
    /*-----------------------------------------------ELIMINO TESTATA FATTURA------------------------------------------*/
    $fatT = new FatturazioneTesta($con);
    $fatT->findByPk($id);
    $idRata = $fatT->getIdRata();
    $fatT->deleteByPk($id);
    /*-----------------------------------------------SBLOCCO RATE EMESSE----------------------------------------------*/
    $rate = new Rate($con);
    $rate->findByPk($idRata);
    $rate->setBloccata(0);
    $rate->saveOrUpdate();
}

/*-----------------------------------------------ELIMINAZIONE F24-----------------------------------------------------*/


function eliminaF24($con, $codiceGruppo, $id)
{
    if ($id == null) {
        eliminaGruppoF24($codiceGruppo, $con);
    } else {
        eliminaDettaglioF24($id, $con);
    }
}


function eliminaGruppoF24($gruppoF24, $con)
{
    $f24 = new AggiornamentoF24($con);
    /** @var FatturazioneTesta $appF24 */
    foreach ($f24->findByIdxCodiceFlusso($gruppoF24) as $appF24) {
        eliminaDettaglioF24($appF24->getId(), $con);
    }
}


function eliminaDettaglioF24($id, $con)
{
    /*-----------------------------------------------ELIMINO DETTAGLI F24---------------------------------------------*/
    $aggF24 = new AggiornamentoF24($con);
    /** @var AggiornamentoF24 $appF24 */
    $aggF24->findByPk($id);
    $impReg = new ImpostaRegistro($con);
    $impReg->findByPk($aggF24->getIdImpostaRegistro());
    $impReg->setCodiceUfficio(ImpostaRegistro::NULL_VALUE);
    $impReg->setDataVersamento(ImpostaRegistro::NULL_VALUE);
    $impReg->saveOrUpdate();
    $aggF24->deleteByPk($aggF24->getId());
}

/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;