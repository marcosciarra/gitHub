<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 15/12/17
 * Time: 10.38
 */

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';
require_once '../../../src/model/Istat.php';
require_once '../../../src/model/Rate.php';
require_once '../../../src/model/PianoRateTesta.php';
require_once '../../../src/model/CanoniOneri.php';
require_once '../../../src/model/AggiornaContratto.php';
require_once '../../../src/model/RateDettagli.php';
require_once '../../../src/model/TipiIva.php';
require_once '../../../src/model/Gestioni.php';
require_once '../../../src/model/AggiornamentoIstat.php';
require_once '../../../src/model/DrakkarTraceLog.php';
require_once '../../../src/model/UnitaImmobiliariContratti.php';

require_once '../../../src/function/functionLogin.php';

use Click\Affitti\Viste\Istat;
use Click\Affitti\TblBase\Rate;
use Click\Affitti\TblBase\PianoRateTesta;
use Click\Affitti\TblBase\CanoniOneri;
use Click\Affitti\Viste\AggiornaContratto;
use Click\Affitti\TblBase\RateDettagli;
use Click\Affitti\TblBase\TipiIva;
use Click\Affitti\TblBase\AggiornamentoIstat;
use Click\Affitti\TblBase\Gestioni;
use Click\Affitti\TblBase\UnitaImmobiliariContratti;


function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        $istat = new Istat($con, $con, 'Foi');
        $result['elenco_agg_istat'] = $istat->findElencoAggiornamentoIstat(false, Istat::FETCH_KEYARRAY);
        $rata = new Rate($con);
        $uic = new UnitaImmobiliariContratti($con);
        for ($i = 0; $i < count($result['elenco_agg_istat']); $i++) {
            $rata->setWhereBase(' bloccata=0 ');
            $result['elenco_agg_istat'][$i]['rate'] = $rata->findByIdContratto($result['elenco_agg_istat'][$i]['idContratto'], Rate::FETCH_KEYARRAY);
            if (isset($result['elenco_agg_istat'][$i]['rate'][0]['id']))
                $result['elenco_agg_istat'][$i]['rataSelezionata'] = $result['elenco_agg_istat'][$i]['rate'][0]['id'];
            $result['elenco_agg_istat'][$i]['immobili'] = $uic->elencoImmobiliPerContratto($result['elenco_agg_istat'][$i]['idContratto'], UnitaImmobiliariContratti::FETCH_KEYARRAY);
        }

        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
        $istat = new Istat($conExt, $con, 'Foi');
        $result['foi'] = $istat->findAll(false, Istat::FETCH_KEYARRAY);
        $result['anni'] = $istat->findAnni();
        $result['tipiIstat'] = $istat->getElencoTipiIstat(true);

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


function salvaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);

        $codiceGruppo = time();

        foreach ($request->obj as $elenco) {
            if ($elenco->selezionato) {
                $pianoRateTesta = new PianoRateTesta($con);

                /** @var PianoRateTesta $pianoRateTesta */
                foreach ($pianoRateTesta->findByIdxIdGestione($elenco->idGestione) as $pianoRateTesta) {
                    $canoniOneri = new CanoniOneri($con);
                    $canoniOneri->findByPk($pianoRateTesta->getIdCanoniOneri());
                    if ($canoniOneri->getTipoSaldo() == 'F') {

                        $importoVecchio = $pianoRateTesta->getImporto();

                        $conguaglioIstat = ((($pianoRateTesta->getImporto()) / 100) * $elenco->percentualeIstat);
                        $conguaglioIstat = round(($conguaglioIstat / 12) * $elenco->mesi_conguaglio_istat, 2);

                        $pianoRateTesta->setPercentualeIstat($elenco->percentualeIstat);
                        $pianoRateTesta->setConguaglio($conguaglioIstat);
                        $newImporto = round($importoVecchio * (1 + ($elenco->percentualeIstat / 100)), 2);
                        $pianoRateTesta->setImporto($newImporto);
                        //Calolo imponibile
                        $tipiIva = new TipiIva($con);
                        $newImponibile = $tipiIva->calcolaImponibileDaImporto(
                            $pianoRateTesta->getIdTipoIva(),
                            $newImporto
                        );
                        $pianoRateTesta->setImponibile($newImponibile);

                        $pianoRateTesta->setDataAggiornamentoIstat(date("Y-m-d G:i:s"));
                        $idPianoRateT = $pianoRateTesta->saveOrUpdate();

                        $gest = new Gestioni($con);
                        $gest->findByPk($elenco->idGestione);

                        $aggiornaContratto = new AggiornaContratto($con, $conExt);
                        $aggiornaContratto->cambioImporti(
                            $newImponibile,
                            $canoniOneri->getIdContratto(),
                            $canoniOneri->getId(),
                            $gest->getDataInizio(),
                            true
                        );
                        $pianoRateT = new PianoRateTesta($con);
                        $pianoRateT->findByPk($idPianoRateT);
                        $aggIstat = new AggiornamentoIstat($con);
                        $aggIstat->setCodiceGruppo($codiceGruppo);
                        $aggIstat->setIdContratto($canoniOneri->getIdContratto());
                        $aggIstat->setIdPianoRateTesta($pianoRateT->getId());
                        $aggIstat->setIdRata($elenco->rataSelezionata);
                        $aggIstat->setCanone($importoVecchio);
                        $aggIstat->setNuovoCanone(round($pianoRateT->getImporto(), 2));
                        $aggIstat->setPercentuale($elenco->percentualeIstat);
                        $aggIstat->setMesiConguaglio($elenco->mesi_conguaglio_istat);
                        $aggIstat->setConguaglio(round($pianoRateT->getConguaglio(), 2));
                        $aggIstat->saveOrUpdate();

                        if ($conguaglioIstat != 0) {
                            $rateD = new RateDettagli($con);
                            $rateD->setIdRata($elenco->rataSelezionata);
                            $rateD->setIdTipoIva($canoniOneri->getIdTipiIva());
                            $rateD->setTipoSpesa($canoniOneri->getTipoSpesa());
                            $rateD->setTipoSaldo($canoniOneri->getTipoSaldo());
                            $rateD->setDescrizione('Conguaglio ISTAT');
                            $rateD->setIdCategoriaSpesa('T');
                            $rateD->setImporto($conguaglioIstat);
                            $iva = new TipiIva($con);
                            $iva->findByPk($canoniOneri->getIdTipiIva());
                            $percentualeIva = $iva->getAliquota();
                            $rateD->setImponibile(round($conguaglioIstat / (1 + ($percentualeIva / 100)), 2));
                            $rateD->saveOrUpdate();
                        }
                    }
                }
            }
        }
        $con->commit();
        new \Drakkar\Log\DrakkarTraceLog(getLoginDataFromSession('id', 1));

        $result['codiceAggiornamentoIstat'] = $codiceGruppo;
        $result['status'] = 'ok';
        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarIntegrityConstrainException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::integrityConstrainException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
