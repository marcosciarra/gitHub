<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 15/12/17
 * Time: 10.38
 */

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';
require_once '../../../src/function/functionDate.php';
require_once '../../../src/function/functionLogin.php';

require_once '../../../src/model/ContrattiConAnagrafiche.php';
require_once '../../../src/model/ContrattiDettagli.php';
require_once '../../../src/model/Rli.php';
require_once '../../../src/model/UnitaImmobiliariContratti.php';
require_once '../../../src/model/DrakkarTraceLog.php';

use Click\Affitti\Viste\ContrattiConAnagrafiche;
use Click\Affitti\TblBase\ContrattiDettagli;
use Click\Affitti\TblBase\UnitaImmobiliari;
use Click\Affitti\TblBase\Rli;

function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        // CARICO DATI
        $contratti = new ContrattiConAnagrafiche($con);
        $contrattiDettagli = new ContrattiDettagli($con);
        $rli = new Rli($con);
        $ui = new UnitaImmobiliari($con);

        $result['contratti'] = [];
        $contratti->setWhereBase(' cestino=0 AND elaborato=1 ');
        $app = $contratti->findAll(false, ContrattiConAnagrafiche::FETCH_KEYARRAY);
        for ($i = 0; $i < count($app); $i++) {
            /** @var Rli $rli */
            foreach ($rli->findByIdContratto($app[$i]['id']) as $rli) {
                break;
            }

            // 3 - Tutti i locatori non optano alla cedolare secca
            if ($rli->getCedolareSecca() == 3) {
                $appoggio['contratto'] = $app[$i];
                $appoggio['dettagli'] = $contrattiDettagli->findByPk($app[$i]['id'], ContrattiDettagli::FETCH_KEYARRAY);
                $appoggio['ui'] = $ui->findByIdContratto($app[$i]['id'], UnitaImmobiliari::FETCH_KEYARRAY);
                $result['contratti'][] = $appoggio;
            }
        }

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
