ngApp.controller("lettereIstatController", ["$scope", "$http", "$filter", function ($scope, $http, $filter) {

    var url = window.location.href;
    var params = decodeUrl(url);
    stampalog(params);

    $scope.caricamentoCompletato = true;
    $scope.mesi = [
        {id: '1', descrizione: 'GENNAIO'},
        {id: '2', descrizione: 'FEBBRAIO'},
        {id: '3', descrizione: 'MARZO'},
        {id: '4', descrizione: 'APRILE'},
        {id: '5', descrizione: 'MAGGIO'},
        {id: '6', descrizione: 'GIUGNO'},
        {id: '7', descrizione: 'LUGLIO'},
        {id: '8', descrizione: 'AGOSTO'},
        {id: '9', descrizione: 'SETTEMBRE'},
        {id: '10', descrizione: 'OTTOBRE'},
        {id: '11', descrizione: 'NOVEMBRE'},
        {id: '12', descrizione: 'DICEMBRE'}
    ];

    /*--------------------------------------------------CARICA DATI---------------------------------------------------*/

    $scope.init = function () {
        $scope.filtroUtenti = [];
        $scope.filtroStabili = [];
        $scope.filtroLocatori = [];
        $scope.filtroConduttori = [];
        $scope.elencoUtenti = [];
        $scope.elencoLocatori = [];
        $scope.elencoConduttori = [];
        $scope.elencoStabili = [];

        $scope.caricaFiltri();

        var d = new Date();
        var app = (d.getMonth() + 1 + 1);
        $scope.meseSelezionato = (app > 12) ? '1' : '' + app;

        $scope.caricaDati();
    };

    $scope.caricaDati = function () {

        $http.post(params['form'] + '/istat/controller/lettereIstatHandler.php',
            {
                'function': 'caricaDati'
            }
        ).then(function (data, status, headers, config) {

            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }

            $scope.elencoContratti = [];
            $scope.elencoContrattiApp = data.data;

            stampalog($scope.elencoContrattiApp);

            for (var i = 0; i < $scope.elencoContrattiApp.contratti.length; i++) {
                $scope.elencoContrattiApp.contratti[i].selezionato = false;
                $scope.elencoContrattiApp.contratti[i].contratto.conduttori = jsonParse($scope.elencoContrattiApp.contratti[i].contratto.conduttori);
                $scope.elencoContrattiApp.contratti[i].contratto.primoConduttore = $scope.elencoContrattiApp.contratti[i].contratto.conduttori[0].descrizione;
                $scope.elencoContrattiApp.contratti[i].contratto.proprietari = jsonParse($scope.elencoContrattiApp.contratti[i].contratto.proprietari);
                $scope.elencoContrattiApp.contratti[i].contratto.primoProprietario = $scope.elencoContrattiApp.contratti[i].contratto.proprietari[0].descrizione;
                if ($scope.elencoContrattiApp.contratti[i].ui.length > 0)
                    $scope.elencoContrattiApp.contratti[i].ui.primoImmobile = $scope.elencoContrattiApp.contratti[i].ui[0].descrizione;
            }

            $scope.filtraElenco($scope.meseSelezionato);

            $scope.elencoContrattiApp.contrattiCopia = angular.copy($scope.elencoContrattiApp.contratti);

            $scope.caricamentoCompletato = true;

            stampalog($scope.elencoContrattiApp.contratti);
        });
    };

    /*---------------------------------------------------FILTRA DATI---------------------------------------------------*/
    $scope.filtraElenco = function (mese) {
        $scope.elencoContratti = [];
        for (var i = 0; i < $scope.elencoContrattiApp.contratti.length; i++) {
            if ($scope.elencoContrattiApp.contratti[i].dettagli.mese_riferimento_istat == mese) {
                $scope.elencoContratti.push($scope.elencoContrattiApp.contratti[i]);
            }
        }
        stampalog($scope.elencoContratti);
    };

    $scope.selezionaDeselezionaTutti = function (flag) {
        $scope.selezionatiTutti = flag;
        for (var i = 0; i < $scope.elencoContratti.length; i++) {
            $scope.elencoContratti[i].selezionato = flag;
        }
        for (var i = 0; i < $scope.arretrati.length; i++) {
            $scope.arretrati[i].selezionato = flag;
        }
    };

    /* =================================== FILTRI E ORDINAMENTI ===================================================== */

    $scope.selezionaDeselezionaTutti = function (flag) {
        $scope.selezionatiTutti = flag;
        for (var i = 0; i < $scope.elencoContrattiFiltrati.length; i++) {
            $scope.elencoContrattiFiltrati[i].selezionato = flag;
        }
    };

    $scope.cambiaOperazione = function () {
    };

    $scope.filtri = function () {
        $scope.caricaDati();
    };


    $scope.stampaLetteraSingola = function (idContratto) {
        var app = [idContratto];
        window.open(params['baseurl'] + '/stampe/istat/preavvisoIstatPdf.php?idContratto=' + app);
    };

    $scope.stampaLettera = function () {
        var primoId = true;
        if ($scope.elencoContrattiFiltrati != null) {
            var app = '';
            for (var i = 0; i < $scope.elencoContrattiFiltrati.length; i++) {
                if ($scope.elencoContrattiFiltrati[i].selezionato) {
                    if (primoId) {
                        app = $scope.elencoContrattiFiltrati[i].contratto.id;
                        primoId = false;
                    } else {
                        app = app + ',' + $scope.elencoContrattiFiltrati[i].contratto.id;
                    }
                }
            }
        }
        if (app.length == 0) {
            swal("Nessun contratto selezionato!")
        } else {
            window.open(params['baseurl'] + '/stampe/istat/preavvisoIstatPdf.php?idContratto=' + app);
        }
    };


    $scope.caricaDettagliModale = function (elenco, etichetta) {
        $scope.elencoModale = elenco;
        $scope.etichettaModale = etichetta;
    };


    //---------------------------------------------------SEZIONE FILTRI-----------------------------------------------//
    $scope.caricaFiltri = function () {
        $http.post($scope.params['form'] + "/template/controller/homeHandler.php",
            {'function': 'caricaFiltri'}
        ).then(function (data, status, headers, config) {
            // stampalog(data.data);
            $scope.filtriSelectPagina = data.data;
        });
    };
    $scope.settings = {
        dynamicTitle: true,
        enableSearch: true,
        showSelectAll: false,
        keyboardControls: true,
        scrollable: true,
        showCheckAll: false,
        showUncheckAll: true,
        closeOnSelect: false,
        scrollableHeight: '300px',
        externalIdProp: '', //PERMETTE DI AGGIUNGERE ALL'ARRAY DEI SELEZIONATI TUTTO L'OGGETTO
        idProp: 'id', //definisco i campi di cui è composto l'oggetto
        displayProp: 'descrizione' //definisco i campi di cui è composto l'oggetto
    };
    $scope.customTextUtenti = {
        buttonDefaultText: 'Utenti',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextStabili = {
        buttonDefaultText: 'Stabili',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextLocatori = {
        buttonDefaultText: 'Locatori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextConduttori = {
        buttonDefaultText: 'Conduttori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.multiSelectEventUtenti = {
        onItemSelect: function (obj) {
            $scope.filtroUtenti.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroUtenti.length; i++) {
                if ($scope.filtroUtenti[i] == obj.id) {
                    $scope.filtroUtenti.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function () {
            $scope.filtroUtenti = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventStabili = {
        onItemSelect: function (obj) {
            $scope.filtroStabili.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroStabili.length; i++) {
                if ($scope.filtroStabili[i] == obj.id) {
                    $scope.filtroStabili.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroStabili = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventLocatori = {
        onItemSelect: function (obj) {
            $scope.filtroLocatori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroLocatori.length; i++) {
                if ($scope.filtroLocatori[i] == obj.id) {
                    $scope.filtroLocatori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroLocatori = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventConduttori = {
        onItemSelect: function (obj) {
            $scope.filtroConduttori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroConduttori.length; i++) {
                if ($scope.filtroConduttori[i] == obj.id) {
                    $scope.filtroConduttori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroConduttori = [];
            $scope.filtriGenerici();
        }
    };
    $scope.svuotaMultiselect = function () {
        $scope.multiSelectEventUtenti.onDeselectAll();
        $scope.multiSelectEventLocatori.onDeselectAll();
        $scope.multiSelectEventConduttori.onDeselectAll();
        $scope.multiSelectEventStabili.onDeselectAll();
        $scope.elencoUtenti = [];
        $scope.elencoLocatori = [];
        $scope.elencoConduttori = [];
        $scope.elencoStabili = [];
    };
    $scope.filtriGenerici = function () {
        $scope.elencoContratti = [];
        var flag;
        for (var i = 0; i < $scope.elencoContrattiApp.contrattiCopia.length; i++) {
            flag = false;

            if ($scope.filtroUtenti.length == 0) {
                flag = true;
            } else {
                for (var k = 0; k < $scope.filtroUtenti.length; k++) {
                    if ($scope.elencoContrattiApp.contrattiCopia[i].contratto.id_utente_riferimento == $scope.filtroUtenti[k]) {
                        flag = true;
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroStabili.length == 0) {
                    flag = true;
                } else {
                    flag = false;
                    for (var j = 0; j < $scope.elencoContrattiApp.contrattiCopia[i].ui.length; j++) {
                        for (var k = 0; k < $scope.filtroStabili.length; k++) {
                            if ($scope.elencoContrattiApp.contrattiCopia[i].ui[j].id_stabili == $scope.filtroStabili[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroLocatori.length == 0) {
                    flag = true;
                } else {
                    flag = false;
                    for (var j = 0; j < $scope.elencoContrattiApp.contrattiCopia[i].contratto.proprietari.length; j++) {
                        for (var k = 0; k < $scope.filtroLocatori.length; k++) {
                            if ($scope.elencoContrattiApp.contrattiCopia[i].contratto.proprietari[j].id == $scope.filtroLocatori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroConduttori.length == 0) {
                    flag = true;
                } else {
                    flag = false;
                    for (var j = 0; j < $scope.elencoContrattiApp.contrattiCopia[i].contratto.conduttori.length; j++) {
                        for (var k = 0; k < $scope.filtroConduttori.length; k++) {
                            if ($scope.elencoContrattiApp.contrattiCopia[i].contratto.conduttori[j].id == $scope.filtroConduttori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                $scope.elencoContratti.push($scope.elencoContrattiApp.contrattiCopia[i]);
            }
        }
    };

}])
;