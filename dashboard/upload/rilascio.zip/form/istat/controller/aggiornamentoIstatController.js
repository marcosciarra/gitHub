ngApp.controller("aggiornamentoIstatController", ["$scope", "$http", "$filter", function ($scope, $http, $filter) {

    var url = window.location.href;
    var params = decodeUrl(url);
    stampalog(params);

    $scope.showRefresh = true;
    $scope.showIndietro = true;
    $scope.selezionatiTutti = true;
    $scope.caricamentoCompletato = false;
    $scope.filtroCerca = true;

    $scope.init = function () {
        $scope.filtroUtenti = [];
        $scope.filtroStabili = [];
        $scope.filtroLocatori = [];
        $scope.filtroConduttori = [];
        $scope.elencoUtenti = [];
        $scope.elencoLocatori = [];
        $scope.elencoConduttori = [];
        $scope.elencoStabili = [];

        $scope.caricaFiltri();

        $scope.elencoMesiConZero = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
        $scope.elencoMesiSenzaZero = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
        $scope.caricaDati();
    };


    /******************
     *   CARICADATI   * ================================================================================================
     ******************/

    $scope.caricaDati = function () {
        $http.post(params['form'] + '/istat/controller/aggiornamentoIstatHandler.php',
            {'function': 'caricaDati'}
        ).then(function (data, status, headers, config) {

            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }

            stampalog(data.data);

            $scope.elencoAggiornamentoIstat = data.data.elenco_agg_istat;
            $scope.elencoAnni = data.data.anni;
            $scope.elencoTipiIstat = data.data.tipiIstat;

            $scope.foi = data.data.foi;
            if ($scope.elencoAggiornamentoIstat != null) {
                for (i = 0; i < $scope.elencoAggiornamentoIstat.length; i++) {
                    if ($scope.elencoAggiornamentoIstat[i].rate.length == 0) {
                        $scope.elencoAggiornamentoIstat[i].selezionato = false;
                    } else {
                        $scope.elencoAggiornamentoIstat[i].selezionato = true;
                    }
                    $scope.elencoAggiornamentoIstat[i].proprietaro = jsonParse($scope.elencoAggiornamentoIstat[i].proprietari)[0].descrizione;
                    $scope.elencoAggiornamentoIstat[i].proprietari = jsonParse($scope.elencoAggiornamentoIstat[i].proprietari);
                    $scope.elencoAggiornamentoIstat[i].conduttore = jsonParse($scope.elencoAggiornamentoIstat[i].conduttori)[0].descrizione;
                    $scope.elencoAggiornamentoIstat[i].conduttori = jsonParse($scope.elencoAggiornamentoIstat[i].conduttori);
                    app = 1 * $scope.leggiPercentuale(
                        $scope.elencoAggiornamentoIstat[i].mese_riferimento_istat,
                        $scope.elencoAggiornamentoIstat[i].anno,
                        $scope.elencoAggiornamentoIstat[i].colonna_tabella_istat
                    );
                    if (app > 0) {
                        $scope.elencoAggiornamentoIstat[i].percentualeIstat = app;
                    } else {
                        /*
                        si possono togliere dall'elenco i contratti che non hanno un valore di %istat in tabella foi/custom...
                        $scope.elencoAggiornamentoIstat.splice(i, 1);
                        i--;
                        continue;
                        */
                        $scope.elencoAggiornamentoIstat[i].selezionato = false;
                    }

                    // TODO da mettere in una funzione che calcola....
                    $scope.elencoAggiornamentoIstat[i].nuovo_canone = calcolaNuovoCanone($scope.elencoAggiornamentoIstat[i].importo, $scope.elencoAggiornamentoIstat[i].percentualeIstat);
                    $scope.elencoAggiornamentoIstat[i].nuovo_canone = Math.round($scope.elencoAggiornamentoIstat[i].nuovo_canone * 100) / 100;

                    $scope.elencoAggiornamentoIstat[i].conguaglio = (($scope.elencoAggiornamentoIstat[i].nuovo_canone - $scope.elencoAggiornamentoIstat[i].importo) / 12) * ($scope.elencoAggiornamentoIstat[i].mesi_conguaglio_istat);
                    $scope.elencoAggiornamentoIstat[i].conguaglio = Math.round($scope.elencoAggiornamentoIstat[i].conguaglio * 100) / 100;
                }
                $scope.elencoAggiornamentoIstat.tabelle_istat = [
                    {id: 'foi', descrizione: 'FOI'}
                ];
            }

            $scope.elencoAggiornamentoIstatCopia = angular.copy($scope.elencoAggiornamentoIstat);

            $scope.caricamentoCompletato = true;
        });
    };

    /******************
     *   SALVADATI    * ================================================================================================
     ******************/
    $scope.salvaDati = function () {
        $scope.caricamentoCompletato = false;


        swal({
                title: "Procedere con l'aggiornamento ISTAT?",
                text: "",
                type: "success",
                showCancelButton: false,
                confirmButtonClass: "btn-success",
                confirmButtonText: "Si",
                cancelButtonText: "No",
                showLoaderOnConfirm: true,
                showCancelButton: true,
                closeOnConfirm: false,
                closeOnCancel: false
            },
            function (isConfirm) {
                if (isConfirm) {
                    $http.post(params['form'] + '/istat/controller/aggiornamentoIstatHandler.php',
                        {
                            'function': 'salvaDati',
                            'obj': $scope.elencoAggiornamentoIstat
                        }
                    ).then(function (data, status, headers, config) {
                        $scope.caricamentoCompletato = true;

                        if (data.data.status == "ko") {
                            swal(data.data.error.title, data.data.error.message, 'error');
                            return;
                        } else {
                            window.open(params['baseurl'] + '/stampe/istat/variazioneIstatPdf.php?codiceGruppo=' + data.data.codiceAggiornamentoIstat);
                            swal({
                                title: "Aggiornamenti ISTAT creati!",
                                text: 'Aprire anche il tabulato riepilogativo?',
                                type: "success",
                                showCancelButton: true,
                                confirmButtonClass: "btn-primary",
                                confirmButtonText: "Crea stampa!",
                                cancelButtonText: "Chiudi",
                                closeOnConfirm: false
                            }, function (isConfirm) {
                                if (isConfirm) {
                                    window.open(params['baseurl'] + '/stampe/istat/tabultatoIstatPdf.php?codiceGruppo=' + data.data.codiceAggiornamentoIstat);
                                }
                                location.reload();
                            });
                        }
                    })
                } else {
                    swal({
                        title: "Operazione annullata",
                        text: '',
                        type: "error"
                    }, function () {
                        location.reload();
                    });
                }
            });
    };


    /******************
     *    FUNZIONI    * ================================================================================================
     ******************/

    $scope.leggiPercentuale = function (mese, anno, colonna) {
        for (var i = 0; i < $scope.foi.length; i++) {
            if ($scope.foi[i].mese == mese &&
                $scope.foi[i].anno == anno) {
                switch (colonna) {
                    case "a75":
                        return $scope.foi[i].a75;
                        break;
                    case "a100":
                        return $scope.foi[i].a100;
                        break;
                    case "b75":
                        return $scope.foi[i].b75;
                        break;
                    case "b100":
                        return $scope.foi[i].b100;
                        break;
                }
            }
        }
    };

    $scope.recuperaPercentuale = function (mese, anno, colonna, index) {
        for (var i = 0; i < $scope.foi.length; i++) {
            if ($scope.foi[i].mese == mese &&
                $scope.foi[i].anno == anno) {
                switch (colonna) {
                    case "a75":
                        $scope.elencoAggiornamentoIstat[index].percentualeIstat = 1 * $scope.foi[i].a75;
                        break;
                    case "a100":
                        $scope.elencoAggiornamentoIstat[index].percentualeIstat = 1 * $scope.foi[i].a100;
                        break;
                    case "b75":
                        $scope.elencoAggiornamentoIstat[index].percentualeIstat = 1 * $scope.foi[i].b75;
                        break;
                    case "b100":
                        $scope.elencoAggiornamentoIstat[index].percentualeIstat = 1 * $scope.foi[i].b100;
                        break;
                }
                return;
            }
        }
        $scope.elencoAggiornamentoIstat[index].percentualeIstat = 0;
        $scope.elencoAggiornamentoIstat[index].selezionato = false;
        swal("Errore", "Valore non presente", "error");
    };

    $scope.ricalcolaConguaglio = function (importo, percentualeIstat, index) {
        $scope.elencoAggiornamentoIstat[index].nuovo_canone = calcolaNuovoCanone(importo, percentualeIstat);
        $scope.elencoAggiornamentoIstat[index].nuovo_canone = Math.round($scope.elencoAggiornamentoIstat[index].nuovo_canone * 100) / 100;

        var diff = calcolaNuovoCanone(importo, percentualeIstat) - importo;
        $scope.elencoAggiornamentoIstat[index].conguaglio = diff / 12 * ($scope.elencoAggiornamentoIstat[index].mesi_conguaglio_istat);
        $scope.elencoAggiornamentoIstat[index].conguaglio = Math.round($scope.elencoAggiornamentoIstat[index].conguaglio * 100) / 100;
    };

    calcolaNuovoCanone = function (importo, percentualeIstat) {
        return importo * (1 + (percentualeIstat / 100));
    };


    $scope.selezionaDeselezionaTutti = function (flag) {
        $scope.selezionatiTutti = flag;
        for (var i = 0; i < $scope.elencoAggiornamentoIstat.length; i++) {
            if ($scope.elencoAggiornamentoIstat[i].rate.length != 0) {
                $scope.elencoAggiornamentoIstat[i].selezionato = flag;
            }
        }
    };

    $scope.invertiSelezione = function () {
        $scope.selezionatiTutti = false;
        for (var i = 0; i < $scope.elencoAggiornamentoIstat.length; i++) {
            $scope.elencoAggiornamentoIstat[i].selezionato = !$scope.elencoAggiornamentoIstat[i].selezionato;
        }
    };

    $scope.modificaContratto = function (idContratto) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "gestioneContratto", idContratto);
    };


    //---------------------------------------------------SEZIONE FILTRI-----------------------------------------------//
    $scope.caricaFiltri = function () {
        $http.post($scope.params['form'] + "/template/controller/homeHandler.php",
            {'function': 'caricaFiltri'}
        ).then(function (data, status, headers, config) {
            // stampalog(data.data);
            $scope.filtriSelectPagina = data.data;
        });
    };
    $scope.settings = {
        dynamicTitle: true,
        enableSearch: true,
        showSelectAll: false,
        keyboardControls: true,
        scrollable: true,
        showCheckAll: false,
        showUncheckAll: true,
        closeOnSelect: false,
        scrollableHeight: '300px',
        externalIdProp: '', //PERMETTE DI AGGIUNGERE ALL'ARRAY DEI SELEZIONATI TUTTO L'OGGETTO
        idProp: 'id', //definisco i campi di cui è composto l'oggetto
        displayProp: 'descrizione' //definisco i campi di cui è composto l'oggetto
    };
    $scope.customTextUtenti = {
        buttonDefaultText: 'Utenti',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextStabili = {
        buttonDefaultText: 'Stabili',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextLocatori = {
        buttonDefaultText: 'Locatori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextConduttori = {
        buttonDefaultText: 'Conduttori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.multiSelectEventUtenti = {
        onItemSelect: function (obj) {
            $scope.filtroUtenti.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroUtenti.length; i++) {
                if ($scope.filtroUtenti[i] == obj.id) {
                    $scope.filtroUtenti.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function () {
            $scope.filtroUtenti = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventStabili = {
        onItemSelect: function (obj) {
            $scope.filtroStabili.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroStabili.length; i++) {
                if ($scope.filtroStabili[i] == obj.id) {
                    $scope.filtroStabili.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroStabili = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventLocatori = {
        onItemSelect: function (obj) {
            $scope.filtroLocatori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroLocatori.length; i++) {
                if ($scope.filtroLocatori[i] == obj.id) {
                    $scope.filtroLocatori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroLocatori = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventConduttori = {
        onItemSelect: function (obj) {
            $scope.filtroConduttori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroConduttori.length; i++) {
                if ($scope.filtroConduttori[i] == obj.id) {
                    $scope.filtroConduttori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroConduttori = [];
            $scope.filtriGenerici();
        }
    };
    $scope.svuotaMultiselect = function () {
        $scope.multiSelectEventUtenti.onDeselectAll();
        $scope.multiSelectEventLocatori.onDeselectAll();
        $scope.multiSelectEventConduttori.onDeselectAll();
        $scope.multiSelectEventStabili.onDeselectAll();
        $scope.elencoUtenti = [];
        $scope.elencoLocatori = [];
        $scope.elencoConduttori = [];
        $scope.elencoStabili = [];
    };
    $scope.filtriGenerici = function () {
        $scope.elencoAggiornamentoIstat = [];
        var flag;
        for (var i = 0; i < $scope.elencoAggiornamentoIstatCopia.length; i++) {
            flag = false;

            if ($scope.filtroUtenti.length == 0) {
                flag = true;
            } else {
                for (var k = 0; k < $scope.filtroUtenti.length; k++) {
                    if ($scope.elencoAggiornamentoIstatCopia[i].id_utente_riferimento == $scope.filtroUtenti[k]) {
                        flag = true;
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroStabili.length == 0) {
                    flag = true;
                } else {
                    flag = false;
                    for (var j = 0; j < $scope.elencoAggiornamentoIstatCopia[i].immobili.length; j++) {
                        for (var k = 0; k < $scope.filtroStabili.length; k++) {
                            if ($scope.elencoAggiornamentoIstatCopia[i].immobili[j].id_stabili == $scope.filtroStabili[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroLocatori.length == 0) {
                    flag = true;
                } else {
                    flag = false;
                    for (var j = 0; j < $scope.elencoAggiornamentoIstatCopia[i].proprietari.length; j++) {
                        for (var k = 0; k < $scope.filtroLocatori.length; k++) {
                            if ($scope.elencoAggiornamentoIstatCopia[i].proprietari[j].id == $scope.filtroLocatori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroConduttori.length == 0) {
                    flag = true;
                } else {
                    flag = false;
                    for (var j = 0; j < $scope.elencoAggiornamentoIstatCopia[i].conduttori.length; j++) {
                        for (var k = 0; k < $scope.filtroConduttori.length; k++) {
                            if ($scope.elencoAggiornamentoIstatCopia[i].conduttori[j].id == $scope.filtroConduttori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                $scope.elencoAggiornamentoIstat.push($scope.elencoAggiornamentoIstatCopia[i]);
            }
        }
    };


}])
;