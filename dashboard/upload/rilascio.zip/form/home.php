<!DOCTYPE html>
<html ng-app="affittiApp" ng-controller="homeController">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <?php
    header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1.
    header("Pragma: no-cache"); // HTTP 1.0.
    header("Expires: 0"); // Proxies.
    ?>
    <!--import lib css js-->
    <?php include_once '../grafica/header.html';?>
    <!--import controller-->
    <script type="text/javascript"  src="template/controller/homeController.js"></script>
    <!--funzione php per l'import dinamico dei controller delle pagine di cui faccio l'include-->
    <?php
        $sezione = 'cruscotto';
        $controller = 'cruscottoController.js';
        $cartella = 'controller';

        if(isset($_GET['sezione']))
            $sezione = $_GET['sezione'];
        if(isset($_GET['pagina']))
            $controller = $_GET['pagina'].'Controller.js';

//        echo '<script type="text/javascript" src="'.$sezione.'/'.$cartella.'/'.$controller.'"></script>';
        echo '<script type="text/javascript" src="'.$sezione.'/'.$cartella.'/'.$controller.'?version='.date('Ymd').'"></script>';

        if(isset($_GET['pagina']) && $_GET['pagina']=='timelineContratto'){
            echo '<link href="../grafica/css/timeline.css" rel="stylesheet" type="text/css" media="all">';
        }
    ?>

</head>

<body class="bgColor">
<div class="horizontalBar">
    <div class="mostraMenuContainer pointer">
        <img src="../grafica/img/Logo-Click.png"
        style="margin-top: 4px; background-color: rgba(255,255,255,0.6); border: 1px solid #fff; border-radius: 5px;" ng-click="contatti();">
    </div>

    <div id="gestioneUtente" class="containerUtenteHeader">
        <div class="horizontalBarButtonContainer">
            <button type="button" class="btn btn-sm horizontalBarErrorButton pointer" title="Configurazioni"
                    ng-show="mostraAvvisoCambioPwd" ng-click="cambiaPassword()">
                <i class="fa fa-fw fa-key fa-2x" aria-hidden="true"></i>
            </button>
            <button type="button" class="btn btn-sm horizontalBarButton pointer" title="Configurazioni"
                    ng-click="includePage('configurazioni','configurazioni')">
                <i class="fa fa-fw fa-cog fa-2x" aria-hidden="true"></i>
            </button>
            <button type="button" class="btn btn-sm horizontalBarButton pointer" title="Logout"
                    ng-click="logout()">
                <i class="fa fa-fw fa-power-off fa-2x" aria-hidden="true"></i>
            </button>
            <div class="infoUtente">Benvenuto: {{username}}</div>

        </div>
    </div>
</div>

<div ng-class="{'sidebarOpened' : visible, 'sidebarClosed' : !visible}">

    <div class="menu-container" id="containerMostraMenu">
        <div class="mostraMenu pointer" ng-click="mostraMenu()">
            <i class="fa fa-bars fa-fw fa-lg" aria-hidden="true"></i>
            <span class="menu-testo">Nascondi menu</span>
        </div>
    </div>

    <!--------------------------------------------------HOME----------------------------------------------------------->
    <div class="menu-container">
        <div class="primoLivello pointer" ng-click="includePage('cruscotto','cruscotto')" title="Home">
            <i class="fa fa-tachometer fa-fw fa-lg" aria-hidden="true"></i>
            <span class="menu-testo">Home</span>
        </div>
    </div>

    <!--------------------------------------------------ANAGRAFICA----------------------------------------------------->
    <div class="menu-container">
        <div class="primoLivello pointer" ng-click="includePage('anagrafica','anagrafica')" title="Anagrafica">
            <i class="fa fa-address-book-o fa-fw fa-lg" aria-hidden="true"></i>
            <span class="menu-testo">Anagrafica</span>
        </div>
    </div>
    <div class="menu-container" id="containerAnagrafica" ng-show="import.indexOf('anagrafica') > -1 ">
        <div class="secondoLivello pointer" ng-click="includePage('anagrafica','stampeAnagrafiche')" title="Stampe Anagrafiche">
            <i class="fa fa-print fa-fw fa-lg" aria-hidden="true"></i>
            <span class="menu-testo">Stampe Anagrafiche</span>
        </div>
    </div>
    <!--------------------------------------------------IMMOBILI------------------------------------------------------->
    <div class="menu-container">
        <div class="primoLivello pointer" ng-click="includePage('immobili','stabili')" title="Stabile">
            <i class="fa fa-building fa-fw fa-lg" aria-hidden="true"></i>
            <span class="menu-testo">Stabili</span>
        </div>
    </div>
    <div class="menu-container" id="containerImmobili" ng-show="import.indexOf('immobili') > -1 ">
        <div class="secondoLivello pointer" ng-click="includePage('immobili','immobile')" title="Unità Immobiliare">
            <i class="fa fa-home fa-fw fa-lg" aria-hidden="true"></i>
            <span class="menu-testo">Unità Immobiliare</span>
        </div>
    </div>

    <!--------------------------------------------------CONTRATTO------------------------------------------------------>
    <div class="menu-container">
        <div class="primoLivello pointer" ng-click="includePage('contratto','contratto')" title="Contratti">
            <i class="fa fa-handshake-o fa-fw fa-lg" aria-hidden="true"></i>
            <span class="menu-testo">Contratti</span>
        </div>
    </div>
    <div class="menu-container" id="containerContratto" ng-show="import.indexOf('contratto') > -1 ">
        <div class="secondoLivello pointer" ng-click="includePage('contratto','proroghe')" title="Elenco Proroghe">
            <i class="fa fa-refresh fa-fw fa-lg" aria-hidden="true"></i>
            <span class="menu-testo">Elenco Proroghe (F24)</span>
        </div>
        <div class="secondoLivello pointer" ng-click="includePage('contratto','disdette')" title="Elenco Disdette">
            <i class="fa fa-bell fa-fw fa-lg" aria-hidden="true"></i>
            <span class="menu-testo">Elenco Disdette</span>
        </div>
        <div class="secondoLivello pointer" ng-click="includePage('contratto','stampeContrattuali')" title="Stampe Contrattuali">
            <i class="fa fa-print fa-fw fa-lg" aria-hidden="true"></i>
            <span class="menu-testo">Stampe Contrattuali</span>
        </div>
    </div>

    <!--------------------------------------------------ISTAT---------------------------------------------------------->
    <div class="menu-container">
        <div class="primoLivello pointer" ng-click="includePage('istat','aggiornamentoIstat')" title="Istat">
            <i class="fa fa fa-bar-chart fa-fw fa-lg" aria-hidden="true"></i>
            <span class="menu-testo">Istat</span>
        </div>
    </div>
    <div class="menu-container" id="containerIstat" ng-show="import.indexOf('istat') > -1 ">
        <div class="secondoLivello pointer" ng-click="includePage('istat','lettereIstat')" title="Preavviso Istat">
            <i class="fa fa-file-text-o fa-fw fa-lg" aria-hidden="true"></i>
            <span class="menu-testo">Preavviso Istat</span>
        </div>
        <div class="secondoLivello pointer" ng-click="includePage('istat','tabelleIstat')" title="Tabelle Istat">
            <i class="fa fa-table fa-fw fa-lg" aria-hidden="true"></i>
            <span class="menu-testo">Tabelle Istat</span>
        </div>
    </div>

    <!--------------------------------------------------FATTURAZIONE--------------------------------------------------->
    <div class="menu-container">
        <div class="primoLivello pointer" ng-click="includePage('fatturazione','fatturazione')" title="Esazione">
            <i class="fa fa-eur fa-fw fa-lg" aria-hidden="true"></i>
            <span class="menu-testo">Esazione</span>
        </div>
    </div>
    <div class="menu-container" id="containerIstat" ng-show="import.indexOf('fatturazione') > -1 ">
        <div class="secondoLivello pointer" ng-click="includePage('fatturazione','eFatture')" title="Fatture Elettroniche">
            <i class="fa fa-file-code-o fa-fw fa-lg" aria-hidden="true"></i>
            <span class="menu-testo">e-Fatture</span>
        </div>
        <div class="secondoLivello pointer" ng-click="includePage('fatturazione','eFattureStato')" title="Stato Fatture">
            <i class="fa fa-stack-exchange fa-fw fa-lg" aria-hidden="true"></i>
            <span class="menu-testo">Stato e-Fatture</span>
        </div>
    </div>

    <!--------------------------------------------------CONTABILITA--------------------------------------------------->
    <div class="menu-container">
        <div class="primoLivello pointer" ng-click="includePage('contabilita','contabilita')" title="Fatturazione">
            <i class="fa fa-calculator fa-fw fa-lg" aria-hidden="true"></i>
            <span class="menu-testo">Contabilità</span>
        </div>
    </div>

    <!--------------------------------------------------ARCHIVIO------------------------------------------------------->
    <div class="menu-container">
        <div class="primoLivello pointer" ng-click="includePage('archivio','archivio')" title="Archivio">
            <i class="fa fa-archive fa-fw fa-lg" aria-hidden="true"></i>
            <span class="menu-testo">Archivio</span>
        </div>
    </div>
    <div class="menu-container" id="containerIstat" ng-show="import.indexOf('archivio') > -1 ">
        <div class="secondoLivello pointer" ng-click="includePage('archivio','operazioni')" title="Preavviso Istat">
            <i class="fa fa-wrench fa-fw fa-lg" aria-hidden="true"></i>
            <span class="menu-testo">Operazioni</span>
        </div>
        <div class="secondoLivello pointer" ng-click="includePage('archivio','flussi')" title="Tabelle Istat">
            <i class="fa fa-database fa-fw fa-lg" aria-hidden="true"></i>
            <span class="menu-testo">Flussi</span>
        </div>
    </div>

    <!--------------------------------------------------AVVISI----------------------------------------------------------->
    <div class="menu-container">
        <div class="primoLivello pointer" ng-click="includePage('avvisi','avvisi')" title="Avvisi"
             ng-class="{'avvisiNonLetti' : avvisi>0}">
            <i class="fa fa-commenting-o fa-fw fa-lg" aria-hidden="true"></i>
            <span class="menu-testo" ng-show="avvisi>0">Avvisi : {{avvisi}}</span>
            <span class="menu-testo" ng-show="avvisi==0">Avvisi</span>
        </div>
    </div>

    <!--------------------------------------------------INTERVENTI----------------------------------------------------->
<!--    <div class="menu-container">-->
<!--        <div class="primoLivello pointer" ng-click="includePage('interventi','interventi')" title="Operazioni">-->
<!--            <i class="fa fa-volume-control-phone fa-fw fa-lg" aria-hidden="true"></i>-->
<!--            <span class="menu-testo">Interventi</span>-->
<!--        </div>-->
<!--    </div>-->

</div>




<div ng-class="{'contentPart' : visible, 'contentFull' : !visible}">
    <!--
     pagina: variabile di scope contente la pagina da includere
     ng-init: attiva l'ng-include al termine della funzione, in getPageIncluded definisco quale sarà la variabile 'pagina' poi la importo
     -->

    <div id="contenitorePagina">
        <div ng-include src="import" ng-init="getPageIncluded()"></div>
    </div>
</div>
<script>
    $(document).ready(function(){
        $('[data-toggle="popover"]').popover({trigger:"focus",placement:"bottom",container:"body"});
    });
</script>

</body>
</html>