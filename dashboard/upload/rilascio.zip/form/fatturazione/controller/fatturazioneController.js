ngApp.controller("fatturazioneController", ["$scope", "$http", "$filter", function ($scope, $http, $filter) {

    var url = window.location.href;
    var params = decodeUrl(url);
    stampalog(params);

    $scope.caricamentoCompletato = false;
    $scope.filtroCerca = false;
    /*================================================CARICADATI======================================================*/

    $scope.init = function () {
        $scope.filtroUtenti = [];
        $scope.filtroStabili = [];
        $scope.filtroLocatori = [];
        $scope.filtroConduttori = [];
        $scope.elencoUtenti = [];
        $scope.elencoLocatori = [];
        $scope.elencoConduttori = [];
        $scope.elencoStabili = [];

        $scope.caricaFiltri();


        $scope.filtroTipoContratto = 'A';

        var d = new Date;
        var app = new Date(d.setDate(d.getDate()));
        var app = new Date(app.setMonth(app.getMonth()));
        $scope.filtroDataInizio = app;
        $http.post(params['form'] + '/template/controller/homeHandler.php',
            {
                'function': 'sommaData',
                'data_inizio': getYYYYMMGGFromJsDate($scope.filtroDataInizio)
            }
        ).then(function (data, status, headers, config) {
            $scope.filtroDataFine = getJsDateFromYYYYMMGG(data.data);

            // $scope.tipoRichiesta = [
            //     {id: 'A', descrizione: 'AVVISO DI PAGAMENTO'},
            //     {id: 'F', descrizione: 'FATTURA'},
            //     {id: 'FP', descrizione: 'FATTURA AL PAGAMENTO'},
            //     {id: 'M', descrizione: 'MAV'},
            //     {id: 'R', descrizione: 'RID'}
            // ];

            $scope.bollettazione_tipo = 'A';
            $scope.selezionatiTutti = true;
            $scope.caricaDati();
        });
    };

    /*----------------------------------------------CARICAMENTO DATI--------------------------------------------------*/
    $scope.caricaDati = function () {

        if (isValidDate(getYYYYMMGGFromJsDate($scope.filtroDataInizio)) && isValidDate(getYYYYMMGGFromJsDate($scope.filtroDataFine))) {

            $scope.caricamentoCompletato = false;
            $http.post(params['form'] + '/fatturazione/controller/fatturazioneHandler.php',
                {
                    'function': 'caricaDati',
                    'dataInizio': getYYYYMMGGFromJsDate($scope.filtroDataInizio),
                    'dataFine': getYYYYMMGGFromJsDate($scope.filtroDataFine),
                    'tipoDocumento': $scope.filtroTipoContratto
                }
            ).then(function (data, status, headers, config) {

                if (data.data.status == 'ko') {
                    swal(data.data.error.title, data.data.error.message, 'error');
                    return;
                }

                //CARICAMENTO SELECT
                //Tipo contratto (Abitativo...)
                $scope.elencoFatture = data.data.elencoFatture;
                for (var i = 0; i < $scope.elencoFatture.length; i++) {
                    $scope.elencoFatture[i].proprietari = jsonParse($scope.elencoFatture[i].proprietari);
                    $scope.elencoFatture[i].primoLocatore = $scope.elencoFatture[i].proprietari[0].descrizione;
                    $scope.elencoFatture[i].conduttori = jsonParse($scope.elencoFatture[i].conduttori);
                    $scope.elencoFatture[i].primoConduttore = $scope.elencoFatture[i].conduttori[0].descrizione;
                    $scope.elencoFatture[i].dataScadenzaFormat = formattaDataDbToIta($scope.elencoFatture[i].data_scadenza);

                    $scope.elencoFatture[i].selezionato = true;
                }

                $scope.gruppiFatturazione = data.data.gruppiFatturazione;

                // stampalog('Gruppi Fatturazione');
                // stampalog($scope.gruppiFatturazione);
                // stampalog('Dettaglio fatture');
                // stampalog($scope.elencoFatture);
                stampalog(data.data);

                $scope.data_emissione = new Date(today());

                $scope.elencoFattureCopia = angular.copy($scope.elencoFatture);


                $scope.totaleAvvisi = data.data.totaleAvvisi;
                $scope.totaleFatture = data.data.totaleFatture;
                $scope.totaleMav = data.data.totaleMav;
                $scope.totaleRid = data.data.totaleRid;
                $scope.totaleFattureAlPagamento = data.data.totaleFattureAlPagamento;

                $scope.caricamentoCompletato = true;
            });
        }
        else {
            swal('Verificare le date di ricerca', '', 'error');
        }
    };

    /*-----------------------------------------------------SALVA DATI-------------------------------------------------*/

    $scope.salvaDati = function () {
        $scope.caricamentoCompletato = false;

        $http.post(params['form'] + '/fatturazione/controller/fatturazioneHandler.php',
            {
                'function': 'salvaFlusso',
                'dataEmissione': getYYYYMMGGFromJsDate($scope.data_emissione),
                'gruppiFatturazione': $scope.gruppiFatturazione,
                'elencoFatture': $scope.elencoFattureFiltrate,
                'anteprima': false
            }
        ).then(function (data, status, headers, config) {
            $scope.caricamentoCompletato = true;
            if (data.data.status == "ko") {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }
            else {
                window.open(params['baseurl'] + '/stampe/avvisiPagamento/avvisoPagamentoPdf.php?codiceGruppo=' + data.data.codice_gruppo);
                swal({
                    title: "Documenti creati!",
                    text: 'Aprire anche il tabulato riepilogativo?',
                    type: "success",
                    showCancelButton: true,
                    confirmButtonClass: "btn-primary",
                    confirmButtonText: "Crea stampa!",
                    cancelButtonText: "Chiudi",
                    closeOnConfirm: false
                }, function (isConfirm) {
                    if (isConfirm) {
                        window.open(params['baseurl'] + '/stampe/avvisiPagamento/tabulatoRiepilogativoPdf.php?codiceGruppo=' + data.data.codice_gruppo);
                    }
                    location.reload();
                });
            }
        });
    };


    /*----------------------------------------------CARICA DATI PER MODALE--------------------------------------------*/

    $scope.caricaDettagliModale = function (elenco, etichetta) {
        $scope.elencoModale = elenco;
        $scope.etichettaModale = etichetta;
    };

    $scope.caricaDettaglioFattura = function (idRata) {
        $http.post(params['form'] + '/fatturazione/controller/fatturazioneHandler.php',
            {
                'function': 'dettaglioFattura',
                'idRata': idRata
            }
        ).then(function (data, status, headers, config) {

            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }

            //CARICAMENTO SELECT
            $scope.dettaglioFattura = data.data.dettaglioFattura;

        });
    };


    $scope.stampaTabulato = function () {


        swal({
            title: "Creare l'anteprima di stampa",
            text: "",
            type: "warning",
            showCancelButton: true,
            cancelButtonText: "No",
            confirmButtonClass: "btn-success",
            confirmButtonText: "Si, procedi.",
            showLoaderOnConfirm: true,
            closeOnConfirm: false
        }, function () {
            $http.post(params['form'] + '/template/controller/homeHandler.php',
                {
                    'function': 'getUsernameUserLogged'
                }
            ).then(function (data, status, headers, config) {
                $scope.sessionId = data.data.sessionId;
                $http.post(params['form'] + '/fatturazione/controller/fatturazioneHandler.php',
                    {
                        'function': 'salvaFlusso',
                        'dataEmissione': getYYYYMMGGFromJsDate($scope.data_emissione),
                        'gruppiFatturazione': $scope.gruppiFatturazione,
                        'elencoFatture': $scope.elencoFattureFiltrate,
                        'anteprima': true
                    }
                ).then(function (data, status, headers, config) {
                    $scope.caricamentoCompletato = true;
                    if (data.data.status == "ko") {
                        swal(data.data.error.title, data.data.error.message, 'error');
                        return;
                    }
                    else {
                        if (data.data.status == "ok") {
                            swal({
                                    title: "Mostra anteprima",
                                    text: "",
                                    type: "success",
                                    showCancelButton: false,
                                    confirmButtonClass: "btn-success",
                                    confirmButtonText: "Ok",
                                    closeOnConfirm: true
                                },
                                function () {
                                    window.open(params['baseurl'] + '/stampe/avvisiPagamento/tabulatoRiepilogativoPdf.php?codiceGruppo=' + data.data.codice_gruppo);

                                    $http.post(params['form'] + '/archivio/controller/operazioniHandler.php',
                                        {
                                            'function': 'eliminaFlusso',
                                            'tipoFlusso': 'fatture',
                                            'codiceGruppo': data.data.codice_gruppo,
                                            'id': null
                                        }
                                    );//.then(function (data, status, headers, config) {
                                });
                        }
                    }
                });
            });
        });
    };


    /*---------------------------------------------------REDIRECT-----------------------------------------------------*/

    $scope.modificaRata = function (idContratto, idRata) {
        var parametri = [];
        parametri.push(idContratto);
        parametri.push(idRata);
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "rateizzazioneContratto", parametri);
    };

    /*******************
     *   ESPORTA PDF   * ================================================================================================
     *******************/

    $scope.visualizzaImpoStampa = false;
    $scope.showImpostazioniStampa = function () {
        $scope.visualizzaImpoStampa = !$scope.visualizzaImpoStampa;
    };

    $scope.stampa = getStrutturaBasePDF();
    $scope.stampa.orientamento = 'P';
    $scope.stampa.nomeFile = "riepilogo_fatture";

    $scope.getHeaderTable = function () {
        return ["LOCATORI", "CONDUTTORI", "SCADENZA", "IMPORTO"];
    };

    $scope.creaFileDaScaricare = function () {
        $scope.fileExport = new Array();

        for (i = 0; i < $scope.elencoFattureFiltrate.length; i++) {
            if ($scope.elencoFattureFiltrate[i].selezionato) {
                app = new Array();
                $scope.elencoFattureFiltrate[i].primoLocatore != null ? app.push("" + $scope.elencoFattureFiltrate[i].primoLocatore) : app.push("");
                $scope.elencoFattureFiltrate[i].primoConduttore != null ? app.push("" + $scope.elencoFattureFiltrate[i].primoConduttore) : app.push("");
                $scope.elencoFattureFiltrate[i].data_scadenza != null ? app.push("" + formatDataDbToIta($scope.elencoFattureFiltrate[i].data_scadenza)) : app.push("");
                $scope.elencoFattureFiltrate[i].importo != null ? app.push("" + $scope.elencoFattureFiltrate[i].importo.toLocaleString('it-IT', {
                    style: 'currency',
                    currency: 'EUR'
                })) : app.push("");

                $scope.fileExport.push(app);
            }
        }

        //stampalog("File da scaricare:");
        //stampalog($scope.fileExport);

        return $scope.fileExport;
    };


    $scope.scaricaPDF = function () {
        var title = 'ELENCO ' + stampaTitoloStampa($scope.bollettazione_tipo);
        title += ' - dal ' + stampaDataFormattata($scope.filtroDataInizio);
        title += ' al ' + stampaDataFormattata($scope.filtroDataFine);
        var elencoDaStampare = $scope.creaFileDaScaricare();
        if (elencoDaStampare.length > 0) {
            scaricaPDF($scope.stampa, $scope.getHeaderTable(), elencoDaStampare, title);
        } else {
            swal('Errore', 'Nessun contratto selezionato', 'error');
            return;
        }
    };

    stampaTitoloStampa = function (id) {
        return $filter('filter')($scope.tipoRichiesta, {id: id})[0].descrizione;
    };
    stampaDataFormattata = function (data) {
        return $filter('date')(data, "dd/MM/yyyy");
    };

    $scope.selezionaDeselezionaTutti = function (flag) {
        $scope.selezionatiTutti = flag;
        for (var i = 0; i < $scope.elencoFattureFiltrate.length; i++) {
            $scope.elencoFattureFiltrate[i].selezionato = flag;
        }
    };


    //---------------------------------------------------SEZIONE FILTRI-----------------------------------------------//
    $scope.caricaFiltri = function () {
        $http.post($scope.params['form'] + "/template/controller/homeHandler.php",
            {'function': 'caricaFiltri'}
        ).then(function (data, status, headers, config) {
            // stampalog(data.data);
            $scope.filtriSelectPagina = data.data;
        });
    };
    $scope.settings = {
        dynamicTitle: true,
        enableSearch: true,
        showSelectAll: false,
        keyboardControls: true,
        scrollable: true,
        showCheckAll: false,
        showUncheckAll: true,
        closeOnSelect: false,
        scrollableHeight: '300px',
        externalIdProp: '', //PERMETTE DI AGGIUNGERE ALL'ARRAY DEI SELEZIONATI TUTTO L'OGGETTO
        idProp: 'id', //definisco i campi di cui è composto l'oggetto
        displayProp: 'descrizione' //definisco i campi di cui è composto l'oggetto
    };
    $scope.customTextUtenti = {
        buttonDefaultText: 'Utenti',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextStabili = {
        buttonDefaultText: 'Stabili',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextLocatori = {
        buttonDefaultText: 'Locatori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextConduttori = {
        buttonDefaultText: 'Conduttori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.multiSelectEventUtenti = {
        onItemSelect: function (obj) {
            $scope.filtroUtenti.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroUtenti.length; i++) {
                if ($scope.filtroUtenti[i] == obj.id) {
                    $scope.filtroUtenti.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function () {
            $scope.filtroUtenti = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventStabili = {
        onItemSelect: function (obj) {
            $scope.filtroStabili.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroStabili.length; i++) {
                if ($scope.filtroStabili[i] == obj.id) {
                    $scope.filtroStabili.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroStabili = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventLocatori = {
        onItemSelect: function (obj) {
            $scope.filtroLocatori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroLocatori.length; i++) {
                if ($scope.filtroLocatori[i] == obj.id) {
                    $scope.filtroLocatori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroLocatori = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventConduttori = {
        onItemSelect: function (obj) {
            $scope.filtroConduttori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroConduttori.length; i++) {
                if ($scope.filtroConduttori[i] == obj.id) {
                    $scope.filtroConduttori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroConduttori = [];
            $scope.filtriGenerici();
        }
    };
    $scope.svuotaMultiselect = function () {
        $scope.multiSelectEventUtenti.onDeselectAll();
        $scope.multiSelectEventLocatori.onDeselectAll();
        $scope.multiSelectEventConduttori.onDeselectAll();
        $scope.multiSelectEventStabili.onDeselectAll();
        $scope.elencoUtenti = [];
        $scope.elencoLocatori = [];
        $scope.elencoConduttori = [];
        $scope.elencoStabili = [];
    };
    $scope.filtriGenerici = function () {
        $scope.elencoFatture = [];
        var flag;
        for (var i = 0; i < $scope.elencoFattureCopia.length; i++) {
            flag = false;

            if ($scope.filtroUtenti.length == 0) {
                flag = true;
            }
            else {
                for (var k = 0; k < $scope.filtroUtenti.length; k++) {
                    if ($scope.elencoFattureCopia[i].id_utente_riferimento == $scope.filtroUtenti[k]) {
                        flag = true;
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroStabili.length == 0) {
                    flag = true;
                }
                else {
                    flag = false;
                    for (var j = 0; j < $scope.elencoFattureCopia[i].immobili.length; j++) {
                        for (var k = 0; k < $scope.filtroStabili.length; k++) {
                            if ($scope.elencoFattureCopia[i].immobili[j].id_stabili == $scope.filtroStabili[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroLocatori.length == 0) {
                    flag = true;
                }
                else {
                    flag = false;
                    for (var j = 0; j < $scope.elencoFattureCopia[i].proprietari.length; j++) {
                        for (var k = 0; k < $scope.filtroLocatori.length; k++) {
                            if ($scope.elencoFattureCopia[i].proprietari[j].id == $scope.filtroLocatori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroConduttori.length == 0) {
                    flag = true;
                }
                else {
                    flag = false;
                    for (var j = 0; j < $scope.elencoFattureCopia[i].conduttori.length; j++) {
                        for (var k = 0; k < $scope.filtroConduttori.length; k++) {
                            if ($scope.elencoFattureCopia[i].conduttori[j].id == $scope.filtroConduttori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                $scope.elencoFatture.push($scope.elencoFattureCopia[i]);
            }
        }
    };

}])
;