<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 23/02/18
 * Time: 16.44
 */

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';
require_once '../../../src/function/functionDate.php';
require_once '../../../src/function/functionGeneric.php';

require_once '../../../src/model/Contratti.php';
require_once '../../../src/model/FatturazioneTesta.php';
require_once '../../../src/model/FatturazioneDettagli.php';
require_once '../../../src/model/UnitaImmobiliari.php';
require_once '../../../src/model/UnitaImmobiliariContratti.php';
require_once '../../../src/model/Rate.php';
require_once '../../../src/model/Contabilita.php';
require_once '../../../src/model/Anagrafiche.php';
require_once '../../../src/model/TipiIva.php';

require_once '../../../src/model/TipoDocumento.php';
require_once '../../../src/model/RegimeFiscale.php';
require_once '../../../src/model/ProgressivoEfattura.php';

require_once '../../../lib/flussi/fattureB2B/Fattura.php';
require_once '../../../lib/flussi/fattureB2B/WS.php';


use Click\Affitti\TblBase\FatturazioneTesta;
use Click\Affitti\Viste\Contabilita;
use Click\Affitti\TblBase\UnitaImmobiliariContratti;
use Click\Affitti\TblBase\Rate;
use Click\Affitti\TblBase\Contratti;
use Click\Affitti\TblBase\Anagrafiche;
use Click\Affitti\TblBase\UnitaImmobiliari;
use Click\Affitti\TblBase\FatturazioneDettagli;
use Click\Affitti\TblBase\TipiIva;
use Click\FattureB2B\Fattura;
use Click\FattureB2B\WS;
use Click\Affitti\TblBase\TipoDocumento;
use Click\Affitti\TblBase\ProgressivoEfattura;


function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        $fattureT = new FatturazioneTesta($con);
        $rate = new Rate($con);
        $uic = new UnitaImmobiliariContratti($con);
        $contratto = new Contratti($con);
        $fattureT->setOrderBase(' codice_gruppo asc, data_scadenza asc ');

        $result['documenti'] = [];
        foreach ($fattureT->findElencoFatturePerXml() as $doc) {
            $app['documento'] = $doc;
            $app['documento']['id_contratto'] = $rate->findIdContrattoByIdRata($doc['id_rata']);
            $app['documento']['immobili'] = $uic->elencoImmobiliPerContratto(17, UnitaImmobiliariContratti::FETCH_KEYARRAY);
            $contratto->findByPk($app['documento']['id_contratto']);
            $app['documento']['id_utente_riferimento'] = $contratto->getIdUtenteRiferimento();
            $result['documenti'][] = $app['documento'];
        }

        $result['status'] = 'ok';
        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }

}


function elaboraSelezionati($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
        $con->beginTransaction();

        $fattureT = new FatturazioneTesta($con);
        $codiceGruppo = time();
        foreach ($request->documenti as $d) {
            if ($d->selezionato) {
                $fattureT->findByPk($d->id);
                //Dare in pasto la fattura al metodo che la contabilizza
                $contabilita = new Contabilita($con, $conExt);
                $contabilita->autoregistrazioneFattura($fattureT->getId(), $codiceGruppo);
                $fattureT->setContabilizzato(1);
                $fattureT->saveOrUpdate();
            }
        }

        $con->commit();

        $result['status'] = 'ok';

        return json_encode($result);

    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


function verificaFlusso($request)
{
    /** @var Fattura $fatturaXml */
    $fatturaXml = preparaFatturaXml($request->id);
    $ws = new \Click\FattureB2B\WS();
    $xmlPath = $ws->creaXMLgetPath($fatturaXml->toJson());
    //error_log($ws->getStringXMLbyPath($xmlPath));
    $wsResult = json_decode($ws->verificaXML($xmlPath, true));
    $result['risposta'] = $wsResult;
    if (isset($wsResult->status) && $wsResult->status == 'OK') {
        try {
            $con = new \Drakkar\DrakkarDbConnector();
            $con->beginTransaction();

            $fattureT = new FatturazioneTesta($con);
            $fattureT->findByPk($request->id);
            $fattureT->setFlussoControllato(1);
            $fattureT->saveOrUpdate();
            $con->commit();
            $result['idFattura'] = $request->id;
            $result['status'] = 'OK';
        } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
            $con->rollBack();
            return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
        } catch (\Drakkar\Exception\DrakkarException $e) {
            $con->rollBack();
            return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
        }
    } else {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $fattureT = new FatturazioneTesta($con);
        $fattureT->findByPk($request->id);
        $fattureT->setFlussoControllato(0);
        $fattureT->saveOrUpdate();
        $con->commit();

        $result['status'] = 'ko';
        if (property_exists($ws, 'Error'))
            $result['error'] = $wsResult->Error;
        if (property_exists($ws, 'ErrorList'))
            $result['list'] = $wsResult->ErrorList;
    }
    return json_encode($result);
}


function inviaFlusso($request)
{
    /** @var Fattura $fatturaXml */
    $fatturaXml = preparaFatturaXml($request->id);
    $ws = new \Click\FattureB2B\WS();
    $xmlPath = $ws->creaXMLgetPath($fatturaXml->toJson());
    $stringXML = $ws->getStringXMLbyPath($xmlPath);
//    error_log($stringXML);
    $ws->verificaXML($xmlPath, true);
    $wsResult = null;
    $wsResult = json_decode($ws->inviaXML($xmlPath, true));
    if ($wsResult->status == 'OK' && isset($wsResult->idCodaInvio)) {
        try {
            $con = new \Drakkar\DrakkarDbConnector();
            $con->beginTransaction();

            $fattureT = new FatturazioneTesta($con);
            $fattureT->findByPk($request->id);
            $fattureT->setFlussoControllato(1);
            $fattureT->setFlussoInviato(1);
            $fattureT->setIdFatturaPa($wsResult->idCodaInvio);
            $fattureT->saveOrUpdate();
            $con->commit();

        } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
            $con->rollBack();
            return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
        } catch (\Drakkar\Exception\DrakkarException $e) {
            $con->rollBack();
            return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
        }
    } else {
        $result['status'] = 'ko';
        $result['msg_return'] = $wsResult ;
        if ($wsResult->status == 'OK' && !isset($wsResult->idCodaInvio)) {
            $result['error'] = $wsResult->result->Error;
        } else {
            if (property_exists($ws, 'Error'))
                $result['error'] = $wsResult->Error;
            if (property_exists($ws, 'ErrorList'))
                $result['list'] = $wsResult->ErrorList;
        }

    }
    return json_encode($result);
}


/**
 * @return false|string
 */
function preparaFatturaXml($id)
{

    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);

        //FATTURA
        $obj = new FatturazioneTesta($con);
        $obj->findByPk($id);

        //CONTRATTO
        $contratto = new Contratti($con);
        $contratto->findByPk($obj->getIdContrattoByIdRata($obj->getIdRata()));

        //AGENZIA IMMOBILIARE / GESTORE
        $gestore = new Anagrafiche($con);
        $gestore->findByPk($contratto->getIdAgenziaImmobiliare());

        //LOCATORE
        $locatore = new Anagrafiche($con);
        $locatore->findByPk($obj->getIdLocatoreFattura());

        //CONDUTTORE
        $conduttore = new Anagrafiche($con);
        $conduttore->findByPk($obj->getIdConduttoreFattura());

        $progFat = new ProgressivoEfattura($con);
        $progFat->setIdFatturazioneTesta($id);
        $progressivo = $progFat->saveOrUpdate();


        /*===================================================HEADER===================================================*/
        $h = new \Click\FattureB2B\Header();

        /*-------------------------------------DATI TRASMISSIONE------------------------------------------------------*/
        $h->creaDatiTrasmissione(
            ifNotValueIsNull($gestore->getPartitaIva(), 'IT' . $gestore->getPartitaIva()),
            $progressivo,
            ifNotValueIsNull($conduttore->getFatturaElettronicaDestinatarioCodice()),
            ifNotValueIsNull($conduttore->getFatturaElettronicaDestinatarioPec()),
            null,
            null
        );

        /*-------------------------------------SOGGETTO CEDENTE-------------------------------------------------------*/
        $appIndirizzoLocatore = $locatore->getObjIndirizzoDomicilioFiscale($obj->getIdLocatoreFattura());
        $h->creaCedentePrestatoreDenominazione(
            ifNotValueIsNull($locatore->getPartitaIva(), 'IT' . $locatore->getPartitaIva()),
            ifNotValueIsNull($locatore->getCodiceFiscale()),
            $locatore->getNominativo(),
            $locatore->getRegimeFiscale(),
            $appIndirizzoLocatore['via'] . ' ' . $appIndirizzoLocatore['civico'],
            $appIndirizzoLocatore['cap'],
            $appIndirizzoLocatore['citta'],
            $appIndirizzoLocatore['provincia'],
            'IT',
            $locatore->getTitolo(),
            null
        );


//        $h->setCedentePrestatoreIscrizioneREA(
//            'ufficio',
//            123,
//            'capitale sociale',
//            'socio unico',
//            'stato liquidazione'
//        );


        /*-------------------------------------SOGGETTO CESSIONARIO---------------------------------------------------*/
        $appIndirizzoConduttore = $conduttore->getObjIndirizzoDomicilioFiscale($obj->getIdConduttoreFattura());
        $h->creaCessionarioCommittenteDenominzaione(
            ifNotValueIsNull($conduttore->getPartitaIva(), 'IT' . $conduttore->getPartitaIva()),
            ifNotValueIsNull($conduttore->getCodiceFiscale()),
            $conduttore->getNominativo(),
            $appIndirizzoConduttore['via'] . ' ' . $appIndirizzoConduttore['civico'],
            $appIndirizzoConduttore['cap'],
            $appIndirizzoConduttore['citta'],
            $appIndirizzoConduttore['provincia'],
            'IT',
            $conduttore->getTitolo(),
            null
        );

        /*-------------------------------------SOGGETTO EMITTENTE-----------------------------------------------------*/
//        $h->creaTerzoIntermediarioSoggettoEmittenteDenominazione(
//            ifNotValueIsNull($gestore->getPartitaIva(), 'IT' . $gestore->getPartitaIva()),
//            ifNotValueIsNull($gestore->getCodiceFiscale()),
//            $gestore->getNominativo(),
//            $gestore->getTitolo(),
//            null
//        );

        /*===================================================BODY=====================================================*/
        $b = new \Click\FattureB2B\Body();

        /*-------------------------------------DATI GENERALI----------------------------------------------------------*/
        $elencoImmobili = '';
        $ui = new UnitaImmobiliari($con);
        foreach (json_decode($obj->getUnitaImmobiliari()) as $imm) {
            $ui->findByPk($imm->id_unita_immobiliare);
            $elencoImmobili = $elencoImmobili . ' ' . $ui->getDescrizione();
        }

        $b->creaDatiGeneraliDocumento(
            $obj->getDataEmissione(),
            $obj->getNumeroDocumento(),
            'EUR',
            $obj->getTipoDocumento()
        );

        if (!is_null($obj->getImportoTotaleFattura($obj->getId(), "'B'"))) {
            $b->creaDatiGeneraliBollo(
                ifNotValueIsNull($obj->getImportoTotaleFattura($obj->getId(), "'B'"), 'SI'),
                ifNotValueIsNull($obj->getImportoTotaleFattura($obj->getId(), "'B'"))
            );
        }

        $b->creaDatiGeneraliFattura('FATTURA DEL ' . formattaDate($obj->getDataEmissione(), 'd/m/Y') .
            ' PER LOCAZIONE CON SCADENZA IL ' . formattaDate($obj->getDataScadenza(), 'd/m/Y') .
            ' PER I SEGUENTI IMMOBILI :' . $elencoImmobili,
            formattaNumero($obj->getImportoTotaleFattura($obj->getId(), "'A','B','C','E','F','I','O','R','S','T'")),
            null,
            null
        );

        /*-------------------------------------BENI E SERVIZI---------------------------------------------------------*/
        $progressivoDettaglio = 0;
        $fattureD = new FatturazioneDettagli($con);
        $tipiIva = new TipiIva($con);
        /** @var FatturazioneDettagli $fD */
        foreach ($fattureD->findByIdxIdFatturazioneTesta($obj->getId()) as $fD) {
            $progressivoDettaglio++;
            $tipiIva->findByPk($fD->getIdTipoIva());
            $b->addDatiBeniServiziDettaglioLinee(
                $progressivoDettaglio,
                $fD->getDescrizione(),
                formattaNumero($fD->getImporto()),
                formattaNumero($tipiIva->getAliquota()),
                null,
                ifNotValueIsNull($tipiIva->getCodiceFatturazione())
            );
        }

        /*-------------------------------------RIEPILOGHI IVA---------------------------------------------------------*/
        $fattureD = new FatturazioneDettagli($con);
        foreach ($fattureD->findTotaleGruppiIvaByIdFatturaTesta($obj->getId(), FatturazioneDettagli::FETCH_KEYARRAY) as $fatD) {
            $esigibilita = null;
            if ($fatD['aliquota'] > 0)
                $esigibilita = 'I';
            $b->addDatiBeniServiziDatiRiepilogo(
                formattaNumero($fatD['aliquota']),
                formattaNumero($fatD['imponibile']),
                formattaNumero(round($fatD['importo'] - $fatD['imponibile'], 2)),
                ifNotValueIsNull($fatD['codice_fatturazione']),
                ifNotValueIsNull($fatD['codice_fatturazione'], $fatD['normativa_pf']),
                $esigibilita
            );
        }

        /*-------------------------------------DATI PAGAMENTO---------------------------------------------------------*/
//        $b->creaDatiPagamento(
//            'TP01',
//            'MP01',
//            formattaNumero($obj->getImportoTotaleFattura($obj->getId(), "'A','B','C','E','F','I','O','R','S','T'")),
//            $obj->getDataScadenza()
//        );


        //CONFIG
        $c = new \Click\FattureB2B\Config(false);

        //FATTURA
        $fatt = new Fattura($h, $b, $c);

        return $fatt;

    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


function ifNotValueIsNull($stringa, $returnValue = null)
{
    if ($stringa == '') return null;
    if (is_null($stringa)) return null;
    if ($returnValue == null) {
        return trim($stringa);
    } else {
        return trim($returnValue);
    }
}


/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
