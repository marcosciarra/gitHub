ngApp.controller("eFattureController", ["$scope", "$http", "$filter", "ngToast", function ($scope, $http, $filter, $ngToast) {

    var url = window.location.href;
    var params = decodeUrl(url, 'id');
    stampalog(params);

    $scope.caricamentoCompletato = false;

    /*--------------------------------------------------CARICA DATI---------------------------------------------------*/

    $scope.init = function () {
        $scope.filtroUtenti = [];
        $scope.filtroStabili = [];
        $scope.filtroLocatori = [];
        $scope.filtroConduttori = [];
        $scope.elencoUtenti = [];
        $scope.elencoLocatori = [];
        $scope.elencoConduttori = [];
        $scope.elencoStabili = [];

        $scope.selezionatiTutti = true;

        $scope.caricaFiltri();
        $scope.caricaDati();
    };

    $scope.caricaDati = function () {
        $http.post(params['form'] + '/fatturazione/controller/eFattureHandler.php',
            {
                'function': 'caricaDati'
            }
        ).then(function (data, status, headers, config) {
            stampalog(data.data.status);
            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }
            stampalog('Carico Dati');
            stampalog(data.data);
            $scope.documenti = data.data.documenti;
            if ($scope.documenti.length > 0) {
                for (var i = 0; i < $scope.documenti.length; i++) {
                    $scope.documenti[i].proprietari = jsonParse($scope.documenti[i].proprietari);
                    $scope.documenti[i].conduttori = jsonParse($scope.documenti[i].conduttori);
                    $scope.documenti[i].primoLocatore = $scope.documenti[i].proprietari[0].descrizione;
                    $scope.documenti[i].primoConduttore = $scope.documenti[i].conduttori[0].descrizione;
                    $scope.documenti[i].dataScadenzaFormat = formatDataDbToIta($scope.documenti[i].data_scadenza);
                    $scope.documenti[i].dataEmissioneFormat = formatDataDbToIta($scope.documenti[i].data_emissione);
                    if ($scope.documenti[i].fattura_elettronica_destinatario_codice.length == 7 && $scope.documenti[i].tipo_assoggettazione == 'S') {
                        $scope.documenti[i].selezionato = true;
                    } else {
                        $scope.documenti[i].selezionato = false;
                    }
                }
            }

            $scope.documentiCopia = angular.copy($scope.documenti);
            $scope.caricamentoCompletato = true;
        });
    };

    $scope.modificaAnagrafica = function (id) {
        window.location.href = params['home'] + encodeUrl('anagrafica', 'gestioneAnagrafica', id);
    };

    /*---------------------------------------------------VERIFICA FLUSSO----------------------------------------------*/

    $scope.verificaFlussoGruppo = function () {
        swal({
                title: "Verificare tutte le fatture selezionate?",
                text: "",
                type: "warning",
                showCancelButton: true,
                cancelButtonText: "No",
                confirmButtonClass: "btn-success",
                confirmButtonText: "Si, procedi.",
                showLoaderOnConfirm: true,
                closeOnConfirm: false
            },
            function (isConfirm) {
                if (isConfirm) {
                    var progr = 0;
                    for (var i = 0; i < $scope.documentiFiltrati.length; i++) {
                        if ($scope.documentiFiltrati[i].selezionato == true) {
                            $http.post(params['form'] + '/fatturazione/controller/eFattureHandler.php',
                                {
                                    'function': 'verificaFlusso',
                                    'id': $scope.documentiFiltrati[i].id
                                }
                            ).then(function (data) {
                                    if (data.data.status == "ok") {
                                        for (var i = 0; i < $scope.documentiFiltrati.length; i++) {
                                            if ($scope.documentiFiltrati[i].id == data.data.idFattura) {
                                                $scope.documentiFiltrati[i].flusso_controllato = 1
                                            }
                                        }
                                        progr++;
                                    } else {
                                        progr++;
                                        var listErrori = '\n\n\n';
                                        angular.forEach(data.data.list, function (er) {
                                            listErrori += '# ' + er + '\n';
                                        });
                                    }
                                }
                            ).then(function () {
                                    if ($scope.documentiFiltrati.length == progr) {
                                        swal({
                                            title: 'Verifica completata',
                                            text: '',
                                            type: "success"
                                        }, function () {
                                            // window.location.href = $scope.params['home'] + encodeUrl("fatturazione", "eFatture");
                                        });
                                    }
                                }
                            );
                        }
                    }
                }
            });
    };


    $scope.verificaFlusso = function (id) {
        swal({
                title: "Verificare la fattura?",
                text: "",
                type: "warning",
                showCancelButton: true,
                cancelButtonText: "No",
                confirmButtonClass: "btn-success",
                confirmButtonText: "Si, procedi.",
                showLoaderOnConfirm: true,
                closeOnConfirm: false
            },
            function (isConfirm) {
                if (isConfirm) {
                    $http.post(params['form'] + '/fatturazione/controller/eFattureHandler.php',
                        {
                            'function': 'verificaFlusso',
                            'id': id
                        }
                    ).then(function (data, status, headers, config) {
                        stampalog(data.data);
                        if (data.data.status == "OK") {
                            for (var i = 0; i < $scope.documentiFiltrati.length; i++) {
                                if ($scope.documentiFiltrati[i].id == id) {
                                    $scope.documentiFiltrati[i].flusso_controllato = 1;
                                }
                            }
                            swal({
                                title: 'Flusso verificato.',
                                text: '',
                                type: "success"
                            }, function () {
                                // window.location.href = $scope.params['home'] + encodeUrl("fatturazione", "eFatture");
                            });
                        } else {
                            for (var i = 0; i < $scope.documentiFiltrati.length; i++) {
                                if ($scope.documentiFiltrati[i].id == id) {
                                    $scope.documentiFiltrati[i].flusso_controllato = 0;
                                }
                            }
                            var listErrori = '\n\n\n';
                            angular.forEach(data.data.list, function (er) {
                                listErrori += '# ' + er + '\n';
                            });
                            swal({
                                title: 'Flusso errato.',
                                text: data.data.error + listErrori,
                                type: "warning"
                            }, function () {
                                // window.location.href = $scope.params['home'] + encodeUrl("fatturazione", "eFatture");
                            });
                        }
                    });
                }
            });
    };

    /*--------------------------------------------INVIO FLUSSO--------------------------------------------------------*/
    $scope.inviaFlusso = function (id) {
        swal({
                title: "Inviare la fattura?",
                text: "",
                type: "warning",
                showCancelButton: true,
                cancelButtonText: "No",
                confirmButtonClass: "btn-success",
                confirmButtonText: "Si, procedi.",
                showLoaderOnConfirm: true,
                closeOnConfirm: false
            },
            function (isConfirm) {
                if (isConfirm) {
                    $http.post(params['form'] + '/fatturazione/controller/eFattureHandler.php',
                        {
                            'function': 'inviaFlusso',
                            'id': id
                        }
                    ).then(function (data, status, headers, config) {
                        stampalog(data.data);
                        if (data.data.status == "OK") {
                            for (var i = 0; i < $scope.documentiFiltrati.length; i++) {
                                if ($scope.documentiFiltrati[i].id == id) {
                                    $scope.documentiFiltrati.splice(i, 1);
                                }
                            }
                            swal({
                                title: 'Flusso verificato.',
                                text: '',
                                type: "success"
                            }, function () {
                                // window.location.href = $scope.params['home'] + encodeUrl("fatturazione", "eFatture");
                            });
                        } else {
                            if (data.data.error != null && data.data.error != undefined) {
                                var testo = data.data.error;
                            } else {
                                var testo = 'Si consiglia di riverificare il flusso.';
                            }
                            var testo =
                                swal({
                                    title: 'Flusso errato.',
                                    text: testo,
                                    type: "warning"
                                }, function () {
                                    // window.location.href = $scope.params['home'] + encodeUrl("fatturazione", "eFatture");
                                });
                        }
                    });
                }
            });
    };

    /*
    Selsezione / Deseleziona tutti gli elementi nella tabella
     */
    $scope.selezionaDeselezionaTutti = function (flag) {
        $scope.selezionatiTutti = flag;
        for (var i = 0; i < $scope.documenti.length; i++) {
            if ($scope.documentiFiltrati[i].fattura_elettronica_destinatario_codice.length == 7 && $scope.documentiFiltrati[i].tipo_assoggettazione == 'S') {
                $scope.documenti[i].selezionato = flag;
            }
        }
    };

    /*
    Apre il Pdf della fattura
     */
    $scope.stampaDettaglio = function (id) {
        window.open(params['baseurl'] + '/stampe/avvisiPagamento/avvisoPagamentoPdf.php?idFattura=' + id);
    };

    $scope.caricaDettagliModale = function (elenco, etichetta) {
        $scope.elencoModale = elenco;
        $scope.etichettaModale = etichetta;
    };

//---------------------------------------------------SEZIONE FILTRI-----------------------------------------------//
    $scope.caricaFiltri = function () {
        $http.post($scope.params['form'] + "/template/controller/homeHandler.php",
            {'function': 'caricaFiltri'}
        ).then(function (data, status, headers, config) {
            // stampalog(data.data);
            $scope.filtriSelectPagina = data.data;
        });
    };
    $scope.settings = {
        dynamicTitle: true,
        enableSearch: true,
        showSelectAll: false,
        keyboardControls: true,
        scrollable: true,
        showCheckAll: false,
        showUncheckAll: true,
        closeOnSelect: false,
        scrollableHeight: '300px',
        externalIdProp: '', //PERMETTE DI AGGIUNGERE ALL'ARRAY DEI SELEZIONATI TUTTO L'OGGETTO
        idProp: 'id', //definisco i campi di cui è composto l'oggetto
        displayProp: 'descrizione' //definisco i campi di cui è composto l'oggetto
    };
    $scope.customTextUtenti = {
        buttonDefaultText: 'Utenti',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextStabili = {
        buttonDefaultText: 'Stabili',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextLocatori = {
        buttonDefaultText: 'Locatori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextConduttori = {
        buttonDefaultText: 'Conduttori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.multiSelectEventUtenti = {
        onItemSelect: function (obj) {
            $scope.filtroUtenti.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroUtenti.length; i++) {
                if ($scope.filtroUtenti[i] == obj.id) {
                    $scope.filtroUtenti.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function () {
            $scope.filtroUtenti = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventStabili = {
        onItemSelect: function (obj) {
            $scope.filtroStabili.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroStabili.length; i++) {
                if ($scope.filtroStabili[i] == obj.id) {
                    $scope.filtroStabili.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroStabili = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventLocatori = {
        onItemSelect: function (obj) {
            $scope.filtroLocatori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroLocatori.length; i++) {
                if ($scope.filtroLocatori[i] == obj.id) {
                    $scope.filtroLocatori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroLocatori = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventConduttori = {
        onItemSelect: function (obj) {
            $scope.filtroConduttori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroConduttori.length; i++) {
                if ($scope.filtroConduttori[i] == obj.id) {
                    $scope.filtroConduttori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroConduttori = [];
            $scope.filtriGenerici();
        }
    };
    $scope.svuotaMultiselect = function () {
        $scope.multiSelectEventUtenti.onDeselectAll();
        $scope.multiSelectEventLocatori.onDeselectAll();
        $scope.multiSelectEventConduttori.onDeselectAll();
        $scope.multiSelectEventStabili.onDeselectAll();
        $scope.elencoUtenti = [];
        $scope.elencoLocatori = [];
        $scope.elencoConduttori = [];
        $scope.elencoStabili = [];
    };
    $scope.filtriGenerici = function () {
        $scope.documenti = [];
        var flag;
        for (var i = 0; i < $scope.documentiCopia.length; i++) {
            flag = false;

            if ($scope.filtroUtenti.length == 0) {
                flag = true;
            } else {
                for (var k = 0; k < $scope.filtroUtenti.length; k++) {
                    if ($scope.documentiCopia[i].id_utente_riferimento == $scope.filtroUtenti[k]) {
                        flag = true;
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroStabili.length == 0) {
                    flag = true;
                } else {
                    flag = false;
                    for (var j = 0; j < $scope.documentiCopia[i].immobili.length; j++) {
                        for (var k = 0; k < $scope.filtroStabili.length; k++) {
                            if ($scope.documentiCopia[i].immobili[j].id_stabili == $scope.filtroStabili[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroLocatori.length == 0) {
                    flag = true;
                } else {
                    flag = false;
                    for (var j = 0; j < $scope.documentiCopia[i].proprietari.length; j++) {
                        for (var k = 0; k < $scope.filtroLocatori.length; k++) {
                            if ($scope.documentiCopia[i].proprietari[j].id == $scope.filtroLocatori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroConduttori.length == 0) {
                    flag = true;
                } else {
                    flag = false;
                    for (var j = 0; j < $scope.documentiCopia[i].conduttori.length; j++) {
                        for (var k = 0; k < $scope.filtroConduttori.length; k++) {
                            if ($scope.documentiCopia[i].conduttori[j].id == $scope.filtroConduttori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                $scope.documenti.push($scope.documentiCopia[i]);
            }
        }
    };

}
])
;