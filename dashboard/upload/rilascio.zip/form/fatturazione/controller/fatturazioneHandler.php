<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 18/04/18
 * Time: 9.35
 */

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';

require_once '../../../src/function/functionDate.php';

require_once '../../../src/model/Contratti.php';
require_once '../../../src/model/ContrattoAffitto.php';
require_once '../../../src/model/Rate.php';
require_once '../../../src/model/RateDettagli.php';
require_once '../../../src/model/GruppiFatturazione.php';
require_once '../../../src/model/FatturazioneTesta.php';
require_once '../../../src/model/FatturazioneDettagli.php';
require_once '../../../src/model/GruppiFatturazione.php';
require_once '../../../src/model/Anagrafiche.php';
require_once '../../../src/model/Bolli.php';
require_once '../../../src/model/PeriodiContrattuali.php';
require_once '../../../src/model/UnitaImmobiliariContratti.php';

require_once '../../../lib/flussi/fattureB2B/Fattura.php';
require_once '../../../lib/flussi/fattureB2B/WS.php';

use Click\Affitti\Viste\ContrattoAffitto;
use Click\Affitti\TblBase\Rate;
use Click\Affitti\TblBase\RateDettagli;
use Click\Affitti\TblBase\GruppiFatturazione;
use Click\Affitti\TblBase\FatturazioneTesta;
use Click\Affitti\TblBase\FatturazioneDettagli;
use Click\Affitti\TblBase\Bolli;
use Click\Affitti\TblBase\PeriodiContrattuali;
use Click\Affitti\TblBase\UnitaImmobiliariContratti;
use Click\FattureB2B\Fattura;
use Click\FattureB2B\WS;

function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        $rate = new Rate($con);
        $result['elencoFatture'] = [];
        $uic = new UnitaImmobiliariContratti($con);
        foreach ($rate->findRatePerFattura($request->dataInizio, $request->dataFine, $request->tipoDocumento, Rate::FETCH_KEYARRAY) as $fatture) {
            $rateD = new RateDettagli($con);
            $fatture['imposta'] = $rateD->getImportoByIdRataIdCategoriaSpesa($fatture['id'], 'R');
            $fatture['istat'] = $rateD->getImportoByIdRataIdCategoriaSpesa($fatture['id'], 'T');
            $fatture['immobili'] = $uic->elencoImmobiliPerContratto($fatture['idContratto'], UnitaImmobiliariContratti::FETCH_KEYARRAY);
            $result['elencoFatture'] [] = $fatture;
        }

        $result['totaleAvvisi'] = count($rate->findRatePerFattura($request->dataInizio, $request->dataFine, 'A', Rate::FETCH_KEYARRAY));
        $result['totaleFatture'] = count($rate->findRatePerFattura($request->dataInizio, $request->dataFine, 'F', Rate::FETCH_KEYARRAY));
        $result['totaleMav'] = count($rate->findRatePerFattura($request->dataInizio, $request->dataFine, 'M', Rate::FETCH_KEYARRAY));
        $result['totaleRid'] = count($rate->findRatePerFattura($request->dataInizio, $request->dataFine, 'R', Rate::FETCH_KEYARRAY));
        $result['totaleFattureAlPagamento'] = count($rate->findRatePerFattura($request->dataInizio, $request->dataFine, 'FP', Rate::FETCH_KEYARRAY));

        /*---------------------------------------CARICO I GRUPPI DI FATTURAZIONE--------------------------------------*/
        $gruppoFatturazione = new GruppiFatturazione($con);
        switch ($request->tipoDocumento) {
            case "A":
            case "M":
            case "R":
                $result['gruppiFatturazione'] = $gruppoFatturazione->findElencoUltimiGruppiFiltrato('0', GruppiFatturazione::FETCH_KEYARRAY);
                break;
            case "F":
            case "FP":
                $result['gruppiFatturazione'] = $gruppoFatturazione->findElencoUltimiGruppiFiltrato('1', GruppiFatturazione::FETCH_KEYARRAY);
                break;
        }

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


function salvaFlusso($request)
{

    $codiceGruppo = time();

    if (count($request->elencoFatture) > 0) {

        try {
            $con = new \Drakkar\DrakkarDbConnector();
            $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
            $cont = new ContrattoAffitto($con);
            $rate = new Rate($con);
            $rateD = new RateDettagli($con);
            $gruppoFat = new GruppiFatturazione($con);
            $anagrafica = new \Click\Affitti\TblBase\Anagrafiche($con);
            $periodoContr = new PeriodiContrattuali($con);

            $con->beginTransaction();

            //AGGIORNO PRIMO NUMERO GRUPPO FATTURAZIONE
            if (!$request->anteprima) {
                //Aggiorno primo numero di documento per gruppi fatturazione
                foreach ($request->gruppiFatturazione as $gruppiFat) {
                    $gruppoFat->findByPk($gruppiFat->id);
                    if ($gruppiFat->ultimo_numero != $gruppoFat->getUltimoNumero()) {
                        $gruppoFat->setUltimoNumero($gruppiFat->ultimo_numero);
                        $gruppoFat->saveOrUpdate();
                    }
                }
            }

            //Carico il bollo da assegnare
            $bolli = new Bolli($conExt);
            /** @var Bolli $bolli */
            foreach ($bolli->findByCategoriaAndData('D', $request->dataEmissione) as $bolli) {
                break;
            }

            foreach ($request->elencoFatture as $fatture) {
                if ($fatture->selezionato) {
                    if ($rate->findByPk($fatture->id)) {

                        $cont->findByPk($fatture->idContratto);

                        $locatori = [];
                        if (is_null($cont->getContrattiPreferenze()->getDivisioneLocatori())) {
                            $locatori[0]['soggetti'] = json_decode($cont->getContratto()->getProprietari());
                            $locatori[0]['percentuale'] = 100;
                        } else {
                            $loc = json_decode($cont->getContrattiPreferenze()->getDivisioneLocatori());
                            foreach ($loc as $app) {
                                $appLocatori['soggetti'] = $app->locatori;
                                $appLocatori['percentuale'] = $app->percentuale;
                                $locatori[] = $appLocatori;
                            }
                        }

                        $conduttori = [];
                        if (is_null($cont->getContrattiPreferenze()->getDivisioneConduttori())) {
                            $conduttori[0]['soggetti'] = json_decode($cont->getContratto()->getConduttori());
                            $conduttori[0]['percentuale'] = 100;
                        } else {
                            $cond = json_decode($cont->getContrattiPreferenze()->getDivisioneConduttori());
                            foreach ($cond as $app) {
                                $appConduttori['soggetti'] = $app->conduttori;
                                $appConduttori['percentuale'] = $app->percentuale;
                                $conduttori[] = $appConduttori;
                            }
                        }

                        foreach ($locatori as $appLoc) {
                            foreach ($conduttori as $appCond) {
                                //Creo Testata della Fattura
                                $fatturaT = new FatturazioneTesta($con);
                                $fatturaT->setCodiceGruppo($codiceGruppo);
                                $fatturaT->setIdRata($fatture->id);
                                $fatturaT->setIdGruppoFatturazione($cont->getContrattiDettagli()->getIdGruppoFatturazione());
                                if (!$request->anteprima) {
                                    $fatturaT->setNumeroDocumento($gruppoFat->getNewGruppo($cont->getContrattiDettagli()->getIdGruppoFatturazione()));
                                }
                                if($cont->getContrattiDettagli()->getBollettazioneTipo()=='F') {
                                    $fatturaT->setTipoDocumento('TD01');
                                }
                                else{
                                    $fatturaT->setTipoDocumento($cont->getContrattiDettagli()->getBollettazioneTipo());
                                }
                                $fatturaT->setDataScadenza($rate->getDataScadenza());
                                $fatturaT->setDataEmissione($request->dataEmissione);
                                $fatturaT->setContoCorrente($cont->getContrattiDettagli()->getIdContoCorrente());
                                $fatturaT->setTipoAssoggettazione($cont->getContratto()->getTipoAssoggettazione());
                                //JSON

                                if (is_null($cont->getContrattiPreferenze()->getDivisioneConduttori())) {
                                    $anagrafica->findByPk($cont->getContrattiDettagli()->getIntestatarioConduttore());
                                    $fatturaT->setIdLocatoreFattura($cont->getContrattiDettagli()->getIntestatarioLocatore());
                                    $fatturaT->setIdConduttoreFattura($cont->getContrattiDettagli()->getIntestatarioConduttore());
                                } else {
                                    $anagrafica->findByPk($appCond['soggetti'][0]->id);
                                    $fatturaT->setIdLocatoreFattura($appLoc['soggetti'][0]->id);
                                    $fatturaT->setIdConduttoreFattura($appCond['soggetti'][0]->id);
                                }

                                $recapito = json_decode($anagrafica->getIndirizzoRecapito($anagrafica->getId()));
                                $recapito->titolo = $anagrafica->getTitolo();
                                if ($anagrafica->getIdTipiSoggetto() == 2) {
                                    $recapito->destinatario = $anagrafica->getCognome() . ' ' . $anagrafica->getNome();
                                } else if ($anagrafica->getIdTipiSoggetto() == 3) {
                                    $recapito->destinatario = $anagrafica->getRagioneSociale() . ' di ' . $anagrafica->getCognome() . ' ' . $anagrafica->getNome();
                                } else {
                                    $recapito->destinatario = $anagrafica->getRagioneSociale();
                                }
                                $fatturaT->setRecapito(json_encode($recapito));

                                $fatturaT->setUnitaImmobiliari($cont->getUnitaImmobiliariContratti(true));
                                $fatturaT->setProprietari($appLoc['soggetti']);
                                $fatturaT->setConduttori($appCond['soggetti']);
                                $fatturaT->setContabilizzato(0);
                                $idFatturaT = $fatturaT->saveOrUpdate();

                                $rate->setBloccata(1);
                                $rate->saveOrUpdate();

                                /** @var RateDettagli $rateD */
                                foreach ($rateD->findByIdxIdRata($fatture->id) as $rateD) {
                                    $addebitoPersonale = false;

                                    if ($rateD->getIdConduttoreAssociato() != null) {
                                        if ($rateD->getIdConduttoreAssociato() != $appCond['soggetti'][0]->id) {
                                            continue;
                                        } else {
                                            $addebitoPersonale = true;
                                        }
                                    }

                                    //Creo Dettagli della Fattura
                                    $fatturaD = new FatturazioneDettagli($con);
                                    $fatturaD->setIdFatturazioneTesta($idFatturaT);
                                    $fatturaD->setIdTipoIva($rateD->getIdTipoIva());
                                    $fatturaD->setIdCategoriaSpese($rateD->getIdCategoriaSpesa());

                                    //Controlle se è addebito personale, nel caso non suddivido la spesa per percentuale dei gruppi
                                    if ($addebitoPersonale == false) {
                                        //DIVISIONE PER PROPRIETARI
                                        $imponibile = round(($rateD->getImponibile() / 100) * $appLoc['percentuale'], 2);
                                        $importo = round(($rateD->getImporto() / 100) * $appLoc['percentuale'], 2);
                                        //DIVISIONE PER INQUILINI
                                        $imponibile = round(($imponibile / 100) * $appCond['percentuale'], 2);
                                        $importo = round(($importo / 100) * $appCond['percentuale'], 2);
                                    } else {
                                        $imponibile = $rateD->getImponibile();
                                        $importo = $rateD->getImporto();
                                    }

                                    //Controlle se è di tipo AFFITTO o SPESA FORFETTARIA
                                    //per il controllo dell'occupazione senza titolo
                                    $checkCategoria = array('A', 'F');
                                    if (in_array($rateD->getIdCategoriaSpesa(), $checkCategoria)) {

                                        switch ($cont->getContratto()->getOccupazioneSenzaTitolo() == 1) {
                                            //Contratto in occupazione senza titolo
                                            case 1:
                                                $fatturaD->setDescrizione('Indennità di occupazione (art. 1591 CC)');
                                                $fatturaD->setDataInizio('');
                                                $fatturaD->setDataFine('');
                                                $fatturaD->setImponibile($rateD->getImponibile());
                                                $fatturaD->setImporto($importo);
                                                break;
                                            //Nel caso sia contratto 'attivo' controllo se il periodo supera la data scadenza contratto
                                            default:
                                                //Rata all'interno della scadenza del contratto
                                                if ($rate->getPeriodoFine() < $cont->getContratto()->getScadenzaContratto()) {
                                                    $fatturaD->setDescrizione($rateD->getDescrizione());
                                                    $fatturaD->setDataInizio($rate->getPeriodoInizio());
                                                    $fatturaD->setDataFine($rate->getPeriodoFine());
                                                    $fatturaD->setImponibile($imponibile);
                                                    $fatturaD->setImporto($importo);
                                                } //Rata totalmente o parzialmente fuori dal contratto
                                                else {
                                                    //totalmente fuori dal contratto
                                                    if ($rate->getPeriodoInizio() > $cont->getContratto()->getScadenzaContratto()) {
                                                        $fatturaD->setIdCategoriaSpese('O');
                                                        $fatturaD->setDescrizione('Indennità di occupazione (art. 1591 CC)');
                                                        $fatturaD->setDataInizio('');
                                                        $fatturaD->setDataFine('');
                                                        $fatturaD->setImponibile($imponibile);
                                                        $fatturaD->setImporto($importo);
                                                    } //parzialmente fuori dal contratto
                                                    else {
                                                        //Parziale in Occupazione senza titolo
                                                        $fatturaD->setIdCategoriaSpese('O');
                                                        $fatturaD->setDescrizione('Indennità di occupazione (art. 1591 CC)');
                                                        $fatturaD->setDataInizio('');
                                                        $fatturaD->setDataFine('');

                                                        $giorniRata = dateDiff($rate->getPeriodoInizio(), $rate->getPeriodoFine(), '%a');
                                                        $giorniOccupazione = dateDiff($cont->getContratto()->getScadenzaContratto(), $rate->getPeriodoFine(), '%a');

                                                        $imponibileParziale = round(($imponibile / $giorniRata) * $giorniOccupazione, 2);
                                                        $importoParziale = round(($importo / $giorniRata) * $giorniOccupazione, 2);

                                                        $fatturaD->setImponibile($imponibileParziale);
                                                        $fatturaD->setImporto($importoParziale);
                                                        $fatturaD->saveOrUpdate();

                                                        //Parziale NON in Occupazione senza titolo
                                                        $fatturaD = new FatturazioneDettagli($con);
                                                        $fatturaD->setIdFatturazioneTesta($idFatturaT);
                                                        $fatturaD->setIdTipoIva($rateD->getIdTipoIva());
                                                        $fatturaD->setIdCategoriaSpese($rateD->getIdCategoriaSpesa());
                                                        $fatturaD->setDescrizione($rateD->getDescrizione());
                                                        $fatturaD->setDataInizio($rate->getPeriodoInizio());
                                                        $fatturaD->setDataFine($cont->getContratto()->getScadenzaContratto());
                                                        $fatturaD->setImponibile($imponibile - $imponibileParziale);
                                                        $fatturaD->setImporto($importo - $importoParziale);
                                                    }
                                                }
                                                break;
                                        }
                                    } else {
                                        $fatturaD->setDescrizione($rateD->getDescrizione());
                                        $fatturaD->setDataInizio($rate->getPeriodoInizio());
                                        $fatturaD->setDataFine($rate->getPeriodoFine());
                                        $fatturaD->setImponibile($imponibile);
                                        $fatturaD->setImporto($importo);
                                    }
                                    $fatturaD->saveOrUpdate();
                                }
                                //MARCA DA BOLLO SE CONTRATTO NON ASSOGGETTATO AD IVA
                                if ($cont->getContratto()->getTipoAssoggettazione() == 'N') {
                                    $fatturaD = new FatturazioneDettagli($con);
                                    $fatturaD->setIdFatturazioneTesta($idFatturaT);
                                    $fatturaD->setIdTipoIva(5);
                                    $fatturaD->setIdCategoriaSpese('B');
                                    $fatturaD->setDescrizione($bolli->getDescrizione());
                                    $fatturaD->setDataInizio('');
                                    $fatturaD->setDataFine('');
                                    $fatturaD->setImponibile($bolli->getValuta());
                                    $fatturaD->setImporto($bolli->getValuta());

                                    $fatturaD->saveOrUpdate();
                                }
                            }
                        }
                    }
                }
            }
            $con->commit();
            $result['codice_gruppo'] = $codiceGruppo;
            $result['status'] = 'ok';
            return json_encode($result);

        } catch
        (\Drakkar\Exception\DrakkarConnectionException $e) {
            $con->rollBack();
            return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
        } catch (\Drakkar\Exception\DrakkarException $e) {
            $con->rollBack();
            return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
        }
    }
}


function dettaglioFattura($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        $rateD = new RateDettagli($con);
        $result['dettaglioFattura'] = $rateD->findByIdRata($request->idRata, RateDettagli::FETCH_KEYARRAY);
        $result['status'] = 'ok';
        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
