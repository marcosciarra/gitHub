<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 05/01/18
 * Time: 9.10
 */

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';

require_once '../../../src/function/functionGeneric.php';
require_once '../../../src/function/functionDate.php';
require_once '../../../src/function/functionLogin.php';

require_once '../../../src/model/News.php';
require_once '../../../src/model/Login.php';

use Click\Affitti\TblBase\News;
use Click\Affitti\TblBase\Login;

function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);

        $login = new Login($con);
        $login->findByUtentePassword(getLoginDataFromSession('username'), getLoginDataFromSession('password'));
        $result['tipoUtente'] = $login->getTipoUtente();
        $idNews = $login->getIdNewsLetta();
        if ($idNews == null)
            $idNews = 0;

        $news = new News($conExt);
        $news->setOrderBase(' id DESC');
        $result['avvisi'] = $news->getAvvisiLetti($idNews, News::FETCH_KEYARRAY);
        $result['avvisiNonLetti'] = $news->getAvvisiNonLetti($idNews, News::FETCH_KEYARRAY);

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


function newAvviso($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);

        $news = new News($conExt);
        $news->setTitolo($request->titolo);
        $anno = date('Y', time());
        $mese = date('m', time());
        $giorno = date('d', time());
        $news->setData(date('Y-m-d', mktime(0, 0, 0, $mese, $giorno, $anno)));
        $news->setLink($request->link);
        $news->setDescrizione($request->descrizione);
        $news->setCestino(0);
        $news->saveOrUpdate();

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


function aggiornaId($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);

        $news = new News($conExt);
        $login = new Login($con);
        $login->findByUtentePassword(getLoginDataFromSession('username'), getLoginDataFromSession('password'));
        $login->setIdNewsLetta($request->id);
        $login->saveOrUpdate();

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


function eliminaAvviso($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);

        $news = new News($conExt);
        $news->findByPk($request->id);
        $news->setCestino(1);
        $news->saveOrUpdate();

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
