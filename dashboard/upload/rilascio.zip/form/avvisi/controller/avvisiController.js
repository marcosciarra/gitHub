ngApp.controller("avvisiController", ["$scope", "$http", "$filter", function ($scope, $http, $filter) {

    var url = window.location.href;
    var params = decodeUrl(url, ['data_inizio', 'data_fine']);
    stampalog(params);

    $scope.datiCorretti = false;
    $scope.nuovoAvviso = {
        'titolo': '',
        'link': '',
        'descrizione': '',
        'data': ''
    }

    $scope.aggiungiAvviso = false;
    $scope.caricamentoCompletato = false;

    /*--------------------------------------------------CARICA DATI---------------------------------------------------*/

    $scope.init = function () {
        $scope.caricaDati();
    };

    $scope.caricaDati = function () {
        $scope.caricamentoCompletato = false;
        $http.post(params['form'] + '/avvisi/controller/avvisiHandler.php',
            {'function': 'caricaDati'}
        ).then(function (data, status, headers, config) {

            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }

            $scope.tipoUtente = data.data.tipoUtente;
            $scope.avvisi = data.data.avvisi;
            $scope.avvisiNonLetti = data.data.avvisiNonLetti;

            stampalog(data.data);

            $scope.caricamentoCompletato = true;

        });

    };

    $scope.newAvviso = function () {
        $scope.caricamentoCompletato = false;
        $scope.aggiungiAvviso = false;
        $http.post(params['form'] + '/avvisi/controller/avvisiHandler.php',
            {
                'function': 'newAvviso',
                'titolo': $scope.nuovoAvviso.titolo,
                'link': $scope.nuovoAvviso.link,
                'descrizione': $scope.nuovoAvviso.descrizione
            }
        ).then(function (data, status, headers, config) {
            $scope.caricamentoCompletato = true;
            stampalog(data.data);
            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }
            else {
                swal({
                    title: "Avviso caricato!",
                    text: '',
                    type: "success",
                    showCancelButton: false,
                    confirmButtonClass: "btn-primary",
                    confirmButtonText: "Ok!",
                    closeOnConfirm: false
                }, function (isConfirm) {
                    if (isConfirm) {
                        window.location.reload();
                    }
                });
            }
        });
    };

    $scope.annullaNuovoAvviso = function () {
        $scope.nuovoAvviso.titolo = '';
        $scope.nuovoAvviso.link = '';
        $scope.nuovoAvviso.descrizione = '';
        $scope.nuovoAvviso.data = '';
        $scope.datiCorretti = false;
        $scope.aggiungiAvviso = false;
    };

    $scope.aggiornaId = function (id) {
        $http.post(params['form'] + '/avvisi/controller/avvisiHandler.php',
            {
                'function': 'aggiornaId',
                'id': id
            }
        ).then(function (data, status, headers, config) {

            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }
        });
    };

    $scope.eliminaAvviso = function (id) {
        swal({
                title: "Cestinare l'avviso?",
                text: "",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: "btn-danger",
                confirmButtonText: "Si, cestina!",
                cancelButtonText: "No, annulla!",
                closeOnConfirm: false,
                closeOnCancel: false
            },
            function (isConfirm) {
                if (isConfirm) {

                    $http.post(params['form'] + '/avvisi/controller/avvisiHandler.php',
                        {
                            'function': 'eliminaAvviso',
                            'id': id
                        }
                    ).then(function (data, status, headers, config) {

                        if (data.data.status == 'ko') {
                            swal(data.data.error.title, data.data.error.message, 'error');
                            return;
                        }
                        else {
                            window.location.reload();
                        }
                    });
                }
                else {
                    swal("Cancellazione annullata", "", "error");
                }
            });

    };

    $scope.caricaAvviso = function (id, gruppo) {
        if (gruppo == 'nuovi') {
            for (var i = 0; i < $scope.avvisiNonLetti.length; i++) {
                if (id == $scope.avvisiNonLetti[i].id) {
                    $scope.titolo = $scope.avvisiNonLetti[i].titolo;
                    $scope.data = $scope.avvisiNonLetti[i].data;
                    $scope.link = $scope.avvisiNonLetti[i].link;
                    $scope.descrizione = $scope.avvisiNonLetti[i].descrizione;
                }
            }
        }
        else {
            for (var i = 0; i < $scope.avvisi.length; i++) {
                if (id == $scope.avvisi[i].id) {
                    $scope.titolo = $scope.avvisi[i].titolo;
                    $scope.data = $scope.avvisi[i].data;
                    $scope.link = $scope.avvisi[i].link;
                    $scope.descrizione = $scope.avvisi[i].descrizione;
                }
            }
        }
    }

    /** WATCH form inserimento ----------------------------------------------------------------------------*/
    $scope.$watchGroup(["nuovoAvviso.titolo", "nuovoAvviso.descrizione"], function () {

        if ($scope.nuovoAvviso) {
            if ($scope.nuovoAvviso.titolo != "" && $scope.nuovoAvviso.descrizione != "") {
                $scope.datiCorretti = true;
            } else {
                $scope.datiCorretti = false;
            }
        }
    });


}])
;