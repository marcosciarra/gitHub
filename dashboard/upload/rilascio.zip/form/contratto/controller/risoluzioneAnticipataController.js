ngApp.controller("risoluzioneAnticipataController", ["$scope", "$http", "$filter", function ($scope, $http, $filter) {

    var url = window.location.href;
    var params = decodeUrl(url, 'id');
    stampalog('URL');
    stampalog(params);

    $scope.init = function () {
        $scope.caricamentoCompletato = false;
        $scope.idContratto = params['id'];
        $scope.caricaDati();
        $scope.bloccaRate = true;
        $scope.disdettaContratto = true;
    };


    /******************
     *   CARICADATI   * ================================================================================================
     ******************/

    $scope.caricaDati = function () {
        $scope.dataRisoluzione = new Date(today());
        $scope.cercaRata();
        $scope.caricamentoCompletato = true;
    };


    $scope.cercaRata = function () {
        $http.post(params['form'] + '/contratto/controller/risoluzioneAnticipataHandler.php',
            {
                'function': 'cercaRata',
                'id': params['id'],
                'dataRisoluzione': getYYYYMMGGFromJsDate($scope.dataRisoluzione)
            }
        ).then(function (data, status, headers, config) {

            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }
            stampalog(data.data);

            //----------------------Dettagli alti contratto-----------------------------------------------------------//
            $scope.locatori = jsonParse(data.data.anagrafica_contratto.proprietari);
            $scope.primoLocatore = $scope.locatori[0].descrizione;

            $scope.conduttori = jsonParse(data.data.anagrafica_contratto.conduttori);
            $scope.primoConduttore = $scope.conduttori[0].descrizione;

            $scope.unitaImmobiliari = data.data.anagrafica_contratto.unita_immobiliari;
            $scope.primoStabile = $scope.unitaImmobiliari[0].descrizione;
            //--------------------------------------------------------------------------------------------------------//


            $scope.rate = data.data.rate;
            $scope.statoContratto = data.data.statoContratto;
            if ($scope.rate != null) {
                $scope.descrizione_rata = data.data.rate.descrizione;
                $scope.scadenza_rata = data.data.rate.data_scadenza;
                $scope.periodo_inizio = data.data.rate.periodo_inizio;
                $scope.periodo_fine = data.data.rate.periodo_fine;


                $http.post(params['form'] + '/contratto/controller/risoluzioneAnticipataHandler.php',
                    {
                        'function': 'caricaDatiRata',
                        'id': params['id'],
                        'idRata': $scope.rate.id,
                        'dataRisoluzione': $scope.dataRisoluzione,
                        'periodoInizio': $scope.periodo_inizio,
                        'periodoFine': $scope.periodo_fine
                    }
                ).then(function (data, status, headers, config) {
                    $scope.dettagli = data.data.dettagli;
                    stampalog($scope.dettagli);

                });
            }
        });
    };


    $scope.caricaDettagliModale = function (elenco, etichetta) {
        $scope.elencoModale = elenco;
        $scope.etichettaModale = etichetta;
    };


    $scope.aggiornaRata = function () {
        $http.post(params['form'] + '/contratto/controller/risoluzioneAnticipataHandler.php',
            {
                'function': 'aggiornaRata',
                'dettagli': $scope.dettagli,
                'idContratto': params['id'],
                'dataRisoluzione': getYYYYMMGGFromJsDate($scope.dataRisoluzione),
                'bloccaRateSuccessive': $scope.bloccaRate,
                'disdettaContratto': $scope.disdettaContratto
            }
        ).then(function (data, status, headers, config) {

            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            } else {
                swal({
                    title: "Elaborazione effettuata",
                    text: '',
                    type: "success"
                }, function () {
                    $scope.rateizzazioneContratto(params['id'],$scope.rate.id);
                });
            }

            stampalog(data.data);
        });
    };

    /* ========================================= GESTIONE CONTRATTO ================================================= */

    $scope.gestioneContratto = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "gestioneContratto", id);
    };
    $scope.rateizzazioneContratto = function (id,idRata) {
        var parametri=[];
        parametri.push(id);
        parametri.push(idRata);
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "rateizzazioneContratto", parametri);
    };

}]);