<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 15/12/17
 * Time: 10.38
 */
require_once '../../../src/function/functionDate.php';

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';

require_once '../../../src/model/PeriodiContrattuali.php';
require_once '../../../src/model/CanoniOneri.php';
require_once '../../../src/model/RateDettagli.php';
require_once '../../../src/model/AggiornaContratto.php';
require_once '../../../src/model/Gestioni.php';
require_once '../../../src/model/PianoRateTesta.php';
require_once '../../../src/model/PianiRateDettagli.php';
require_once '../../../src/model/Rate.php';
require_once '../../../src/model/ContrattiConAnagrafiche.php';

use Click\Affitti\TblBase\PeriodiContrattuali;
use Click\Affitti\TblBase\CanoniOneri;
use Click\Affitti\TblBase\RateDettagli;
use Click\Affitti\TblBase\Gestioni;
use Click\Affitti\Viste\AggiornaContratto;
use Click\Affitti\TblBase\PianiRateDettagli;
use Click\Affitti\TblBase\Rate;
use Click\Affitti\TblBase\PianoRateTesta;
use Click\Affitti\Viste\ContrattiConAnagrafiche;

function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $tmp = new PeriodiContrattuali($con);
        $result['periodi_contrattuali'] = $tmp->findByIdContrattoConDettagli($request->id, 'pianoRate',
            PeriodiContrattuali::FETCH_KEYARRAY);
        $result['gestione_oggi'] = $tmp->findGestioneByToDay($request->id, PeriodiContrattuali::FETCH_KEYARRAY);
        $spese = new CanoniOneri($con);
        $result['canoni_oneri'] = $spese->findByIdContratto($request->id, CanoniOneri::FETCH_KEYARRAY);
        $gestione = new Gestioni($con);
        $result['canoni_oneri_descrizioni'] = $gestione->findDescrizioneByIdContratto($request->id, Gestioni::FETCH_KEYARRAY);
        $PianoRateD = new PianiRateDettagli($con);
        $result['pianoRateD'] = $PianoRateD->getEmptyDbKeyArray();
        $rate = new Rate($con);
        $result['emptyRate'] = $rate->getEmptyDbKeyArray();
        $anagrafiche = new ContrattiConAnagrafiche($con);
        $result['anagrafica_contratto'] = $anagrafiche->findByPk($request->id,ContrattiConAnagrafiche::FETCH_KEYARRAY);

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


function caricaScadenzeGestione($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $rate = new Rate($con);
        $result['rate'] = $rate->findByIdxIdGestione($request->idGestione, Rate::FETCH_KEYARRAY);
        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


function caricaElencoRate($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $rate = new Rate($con);
        $result['listaRate'] = $rate->findByIdContratto($request->idContratto, Rate::FETCH_KEYARRAY);
        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


function modificaPianoSpese($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
        $con->beginTransaction();

        $aggContratto = new AggiornaContratto($con, $conExt);

        $appNewArray = $request->newPianoRate;
        $appOldArray = $request->oldPianoRate;
        for ($i = 0; $i < count($appNewArray); $i++) {
            //controllo se posso paragonare o se sono nuove rate
            if ($appNewArray[$i]->id > 0) {

                if ($appNewArray[$i]->percentuale == '')
                    $appNewArray[$i]->percentuale = 0;

                //AGGIORNA LA PERCENTUALE DELLA RATA
                /*--------------------------------------PERCENTUALE RATE------------------------------------------*/
                if ($appNewArray[$i]->percentuale != $appOldArray[$i]->percentuale) {
                    $aggContratto->cambioPercentualeRateDettagli(
                        $appNewArray[$i]->percentuale,
                        $appNewArray[$i]->id_piano_rate_testata,
                        $appNewArray[$i]->id
                    );
                }

                //CAMBIA DATA SCADENZA
                if ($appNewArray[$i]->rate[0]->id != $appOldArray[$i]->rate[0]->id) {
                    $rateD = new RateDettagli($con);
                    /** @var RateDettagli $rateD */
                    foreach ($rateD->findByIdPianoRateDettagli($appNewArray[$i]->id) as $rateD) {
                        $rateD->setIdRata($appNewArray[$i]->rate[0]->id);
                        $rateD->saveOrUpdate();
                    }
                }

                //ELIMINO LA RATA
                if ($appNewArray[$i]->cestino == 1) {
                    $pianoRateD = new PianiRateDettagli($con);
                    $pianoRateD->deleteByPk($appNewArray[$i]->id);
                    //Elimino sola il PianoRateDettagli perchè la RateDettagli si elimina automaticamente con la  foreign key
                }
            } //Rate nuove
            else {
                $rate = new Rate($con);
                $rate->findByPk($appNewArray[$i]->rate[0]->id);
                $pianoRateT = new PianoRateTesta($con);
                $pianoRateT->findByPk($appNewArray[$i]->id_piano_rate_testata);

                $pianoRateD = new PianiRateDettagli($con);
                $pianoRateD->setIdPianoRateTestata($appNewArray[$i]->id_piano_rate_testata);
                $pianoRateD->setIdTipoIva($appNewArray[$i]->id_tipo_iva);

                $pianoRateD->setDataScadenza($rate->getDataScadenza());

                $pianoRateD->setPercentuale($appNewArray[$i]->percentuale);
                $imponibile=round(($pianoRateT->getImponibile() / 100) * $appNewArray[$i]->percentuale, 2);
                $pianoRateD->setImponibile($imponibile);
                $idPianoRateD = $pianoRateD->saveOrUpdate();

                $pianoRateD->findByPk($idPianoRateD);

                $rateD = new RateDettagli($con);
                $rateD->setIdRata($rate->getId());
                $rateD->setIdTipoIva($appNewArray[$i]->id_tipo_iva);

                if ($pianoRateT->getTipoSpesa() == 'C') {
                    $categoriaSpese = 'A';
                } else {
                    //Se il saldo è a conguaglio
                    if ($pianoRateT->getTipoSaldo() == 'C') {
                        $categoriaSpese = 'S';
                    } else {
                        $categoriaSpese = 'F';
                    }
                }
                $rateD->setIdCategoriaSpesa($categoriaSpese);

                $rateD->setTipoSpesa($pianoRateT->getTipoSpesa());
                $rateD->setTipoSaldo($pianoRateT->getTipoSaldo());
                $rateD->setDescrizione($pianoRateT->getDescrizione());
                $rateD->setImponibile($pianoRateD->getImponibile());
                $rateD->setIdPianoRateDettagli($idPianoRateD);
                $rateD->saveOrUpdate();

                $aggContratto->cambioPercentualeRateDettagli(
                    $appNewArray[$i]->percentuale,
                    $appNewArray[$i]->id_piano_rate_testata,
                    $idPianoRateD
                );

            }
        }

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
