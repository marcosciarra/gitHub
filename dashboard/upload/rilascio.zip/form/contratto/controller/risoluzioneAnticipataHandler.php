<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 15/12/17
 * Time: 10.38
 */
require_once '../../../src/function/functionDate.php';

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';

require_once '../../../src/model/ContrattiConAnagrafiche.php';
require_once '../../../src/model/Contratti.php';
require_once '../../../src/model/Rate.php';
require_once '../../../src/model/RateDettagli.php';
require_once '../../../src/model/TipiIva.php';


use Click\Affitti\TblBase\Contratti;
use Click\Affitti\TblBase\Rate;
use Click\Affitti\TblBase\RateDettagli;
use Click\Affitti\TblBase\TipiIva;
use Click\Affitti\Viste\ContrattiConAnagrafiche;


function cercaRata($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        $contratti=new Contratti($con);
        $contratti->findByPk($request->id);
        $result['statoContratto'] = $contratti->getStatoContratto();

        $anagrafiche = new ContrattiConAnagrafiche($con);
        $result['anagrafica_contratto'] = $anagrafiche->findByPk($request->id,ContrattiConAnagrafiche::FETCH_KEYARRAY);

        $rate = new Rate($con);
        $rate->setWhereBase(' rate.bloccata=0 ');
        $idRata = $rate->getIdRataByData($request->id, $request->dataRisoluzione);
        if ($idRata > 0) {
            $result['rate'] = $rate->findByPk($idRata, Rate::FETCH_KEYARRAY);
        } else {
            $result['rate'] = null;
        }

        $result['status'] = 'ok';

        return json_encode($result);
    } catch
    (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


function caricaDatiRata($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        $rateD = new RateDettagli($con);

        $periodo = dateDiff($request->periodoInizio, $request->periodoFine, '%a') + 1;
        $periodoIniziale = dateDiff($request->periodoInizio, $request->dataRisoluzione, '%a') + 1;

        //Filtro solo i tipi su cui ha senso calcolare il rapporto in giorni
        $rateD->setWhereBase(" id_categoria_spesa IN ('A','F','S','O') ");
        $result['dettagli'] = $rateD->findByIdRata($request->idRata, RateDettagli::FETCH_KEYARRAY);
        for ($i = 0; $i < count($result['dettagli']); $i++) {
            $result['dettagli'][$i]['giorni'] = $periodoIniziale;
            $result['dettagli'][$i]['periodo'] = $periodo;
            $importo = $result['dettagli'][$i]['importo'];
            $result['dettagli'][$i]['nuovoImportoSpesa'] = round(($importo / $periodo) * $periodoIniziale, 2);
        }

        $result['status'] = 'ok';

        return json_encode($result);
    } catch
    (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


function aggiornaRata($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();


        foreach ($request->dettagli as $r) {

            $rateD = new RateDettagli($con);

            $rateD->findByPk($r->id);
            $rateD->setImporto($r->nuovoImportoSpesa);

            $tipiIva = new TipiIva($con);
            $tipiIva->findByPk($r->id_tipo_iva);
            $aliquota = $tipiIva->getAliquota();
            $aliquota = 1 + ($aliquota / 100);
            $rateD->setImponibile(round(($r->nuovoImportoSpesa / $aliquota), 2));
            $rateD->saveOrUpdate();

            $rate=new Rate($con);
            $rate->cambiaDataFineRata($rateD->getIdRata(),$request->dataRisoluzione);

            if($request->disdettaContratto==true){
                $contratti=new Contratti($con);
                $contratti->findByPk($request->idContratto);
                $contratti->setStatoContratto('D');
                $contratti->saveOrUpdate();
            }

            if($request->bloccaRateSuccessive==true){
                /** @var Rate $rate */
                foreach ($rate->elencoRateSbloccateSuccessiveData($request->idContratto,$request->dataRisoluzione) as $rate){
                    $rate->setBloccata(1);
                    $rate->saveOrUpdate();
                }
            }
        }

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }

}

/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
