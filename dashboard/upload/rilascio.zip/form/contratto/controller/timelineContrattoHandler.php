<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 15/12/17
 * Time: 10.38
 */
require_once '../../../src/function/functionDate.php';

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';

require_once '../../../src/model/Contratti.php';
require_once '../../../src/model/PeriodiContrattuali.php';
require_once '../../../src/model/Rli.php';
require_once '../../../src/model/ImpostaRegistro.php';
require_once '../../../src/model/AggiornamentoIstat.php';
require_once '../../../src/model/ContrattiConAnagrafiche.php';


use Click\Affitti\TblBase\PeriodiContrattuali;
use Click\Affitti\TblBase\CanoniOneri;
use Click\Affitti\TblBase\TipiIva;
use Click\Affitti\TblBase\RateDettagli;
use Click\Affitti\Viste\ElaboraContratto;
use Click\Affitti\TblBase\Rate;
use Click\Affitti\TblBase\Rli;
use Click\Affitti\TblBase\ImpostaRegistro;
use Click\Affitti\TblBase\AggiornamentoIstat;
use Click\Affitti\Viste\ContrattiConAnagrafiche;


function caricaDati($request)
{
    $result = array();
    $eventi = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        $oggi = date("Y-m-d", time());

        //DATE CONTRATTO
        $contratto = new \Click\Affitti\TblBase\Contratti($con);
        $contratto->findByPk($request->id);
        $eventi[] = [
            'tipo' => 'A',
            'data' => formattaDate($contratto->getDataStipula(), 'Y-m-d'),
            'titolo' => 'Stipula contratto',
            'testo' => ''
        ];
        $eventi[] = [
            'tipo' => 'C',
            'data' => formattaDate($contratto->getDataInizio(), 'Y-m-d'),
            'titolo' => 'Inizio contratto',
            'testo' => ''
        ];

        //INIZIO PERIODO CONTRATTUALE
        $periodo = new PeriodiContrattuali($con);
        /** @var PeriodiContrattuali $periodo */
        foreach ($periodo->findByIdContratto($request->id) as $periodo) {
            if ($periodo->getDataInizio() <= $oggi) {
                $eventi[] = [
                    'tipo' => 'R',
                    'data' => formattaDate($periodo->getDataInizio(), 'Y-m-d'),
                    'titolo' => 'Inizio ' . $periodo->getProgressivo() . '° periodo contrattuale (' .
                        formattaDate($periodo->getDataInizio(), 'Y-m-d') . ' - ' .
                        formattaDate($periodo->getDataFine(), 'Y-m-d')
                        . ')',
                    'testo' => ''
                ];
            }
        }

        //RLI
        $rli = new Rli($con);
        $rli->setOrderBase(' data_adempimento ASC');
        /** @var Rli $rli */
        foreach ($rli->findByIdContratto($request->id) as $rli) {
            if ($rli->getDataAdempimento() <= $oggi && $rli->getDataAdempimento() != null) {
                $eventi[] = [
                    'tipo' => 'I',
                    'data' => formattaDate($rli->getDataAdempimento(), 'Y-m-d'),
                    'titolo' => 'Creazione modello Rli',
                    'testo' => ''
                ];
            }
        }

        //Richiesta imposta di registro
        $rate = new Rate($con);
        /** @var Rate $rate */
        foreach ($rate->findByIdContrattoConDataRichiesta($request->id) as $rate) {
            if ($rate->getDataScadenza() <= $oggi) {
                $eventi[] = [
                    'tipo' => 'I',
                    'data' => formattaDate($rate->getDataScadenza(), 'Y-m-d'),
                    'titolo' => 'Richiesta imposta di registro',
                    'testo' => ''
                ];
            }
        }

        //Pagamento imposta di registro
        $istat = new ImpostaRegistro($con);
        /** @var ImpostaRegistro $istat */
        foreach ($istat->findByIdContrattoVersati($request->id) as $istat) {
            $eventi[] = [
                'tipo' => 'F',
                'data' => formattaDate($istat->getDataVersamento(), 'Y-m-d'),
                'titolo' => 'Pagamento imposta di registro (F24)',
                'testo' => ''
            ];
        }

        //Aggiornamento ISTAT
        $istat = new AggiornamentoIstat($con);
        /** @var AggiornamentoIstat $istat */
        foreach ($istat->findByIdContratto($request->id,AggiornamentoIstat::FETCH_KEYARRAY) as $istat) {
            $eventi[] = [
                'tipo' => 'T',
                'data' => formattaDate($istat['data_aggiornamento'], 'Y-m-d'),
                'titolo' => 'Aggiornamento ISTAT',
                'testo' => 'Canone variato del ' . $istat['percentuale']. '%'
            ];
        }

        $result['eventi'] = $eventi;

        $anagrafiche = new ContrattiConAnagrafiche($con);
        $result['anagrafica_contratto'] = $anagrafiche->findByPk($request->id,ContrattiConAnagrafiche::FETCH_KEYARRAY);

        $result['status'] = 'ok';

        return json_encode($result);
    } catch
    (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
