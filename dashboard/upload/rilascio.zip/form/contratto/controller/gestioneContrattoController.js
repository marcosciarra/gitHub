ngApp.controller("gestioneContrattoController", ["$scope", "$http", "$filter", "ngToast", function ($scope, $http, $filter, $ngToast) {

    var url = window.location.href;
    var params = decodeUrl(url, 'id');
    stampalog(params);

    $scope.caricamentoCompletato = false;
    $scope.filtroCerca = false;
    $scope.pannelloNote = 0;
    $scope.pannelloContratto = 1;
    $scope.pannelloIntestatari = 0;
    $scope.pannelloImmobili = 0;
    $scope.pannelloCanoni = 0;
    $scope.pannelloCauzioni = 0;
    $scope.pannelloRli = 0;

    $scope.mesi_istat = [
        {id: '0', descrizione: 'NO ISTAT'},
        {id: '1', descrizione: 'GENNAIO'},
        {id: '2', descrizione: 'FEBBRAIO'},
        {id: '3', descrizione: 'MARZO'},
        {id: '4', descrizione: 'APRILE'},
        {id: '5', descrizione: 'MAGGIO'},
        {id: '6', descrizione: 'GIUGNO'},
        {id: '7', descrizione: 'LUGLIO'},
        {id: '8', descrizione: 'AGOSTO'},
        {id: '9', descrizione: 'SETTEMBRE'},
        {id: '10', descrizione: 'OTTOBRE'},
        {id: '11', descrizione: 'NOVEMBRE'},
        {id: '12', descrizione: 'DICEMBRE'}
    ];

    /******************
     *   CARICADATI   * ================================================================================================
     ******************/

    $scope.init = function () {
        $scope.caricaDati();
    };

    $scope.caricaDati = function () {
        $http.post(params['form'] + '/contratto/controller/gestioneContrattoHandler.php',
            {
                'function': 'caricaDati',
                'id': params['id']
            }
        ).then(function (data, status, headers, config) {
            stampalog(data.data.status);
            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }
            stampalog('Carico Dati');
            stampalog(data.data);
            $scope.contrattoAffitto = data.data.contrattoAffitto;
            //Unità Immobiliari
            $scope.elencoUnitaImmobiliari = data.data.elencoUnitaImmobiliari;
            //Tipologie di spese (canone e oneri)
            $scope.elencoTipiSpesa = data.data.elencoTipiSpesa;
            $scope.elencoTipiSaldo = data.data.elencoTipiSaldo;
            //TipiCauzione
            $scope.elencoTipiCauzione = data.data.elencoTipiCauzione;

            $scope.contrattoAffitto.contratto.data_stipula = formatDataDbToIta($scope.contrattoAffitto.contratto.data_stipula);
            $scope.contrattoAffitto.contratto.data_inizio = formatDataDbToIta($scope.contrattoAffitto.contratto.data_inizio);
            $scope.contrattoAffitto.contrattiDettagli.data_registrazione = formatDataDbToIta($scope.contrattoAffitto.contrattiDettagli.data_registrazione);
            $scope.contrattoAffitto.contrattiDettagli.data_consegna_chiavi = formatDataDbToIta($scope.contrattoAffitto.contrattiDettagli.data_consegna_chiavi);

            $scope.locatori = jsonParse($scope.contrattoAffitto.contratto.proprietari);
            $scope.conduttori = jsonParse($scope.contrattoAffitto.contratto.conduttori);
            $scope.garanti = jsonParse($scope.contrattoAffitto.contratto.garanti);

            for (var i = 0; i < $scope.contrattoAffitto.cauzioni.length; i++) {
                if ($scope.contrattoAffitto.cauzioni[i].cestino == 1) {
                    $scope.contrattoAffitto.cauzioni.splice(i, 1);
                    i--;
                    continue;
                }
                var app = $scope.contrattoAffitto.cauzioni[i].data_scadenza;
                if (app != null) {
                    $scope.contrattoAffitto.cauzioni[i].data_scadenza = formatDataDbToIta($scope.contrattoAffitto.cauzioni[i].data_scadenza);
                }
            }

            if ($scope.contrattoAffitto.rli.pagamento_una_tantum == 0) {
                $scope.tipo_pagamento_rli = "ANNUALE";
            }
            else {
                $scope.tipo_pagamento_rli = "UNA TANTUM";
            }
            $scope.paercentualeLocatore = $scope.contrattoAffitto.contrattiPreferenze.imposta_registro_perc_locatore;
            $scope.paercentualeConduttore = 100 - $scope.contrattoAffitto.contrattiPreferenze.imposta_registro_perc_locatore;

            $scope.statoAvanzamento1 = data.data.tempoPeriodo;
            $scope.statoAvanzamento2 = data.data.tempoContratto;
            $scope.fatturato = data.data.fatturato;
            if ($scope.fatturato == false)
                $scope.fatturato = 0;
            $scope.saldo = data.data.saldo;
            if ($scope.saldo == false)
                $scope.saldo = $scope.fatturato;
            if ($scope.fatturato != 0) {
                var incassato = $scope.fatturato - $scope.saldo;
                $scope.statoAvanzamento3 = ((incassato * 100) / $scope.fatturato);
                $scope.statoAvanzamento3 = $scope.statoAvanzamento3 * 100;
                $scope.statoAvanzamento3 = Math.round($scope.statoAvanzamento3);
                $scope.statoAvanzamento3 = $scope.statoAvanzamento3 / 100;
            }
            else {
                $scope.statoAvanzamento3 = 100;
            }

            $scope.contratto_data_inizio = data.data.contratto_data_inizio;
            $scope.contratto_data_fine = data.data.contratto_data_fine;
            $scope.periodo_data_inizio = data.data.periodo_data_inizio;
            $scope.periodo_data_fine = data.data.periodo_data_fine;

            $scope.note = data.data.note;
            if ($scope.note.length > 0) {
                $scope.pannelloNote = 1;
                $scope.pannelloContratto = 0;
            }

            $scope.caricamentoCompletato = true;
        });
    };

    $scope.stampaNome = function (id) {
        return $filter('filter')($scope.elencoUnitaImmobiliari, {id: id})[0].descrizione;
    };

    $scope.stampaMese = function (id) {
        return $filter('filter')($scope.mesi_istat, {id: id})[0].descrizione;
    };

    /* =========================================== NOTE ============================================================= */

    $scope.gestioneNote = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "note", id);
    };

    /* ======================================= TIMELINE ============================================================= */

    $scope.timeline = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "timelineContratto", id);
    };

    /* ======================================= PIANO RATE SPESE ===================================================== */

    $scope.pianoSpese = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "pianoSpeseContratto", id);
    };

    /* =========================================== SCADENZE ========================================================= */

    $scope.scadenze = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "scadenze", id);
    };

    /* ======================================= PIANO RATE CANONE ==================================================== */

    $scope.pianoRate = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "pianoRateContratto", id);
    };

    /* ==================================== RATEIZZAZIONE CANONE ==================================================== */

    $scope.rateizzazione = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "rateizzazioneContratto", id);
    };
    /* ==================================== RISOLUZIONE ANTICIPATA=================================================== */

    $scope.risoluzioneAnticipata = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "risoluzioneAnticipata", id);
    };

    /* ========================================= GESTIONE CONTRATTO ================================================= */

    $scope.gestioneContratto = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "gestioneContratto", id);
    };

    /* ========================================= IMPOSTA DI REGISTRO ================================================= */

    $scope.impostaDiRegistro = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "impostaDiRegistro", id);
    };

    /* ================================================= RLI ======================================================== */

    $scope.rli = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "rli", id);
    };

    /* ============================================= CONFIGURAZIONI ================================================= */

    $scope.configurazioni = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "configurazioni", id);
    };

    /* ============================================= CORRISPONDENZA ================================================= */

    $scope.corrispondenza = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "corrispondenza", id);
    };

    /* ========================================= GESTIONE PANNELLI ================================================= */

    $scope.gestionePannelli = function (pannello) {
        switch (pannello) {
            case 0:
                $scope.pannelloNote = 1;
                $scope.pannelloContratto = 0;
                $scope.pannelloIntestatari = 0;
                $scope.pannelloImmobili = 0;
                $scope.pannelloCanoni = 0;
                $scope.pannelloCauzioni = 0;
                $scope.pannelloRli = 0;
                break;
            case 1:
                $scope.pannelloNote = 0;
                $scope.pannelloContratto = 1;
                $scope.pannelloIntestatari = 0;
                $scope.pannelloImmobili = 0;
                $scope.pannelloCanoni = 0;
                $scope.pannelloCauzioni = 0;
                $scope.pannelloRli = 0;
                break;
            case 2:
                $scope.pannelloNote = 0;
                $scope.pannelloContratto = 0;
                $scope.pannelloIntestatari = 1;
                $scope.pannelloImmobili = 0;
                $scope.pannelloCanoni = 0;
                $scope.pannelloCauzioni = 0;
                $scope.pannelloRli = 0;
                break;
            case 3:
                $scope.pannelloNote = 0;
                $scope.pannelloContratto = 0;
                $scope.pannelloIntestatari = 0;
                $scope.pannelloImmobili = 1;
                $scope.pannelloCanoni = 0;
                $scope.pannelloCauzioni = 0;
                $scope.pannelloRli = 0;
                break;
            case 4:
                $scope.pannelloNote = 0;
                $scope.pannelloContratto = 0;
                $scope.pannelloIntestatari = 0;
                $scope.pannelloImmobili = 0;
                $scope.pannelloCanoni = 1;
                $scope.pannelloCauzioni = 0;
                $scope.pannelloRli = 0;
                break;
            case 5:
                $scope.pannelloNote = 0;
                $scope.pannelloContratto = 0;
                $scope.pannelloIntestatari = 0;
                $scope.pannelloImmobili = 0;
                $scope.pannelloCanoni = 0;
                $scope.pannelloCauzioni = 1;
                $scope.pannelloRli = 0;
                break;
            case 6:
                $scope.pannelloNote = 0;
                $scope.pannelloContratto = 0;
                $scope.pannelloIntestatari = 0;
                $scope.pannelloImmobili = 0;
                $scope.pannelloCanoni = 0;
                $scope.pannelloCauzioni = 0;
                $scope.pannelloRli = 1;
                break;
        }
    };

    $scope.thresholdOptions = {
        '0': {color: 'green'},
        '50': {color: 'blue'},
        '80': {color: 'red'}
    };
    $scope.thresholdOptionsInverso = {
        '0': {color: 'red'},
        '75': {color: 'blue'},
        '90': {color: 'green'}
    };

}])
;