ngApp.controller("configurazioniController", ["$scope", "$http", "$filter", "ngToast", function ($scope, $http, $filter, $ngToast) {

    var url = window.location.href;
    var params = decodeUrl(url, 'id');
    stampalog('URL');
    stampalog(params);
    $scope.visualizza = 'contratto';

    $scope.salvaLocatore = true;
    $scope.salvaConduttore = true;
    $scope.modificaLocatore = false;
    $scope.modificaConduttore = false;

    $scope.tipo_assoggettazione = [
        {id: 'N', descrizione: 'NON ASSOGGETTO AD IVA'},
        {id: 'S', descrizione: 'ASSOGGETTO AD IVA'}
    ];
    $scope.mesi_istat = [
        {id: 0, descrizione: 'NO ISTAT'},
        {id: 1, descrizione: 'GENNAIO'},
        {id: 2, descrizione: 'FEBBRAIO'},
        {id: 3, descrizione: 'MARZO'},
        {id: 4, descrizione: 'APRILE'},
        {id: 5, descrizione: 'MAGGIO'},
        {id: 6, descrizione: 'GIUGNO'},
        {id: 7, descrizione: 'LUGLIO'},
        {id: 8, descrizione: 'AGOSTO'},
        {id: 9, descrizione: 'SETTEMBRE'},
        {id: 10, descrizione: 'OTTOBRE'},
        {id: 11, descrizione: 'NOVEMBRE'},
        {id: 12, descrizione: 'DICEMBRE'}
    ];
    $scope.mesi_conguaglio_istat = [
        {id: 0, descrizione: '0 MESI'},
        {id: 1, descrizione: '1 MESE'},
        {id: 2, descrizione: '2 MESI'},
        {id: 3, descrizione: '3 MESI'},
        {id: 4, descrizione: '4 MESI'},
        {id: 5, descrizione: '5 MESI'},
        {id: 6, descrizione: '6 MESI'},
        {id: 7, descrizione: '7 MESI'},
        {id: 8, descrizione: '8 MESI'},
        {id: 9, descrizione: '9 MESI'},
        {id: 10, descrizione: '10 MESI'},
        {id: 11, descrizione: '11 MESI'},
        {id: 12, descrizione: '12 MESI'}
    ];
    $scope.elenco_tipo_restituzione_interessi = [
        {id: 'N', descrizione: 'NESSUN CALCOLO'},
        {id: 'A', descrizione: 'ANNUALI'},
        {id: 'C', descrizione: 'RISOLUZIONE (CAPITALE)'},
        {id: 'V', descrizione: 'RISOLUZIONE (VERSATO)'}
    ];

    $scope.tipo_pagamento_imposta = [
        {id: 'A', descrizione: 'ANTICIPATA'},
        {id: 'P', descrizione: 'POSTICIPATA'}
    ];

    $scope.tipo_istat = [
        {id: 'a75', descrizione: 'ANNUALE 75%'},
        {id: 'a100', descrizione: 'ANNUALE 100%'}
        // {id: 'a75', descrizione: 'ANNUALE 75%'},
        // {id: 'a100', descrizione: 'ANNUALE 100%'},
        // {id: 'b75', descrizione: 'BIENNALE 75%'},
        // {id: 'b100', descrizione: 'BIENNALE 100%'}
    ];


    $scope.init = function () {
        $scope.caricaDati();
        $scope.mostraFormNuovoDettaglio = false;
    };

    $scope.mostraImpostazioni = function (tab) {
        $scope.visualizza = tab;
    };


    /******************
     *   CARICADATI   * ================================================================================================
     ******************/

    $scope.caricaDati = function () {
        $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
            {
                'function': 'caricaDati',
                'id': params['id']
            }
        ).then(function (data, status, headers, config) {

            stampalog(data.data.status);
            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }
            $scope.dettagliContratto = data.data;

            $scope.idContratto = params['id'];
            stampalog('Carico Dati');
            stampalog($scope.dettagliContratto);
            for (var i = 0; i < data.data.elencoContiCorrente.length; i++) {
                if (data.data.elencoContiCorrente[i].fineCC == null) {
                    data.data.elencoContiCorrente[i].descrizione = 'CASSA: ' + data.data.elencoContiCorrente[i].agenzia;
                } else {
                    data.data.elencoContiCorrente[i].descrizione = 'CC: ' +
                        data.data.elencoContiCorrente[i].fineCC + ' - AGENZIA di: ' +
                        data.data.elencoContiCorrente[i].agenzia;
                }
            }

            $scope.elencoAnagrafica = data.data.elencoAnagrafica;

            $scope.elencoCCconduttori = data.data.elencoContiCorrente;

            $scope.dataScadenzaContratto = data.data.dataScadenzaContratto;

            $scope.elencoUtenti = data.data.elencoUtenti;
            $scope.gruppiFat = [];
            if (data.data.gruppiFat != null) {
                for (var i = 0; i < data.data.gruppiFat.length; i++) {
                    if (data.data.gruppiFat[i].id_anagrafica == $scope.dettagliContratto.contrattoAffitto.contratto.id_agenzia_immobiliare) {
                        $scope.gruppiFat.push(data.data.gruppiFat[i]);
                    }
                }
            }
            for (var i = 0; i < $scope.dettagliContratto.cedolareSecca.length; i++) {
                $scope.dettagliContratto.cedolareSecca[i].key =
                    '' + $scope.dettagliContratto.cedolareSecca[i].key;
            }

            // codice identificativo rli
            if (
                $scope.dettagliContratto.contrattoAffitto.rli.codice_identificativo == null ||
                $scope.dettagliContratto.contrattoAffitto.rli.codice_identificativo.length < 16
            ) {
                $scope.disabilitaInserimentoCodiceId = false;
                if ($scope.dettagliContratto.contrattoAffitto.rli.codice_ufficio == null) {
                    $scope.dettagliContratto.contrattoAffitto.rli.codice_ufficio = '';
                }
                if ($scope.dettagliContratto.contrattoAffitto.rli.anno_stipula == null) {
                    $scope.dettagliContratto.contrattoAffitto.rli.anno_stipula = '';
                }
                if ($scope.dettagliContratto.contrattoAffitto.rli.serie == null) {
                    $scope.dettagliContratto.contrattoAffitto.rli.serie = '';
                }
                if ($scope.dettagliContratto.contrattoAffitto.rli.numero == null) {
                    $scope.dettagliContratto.contrattoAffitto.rli.numero = '';
                }
                if ($scope.dettagliContratto.contrattoAffitto.rli.sottonumero == null) {
                    $scope.dettagliContratto.contrattoAffitto.rli.sottonumero = '';
                }
            } else {
                $scope.disabilitaInserimentoCodiceId = true;
            }

            for (var i = 0; i < $scope.dettagliContratto.contrattoAffitto.cauzioni.length; i++) {
                var app = $scope.dettagliContratto.contrattoAffitto.cauzioni[i].data_cauzione;
                if (app != null) {
                    $scope.dettagliContratto.contrattoAffitto.cauzioni[i].data_cauzione = new Date(app);
                }
                var app = $scope.dettagliContratto.contrattoAffitto.cauzioni[i].data_scadenza;
                if (app != null) {
                    $scope.dettagliContratto.contrattoAffitto.cauzioni[i].data_scadenza = new Date(app);
                }
            }

            $scope.locatori = jsonParse(data.data.anagrafica_contratto.proprietari);
            $scope.primoLocatore = $scope.locatori[0].descrizione;

            $scope.conduttori = jsonParse(data.data.anagrafica_contratto.conduttori);
            $scope.primoConduttore = $scope.conduttori[0].descrizione;

            $scope.unitaImmobiliari = data.data.anagrafica_contratto.unita_immobiliari;
            $scope.primoStabile = $scope.unitaImmobiliari[0].descrizione;

            $scope.elencoTipiCauzione = data.data.elencoTipiCauzione;
            $scope.nuovaCauzione = data.data.nuovaCauzione;
            $scope.nuovaCauzione.tipo_restituzione_interessi = 'N';
            $scope.nuovaCauzione.id_contratto = 1 * params['id'];


            //Carico elenco Locatori
            if ($scope.dettagliContratto.contrattoAffitto.contrattiPreferenze.divisione_locatori != null) {
                $scope.modificaLocatore = true;
                $scope.gruppiLocatori = jsonParse($scope.dettagliContratto.contrattoAffitto.contrattiPreferenze.divisione_locatori);

                //Carico gruppi di Locatori
                $scope.elencoGruppiLocatori = [];
                for (var i = 0; i < $scope.gruppiLocatori.length; i++) {
                    $scope.elencoGruppiLocatori.push({
                        gruppo: $scope.gruppiLocatori[i].gruppo,
                        percentuale: $scope.gruppiLocatori[i].percentuale
                    });
                }

                //Carico elenco dei Locatori
                $scope.elencoLocatori = [];
                for (var i = 0; i < $scope.gruppiLocatori.length; i++) {
                    for (var j = 0; j < $scope.gruppiLocatori[i].locatori.length; j++) {
                        $scope.elencoLocatori.push({
                            id: $scope.gruppiLocatori[i].locatori[j].id,
                            descrizione: $scope.gruppiLocatori[i].locatori[j].descrizione,
                            gruppo: $scope.gruppiLocatori[i].gruppo
                        });
                    }
                }
            }
            else {
                $scope.modificaLocatore = false;
                //Carico gruppi di Locatori
                $scope.elencoGruppiLocatori = [];
                $scope.elencoGruppiLocatori.push({
                    gruppo: 0,
                    percentuale: 100
                });

                //Carico elenco dei Locatori
                $scope.locatori = jsonParse($scope.dettagliContratto.contrattoAffitto.contratto.proprietari);
                $scope.elencoLocatori = [];
                for (var i = 0; i < $scope.locatori.length; i++) {
                    $scope.elencoLocatori.push({
                        id: $scope.locatori[i].id,
                        descrizione: $scope.locatori[i].descrizione,
                        gruppo: 0
                    });
                }
            }
            //Carico elenco Conduttori
            if ($scope.dettagliContratto.contrattoAffitto.contrattiPreferenze.divisione_conduttori != null) {
                $scope.modificaConduttore = true;
                $scope.gruppiConduttori = jsonParse($scope.dettagliContratto.contrattoAffitto.contrattiPreferenze.divisione_conduttori);

                //Carico gruppi di conduttori
                $scope.elencoGruppiConduttori = [];
                for (var i = 0; i < $scope.gruppiConduttori.length; i++) {
                    $scope.elencoGruppiConduttori.push({
                        gruppo: $scope.gruppiConduttori[i].gruppo,
                        percentuale: $scope.gruppiConduttori[i].percentuale
                    });
                }

                //Carico elenco dei Conduttori
                $scope.elencoConduttori = [];
                for (var i = 0; i < $scope.gruppiConduttori.length; i++) {
                    for (var j = 0; j < $scope.gruppiConduttori[i].conduttori.length; j++) {
                        $scope.elencoConduttori.push({
                            id: $scope.gruppiConduttori[i].conduttori[j].id,
                            descrizione: $scope.gruppiConduttori[i].conduttori[j].descrizione,
                            gruppo: $scope.gruppiConduttori[i].gruppo
                        });
                    }
                }
            }
            else {
                $scope.modificaConduttore = false;
                //Carico gruppi di Conduttori
                $scope.elencoGruppiConduttori = [];
                $scope.elencoGruppiConduttori.push({
                    gruppo: 0,
                    percentuale: 100
                });

                //Carico elenco dei Conduttori
                $scope.conduttori = jsonParse($scope.dettagliContratto.contrattoAffitto.contratto.conduttori);
                $scope.elencoConduttori = [];
                for (var i = 0; i < $scope.conduttori.length; i++) {
                    $scope.elencoConduttori.push({
                        id: $scope.conduttori[i].id,
                        descrizione: $scope.conduttori[i].descrizione,
                        gruppo: 0
                    });
                }
            }

            $scope.elencoLocatori = data.data.elencoLocatori;
            $scope.elencoConduttori = data.data.elencoConduttori;
            $scope.intestatario_locatore = data.data.intestatario_locatore;
            $scope.intestatario_conduttore = data.data.intestatario_conduttore;


            $scope.utente = localStorage.getItem("tipoUtente");

            $scope.caricamentoCompletato = true;
        });
    };


    $scope.aggiungiGruppo = function (tipo) {
        if (tipo == 'locatori') {
            $scope.elencoGruppiLocatori.push({
                gruppo: $scope.elencoGruppiLocatori.length,
                percentuale: 0
            });
        }
        else {
            $scope.elencoGruppiConduttori.push({
                gruppo: $scope.elencoGruppiConduttori.length,
                percentuale: 0
            });
        }
    };


    $scope.controllaLocatori = function () {
        $scope.salvaLocatore = false;
        var perc = 0;
        //Controllo la somma delle percentuali
        for (var i = 0; i < $scope.elencoGruppiLocatori.length; i++) {
            perc += ($scope.elencoGruppiLocatori[i].percentuale * 1);
        }
        if (perc == 100)
            $scope.salvaLocatore = true;
        //Controllo che tutti i proprietari abbiano un gruppo associato
        if ($scope.salvaLocatore == true) {
            for (var i = 0; i < $scope.elencoLocatori.length; i++) {
                if ($scope.elencoLocatori[i].gruppo < 0) {
                    $scope.salvaLocatore = false;
                    return;
                }
            }
        }
    };

    $scope.controllaConduttori = function () {
        $scope.salvaConduttore = false;
        var perc = 0;
        //Controllo la somma delle percentuali
        for (var i = 0; i < $scope.elencoGruppiConduttori.length; i++) {
            perc += ($scope.elencoGruppiConduttori[i].percentuale * 1);
        }
        if (perc == 100)
            $scope.salvaConduttore = true;
        //Controllo che tutti i proprietari abbiano un gruppo associato
        if ($scope.salvaConduttore == true) {
            for (var i = 0; i < $scope.elencoGruppiConduttori.length; i++) {
                if ($scope.elencoGruppiConduttori[i].gruppo < 0) {
                    $scope.salvaConduttore = false;
                    return;
                }
            }
        }
    };

    $scope.eliminaSuddivisione = function (tipo) {
        if (tipo == 'locatori') {
            $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
                {
                    'function': 'eliminaSuddivisione',
                    'idContratto': params['id'],
                    'tipo': 'locatori'
                }
            ).then(function (data, status, headers, config) {
                if (data.data == 'ok') {
                    $ngToast.create({
                        className: 'danger',
                        content: 'Suddivisione locatori eliminata',
                        dismissButton: true,
                        timeout: 1500
                    });
                } else {
                    swal({
                            title: "Errore",
                            text: "Impossibile modificare lo stato contratto",
                            type: "error",
                            showCancelButton: false,
                            confirmButtonClass: "btn-danger",
                            confirmButtonText: "Ok",
                            closeOnConfirm: false
                        },
                        function () {
                            window.location.reload();
                        });

                }
            });
        }
        else {
            $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
                {
                    'function': 'eliminaSuddivisione',
                    'idContratto': params['id'],
                    'tipo': 'conduttori'
                }
            ).then(function (data, status, headers, config) {
                if (data.data == 'ok') {
                    $ngToast.create({
                        className: 'danger',
                        content: 'Suddivisione conduttori eliminata',
                        dismissButton: true,
                        timeout: 1500
                    });
                } else {
                    swal({
                            title: "Errore",
                            text: "Impossibile modificare lo stato contratto",
                            type: "error",
                            showCancelButton: false,
                            confirmButtonClass: "btn-danger",
                            confirmButtonText: "Ok",
                            closeOnConfirm: false
                        },
                        function () {
                            window.location.reload();
                        });

                }
            });
        }
    };

    $scope.salvaGruppo = function (tipo) {

        if (tipo == 'locatori') {
            for (var i = 0; i < $scope.elencoGruppiLocatori.length; i++) {
                $scope.elencoGruppiLocatori[i].locatori = [];
                for (var j = 0; j < $scope.elencoLocatori.length; j++) {
                    if ($scope.elencoLocatori[j].gruppo == $scope.elencoGruppiLocatori[i].gruppo) {
                        $scope.elencoGruppiLocatori[i].locatori.push(
                            {id: $scope.elencoLocatori[j].id, descrizione: $scope.elencoLocatori[j].descrizione}
                        );
                    }
                }
            }
            $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
                {
                    'function': 'salvaGruppo',
                    'idContratto': params['id'],
                    'elencoGruppiLocatori': $scope.elencoGruppiLocatori,
                    'tipo': 'locatori'
                }
            ).then(function (data, status, headers, config) {
                if (data.data == 'ok') {
                    $ngToast.create({
                        className: 'success',
                        content: 'Gruppo Locatori modificato',
                        dismissButton: true,
                        timeout: 1500
                    });
                } else {
                    swal({
                            title: "Errore",
                            text: "Impossibile modificare lo stato contratto",
                            type: "error",
                            showCancelButton: false,
                            confirmButtonClass: "btn-danger",
                            confirmButtonText: "Ok",
                            closeOnConfirm: false
                        },
                        function () {
                            window.location.reload();
                        });

                }
            });
        }
        else {
            for (var i = 0; i < $scope.elencoGruppiConduttori.length; i++) {
                $scope.elencoGruppiConduttori[i].conduttori = [];
                for (var j = 0; j < $scope.elencoConduttori.length; j++) {
                    if ($scope.elencoConduttori[j].gruppo == $scope.elencoGruppiConduttori[i].gruppo) {
                        $scope.elencoGruppiConduttori[i].conduttori.push(
                            {id: $scope.elencoConduttori[j].id, descrizione: $scope.elencoConduttori[j].descrizione}
                        );
                    }
                }
            }
            $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
                {
                    'function': 'salvaGruppo',
                    'idContratto': params['id'],
                    'elencoGruppiConduttori': $scope.elencoGruppiConduttori,
                    'tipo': 'conduttori'
                }
            ).then(function (data, status, headers, config) {
                if (data.data == 'ok') {
                    $ngToast.create({
                        className: 'success',
                        content: 'Gruppo Conduttori modificato',
                        dismissButton: true,
                        timeout: 1500
                    });
                } else {
                    swal({
                            title: "Errore",
                            text: "Impossibile modificare lo stato contratto",
                            type: "error",
                            showCancelButton: false,
                            confirmButtonClass: "btn-danger",
                            confirmButtonText: "Ok",
                            closeOnConfirm: false
                        },
                        function () {
                            window.location.reload();
                        });

                }
            });
        }
    };


    $scope.caricaDettagliModale = function (elenco, etichetta) {
        $scope.elencoModale = elenco;
        $scope.etichettaModale = etichetta;
    };


    /* ========================================= GESTIONE CONTRATTO ================================================= */

    $scope.gestioneContratto = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "gestioneContratto", id);
    };

    /*===========================================DISDETTA=============================================================*/

    $scope.disdetta = function (stato) {
        $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
            {'function': 'statoContratto', 'idContratto': params['id'], 'stato': stato}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                if (stato == 'A') {
                    $ngToast.create({
                        className: 'success',
                        content: 'Contratto ATTIVO',
                        dismissButton: true,
                        timeout: 1500
                    });
                } else {
                    $ngToast.create({
                        className: 'danger',
                        content: 'Contratto DISDETTATO',
                        dismissButton: true,
                        timeout: 1500
                    });
                }
                $scope.dettagliContratto.contrattoAffitto.contratto.stato_contratto = stato;
            } else {
                swal({
                        title: "Errore",
                        text: "Impossibile modificare lo stato contratto",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });

            }
        });
    };

    $scope.stampaLetteraSingola = function () {
        window.open(params['baseurl'] + '/stampe/disdette/letteraDisdettaPdf.php?idContratto=' + params['id']);
    };

    /*===========================================OCCUPAZIONE SENZA TITOLO=============================================*/

    $scope.occupazione = function (stato) {
        $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
            {'function': 'occupazione', 'idContratto': params['id'], 'stato': stato}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                if (stato == 0) {
                    $ngToast.create({
                        className: 'success',
                        content: 'Contratto RIPRISTINATO',
                        dismissButton: true,
                        timeout: 1500
                    });
                } else {
                    $ngToast.create({
                        className: 'danger',
                        content: 'Contratto in OCCUPAZIONE',
                        dismissButton: true,
                        timeout: 1500
                    });
                }
                $scope.dettagliContratto.contrattoAffitto.contratto.occupazione_senza_titolo = stato;
            } else {
                swal({
                        title: "Errore",
                        text: "Impossibile modificare lo stato contratto",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });

            }
        });
    };

    /*===========================================CEDOLARE SECCA=======================================================*/
    $scope.fixImpReg = function () {
        $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
            {'function': 'fixImpReg'}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                $ngToast.create({
                    className: 'success',
                    content: 'FATTO',
                    dismissButton: true,
                    timeout: 1500
                });
            }
            else {
                swal({
                        title: "Errore",
                        text: "",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });

            }
        });
    };


    $scope.cedolareSecca = function (stato) {
        $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
            {'function': 'cedolareSecca', 'idContratto': params['id'], 'stato': stato}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                if (stato == '1') {
                    $ngToast.create({
                        className: 'success',
                        content: 'Adesione alla cedolare secca',
                        dismissButton: true,
                        timeout: 1500
                    });
                } else if (stato == '2') {
                    $ngToast.create({
                        className: 'info',
                        content: 'Almeno un locatore opta alla cedolare secca',
                        dismissButton: true,
                        timeout: 1500
                    });
                } else {
                    $ngToast.create({
                        className: 'danger',
                        content: 'Nessun locatore opta alla cedolare secca',
                        dismissButton: true,
                        timeout: 1500
                    });
                }
                $scope.dettagliContratto.dettagliContratto.contrattoAffitto.rli.cedolare_secca = stato;
            } else {
                stampalog(data.data);
                swal({
                        title: "Errore",
                        text: "Impossibile modificare lo stato della cedolare secca",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });

            }
        });
    };


    /*=====================================RICHIESTA IMPOSTA DI REGISTRO==============================================*/
    $scope.cambiaRichiestaImposta = function () {
        $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
            {
                'function': 'cambiaRichiestaImposta',
                'idContratto': params['id'],
                'tipoRichiesta': $scope.dettagliContratto.contrattoAffitto.contrattiPreferenze.imposta_registro_tipo_richiesta
            }
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                $ngToast.create({
                    className: 'warning',
                    content: 'Tipo richiesta imposta di registro aggiornata',
                    dismissButton: true,
                    timeout: 1500
                });
            } else {
                swal({
                        title: "Errore",
                        text: "Impossibile modificare la richiesta di imposta di registro",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });

            }
        });
    };


    /*===========================================UTENTE RIFERIMENTO===================================================*/

    $scope.utenteRiferimento = function (codice) {
        $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
            {'function': 'utenteRiferimento', 'idContratto': params['id'], 'codice': codice}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                $ngToast.create({
                    className: 'success',
                    content: 'Utente di riferimento modificato',
                    dismissButton: true,
                    timeout: 1500
                });
            } else {
                swal({
                        title: "Errore",
                        text: "Impossibile modificare il tipo richiesta",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });

            }
        });
    };

    $scope.eliminaUtenteRiferimento = function () {
        $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
            {'function': 'eliminaUtenteRiferimento', 'idContratto': params['id']}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                $scope.dettagliContratto.contrattoAffitto.contratto.id_utente_riferimento = 0;
                $ngToast.create({
                    className: 'warning',
                    content: 'Utente di riferimento eliminato',
                    dismissButton: true,
                    timeout: 1500
                });
            } else {
                swal({
                        title: "Errore",
                        text: "Impossibile eliminare l'utente di riferimento",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });

            }
        });
    };

    /*===========================================GRUPPO FATTURAZIONE==================================================*/

    $scope.cambiaGruppoFatturazione = function (codice) {
        $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
            {'function': 'cambiaGruppoFatturazione', 'idContratto': params['id'], 'codice': codice}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                $ngToast.create({
                    className: 'success',
                    content: 'Gruppo fatturazione modificato',
                    dismissButton: true,
                    timeout: 1500
                });
            } else {
                swal({
                        title: "Errore",
                        text: "Impossibile modificare il gruppo di fatturazione",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });

            }
        });
    };

    /*===========================================TIPO RICHIESTA=======================================================*/

    $scope.cambiaTipoRichiesta = function (codice) {
        $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
            {'function': 'tipoRichiesta', 'idContratto': params['id'], 'codice': codice}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                $ngToast.create({
                    className: 'success',
                    content: 'Tipo richiesta canone modificato',
                    dismissButton: true,
                    timeout: 1500
                });
            } else {
                swal({
                        title: "Errore",
                        text: "Impossibile modificare il tipo richiesta",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });

            }
        });
    };

    /*=========================================== CAUZIONE===================================================*/

    $scope.controllaNuovaCauzione = function () {
        if ($scope.nuovaCauzione.id_tipo_cauzione != '' &&
            $scope.nuovaCauzione.id_tipo_cauzione != undefined &&
            $scope.nuovaCauzione.descrizione != '' &&
            $scope.nuovaCauzione.data_cauzione != '' &&
            $scope.nuovaCauzione.data_cauzione != undefined &&
            $scope.nuovaCauzione.importo > 0
        ) {
            $scope.mostraPulsantiCauzione = true;
        }
        else {
            $scope.mostraPulsantiCauzione = false;
        }
    };

    $scope.aggiungiNuovaCauzione = function () {
        $scope.nuovaCauzione.data_cauzione = getYYYYMMGGFromJsDate($scope.nuovaCauzione.data_cauzione);
        $scope.nuovaCauzione.data_scadenza = getYYYYMMGGFromJsDate($scope.nuovaCauzione.data_scadenza);

        $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
            {
                'function': 'aggiungiNuovaCauzione',
                'cauzione': $scope.nuovaCauzione
            }
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                window.location.reload();
            } else {
                swal({
                    title: "Errore",
                    text: "Impossibile salvare la cauzione",
                    type: "error",
                    showCancelButton: false,
                    confirmButtonClass: "btn-danger",
                    confirmButtonText: "Ok",
                    closeOnConfirm: false
                });
            }
        });
    };

    $scope.salvaCauzione = function (cauzione) {
        dataScadenza = getYYYYMMGGFromJsDate(cauzione.dataScadenza);

        $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
            {
                'function': 'salvaCauzione',
                'cauzione': cauzione,
                'dataScadenza': dataScadenza,
            }
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                $ngToast.create({
                    className: 'success',
                    content: 'Cauzione modificata',
                    dismissButton: true,
                    timeout: 1500
                });
            } else {
                swal({
                        title: "Errore",
                        text: "Impossibile modificare la cauzione",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });
            }
        });
    };

    $scope.cestinaCauzione = function (id) {
        swal({
                title: "Eliminare la cauzione?",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: "btn-danger",
                confirmButtonText: "Si!",
                cancelButtonText: "No!",
                closeOnConfirm: true,
                closeOnCancel: true
            },
            function (isConfirm) {
                if (isConfirm) {

                    $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
                        {
                            'function': 'cestinaCauzione',
                            'idContratto': params['id'],
                            'id': id
                        }
                    ).then(function (data, status, headers, config) {
                        if (data.data == 'ok') {
                            window.location.reload();
                        } else {
                            swal({
                                title: "Errore",
                                text: "Impossibile eliminare la cauzione",
                                type: "error",
                                showCancelButton: false,
                                confirmButtonClass: "btn-danger",
                                confirmButtonText: "Ok",
                                closeOnConfirm: false
                            });
                        }
                    });
                }
            });
    };

    /*===========================================PERCENTUALE ISTAT====================================================*/

    $scope.cambiaColonnaTabellaIstat = function (codice) {
        $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
            {'function': 'cambiaColonnaTabellaIstat', 'idContratto': params['id'], 'codice': codice}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                $ngToast.create({
                    className: 'success',
                    content: 'Percentuale di riferimento modificato',
                    dismissButton: true,
                    timeout: 1500
                });
            } else {
                swal({
                        title: "Errore",
                        text: "Impossibile modificare il mese di riferimento",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });

            }
        });
    };

    /*===========================================MESE RIFERIMENTO ISTAT===============================================*/

    $scope.cambiaMeseRiferimentoIstat = function (codice) {
        $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
            {'function': 'cambiaMeseRiferimentoIstat', 'idContratto': params['id'], 'codice': codice}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                $ngToast.create({
                    className: 'success',
                    content: 'Mese di riferimento modificato',
                    dismissButton: true,
                    timeout: 1500
                });
            } else {
                swal({
                        title: "Errore",
                        text: "Impossibile modificare il mese di riferimento",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });

            }
        });
    };

    /*===========================================MESI CONGUAGLIO ISTAT================================================*/

    $scope.cambiaMeseConguaglioIstat = function (codice) {
        $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
            {'function': 'cambiaMeseConguaglioIstat', 'idContratto': params['id'], 'codice': codice}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                $ngToast.create({
                    className: 'success',
                    content: 'Mesi di conguaglio modificato',
                    dismissButton: true,
                    timeout: 1500
                });
            } else {
                swal({
                        title: "Errore",
                        text: "Impossibile modificare i mesi di conguaglio",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });

            }
        });
    };

    /*===========================================BANCHE===============================================================*/

    $scope.cambiaBanca = function (codice) {
        $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
            {'function': 'cambiaBanca', 'idContratto': params['id'], 'codice': codice}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                $ngToast.create({
                    className: 'success',
                    content: 'Banca modificata',
                    dismissButton: true,
                    timeout: 1500
                });
            } else {
                swal({
                        title: "Errore",
                        text: "Impossibile modificare la banca",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });

            }
        });
    };

    $scope.cambiaBancaRli = function (codice) {
        $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
            {'function': 'cambiaBancaRli', 'idContratto': params['id'], 'codice': codice}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                $ngToast.create({
                    className: 'success',
                    content: 'Banca modificata',
                    dismissButton: true,
                    timeout: 1500
                });
            } else {
                swal({
                        title: "Errore",
                        text: "Impossibile modificare la banca",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });

            }
        });
    };

    /*===========================================CONTRIBUENTE=========================================================*/

    $scope.cambiaContribuente = function (codice) {
        $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
            {'function': 'cambiaContribuente', 'idContratto': params['id'], 'codice': codice}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                $ngToast.create({
                    className: 'success',
                    content: 'Contribuente modificato',
                    dismissButton: true,
                    timeout: 1500
                });
            } else {
                swal({
                        title: "Errore",
                        text: "Impossibile modificare il contribuente",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });

            }
        });
    };

    /*===========================================ASSOGGETTAZIONE======================================================*/

    $scope.cambiaAssoggettazione = function (codice) {
        $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
            {'function': 'cambiaAssoggettazione', 'idContratto': params['id'], 'codice': codice}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                $ngToast.create({
                    className: 'success',
                    content: 'Tipo assoggetazione modificata',
                    dismissButton: true,
                    timeout: 1500
                });
            } else {
                swal({
                        title: "Errore",
                        text: "Impossibile modificare il tipo assoggettazione",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });

            }
        });
    };

    /*===========================================COOBBLIGATO==========================================================*/

    $scope.cambiaCoobbligato = function (codice) {
        $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
            {'function': 'cambiaCoobbligato', 'idContratto': params['id'], 'codice': codice}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                $ngToast.create({
                    className: 'success',
                    content: 'Coobbligato modificato',
                    dismissButton: true,
                    timeout: 1500
                });
            } else {
                swal({
                        title: "Errore",
                        text: "Impossibile modificare il Coobbligato",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });

            }
        });
    };

    /*===========================================RLI==========================================================*/

    $scope.creaCodiceIdentificativo = function () {
        //Standardizzo i dati nel form
        $scope.dettagliContratto.contrattoAffitto.rli.codice_ufficio = $scope.dettagliContratto.contrattoAffitto.rli.codice_ufficio.substr(-3).toUpperCase();
        $scope.dettagliContratto.contrattoAffitto.rli.anno_stipula = ('' + ($scope.dettagliContratto.contrattoAffitto.rli.anno_stipula)).substr(-4);
        $scope.dettagliContratto.contrattoAffitto.rli.serie = $scope.dettagliContratto.contrattoAffitto.rli.serie.substr(-2);
        $scope.dettagliContratto.contrattoAffitto.rli.numero = $scope.dettagliContratto.contrattoAffitto.rli.numero.substr(-6);
        $scope.dettagliContratto.contrattoAffitto.rli.sottonumero = $scope.dettagliContratto.contrattoAffitto.rli.sottonumero.substr(-3);

        //Creo codice Identificativo
        var ufficio = $scope.dettagliContratto.contrattoAffitto.rli.codice_ufficio.substr(-3);
        var anno = $scope.dettagliContratto.contrattoAffitto.rli.anno_stipula.substr(-2);
        var serie = $scope.dettagliContratto.contrattoAffitto.rli.serie.substr(-2);
        var numero = $scope.dettagliContratto.contrattoAffitto.rli.numero.substr(-6);
        var sottonumero = $scope.dettagliContratto.contrattoAffitto.rli.sottonumero.substr(-3);

        $scope.dettagliContratto.contrattoAffitto.rli.codice_identificativo = ufficio + anno + serie + numero + sottonumero;

        return;
    };

    $scope.salvaCodiceIdentificativo = function () {
        $scope.dettagliContratto.contrattoAffitto.rli.anno_stipula = 1 * $scope.dettagliContratto.contrattoAffitto.rli.anno_stipula;
        $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
            {
                'function': 'salvaCodiceIdentificativo',
                'idContratto': params['id'],
                'rli': $scope.dettagliContratto.contrattoAffitto.rli
            }
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                $scope.disabilitaInserimentoCodiceId = true;
                $ngToast.create({
                    className: 'success',
                    content: 'Codice identificativo salvato',
                    dismissButton: true,
                    timeout: 1500
                });
            } else {
                swal({
                        title: "Errore",
                        text: "Impossibile salvare il codice",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });

            }
        });
    };


    /*===========================================INTESTATARIO FATTURA=================================================*/

    $scope.cambiaIntestatarioLocatore = function (idLocatore) {
        $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
            {'function': 'cambiaIntestatarioLocatore', 'idContratto': params['id'], 'idLocatore': idLocatore}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                $ngToast.create({
                    className: 'success',
                    content: 'Locatore predefinito modificato',
                    dismissButton: true,
                    timeout: 1500
                });
            } else {
                swal({
                        title: "Errore",
                        text: "Impossibile modificare il locatore predefinito",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });

            }
        });
    };


    $scope.cambiaIntestatarioConduttore = function (idConduttore) {
        $http.post(params['form'] + '/contratto/controller/configurazioniHandler.php',
            {'function': 'cambiaIntestatarioConduttore', 'idContratto': params['id'], 'idConduttore': idConduttore}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                $ngToast.create({
                    className: 'success',
                    content: 'Conduttore predefinito modificato',
                    dismissButton: true,
                    timeout: 1500
                });
            } else {
                swal({
                        title: "Errore",
                        text: "Impossibile modificare il conduttore predefinito",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });

            }
        });
    };


}])
;