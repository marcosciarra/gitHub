ngApp.controller("rateizzazioneContrattoController", ["$scope", "$http", "$filter", "ngToast", function ($scope, $http, $filter, $ngToast) {

    var url = window.location.href;
    var params = decodeUrl(url, ['id', 'idRata']);
    stampalog('URL');
    stampalog(params);

    $scope.init = function () {
        $scope.caricaDati();
        $scope.mostraFormNuovoDettaglio = false;
    };


    /******************
     *   CARICADATI   * ================================================================================================
     ******************/

    $scope.caricaDati = function () {
        $http.post(params['form'] + '/contratto/controller/rateizzazioneContrattoHandler.php',
            {
                'function': 'caricaDati',
                'id': params['id']
            }
        ).then(function (data, status, headers, config) {

            stampalog(data.data.status);
            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }


            stampalog('Carico Dati');
            stampalog(data.data);
            $scope.elencoRate = data.data;
            $scope.formattaImporto();
            stampalog($scope.elencoRate);

            //Tipi IVA (e presetto il 22%)
            $scope.elencoTipiIva = data.data.elencoTipiIva;

            //Tipi SPESA
            $scope.elencoTipiSpesa = data.data.elencoTipiSpesa;

            //SPESE estemporanee
            $scope.elencoCategorieSpesa = [
                {id: 'E', descrizione: 'Estemporanea'},
                {id: 'C', descrizione: 'Conguaglio spese'}
            ];

            $scope.locatori = jsonParse(data.data.anagrafica_contratto.proprietari);
            $scope.primoLocatore = $scope.locatori[0].descrizione;

            $scope.conduttori = jsonParse(data.data.anagrafica_contratto.conduttori);
            $scope.primoConduttore = $scope.conduttori[0].descrizione;

            $scope.unitaImmobiliari = data.data.anagrafica_contratto.unita_immobiliari;
            $scope.primoStabile = $scope.unitaImmobiliari[0].descrizione;

            $scope.showDettaglio = -1;
            $scope.idContratto = params['id'];
            $scope.periodo=0;
            $scope.gestione=0;
            $scope.rate=0;
            if (data.data.rata_oggi[0]) {
                $scope.periodo = data.data.rata_oggi[0].id_periodi_contrattuali;
                $scope.gestione = data.data.rata_oggi[0].id_gestione;
                $scope.rate = data.data.rata_oggi[0].id_rate;
                $scope.showDettaglio = data.data.rata_oggi[0].id_rate;
            }
            $scope.anagrafica_contratto = data.data.anagrafica_contratto;

            if (params['idRata'] != null)
                $http.post(params['form'] + '/contratto/controller/rateizzazioneContrattoHandler.php',
                    {
                        'function': 'caricaDatiRata',
                        'idRata': params['idRata']
                    }
                ).then(function (data, status, headers, config) {
                    stampalog(data.data.status);
                    if (data.data.status == 'ko') {
                        swal(data.data.error.title, data.data.error.message, 'error');
                        return;
                    }
                    stampalog(data.data);
                    $scope.modificaPeriodo(data.data.idPeriodo);
                    $scope.modificaGestione(data.data.idGestione);
                    $scope.modificaRata(params['idRata']);
                });

            $scope.caricamentoCompletato = true;

        });
    };

    $scope.caricaDettagliModale = function (elenco, etichetta) {
        $scope.elencoModale = elenco;
        $scope.etichettaModale = etichetta;
    };


    $scope.modificaPeriodo = function (id) {
        $scope.periodo = id;
        $scope.gestione = 0;
        $scope.rate = 0;
        $scope.showDettaglio = -1;
        if ($scope.strutturaDettaglio != undefined) {
            if (id != $scope.strutturaDettaglio.id_rata) {
                $scope.resetFormNuovoDettaglio();
            }
        }
    };
    $scope.modificaGestione = function (id) {
        $scope.gestione = id;
        $scope.rate = 0;
        $scope.showDettaglio = -1;
        if ($scope.strutturaDettaglio != undefined) {
            if (id != $scope.strutturaDettaglio.id_rata) {
                $scope.resetFormNuovoDettaglio();
            }
        }
    };
    $scope.modificaRata = function (id) {
        $scope.rate = id;
        $scope.showDettaglio = id;
        if ($scope.strutturaDettaglio != undefined) {
            if (id != $scope.strutturaDettaglio.id_rata) {
                $scope.resetFormNuovoDettaglio();
            }
        }
    };
    $scope.formattaImporto = function () {
        angular.forEach($scope.elencoRate.periodi_contrattuali, function (pc) {
            angular.forEach(pc.gestione, function (g) {
                angular.forEach(g.rate, function (r) {
                    angular.forEach(r.dettagli, function (d) {
                        d.importo = parseFloat(d.importo);
                    });
                });
            });
        });
    };

    $scope.stampaTipoIva = function (id) {
        return $filter('filter')($scope.elencoTipiIva, {id: id})[0].aliquota;
    };
    $scope.stampaTipoSpesa = function (id) {
        return $filter('filter')($scope.elencoTipiSpesa, {id: id})[0].descrizione;
    };

    /***********************
     *   NUOVO DETTAGLIO   * ================================================================================================
     ***********************/

    $scope.nuovoDettaglio = function (d) {
        //stampalog(d);
        $scope.mostraFormNuovoDettaglio = true;
        if($scope.conduttori.length>1) {
            $scope.strutturaDettaglio = {
                'tipo_spesa': 'E',
                'descrizione': '',
                'id_tipo_iva': 1,
                'importo': '',
                'id_rata': d.id_rata,
                'id_piano_rate': d.id_piano_rate,
                'id_categoria_spesa': 'E',
                'id_conduttore_associato': $scope.conduttori[0].id
            }
        }
        else{
            $scope.strutturaDettaglio = {
                'tipo_spesa': 'E',
                'descrizione': '',
                'id_tipo_iva': 1,
                'importo': '',
                'id_rata': d.id_rata,
                'id_piano_rate': d.id_piano_rate,
                'id_categoria_spesa': 'E',
                'id_conduttore_associato': null
            }
        }
    };

    /****************************
     *   CONTROLLA SP.ESTEMP.   * ================================================================================================
     ****************************/

    $scope.controllaTipoIvaEstemporanea = function () {
        if ($scope.strutturaDettaglio.id_categoria_spesa == 'C') {
            $scope.disabilitaTipoIvaSpesaEstemporanea = true;
            $scope.strutturaDettaglio.id_tipo_iva = 2;
            $scope.strutturaDettaglio.tipo_spesa = 'O';
        } else {
            $scope.disabilitaTipoIvaSpesaEstemporanea = false;
            $scope.strutturaDettaglio.tipo_spesa = 'E';
        }
    }

    /*****************************
     *   SALVA NUOVO DETTAGLIO   * ================================================================================================
     ****************************/

    $scope.salvaNuovoDettaglio = function () {
        $http.post(params['form'] + '/contratto/controller/rateizzazioneContrattoHandler.php',
            {'function': 'salvaDettaglio', 'object': $scope.strutturaDettaglio}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                window.location.reload();
            }
        });
    };

    /**********************
     *   EDIT DETTAGLIO   * ================================================================================================
     *********************/

    $scope.modificaDettaglio = function (dettaglio) {
        $http.post(params['form'] + '/contratto/controller/rateizzazioneContrattoHandler.php',
            {'function': 'salvaDettaglio', 'object': dettaglio}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                window.location.reload();
            } else {
                // TODO ?
                stampalog('TODO');
            }
        });
    };

    $scope.resetFormNuovoDettaglio = function () {
        $scope.mostraFormNuovoDettaglio = false;
    };

    /**********************
     *   CANCELLA DETTAGLIO   * ========================================================================================
     *********************/

    $scope.eliminaDettaglio = function (id) {
        swal({
                title: "",
                text: "Confermare la cancellazione",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: "btn-danger",
                confirmButtonText: "Si",
                cancelButtonText: "No",
                closeOnConfirm: false
            },
            function () {
                $http.post(params['form'] + '/contratto/controller/rateizzazioneContrattoHandler.php',
                    {'function': 'eliminaDettaglio', 'id': id}
                ).then(function (data, status, headers, config) {
                    if (data.data == 'ok') {
                        window.location.reload();
                    } else {
                        alert('Eliminazione bloccata');
                    }
                });
            });
    };

    /**************************
     *   LORDO / IMPONIBILE   * ========================================================================================
     **************************/

    $scope.formattaImporto = function () {
        angular.forEach($scope.elencoRate.periodi_contrattuali, function (pc) {
            angular.forEach(pc.gestione, function (g) {
                angular.forEach(g.rate, function (r) {
                    angular.forEach(r.dettagli, function (d) {
                        d.importo = parseFloat(d.importo);
                    });
                });
            });
        });
    };

    $scope.calcolaLordo = function (imponibile, idTipoIva, idDettaglioRata) {
        var aliquota = $filter('filter')($scope.elencoTipiIva, {id: idTipoIva})[0].aliquota;
        if (idDettaglioRata == 0) {
            $scope.strutturaDettaglio.importo = Math.round(imponibile * (1 + (aliquota / 100)) * 100) / 100;
        } else {
            angular.forEach($scope.elencoRate.periodi_contrattuali, function (pc) {
                angular.forEach(pc.gestione, function (g) {
                    angular.forEach(g.rate, function (r) {
                        angular.forEach(r.dettagli, function (d) {
                            if (d.id == idDettaglioRata) {
                                d.importo = Math.round(imponibile * (1 + (aliquota / 100)) * 100) / 100;
                            }
                        });
                    });
                });
            });
        }
    };

    $scope.calcolaImponibile = function (importo, idTipoIva, idDettaglioRata) {
        var aliquota = $filter('filter')($scope.elencoTipiIva, {id: idTipoIva})[0].aliquota;
        if (idDettaglioRata == 0) {
            $scope.strutturaDettaglio.imponibile = Math.round(importo / (1 + (aliquota / 100)) * 100) / 100;
        } else {
            angular.forEach($scope.elencoRate.periodi_contrattuali, function (pc) {
                angular.forEach(pc.gestione, function (g) {
                    angular.forEach(g.rate, function (r) {
                        angular.forEach(r.dettagli, function (d) {
                            if (d.id == idDettaglioRata) {
                                d.imponibile = Math.round(importo / (1 + (aliquota / 100)) * 100) / 100;
                            }
                        });
                    });
                });
            });
        }
    };

    /***********************
     * BLOCCA-SBLOCCA RATA * ========================================================================================
     ***********************/

    $scope.bloccaSblocca = function (id, idFattura, stato) {
        if (idFattura == false) {
            $http.post(params['form'] + '/contratto/controller/rateizzazioneContrattoHandler.php',
                {'function': 'bloccaSbloccaRata', 'id': id, 'stato': stato}
            ).then(function (data, status, headers, config) {
                if (data.data == 'ok') {
                    if (stato == 1) {
                        $ngToast.create({
                            className: 'danger',
                            content: 'Rata bloccata',
                            dismissButton: true,
                            timeout: 1500
                        });
                    } else if (stato == 0) {
                        $ngToast.create({
                            className: 'success',
                            content: 'Rata sbloccata',
                            dismissButton: true,
                            timeout: 1500
                        });
                    }
                } else {
                    swal({
                            title: "Errore",
                            text: "Impossibile modificare lo stato della rata",
                            type: "error",
                            showCancelButton: false,
                            confirmButtonClass: "btn-danger",
                            confirmButtonText: "Ok",
                            closeOnConfirm: false
                        },
                        function () {
                            window.location.reload();
                        });

                }
            });
        }
        else {
            swal({
                    title: "Sbloccare rata?",
                    text: "In caso di conferma verrà eliminato il documento associato.",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonClass: "btn-danger",
                    confirmButtonText: "Si",
                    cancelButtonText: "No",
                    closeOnConfirm: false,
                    closeOnCancel: true
                },
                function (isConfirm) {
                    if (isConfirm) {
                        $http.post(params['form'] + '/contratto/controller/rateizzazioneContrattoHandler.php',
                            {'function': 'sbloccaEliminaRata', 'id': id, 'idFattura': idFattura}
                        ).then(function (data, status, headers, config) {
                            if (data.data == 'ok') {
                                swal({title: "Rata sbloccata!", text: "", type: "success"},
                                    function () {
                                        window.location.reload();
                                    }
                                );
                            } else {
                                swal({
                                        title: "Errore",
                                        text: "Impossibile modificare lo stato della rata",
                                        type: "error",
                                        showCancelButton: false,
                                        confirmButtonClass: "btn-danger",
                                        confirmButtonText: "Ok",
                                        closeOnConfirm: false
                                    },
                                    function () {
                                        window.location.reload();
                                    });

                            }
                        });
                    }
                });
        }
    };

    /**********************
     *   STAMPA FATTURA   * ========================================================================================
     *********************/
    $scope.stampaFattura = function (id) {
        window.open(params['baseurl'] + '/stampe/avvisiPagamento/avvisoPagamentoPdf.php?idFattura=' + id);
    };

    /* ========================================= GESTIONE CONTRATTO ================================================= */

    $scope.gestioneContratto = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "gestioneContratto", id);
    };

}]);

/******************
 *   FILTRI   * ================================================================================================
 ******************/

ngApp.filter('formatDate', function () {
    return function (date) {
        return date.substring(8, 10) + '/' + date.substring(5, 7) + '/' + date.substring(0, 4);
        ;
    };
});