ngApp.controller("scadenzeController", ["$scope", "$http", "$filter", function ($scope, $http, $filter) {

    var url = window.location.href;
    var params = decodeUrl(url, 'id');
    stampalog('URL');
    stampalog(params);

    $scope.init = function () {
        $scope.caricaDati();
    };


    /******************
     *   CARICADATI   * ================================================================================================
     ******************/

    $scope.caricaDati = function () {
        $http.post(params['form'] + '/contratto/controller/scadenzeHandler.php',
            {
                'function': 'caricaDati',
                'id': params['id']
            }
        ).then(function (data, status, headers, config) {

            stampalog(data.data.status);
            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }

            stampalog('Carico Dati');
            stampalog(data.data);
            $scope.elencoRate = data.data;
            $scope.formattaDate();
            stampalog($scope.elencoRate);

            //Tipi IVA (e presetto il 22%)
            $scope.elencoTipiIva = data.data.elencoTipiIva;

            //Tipi SPESA
            $scope.elencoTipiSpesa = data.data.elencoTipiSpesa;

            $scope.locatori = jsonParse(data.data.anagrafica_contratto.proprietari);
            $scope.primoLocatore = $scope.locatori[0].descrizione;

            $scope.conduttori = jsonParse(data.data.anagrafica_contratto.conduttori);
            $scope.primoConduttore = $scope.conduttori[0].descrizione;

            $scope.unitaImmobiliari = data.data.anagrafica_contratto.unita_immobiliari;
            $scope.primoStabile = $scope.unitaImmobiliari[0].descrizione;

            $scope.showDettaglio = -1;
            $scope.idContratto = params['id'];
            $scope.periodo=0;
            $scope.gestione=0;
            $scope.rate=0;
            if (data.data.rata_oggi[0]) {
                $scope.periodo = data.data.rata_oggi[0].id_periodi_contrattuali;
                $scope.gestione = data.data.rata_oggi[0].id_gestione;
                $scope.rate = data.data.rata_oggi[0].id_rate;
                $scope.showDettaglio = data.data.rata_oggi[0].id_rate;
            }

            $scope.nuovaScadenza = data.data.nuovaScadenza;
            $scope.nuovaScadenza.idGestione = $scope.gestione;

            $scope.caricamentoCompletato = true;

        });
    };

    $scope.caricaDettagliModale = function (elenco, etichetta) {
        $scope.elencoModale = elenco;
        $scope.etichettaModale = etichetta;
    };


    $scope.modificaPeriodo = function (id) {
        $scope.periodo = id;
        $scope.gestione = 0;
        $scope.rate = 0;
        $scope.showDettaglio = -1;
        if ($scope.strutturaDettaglio != undefined) {
            if (id != $scope.strutturaDettaglio.id_rata) {
                $scope.resetFormNuovoDettaglio();
            }
        }
    };
    $scope.modificaGestione = function (id) {
        $scope.gestione = id;
        $scope.rate = 0;
        $scope.showDettaglio = -1;
        if ($scope.strutturaDettaglio != undefined) {
            if (id != $scope.strutturaDettaglio.id_rata) {
                $scope.resetFormNuovoDettaglio();
            }
        }
        $scope.nuovaScadenza.idGestione = id;
    };
    $scope.modificaRata = function (id) {
        $scope.rate = id;
        $scope.showDettaglio = id;
        if ($scope.strutturaDettaglio != undefined) {
            if (id != $scope.strutturaDettaglio.id_rata) {
                $scope.resetFormNuovoDettaglio();
            }
        }
    };
    $scope.formattaDate = function () {
        angular.forEach($scope.elencoRate.periodi_contrattuali, function (pc) {
            angular.forEach(pc.gestione, function (g) {
                angular.forEach(g.rate, function (r) {
                    /*
                    angular.forEach(r.dettagli, function (d) {
                        d.importo = parseFloat(d.importo);
                    });
                    */
                    r.data_scadenza = new Date(r.data_scadenza);
                    r.periodo_inizio = new Date(r.periodo_inizio);
                    r.periodo_fine = new Date(r.periodo_fine);
                });
            });
        });
    };

    $scope.stampaTipoIva = function (id) {
        return $filter('filter')($scope.elencoTipiIva, {id: id})[0].aliquota;
    };
    $scope.stampaTipoSpesa = function (id) {
        return $filter('filter')($scope.elencoTipiSpesa, {id: id})[0].descrizione;
    };

    /******************
     *   SALVA RATA   * ================================================================================================
     ******************/

    $scope.controllaCampiScadenza = function (scadenza, gestione) {
        var periodo_inizio = getYYYYMMGGFromJsDate(scadenza.periodo_inizio);
        var periodo_fine = getYYYYMMGGFromJsDate(scadenza.periodo_fine);
        var data_scadenza = getYYYYMMGGFromJsDate(scadenza.data_scadenza);

        if (!isValidDate(periodo_inizio) || !isValidDate(periodo_fine) || !isValidDate(data_scadenza)) {
            $scope.datiCorrettiScadenza = false;
            return;
        }

        if (
            periodo_inizio >= gestione.data_inizio &&
            periodo_fine <= gestione.data_fine &&
            periodo_inizio < periodo_fine &&
            data_scadenza &&
            scadenza.descrizione.length > 0
        ) {
            $scope.datiCorrettiScadenza = true;
            return;
        } else {
            $scope.datiCorrettiScadenza = false;
            return;
        }
    };

    $scope.salvaRata = function (rata) {
        /*
        var datiCorretti = true;
        angular.forEach($scope.elencoRate.periodi_contrattuali, function (pc) {
            angular.forEach(pc.gestione, function (g) {
                var inizioGestione = getYYYYMMGGFromJsDate(new Date(g.data_inizio));
                var fineGestione = getYYYYMMGGFromJsDate(new Date(g.data_fine));
                angular.forEach(g.rate, function (r) {
                    if(r.id == rata.id) {
                        var inizioRata = getYYYYMMGGFromJsDate(new Date(r.periodo_inizio));
                        var fineRata = getYYYYMMGGFromJsDate(new Date(r.periodo_fine));
                        var scadenzaRata = getYYYYMMGGFromJsDate(new Date(r.data_scadenza));
                        if (
                            !isValidDate(scadenzaRata) || scadenzaRata == null ||
                            !isValidDate(inizioRata) || inizioRata == null ||
                            !isValidDate(fineRata) || fineRata == null
                        ) {
                            datiCorretti = false;
                            swal("Errore", "Controllare le date", "error");
                            return;
                        }
                        if(inizioRata < inizioGestione || fineRata > fineGestione || inizioRata > fineRata){
                            datiCorretti = false;
                            swal("Errore", "Errore nella selezione delle date", "error");
                            return;
                        }
                        if(r.descrizione.length <= 0){
                            datiCorretti = false;
                            swal("Errore", "Inserire una descrizione", "error");
                            return;
                        }
                    }
                });
            });
        });
        */
        //if(datiCorretti){
        rata.periodo_inizio = getYYYYMMGGFromJsDate(rata.periodo_inizio);
        rata.periodo_fine = getYYYYMMGGFromJsDate(rata.periodo_fine);
        rata.data_scadenza = getYYYYMMGGFromJsDate(rata.data_scadenza);
        //var inizioRata = getYYYYMMGGFromJsDate(new Date(r.periodo_inizio));
        //var fineRata = getYYYYMMGGFromJsDate(new Date(r.periodo_fine));
        //var scadenzaRata = getYYYYMMGGFromJsDate(new Date(r.data_scadenza));

        $http.post(params['form'] + '/contratto/controller/scadenzeHandler.php',
            {
                'function': 'salvaRata',
                'obj': rata
            }
        ).then(function (data, status, headers, config) {
            if (data.data.status == "ko") {
                swal("Errore", "Salvataggio non riuscito", "error");
            } else {
                swal({
                    title: "Salvataggio eseguito",
                    text: '',
                    type: "success"
                }, function () {
                    location.reload();
                });
            }
        });
        //}
    };

    /*************************
     *   CANCELLA SCADENZA   * ========================================================================================
     *************************/

    $scope.eliminaRata = function (scadenza) {
        swal({
                title: "",
                text: "Confermare la cancellazione",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: "btn-danger",
                confirmButtonText: "Si",
                cancelButtonText: "No",
                closeOnConfirm: false
            },
            function () {
                if (scadenza.dettagli.length > 0) {
                    swal({
                        title: "Impossibile procedere",
                        text: "Risultano delle spese associate a questa scadenza",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-success",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    });
                } else {
                    $http.post(params['form'] + '/contratto/controller/scadenzeHandler.php',
                        {'function': 'eliminaRata', 'id': scadenza.id}
                    ).then(function (data, status, headers, config) {
                        if (data.data == "ko") {
                            swal("Errore", "Eliminazione non riuscita", "error");
                        } else {
                            swal({
                                title: "Scadenza eliminata con successo",
                                text: '',
                                type: "success"
                            }, function () {
                                location.reload();
                            });
                        }
                    });
                }
            });
    };

    $scope.resetFormNuovoDettaglio = function () {
        $scope.mostraFormNuovoDettaglio = false;
    };

    /* ========================================= GESTIONE CONTRATTO ================================================= */

    $scope.gestioneContratto = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "gestioneContratto", id);
    };

}]);

/******************
 *   FILTRI   * ================================================================================================
 ******************/

ngApp.filter('formatDate', function () {
    return function (date) {
        return date.substring(8, 10) + '/' + date.substring(5, 7) + '/' + date.substring(0, 4);
        ;
    };
});