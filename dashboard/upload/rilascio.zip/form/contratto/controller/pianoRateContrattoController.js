ngApp.controller("pianoRateContrattoController", ["$scope", "$http", "$filter", function ($scope, $http, $filter) {

    var url = window.location.href;
    var params = decodeUrl(url, 'id');
    stampalog('URL');
    stampalog(params);

    $scope.init = function () {
        $scope.caricaDati();
        $scope.mostraFormNuovoDettaglio = false;
    };


    /******************
     *   CARICADATI   * ================================================================================================
     ******************/

    $scope.caricaDati = function () {
        $http.post(params['form'] + '/contratto/controller/pianoRateContrattoHandler.php',
            {
                'function': 'caricaDati',
                'id': params['id']
            }
        ).then(function (data, status, headers, config) {

            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }

            stampalog('Carico Dati');
            stampalog(data.data);
            $scope.pianoRate = data.data;
            $scope.emptyRate = data.data.emptyRate;
            $scope.pianoRateOld = angular.copy(data.data.periodi_contrattuali);
            $scope.pianoRateD = data.data.pianoRateD;
            $scope.pianoRateD.rate = [];
            $scope.pianoRateD.cestino = 0;
            $scope.pianoRateD.percentuale = 0;
            $scope.elencoTipiSpesa = data.data.canoni_oneri;
            $scope.elencoCanoniOneri = data.data.canoni_oneri_descrizioni;

            //Formatto le date
            for (var $i = 0; $i < $scope.pianoRate.periodi_contrattuali.length; $i++) {
                for (var $j = 0; $j < $scope.pianoRate.periodi_contrattuali[$i].gestione.length; $j++) {
                    for (var $k = 0; $k < $scope.pianoRate.periodi_contrattuali[$i].gestione[$j].pianoRateT.length; $k++) {
                        for (var $m = 0; $m < $scope.pianoRate.periodi_contrattuali[$i].gestione[$j].pianoRateT[$k].pianoRateD.length; $m++) {
                            $scope.pianoRate.periodi_contrattuali[$i].gestione[$j].pianoRateT[$k].pianoRateD[$m].data_scadenza =
                                new Date($scope.pianoRate.periodi_contrattuali[$i].gestione[$j].pianoRateT[$k].pianoRateD[$m].data_scadenza);
                            $scope.pianoRate.periodi_contrattuali[$i].gestione[$j].pianoRateT[$k].pianoRateD[$m].cestino = 0;
                            $scope.pianoRate.periodi_contrattuali[$i].gestione[$j].pianoRateT[$k].pianoRateD[$m].percentuale =
                                1 * $scope.pianoRate.periodi_contrattuali[$i].gestione[$j].pianoRateT[$k].pianoRateD[$m].percentuale;
                            $scope.pianoRate.periodi_contrattuali[$i].gestione[$j].pianoRateT[$k].pianoRateD[$m].listaRate = [];
                        }
                    }
                }
            }

            $scope.locatori = jsonParse(data.data.anagrafica_contratto.proprietari);
            $scope.primoLocatore = $scope.locatori[0].descrizione;

            $scope.conduttori = jsonParse(data.data.anagrafica_contratto.conduttori);
            $scope.primoConduttore = $scope.conduttori[0].descrizione;

            $scope.unitaImmobiliari = data.data.anagrafica_contratto.unita_immobiliari;
            $scope.primoStabile = $scope.unitaImmobiliari[0].descrizione;

            $scope.showDettaglio = -1;
            $scope.idContratto = params['id'];
            $scope.periodo = data.data.gestione_oggi[0].id_periodi_contrattuali;
            $scope.gestione = data.data.gestione_oggi[0].id_gestione;

            $scope.caricaElencoRate();

            $scope.caricaScadenzeGestione($scope.gestione);
            $scope.caricamentoCompletato = true;
        });
    };


    $scope.caricaElencoRate = function () {
        $http.post(params['form'] + '/contratto/controller/pianoRateContrattoHandler.php',
            {
                'function': 'caricaElencoRate',
                'idContratto': params['id']
            }
        ).then(function (data, status, headers, config) {
            for (var $i = 0; $i < $scope.pianoRate.periodi_contrattuali.length; $i++) {
                for (var $j = 0; $j < $scope.pianoRate.periodi_contrattuali[$i].gestione.length; $j++) {
                    for (var $k = 0; $k < $scope.pianoRate.periodi_contrattuali[$i].gestione[$j].pianoRateT.length; $k++) {
                        for (var $m = 0; $m < $scope.pianoRate.periodi_contrattuali[$i].gestione[$j].pianoRateT[$k].pianoRateD.length; $m++) {
                            $scope.pianoRate.periodi_contrattuali[$i].gestione[$j].pianoRateT[$k].pianoRateD[$m].listaRate=[];
                            for (var $n = 0; $n < data.data.listaRate.length; $n++) {
                                if (data.data.listaRate[$n].id_gestione == $scope.pianoRate.periodi_contrattuali[$i].gestione[$j].pianoRateT[$k].id_gestione)
                                    $scope.pianoRate.periodi_contrattuali[$i].gestione[$j].pianoRateT[$k].pianoRateD[$m].listaRate.push(data.data.listaRate[$n]);
                            }
                        }
                    }
                }
            }
        });
    };


    $scope.caricaDettagliModale = function (elenco, etichetta) {
        $scope.elencoModale = elenco;
        $scope.etichettaModale = etichetta;
    };


    $scope.modificaPeriodo = function (id) {
        $scope.resetFormNuovoDettaglio();
        $scope.periodo = id;
        $scope.gestione = 0;
        $scope.rate = 0;
        $scope.showDettaglio = -1;
    };
    $scope.modificaGestione = function (id) {
        $scope.resetFormNuovoDettaglio();
        $scope.gestione = id;
        $scope.rate = 0;
        $scope.showDettaglio = -1;
    };
    $scope.modificaRata = function (id) {
        $scope.resetFormNuovoDettaglio();
        $scope.rate = id;
        $scope.showDettaglio = id;
        $scope.controllaPercentualeRate(id);
        $scope.caricaScadenze(id);
    };

    $scope.stampaTipoIva = function (id) {
        return $filter('filter')($scope.elencoTipiIva, {id: id})[0].aliquota;
    };
    $scope.stampaTipoSpesa = function (id) {
        return $filter('filter')($scope.elencoTipiSpesa, {id: id})[0].descrizione;
    };
    $scope.stampaDescrizione = function (id) {
        return $filter('filter')($scope.elencoTipiSpesa, {id: id})[0].descrizione;
    };

    $scope.controllaPercentualeRate = function (idPianoRateTesta) {
        var percentuale = 0;
        angular.forEach($scope.pianoRate.periodi_contrattuali, function (pc) {
            angular.forEach(pc.gestione, function (g) {
                angular.forEach(g.pianoRateT, function (r) {
                    if (r.id == idPianoRateTesta) {
                        angular.forEach(r.pianoRateD, function (d) {
                            percentuale = percentuale + (10000 * d.percentuale);
                        });
                        $scope.percentualeSomma = percentuale/10000;
                        if (percentuale == 100) {
                            $scope.percentuale100 = true;
                        } else {
                            $scope.percentuale100 = false;
                        }
                        return;
                    }
                });

            });
        });
    };


    $scope.caricaScadenze = function (idPianoRateTesta) {
        $scope.rateNuove = [];
        angular.forEach($scope.pianoRate.periodi_contrattuali, function (pc) {
            angular.forEach(pc.gestione, function (g) {
                angular.forEach(g.pianoRateT, function (r) {
                    if (r.id == idPianoRateTesta) {
                        if (r.pianoRateD[0] != undefined) {
                            $scope.rateNuove.push(r.pianoRateD[0].listaRate);
                        }
                        else {
                            $scope.caricaScadenzeGestione(g.id);
                        }
                        return;
                    }
                });

            });
        });
    };

    /*===================================================AGGIORNA RATEIZZAZIONE=======================================*/
    $scope.aggiornaRateizzazione = function (idPianoRateTesta, ricorsivo) {
        for (var i = 0; i < $scope.pianoRate.periodi_contrattuali.length; i++) {
            for (var j = 0; j < $scope.pianoRate.periodi_contrattuali[i].gestione.length; j++) {
                for (var k = 0; k < $scope.pianoRate.periodi_contrattuali[i].gestione[j].pianoRateT.length; k++) {
                    if ($scope.pianoRate.periodi_contrattuali[i].gestione[j].pianoRateT[k].id == idPianoRateTesta) {
                        $scope.caricamentoCompletato = false;

                        stampalog('Dati vecchi');
                        stampalog($scope.pianoRateOld[i].gestione[j].pianoRateT[k].pianoRateD);
                        stampalog('Dati nuovi');
                        stampalog($scope.pianoRate.periodi_contrattuali[i].gestione[j].pianoRateT[k].pianoRateD);


                        $http.post(params['form'] + '/contratto/controller/pianoRateContrattoHandler.php',
                            {
                                'function': 'modificaPianoSpese',
                                'idContratto': params['id'],
                                'idCanoneOnere': $scope.pianoRate.periodi_contrattuali[i].gestione[j].pianoRateT[k].id_canoni_oneri,
                                'newPianoRate': $scope.pianoRate.periodi_contrattuali[i].gestione[j].pianoRateT[k].pianoRateD,
                                'oldPianoRate': $scope.pianoRateOld[i].gestione[j].pianoRateT[k].pianoRateD
                            }
                        ).then(function (data, status, headers, config) {
                            if (data.data == 'ok') {
                                swal({
                                        title: "Piano rate aggiornato",
                                        text: "",
                                        type: "success",
                                        showCancelButton: false,
                                        confirmButtonClass: "btn-success",
                                        confirmButtonText: "Ok",
                                        closeOnConfirm: false
                                    },
                                    function () {
                                        window.location.href = $scope.params['home'] + encodeUrl("contratto", "pianoRateContratto", params['id']);
                                    });
                            }
                            else {
                                swal(data.data.error.title, data.data.error.message, 'error');
                                return;
                            }
                        });
                    }
                }
            }
        }
    };


    $scope.caricaScadenzeGestione = function (idGestione) {
        $scope.elencoRate = [];
        $http.post(params['form'] + '/contratto/controller/pianoRateContrattoHandler.php',
            {'function': 'caricaScadenzeGestione', 'idGestione': idGestione}
        ).then(function (data, status, headers, config) {
            $scope.elencoRate = data.data;
        });
    };


    /***********************
     *   NUOVO DETTAGLIO   * ================================================================================================
     ***********************/
    $scope.nuovoDettaglio = function (idPianoRateT) {
        for (var $i = 0; $i < $scope.pianoRate.periodi_contrattuali.length; $i++) {
            for (var $j = 0; $j < $scope.pianoRate.periodi_contrattuali[$i].gestione.length; $j++) {
                for (var $k = 0; $k < $scope.pianoRate.periodi_contrattuali[$i].gestione[$j].pianoRateT.length; $k++) {
                    if ($scope.pianoRate.periodi_contrattuali[$i].gestione[$j].pianoRateT[$k].id == idPianoRateT) {
                        var app = angular.copy($scope.pianoRateD);
                        app.id_piano_rate_testata = idPianoRateT;
                        app.listaRate = angular.copy($scope.elencoRate.rate);
                        app.rate[0] = angular.copy($scope.emptyRate);
                        app.id_tipo_iva = $scope.pianoRate.periodi_contrattuali[$i].gestione[$j].pianoRateT[$k].id_tipo_iva;
                        $scope.pianoRate.periodi_contrattuali[$i].gestione[$j].pianoRateT[$k].pianoRateD.push(app);
                    }
                }
            }
        }
    };


    $scope.resetFormNuovoDettaglio = function () {
        $scope.mostraFormNuovoDettaglio = false;
    };

    /**********************
     *   CANCELLA DETTAGLIO   * ========================================================================================
     *********************/

    $scope.eliminaDettaglio = function (indice) {
        angular.forEach($scope.pianoRate.periodi_contrattuali, function (pc) {
            angular.forEach(pc.gestione, function (g) {
                angular.forEach(g.pianoRateT, function (r) {
                    angular.forEach(r.pianoRateD, function (d, index) {
                        if (index == indice) {
                            d.cestino = 1;
                            return;
                        }
                    });

                });
            });
        });
    };

    /* ========================================= GESTIONE CONTRATTO ================================================= */

    $scope.gestioneContratto = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "gestioneContratto", id);
    };

}]);

/******************
 *   FILTRI   * ================================================================================================
 ******************/

ngApp.filter('formatDate', function () {
    return function (date) {
        return date.substring(8, 10) + '/' + date.substring(5, 7) + '/' + date.substring(0, 4);
        ;
    };
});