<?php

require_once '../../../conf/conf.php';
require_once '../../../src/function/functionLogin.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';
require_once '../../../src/model/DrakkarTraceLog.php';
require_once '../../../src/model/DrakkarJsonException.php';

require_once '../../../src/function/functionDate.php';

require_once '../../../src/model/Anagrafiche.php';
require_once '../../../src/model/UnitaImmobiliari.php';
require_once '../../../src/model/UnitaImmobiliariContratti.php';
require_once '../../../src/model/ContrattoAffitto.php';
require_once '../../../src/model/CanoniOneri.php';
require_once '../../../src/model/TipiCauzione.php';
require_once '../../../src/model/Cauzioni.php';
require_once '../../../src/model/TipiIva.php';
require_once '../../../src/model/GruppiFatturazione.php';
require_once '../../../src/model/Rli.php';
require_once '../../../src/model/CodiceCoobbligato.php';
require_once '../../../src/model/TipoContrattoRli.php';
require_once '../../../src/model/ElaboraContratto.php';
require_once '../../../src/model/ContiCorrenti.php';
require_once '../../../src/model/Login.php';
require_once '../../../src/model/Contratti.php';
require_once '../../../src/model/Opzioni.php';


use Click\Affitti\TblBase\Anagrafiche;
use Click\Affitti\TblBase\UnitaImmobiliari;
use Click\Affitti\TblBase\UnitaImmobiliariContratti;
use Click\Affitti\Viste\ContrattoAffitto;
use Click\Affitti\TblBase\Contratti;
use Click\Affitti\TblBase\CanoniOneri;
use Click\Affitti\TblBase\TipiCauzione;
use Click\Affitti\TblBase\Cauzioni;
use Click\Affitti\TblBase\TipiIva;
use Click\Affitti\TblBase\GruppiFatturazione;
use Click\Affitti\TblBase\Rli;
use Click\Affitti\TblBase\CodiceCoobbligato;
use Click\Affitti\TblBase\TipoContrattoRli;
use Click\Affitti\Viste\ElaboraContratto;
use Click\Affitti\TblBase\ContiCorrenti;
use Click\Affitti\TblBase\Login;
use Click\Affitti\TblBase\Opzioni;


function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        $contrattoAffitto = new ContrattoAffitto($con);
        $anagrafica = new Anagrafiche($con);
        $agenziaImmobiliare = new Anagrafiche($con);
        $unitaImmobiliari = new UnitaImmobiliari($con);
        $unitaImmobiliariContratti = new UnitaImmobiliariContratti($con);
        $canoneOneri = new CanoniOneri($con);
        $cauzioni = new Cauzioni($con);
        $tipiCauzione = new TipiCauzione($con);
        $tipiIva = new TipiIva($con);
        $gruppiFat = new GruppiFatturazione($con);
        $rli = new Rli($con);
        $utenti = new Login($con);

        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
        $codiceCoobbligato = new CodiceCoobbligato($conExt);
        $tipoContrattoRli = new TipoContrattoRli($conExt);

        $result['utenteLoggato'] = getLoginDataFromSession('id');

        // CARICO SELECT
        $result['elencoTipiContratto'] = $contrattoAffitto->getTipoContratto()->findAllConDescrizione(ContrattoAffitto::FETCH_KEYARRAY);
        $anagrafica->setOrderBase(' descrizione ASC ');
        $result['elencoAnagrafica'] = $anagrafica->findAllPerSelect(Anagrafiche::FETCH_KEYARRAY);
        $result['elencoAgenziaImmobiliare'] = $agenziaImmobiliare->findAllAgenziaImmobiliare(Anagrafiche::FETCH_KEYARRAY);
        $result['elencoUnitaImmobiliari'] = [];
        $unitaImmobiliari->setWhereBase(' cestino=0 ');
        $result['elencoUnitaImmobiliariElenco'] = $unitaImmobiliari->findAllPerSelect(UnitaImmobiliari::FETCH_KEYARRAY);
        $result['elencoTipiSpesa'] = $contrattoAffitto->getElencoTipoSpesa(true);
        $result['elencoTipiSaldo'] = $contrattoAffitto->getElencoTipoSaldo(true);
        $result['elencoTipiCauzione'] = $tipiCauzione->findAll(false, TipiCauzione::FETCH_KEYARRAY);
        $result['elencoTipiIva'] = $tipiIva->findAll(false, TipiIva::FETCH_KEYARRAY);
        $result['gruppiFat'] = $gruppiFat->findElencoUltimiGruppi(false, GruppiFatturazione::FETCH_KEYARRAY);
        $result['elencoTipiCedolareSecca'] = $rli->getCedolareSeccaValuesList(true);
        $result['elencoCoobbligati'] = $codiceCoobbligato->findAll(false, CodiceCoobbligato::FETCH_KEYARRAY);
        $result['elencoTipoImposte'] = $tipoContrattoRli->findAll(false, CodiceCoobbligato::FETCH_KEYARRAY);
        $utenti->setWhereBase(" tipo_utente='A' OR tipo_utente='U' AND bloccato=0");
        $result['elencoUtenti'] = $utenti->findAll(true, Login::FETCH_KEYARRAY);

        //PRESET
        $result['tipoContrattoSelezionato'] = $result['elencoTipiContratto'];
        $result['tipiCauzioneSelezionato'] = $result['elencoTipiCauzione'];

        //CREO RECORD SPESA VUOTO
        $result['spesa'] = $canoneOneri->getEmptyDbKeyArray();
        //CREO RECORD CAUZIONE VUOTA$result['status'] = 'ko';
        $result['cauzioni'] = $cauzioni->getEmptyDbKeyArray();
        //CREO RECORD UNITA' IMMOBILIARE CONTRATTI VUOTA
        $result['unitaImmobiliariContratti'] = $unitaImmobiliariContratti->getEmptyDbKeyArray();


        for ($i = 0; $i < count($result['elencoUnitaImmobiliari']); $i++) {
            $result['elencoUnitaImmobiliari'][$i]['descrizione'] =
                $result['elencoUnitaImmobiliari'][$i]['descrizione'] . ' (' .
                json_decode($result['elencoUnitaImmobiliari'][$i]['indirizzo'])->indirizzo . ' ' .
                json_decode($result['elencoUnitaImmobiliari'][$i]['indirizzo'])->civico .
                ')';
        }

        // CARICO DATI CONTRATTO
        if (isset($request->id)) {
            $result['contrattoAffitto'] = $contrattoAffitto->findByPk($request->id, ContrattoAffitto::FETCH_KEYARRAY);
        } else {
            $result['contrattoAffitto'] = $contrattoAffitto->getEmptyObjKeyArray();

            $opz = new Opzioni($con);
            $opz->findByPk(Opzioni::IMPOSTA_REGISTRO_TIPO_RICHIESTA_DEFAULT);
            if ($opz->getValore() == 0) {
                $result['contrattoAffitto']['contrattiPreferenze']['imposta_registro_tipo_richiesta'] = "A";
            }

        }

        $result['status'] = 'ok';
        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }

}


function salvaDati($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();


        $con->beginTransaction();

        //----------------------------
        //CREO DESCRIZIONE CONTRATTO
        //----------------------------
        $tipoContratto = new \Click\Affitti\TblBase\TipoContratto($con);
        /** @var \Click\Affitti\TblBase\TipoContratto $tipoContratto */
        $tipoContratto->findByPk($request->contratto->contratto->id_tipo_contratto);
        $descrizoneContratto = $tipoContratto->getDescrizione();
        $request->contratto->contratto->descrizione = $descrizoneContratto;
        //----------------------------

        $contrattoAffitto = new ContrattoAffitto($con);
        $contrattoAffitto->creaObjJson($request->contratto);
        $contrattoAffitto->getContratto()->setUltimaModificaUtente(getLoginDataFromSession('id'));

        $locatore = $contrattoAffitto->getContratto()->getProprietari();
        $conduttore = $contrattoAffitto->getContratto()->getConduttori();
        $contrattoAffitto->getContrattiDettagli()->setIntestatarioConduttore($conduttore[0]['id']);
        $contrattoAffitto->getContrattiDettagli()->setIntestatarioLocatore($locatore[0]['id']);

        //$contrattoAffitto->saveOrUpdate();
        $contrattoAffitto->saveOrUpdateAndLog(getLoginDataFromSession('id'));
        //new \Drakkar\Log\DrakkarTraceLog(getLoginDataFromSession('id',1));

        $con->commit();
        $result['idContratto'] = $contrattoAffitto->getContratto()->getId();
        $result['status'] = 'ok';
        return json_encode($result);

    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarJsonException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::jsonException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

function elaboraContratto($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
        $con->beginTransaction();

        $elaboraContratto = new ElaboraContratto($con, $conExt);
        $elaboraContratto->elaborazioneContratto($request->idContratto);
        $cont = new Contratti($con);
        $cont->findByPk($request->idContratto);
        $anno = date('Y', time());
        $mese = date('m', time()) + 1;
        $giorno = date('d', time());
        $oggi = date('Y-m-d', mktime(0, 0, 0, $mese, $giorno, $anno));

        while ($cont->getScadenzaContratto() < $oggi) {
            $elaboraContratto->elaborazioneContratto($request->idContratto);
        }


        new \Drakkar\Log\DrakkarTraceLog(getLoginDataFromSession('id', 1));
        $con->commit();
        $result['status'] = 'ok';
        return json_encode($result);

    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarJsonException $e) {
        $con->rollBack();
        die();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::jsonException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        die();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


function caricaElencoBancheContratto($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        $cc = new ContiCorrenti($con);
        $result['elencoContiCorrente'] = $cc->getElencoContiContratto($request->arrayId, ContiCorrenti::FETCH_KEYARRAY);

        $result['status'] = 'ok';

        return json_encode($result);

    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

/**/
ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
