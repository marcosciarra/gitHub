ngApp.controller("contrattoController", ["$scope", "$http", "$filter", function ($scope, $http, $filter) {

    var url = window.location.href;
    var params = decodeUrl(url);
    stampalog(params);

    $scope.caricamentoCompletato = false;
    $scope.filtroCerca = false;

    /* ============================================= CARICA DATI ==================================================== */
    $scope.init = function () {
        $scope.filtroUtenti = [];
        $scope.filtroStabili = [];
        $scope.filtroLocatori = [];
        $scope.filtroConduttori = [];
        $scope.caricaFiltri();

        var d = new Date;
        $scope.filtroTipoContratto = 0;
        $scope.filtroDataInizio = new Date("2000-01-01");
        $scope.filtroDataFine = new Date(d.getFullYear() + "-12-31");
        $scope.filtroImporto = '0';
        $scope.filtrostatoContratto = 'A';
        $scope.statoContrattoAttuale = 'A';
        $scope.caricaDati('A');

    };

    $scope.caricaDati = function (statoContratto) {

        $http.post(params['form'] + '/contratto/controller/contrattoHandler.php',
            {'function': 'caricaDati', 'cestino': statoContratto}
        ).then(function (data, status, headers, config) {

            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }

            //CARICAMENTO SELECT
            //Tipo contratto (Abitativo...)
            $scope.elencoTipiContratto = data.data.elencoTipiContratto;

            $scope.minCanone = 0;
            $scope.maxCanone = data.data.max_canone;
            $scope.rapparto = ($scope.maxCanone - $scope.minCanone) / 100;
            $scope.inizioCanone = 0;
            $scope.fineCanone = 100;

            //NORMALIZZO DATI
            $scope.contratti = data.data.contratti;
            if ($scope.contratti != null) {
                for (var i = 0; i < $scope.contratti.length; i++) {
                    var temp = $scope.contratti[i].data_inizio;
                    $scope.contratti[i].data_inizio_db = temp.substr(0, 4) + temp.substr(5, 2) + temp.substr(-2);
                    $scope.contratti[i].data_inizio =
                        $scope.contratti[i].data_inizio.substr(8, 2) + "/" +
                        $scope.contratti[i].data_inizio.substr(5, 2) + "/" +
                        $scope.contratti[i].data_inizio.substr(0, 4);
                    $scope.contratti[i].nome_contratto = nomeContratto($scope.contratti[i].id_tipo_contratto);

                    $scope.contratti[i].proprietari = jsonParse($scope.contratti[i].proprietari);
                    $scope.contratti[i].conduttori = jsonParse($scope.contratti[i].conduttori);
                    $scope.contratti[i].garanti = jsonParse($scope.contratti[i].garanti);
                    if ($scope.contratti[i].proprietari != undefined && $scope.contratti[i].proprietari.length > 0) {
                        $scope.contratti[i].primoLocatore = $scope.contratti[i].proprietari[0].descrizione;
                    }
                    if ($scope.contratti[i].conduttori != undefined && $scope.contratti[i].conduttori.length > 0) {
                        $scope.contratti[i].primoConduttore = $scope.contratti[i].conduttori[0].descrizione;
                    }
                    if ($scope.contratti[i].elenco_ui != undefined && $scope.contratti[i].elenco_ui.length > 0) {
                        $scope.contratti[i].ui_descrizione = $scope.contratti[i].elenco_ui[0].descrizione;
                    }
                }
            }
            $scope.contrattiCopia = angular.copy($scope.contratti);
            $scope.filtri(1);

            $scope.filtro = false;
            $scope.caricamentoCompletato = true;
        });
    };

    function nomeContratto(id) {
        for (var i = 1; i <= $scope.elencoTipiContratto.length; i++) {
            if ($scope.elencoTipiContratto[i].id == id) {
                return $scope.elencoTipiContratto[i].descrizione;
                break;
            }
        }
    };


    $scope.stampaTipoContratto = function (id) {
        return $filter('filter')($scope.elencoTipiContratto, {id: id})[0].descrizione;
    };


    /* ==================================== RATEIZZAZIONE CANONE ==================================================== */

    $scope.rateizzazione = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "rateizzazioneContratto", id);
    };

    /* =========================================== MODIFICA DATI ==================================================== */

    $scope.modifica = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "nuovoContratto", id);
    };

    /* ========================================= GESTIONE CONTRATTO ================================================= */

    $scope.gestioneContratto = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "gestioneContratto", id);
    };

    /* =========================================== ELIMINA DATI ===================================================== */

    $scope.elimina = function (id, indiceRecord) {

        swal({
                title: "Cestinare il contratto?",
                text: "",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: "btn-danger",
                confirmButtonText: "Si, cestina!",
                cancelButtonText: "No, annulla!",
                closeOnConfirm: false,
                closeOnCancel: false
            },
            function (isConfirm) {
                if (isConfirm) {
                    $http.post(params['form'] + '/contratto/controller/contrattoHandler.php',
                        {
                            'function': 'eliminaDati',
                            'id': id
                        }
                    ).then(function (data, status, headers, config) {
                        stampalog(data.data);
                        if (data.data.status == "ok") {
                            swal("Contratto eliminato!", "", "success");
                            $scope.contratti.splice(indiceRecord, 1);
                        }
                        else {
                            swal("Cancellazione annullata", "", "error");
                        }
                    });
                }
                else {
                    swal("Cancellazione annullata", "", "error");
                }
            });
    };

    /* =========================================== RIPRISTINA DATI ================================================== */

    $scope.ripristina = function (id, indiceRecord) {

        swal({
                title: "Ripristinare il contratto?",
                text: "",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: "btn-danger",
                confirmButtonText: "Si, ripristina!",
                cancelButtonText: "No, annulla!",
                closeOnConfirm: false,
                closeOnCancel: false
            },
            function (isConfirm) {
                if (isConfirm) {
                    $http.post(params['form'] + '/contratto/controller/contrattoHandler.php',
                        {
                            'function': 'ripristinaContratto',
                            'id': id
                        }
                    ).then(function (data, status, headers, config) {
                        stampalog(data.data);
                        if (data.data.status == "ok") {
                            swal("Contratto ripristinato!", "", "success");
                            $scope.contratti.splice(indiceRecord, 1);
                        }
                        else {
                            swal("Ripristino annullato", "", "error");
                        }
                    });
                }
                else {
                    swal("Ripristino annullato", "", "error");
                }
            });
    };


    /* =================================== FILTRI E ORDINAMENTI ===================================================== */

    $scope.filtri = function (verso) {
        $scope.contratti = angular.copy($scope.contrattiCopia);

        if ($scope.filtrostatoContratto != $scope.statoContrattoAttuale) {
            $scope.statoContrattoAttuale = $scope.filtrostatoContratto;
            $scope.caricaDati($scope.filtrostatoContratto);
            $scope.filtroTipoContratto = 0;
            $scope.filtroImporto = '0';
        }

        if ($scope.contratti) {
            $scope.svuotaMultiselect();
            for (var i = 0; i < $scope.contratti.length; i++) {

                //TIPO CONTRATTO
                if ($scope.filtroTipoContratto > 0) {
                    if ($scope.contratti[i].id_tipo_contratto != $scope.filtroTipoContratto) {
                        $scope.contratti.splice(i, 1);
                        i = i - 1;
                        continue;
                    }
                }

                //Controllo che l'importo minimo non può essere maggiore all'importo massimo
                if (verso == 1) {
                    if ($scope.inizioCanone > $scope.fineCanone) {
                        $scope.fineCanone = $scope.inizioCanone;
                    }
                }
                if ($scope.fineCanone < $scope.inizioCanone) {
                    $scope.inizioCanone = $scope.fineCanone;
                }
                if (verso == 2) {
                    if ($scope.inizioCanone > $scope.fineCanone) {
                        $scope.fineCanone = $scope.inizioCanone;
                    }
                }

                //Controllo su importo
                if ($scope.fineCanone == 100 && $scope.contratti[i].importo > $scope.maxCanone) {
                    i = i - 1;
                    continue;
                }
                if ($scope.inizioCanone == 0 && $scope.contratti[i].importo < 0) {
                    i = i - 1;
                    continue;
                }

                if (!($scope.contratti[i].importo >= ($scope.inizioCanone * $scope.rapparto) &&
                    $scope.contratti[i].importo <= ($scope.fineCanone * $scope.rapparto))) {
                    $scope.contratti.splice(i, 1);
                    i = i - 1;
                    continue;
                }

                if ($scope.disdetto == true && $scope.contratti[i].stato_contratto != "D") {
                    $scope.contratti.splice(i, 1);
                    i = i - 1;
                    continue;
                }

                if ($scope.cedolare == true && $scope.contratti[i].cedolare != "1") {
                    $scope.contratti.splice(i, 1);
                    i = i - 1;
                    continue;
                }
            }
            stampalog($scope.contratti);
        }
    };

    $scope.caricaDettagliModale = function (elenco, etichetta) {
        $scope.elencoModale = elenco;
        $scope.etichettaModale = etichetta;
    };

    $scope.mostraNascondiFiltri = function () {
        if ($scope.filtroCerca == false) {
            $scope.filtroCerca = true;
        }
        else {
            $scope.filtroCerca = false;
        }
    }


    //---------------------------------------------------SEZIONE FILTRI-----------------------------------------------//
    $scope.caricaFiltri = function () {
        $http.post($scope.params['form'] + "/template/controller/homeHandler.php",
            {'function': 'caricaFiltri'}
        ).then(function (data, status, headers, config) {
            // stampalog(data.data);
            $scope.filtriSelectPagina = data.data;
        });
    };
    $scope.settings = {
        dynamicTitle: true,
        enableSearch: true,
        showSelectAll: false,
        keyboardControls: true,
        scrollable: true,
        showCheckAll: false,
        showUncheckAll: true,
        closeOnSelect: false,
        scrollableHeight: '300px',
        externalIdProp: '', //PERMETTE DI AGGIUNGERE ALL'ARRAY DEI SELEZIONATI TUTTO L'OGGETTO
        idProp: 'id', //definisco i campi di cui è composto l'oggetto
        displayProp: 'descrizione' //definisco i campi di cui è composto l'oggetto
    };
    $scope.customTextUtenti = {
        buttonDefaultText: 'Utenti',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextStabili = {
        buttonDefaultText: 'Stabili',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextLocatori = {
        buttonDefaultText: 'Locatori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextConduttori = {
        buttonDefaultText: 'Conduttori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.multiSelectEventUtenti = {
        onItemSelect: function (obj) {
            $scope.filtroUtenti.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroUtenti.length; i++) {
                if ($scope.filtroUtenti[i] == obj.id) {
                    $scope.filtroUtenti.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function () {
            $scope.filtroUtenti = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventStabili = {
        onItemSelect: function (obj) {
            $scope.filtroStabili.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroStabili.length; i++) {
                if ($scope.filtroStabili[i] == obj.id) {
                    $scope.filtroStabili.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroStabili = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventLocatori = {
        onItemSelect: function (obj) {
            $scope.filtroLocatori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroLocatori.length; i++) {
                if ($scope.filtroLocatori[i] == obj.id) {
                    $scope.filtroLocatori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroLocatori = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventConduttori = {
        onItemSelect: function (obj) {
            $scope.filtroConduttori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroConduttori.length; i++) {
                if ($scope.filtroConduttori[i] == obj.id) {
                    $scope.filtroConduttori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroConduttori = [];
            $scope.filtriGenerici();
        }
    };
    $scope.svuotaMultiselect = function () {
        $scope.multiSelectEventUtenti.onDeselectAll();
        $scope.multiSelectEventLocatori.onDeselectAll();
        $scope.multiSelectEventConduttori.onDeselectAll();
        $scope.multiSelectEventStabili.onDeselectAll();
        $scope.elencoUtenti = [];
        $scope.elencoLocatori = [];
        $scope.elencoConduttori = [];
        $scope.elencoStabili = [];
    };
    $scope.filtriGenerici = function () {
        $scope.contratti = [];
        var flag;
        for (var i = 0; i < $scope.contrattiCopia.length; i++) {
            flag = false;

            if ($scope.filtroUtenti.length == 0) {
                flag = true;
            }
            else {
                for (var k = 0; k < $scope.filtroUtenti.length; k++) {
                    if ($scope.contrattiCopia[i].contratti.id_utente_riferimento == $scope.filtroUtenti[k]) {
                        flag = true;
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroStabili.length == 0) {
                    flag = true;
                }
                else {
                    flag = false;
                    for (var j = 0; j < $scope.contrattiCopia[i].elenco_ui.length; j++) {
                        for (var k = 0; k < $scope.filtroStabili.length; k++) {
                            if ($scope.contrattiCopia[i].elenco_ui[j].id_stabili == $scope.filtroStabili[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroLocatori.length == 0) {
                    flag = true;
                }
                else {
                    flag = false;
                    for (var j = 0; j < $scope.contrattiCopia[i].proprietari.length; j++) {
                        for (var k = 0; k < $scope.filtroLocatori.length; k++) {
                            if ($scope.contrattiCopia[i].proprietari[j].id == $scope.filtroLocatori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroConduttori.length == 0) {
                    flag = true;
                }
                else {
                    flag = false;
                    for (var j = 0; j < $scope.contrattiCopia[i].conduttori.length; j++) {
                        for (var k = 0; k < $scope.filtroConduttori.length; k++) {
                            if ($scope.contrattiCopia[i].conduttori[j].id == $scope.filtroConduttori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                $scope.contratti.push($scope.contrattiCopia[i]);
            }
        }
    };

}])
;