<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 15/12/17
 * Time: 10.38
 */
require_once '../../../src/function/functionDate.php';
require_once '../../../src/function/functionLogin.php';

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';
require_once '../../../src/model/DrakkarTraceLog.php';

require_once '../../../src/model/Contratti.php';
require_once '../../../src/model/Cauzioni.php';
require_once '../../../src/model/ContrattiDettagli.php';
require_once '../../../src/model/ContrattiPreferenze.php';
require_once '../../../src/model/Rli.php';
require_once '../../../src/model/ContrattoAffitto.php';
require_once '../../../src/model/ContiCorrenti.php';
require_once '../../../src/model/Login.php';
require_once '../../../src/model/GruppiFatturazione.php';
require_once '../../../src/model/ImpostaRegistro.php';
require_once '../../../src/model/ElaboraImpostaRegistro.php';
require_once '../../../src/model/Rate.php';
require_once '../../../src/model/RateDettagli.php';
require_once '../../../src/model/Gestioni.php';
require_once '../../../src/model/ContrattiConAnagrafiche.php';
require_once '../../../src/model/TipiCauzione.php';


use Click\Affitti\TblBase\Contratti;
use Click\Affitti\Viste\ContrattoAffitto;
use Click\Affitti\TblBase\ContrattiDettagli;
use Click\Affitti\TblBase\Rli;
use Click\Affitti\TblBase\Login;
use Click\Affitti\TblBase\GruppiFatturazione;
use Click\Affitti\TblBase\Cauzioni;
use Click\Affitti\Viste\ElaboraImpostaRegistro;
use Click\Affitti\TblBase\ImpostaRegistro;
use Click\Affitti\TblBase\RateDettagli;
use Click\Affitti\TblBase\Rate;
use Click\Affitti\TblBase\Gestioni;
use Click\Affitti\Viste\ContrattiConAnagrafiche;
use Click\Affitti\TblBase\TipiCauzione;
use Click\Affitti\TblBase\ContrattiPreferenze;


function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $cc = new \Click\Affitti\TblBase\ContiCorrenti($con);

        $contratto = new Contratti($con);
        $contrattoDettagli = new ContrattiDettagli($con);
        $contrattoAffitto = new ContrattoAffitto($con);
        $rli = new Rli($con);

        $contratto->findByPk($request->id);
        $contrattoDettagli->findByPk($request->id);

        /*------------------------------------------------CONTRATTO---------------------------------------------------*/
        $result['contrattoAffitto'] = $contrattoAffitto->findByPk($request->id, ContrattoAffitto::FETCH_KEYARRAY);
        /*------------------------------------------------ANAGRAFICHE INTERESSATE-------------------------------------*/
        $result['elencoAnagrafica'] = [];
        $contrattoAffitto->findByPk($request->id);
        foreach (json_decode($contrattoAffitto->getContratto()->getProprietari()) as $item) {
            $result['elencoAnagrafica'][] = $item;
            $result['elencoLocatori'][] = $item;
        }
        foreach (json_decode($contrattoAffitto->getContratto()->getConduttori()) as $item) {
            $result['elencoAnagrafica'][] = $item;
            $result['elencoConduttori'][] = $item;
        }

        /*------------------------------------------------CAUZIONE----------------------------------------------------*/
        $result['cauzioni'] = $contrattoAffitto->getCauzioni();
        $tipiCauzione = new TipiCauzione($con);
        $result['elencoTipiCauzione'] = $tipiCauzione->findAll(false, TipiCauzione::FETCH_KEYARRAY);
        //CREO RECORD CAUZIONE VUOTA
        $cauzioni = new Cauzioni($con);
        $result['nuovaCauzione'] = $cauzioni->getEmptyDbKeyArray();

        /*------------------------------------------------CEDOLARE SECCA----------------------------------------------*/
        $result['cedolareSecca'] = $rli->getCedolareSeccaValuesList(true);

        /*------------------------------------------------DISDETTA----------------------------------------------------*/
        $result['dataScadenzaContratto'] = $contratto->getScadenzaContratto();

        /*------------------------------------------------UTENTI----------------------------------------------------*/
        $utenti = new Login($con);
        $utenti->setWhereBase(" tipo_utente='A' OR tipo_utente='U' AND bloccato=0");
        $result['elencoUtenti'] = $utenti->findAll(true, Login::FETCH_KEYARRAY);

        /*------------------------------------------------GRUPPI FATTURAZIONE-----------------------------------------*/
        $gruppiFat = new GruppiFatturazione($con);
        $result['gruppiFat'] = $gruppiFat->findElencoUltimiGruppi(false, GruppiFatturazione::FETCH_KEYARRAY);

        /*------------------------------------------------TIPO RICHIESTA----------------------------------------------*/
        $result['tipoRichiesta'] = $contrattoDettagli->getBollettazioneTipoValuesList(true);

        /*------------------------------------------------TIPO RICHIESTA----------------------------------------------*/
        $result['intestatario_locatore'] = $contrattoDettagli->getIntestatarioLocatore();
        $result['intestatario_conduttore'] = $contrattoDettagli->getIntestatarioConduttore();

        /*------------------------------------------------CONTI CORRENTI----------------------------------------------*/
        $ids = [];
        foreach (json_decode($contratto->getProprietari()) as $cond) {
            $ids[] = $cond->id;
        }
        $ids[] = $contratto->getIdAgenziaImmobiliare();
        $result['elencoContiCorrente'] = $cc->getElencoContiContratto($ids, \Click\Affitti\TblBase\ContiCorrenti::FETCH_KEYARRAY);

        $anagrafiche = new ContrattiConAnagrafiche($con);
        $result['anagrafica_contratto'] = $anagrafiche->findByPk($request->id, ContrattiConAnagrafiche::FETCH_KEYARRAY);

        $result['status'] = 'ok';

        return json_encode($result);
    } catch
    (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

/*===========================================OCCUPAZIONE SENZA TITOLO=================================================*/

function occupazione($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $contratto = new Contratti($con);
        $contratto->findByPk($request->idContratto);
        $contratto->setOccupazioneSenzaTitolo($request->stato);
        $contratto->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

/*===========================================RICHIESTA IMPOSTA DI REGISTRO============================================*/

function cambiaRichiestaImposta($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $impReg = new ImpostaRegistro($con);
        /** @var ImpostaRegistro $impReg */
        foreach ($impReg->findByIdContrattoNonVersati($request->idContratto) as $impReg) {
            $rateD = new RateDettagli($con);
            /** @var RateDettagli $rateD */
            $rateD->findByIdxIdImpostaRegistro($impReg->getId());
            $dataScadenza = $impReg->getDataScadenza();
            $rate = new Rate($con);
            if ($request->tipoRichiesta == 'A') {
                $idRata = $rate->getIdRataByData($request->idContratto, $dataScadenza);
            } else {
                $idRata = $rate->getIdRataSuccessivaByData($request->idContratto, $dataScadenza);
            }
            $rateD->setIdRata($idRata);
            $rateD->saveOrUpdate();
        }

        $contrattiP = new ContrattiPreferenze($con);
        $contrattiP->findByPk($request->idContratto);
        $contrattiP->setImpostaRegistroTipoRichiesta($request->tipoRichiesta);
        $contrattiP->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

/*===========================================OCCUPAZIONE SENZA TITOLO=================================================*/

function fixImpReg($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
        $con->beginTransaction();

        $contratto=new Contratti($con);
        $contratto->setWhereBase(' cestino=0 AND elaborato=1 ');
        /** @var Contratti $c */
        foreach ($contratto->findAll() as $c){
            $rli = new Rli($con);
            /** @var Rli $rli */
            foreach ($rli->findByIdContratto($c->getId()) as $rli) {
                break;
            }
            if ($rli->getCedolareSecca()==3){
                //////////////////////////////////////////////////////////////////////
                $impReg = new ImpostaRegistro($con);
                /** @var ImpostaRegistro $impReg */
                foreach ($impReg->findByIdContratto($c->getId()) as $impReg) {
                    if ($impReg->getDataVersamento() == null) {
                        $rateD = new RateDettagli($con);
                        $rateD->findByIdxIdImpostaRegistro($impReg->getId());
                        $rate = new Rate($con);
                        $rate->findByPk($rateD->getIdRata());
                        if ($rate->getBloccata() == 0) {
                            $rateD->deleteByPk($rateD->getId());
                            $impReg->deleteByPk($impReg->getId());
                        }
                    }
                }
                //////////////////////////////////////////////////////////////////////
                $gestione = new Gestioni($con);
                /** @var Gestioni $gestioni */
                foreach
                (
                    $gestione->elencoGestioniDaDataByIdContratto(
                        $c->getId(),
                        date('Y') . '-01-01',
                        true)
                    as $gestioni
                ) {
                    $impReg = new ImpostaRegistro($con);
                    if (count($impReg->findByIdGestione($gestioni->getId(), ImpostaRegistro::FETCH_KEYARRAY)) == 0) {
                        $eleboraImposta = new ElaboraImpostaRegistro($c->getId(), $gestioni->getId(), $con, $conExt);
                        if ($eleboraImposta->preparaDataRichiesta() >= date('Y-m-d')) {
                            $eleboraImposta->creaImposta();
                        }
                    }
                }
            }

        }

        $con->commit();
        return 'ok';
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

function cedolareSecca($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
        $con->beginTransaction();

        //AGGIORNO LO STATO DELL'RLI
        $rli = new Rli($con);
        /** @var Rli $rli */
        foreach ($rli->findByIdContratto($request->idContratto) as $rli) {
            $rli->setCedolareSecca($request->stato);
            $rli->saveOrUpdate();
        }

        switch ($request->stato) {
            case '1':
                //TUTTI I LOCATORI OPTANO PER LA CEDOLARE SECCA
                //ELIMINO LE IMPOSTE DI REGISTRO NON ANCORA CHIESTE
                $impReg = new ImpostaRegistro($con);
                /** @var ImpostaRegistro $impReg */
                foreach ($impReg->findByIdContratto($request->idContratto) as $impReg) {
                    if ($impReg->getDataVersamento() == null) {
                        $rateD = new RateDettagli($con);
                        $rateD->findByIdxIdImpostaRegistro($impReg->getId());
                        $rate = new Rate($con);
                        $rate->findByPk($rateD->getIdRata());
                        if ($rate->getBloccata() == 0) {
                            $rateD->deleteByPk($rateD->getId());
                            $impReg->deleteByPk($impReg->getId());
                        }
                    }
                }
                break;
            case '2':
                //ALMENO UN LOCATORE OPTA PER LA CEDOLARE SECCA
                //TODO::DA GESTIRE IL CASO IN CUI LA CEDOLARE SECCA E' PARZIALE (PER ORA LO GESTISCO COME SE FOSSE TUTTO IN CEDOALARE)


                break;
            case '3':
                //NESSUN LOCATORE OPTA PER LA CEDOLARE SECCA
                $gestione = new Gestioni($con);
                /** @var Gestioni $gestioni */
                foreach
                (
                    $gestione->elencoGestioniDaDataByIdContratto(
                        $request->idContratto,
                        date('Y') . '-01-01',
                        true)
                    as $gestioni
                ) {
                    $impReg = new ImpostaRegistro($con);
                    if (count($impReg->findByIdGestione($gestioni->getId(), ImpostaRegistro::FETCH_KEYARRAY)) == 0) {
                        $eleboraImposta = new ElaboraImpostaRegistro($request->idContratto, $gestioni->getId(), $con, $conExt);
                        if ($eleboraImposta->preparaDataRichiesta() >= date('Y-m-d')) {
                            $eleboraImposta->creaImposta();
                        }
                    }
                }

                break;
        }

        $con->commit();
        return 'ok';
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


/*===========================================DISDETTA=============================================================*/

function statoContratto($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $contratto = new Contratti($con);
        $contratto->findByPk($request->idContratto);
        $contratto->setStatoContratto($request->stato);
        if ($request->stato == 'A') {
            $contratto->setDisdettaInData('');
        }
        $contratto->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

/*===========================================UTENTE RIFERIMENTO=======================================================*/

function utenteRiferimento($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $contratto = new Contratti($con);
        $contratto->findByPk($request->idContratto);
        $contratto->setIdUtenteRiferimento($request->codice);
        $contratto->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

function eliminaUtenteRiferimento($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $contratto = new Contratti($con);
        $contratto->findByPk($request->idContratto);
        $contratto->setIdUtenteRiferimento(0);
        $contratto->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

/*===========================================GRUPPO FATTURAZIONE======================================================*/

function cambiaGruppoFatturazione($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $contratto = new ContrattiDettagli($con);
        $contratto->findByPk($request->idContratto);
        $contratto->setIdGruppoFatturazione($request->codice);
        $contratto->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

/*===========================================PREAVVISO CAUZIONE=======================================================*/

function aggiungiNuovaCauzione($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $cauzione = new Cauzioni($con);
        $cauzione->creaObjJson($request->cauzione, true);
        $cauzione->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

function salvaCauzione($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $cauzione = new Cauzioni($con);
        $cauzione->findByPk($request->cauzione->id);
        $cauzione->setMesiPreavvisoScadenza($request->cauzione->mesi_preavviso_scadenza);
        $cauzione->setDataScadenza($request->cauzione->data_scadenza);
        $cauzione->setImporto($request->cauzione->importo);
        $cauzione->setDataCauzione($request->cauzione->data_cauzione);
        $cauzione->setDescrizione($request->cauzione->descrizione);
        $cauzione->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

function cestinaCauzione($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $cauzione = new Cauzioni($con);
        $cauzione->findByPk($request->id);
        $cauzione->setCestino(1);
        $cauzione->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}


/*===========================================TIPO RICHIESTA=======================================================*/

function tipoRichiesta($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $contratto = new ContrattiDettagli($con);
        $contratto->findByPk($request->idContratto);
        $contratto->setBollettazioneTipo($request->codice);
        $contratto->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

/*===========================================PERCENTUALE RIFERIMENTO ISTAT============================================*/

function cambiaColonnaTabellaIstat($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $contratto = new ContrattiDettagli($con);
        $contratto->findByPk($request->idContratto);
        $contratto->setColonnaTabellaIstat($request->codice);
        $contratto->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

/*===========================================MESE RIFERIMENTO ISTAT===================================================*/

function cambiaMeseRiferimentoIstat($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $contratto = new ContrattiDettagli($con);
        $contratto->findByPk($request->idContratto);
        $contratto->setMeseRiferimentoIstat($request->codice);
        $contratto->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

/*===========================================MESI CONGUAGLIO ISTAT=======================================================*/

function cambiaMeseConguaglioIstat($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $contratto = new ContrattiDettagli($con);
        $contratto->findByPk($request->idContratto);
        $contratto->setMesiConguaglioIstat($request->codice);
        $contratto->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

/*===========================================BANCA BOLLETTINI=========================================================*/

function cambiaBanca($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $contratto = new ContrattiDettagli($con);
        $contratto->findByPk($request->idContratto);
        $contratto->setIdContoCorrente($request->codice);
        $contratto->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

/*===========================================BANCA RLI================================================================*/

function cambiaBancaRli($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $rli = new Rli($con);
        /** @var Rli $rli */
        foreach ($rli->findByIdContratto($request->idContratto) as $rli) {
            $rli->setIdContoCorrente($request->codice);
            $rli->saveOrUpdate();
        }
        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

/*===========================================CONTRIBUENTE=============================================================*/

function cambiaContribuente($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $rli = new Rli($con);
        /** @var Rli $rli */
        foreach ($rli->findByIdContratto($request->idContratto) as $rli) {
            $rli->setIdContribuente($request->codice);
            $rli->saveOrUpdate();
        }
        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

/*===========================================ASSOGGETTAZIONE==========================================================*/

function cambiaAssoggettazione($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $contratto = new Contratti($con);
        $contratto->findByPk($request->idContratto);
        $contratto->setTipoAssoggettazione($request->codice);
        $contratto->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

/*===========================================COOBBLIGATO==============================================================*/

function cambiaCoobbligato($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $rli = new Rli($con);
        /** @var Rli $rli */
        foreach ($rli->findByIdContratto($request->idContratto) as $rli) {
            $rli->setIdCoobbligato($request->codice);
            $rli->saveOrUpdate();
        }
        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

/*===========================================CODICE IDENTIFICATIVO==================================================*/

function salvaCodiceIdentificativo($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $rli = new Rli($con);
        /** @var Rli $rli */
        foreach ($rli->findByIdContratto($request->idContratto) as $rli) {
//        $rli->findByPk($request->rli->id);
            $rli->setUfficioTerritorio($request->rli->ufficio_territorio);
            $rli->setCodiceUfficio($request->rli->codice_ufficio);
            $rli->setAnnoStipula($request->rli->anno_stipula);
            $rli->setSerie($request->rli->serie);
            $rli->setNumero($request->rli->numero);
            $rli->setSottonumero($request->rli->sottonumero);
            $rli->setCodiceIdentificativo($request->rli->codice_identificativo);

            $impReg = new \Click\Affitti\TblBase\ImpostaRegistro($con);
            /** @var \Click\Affitti\TblBase\ImpostaRegistro $impReg */
            foreach ($impReg->findByIdxIdRli($rli->getId()) as $impReg) {
                $impReg->setCodiceUfficio($request->rli->codice_ufficio);
                $impReg->setSerie($request->rli->serie);
                $impReg->setNumero($request->rli->numero);
                $impReg->setSottonumero($request->rli->sottonumero);
                $app = json_decode($impReg->getDettagli());
                foreach ($app as $a) {
                    if ($a->codice != "1500") {
                        $a->elementi_identificativi = $request->rli->codice_identificativo;
                    }
                }
                $impReg->setDettagli(json_encode($app));
                $impReg->saveOrUpdate();
            }
            //$rli->saveOrUpdateAndLog(getLoginDataFromSession('id'));
            $rli->saveOrUpdate();
        }

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

/*===========================================SALVA SUDDIVISIONE GRUPPO ===============================================*/

function salvaGruppo($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $contrattoP = new ContrattiPreferenze($con);
        $contrattoP->findByPk($request->idContratto);
        if ($request->tipo == 'locatori') {
            $contrattoP->setDivisioneLocatori(json_encode($request->elencoGruppiLocatori));
        } else {
            $contrattoP->setDivisioneConduttori(json_encode($request->elencoGruppiConduttori));
        }
        $contrattoP->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

function eliminaSuddivisione($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $contrattoP = new ContrattiPreferenze($con);
        $contrattoP->findByPk($request->idContratto);
        if ($request->tipo == 'locatori') {
            $contrattoP->setDivisioneLocatori($contrattoP::NULL_VALUE);
        } else {
            $contrattoP->setDivisioneConduttori($contrattoP::NULL_VALUE);
        }
        $contrattoP->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

/*===========================================INTESTATARIO FATTURA=================================================*/

function cambiaIntestatarioLocatore($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $contrattoD = new ContrattiDettagli($con);
        $contrattoD->findByPk($request->idContratto);
        $contrattoD->setIntestatarioLocatore($request->idLocatore);

        $contrattoD->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}


function cambiaIntestatarioConduttore($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $contrattoD = new ContrattiDettagli($con);
        $contrattoD->findByPk($request->idContratto);
        $contrattoD->setIntestatarioConduttore($request->idConduttore);

        $contrattoD->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}


/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
