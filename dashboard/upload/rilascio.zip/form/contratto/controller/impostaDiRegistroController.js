ngApp.controller("impostaDiRegistroController", ["$scope", "$http", "$filter", function ($scope, $http, $filter) {

    var url = window.location.href;
    var params = decodeUrl(url, 'id');
    stampalog('URL');
    stampalog(params);

    $scope.init = function () {
        $scope.caricaDati(0);
        $scope.mostraFormNuovoDettaglio = false;
    };

    /******************
     *   CARICA NUOVO   * ================================================================================================
     ******************/
    $scope.caricaNuovoDettaglio = function () {
        $http.post(params['form'] + '/contratto/controller/impostaDiRegistroHandler.php',
            {
                'function': 'caricaNuovoDettaglio'
            }
        ).then(function (data, status, headers, config) {
            stampalog(data.data);
            $scope.nuovo_dettaglio = data.data.nuovoDettaglio;
            $scope.nuovo_dettaglio.dettagli.elementi_identificativi = $scope.codiceIdentificativo;
            $scope.nuovo_dettaglio.dettagli.importi = $scope.nuovo_dettaglio.dettagli.importi * 1;
            $scope.nuovo_dettaglio.dettagli.anno = $scope.nuovo_dettaglio.dettagli.anno * 1;
            $scope.elencoCodiciTributo = data.data.elencoCodiciTributi;

            $scope.mostraFormNuovoDettaglio = true;
            stampalog($scope.nuovo_dettaglio);
        });
    };

    /*******************
     *   CARICA DATI   * ================================================================================================
     *******************/

    $scope.caricaDati = function (id) {
        $scope.caricamentoCompletato = false;
        $scope.modificaRata = false;
        $scope.idContratto = params['id'];

        $http.post(params['form'] + '/contratto/controller/impostaDiRegistroHandler.php',
            {
                'function': 'caricaImposteDaIdGestione',
                'idGestione': id,
                'idContratto': $scope.idContratto
            }
        ).then(function (data, status, headers, config) {
            stampalog(data.data);
            $scope.imposteRegistro = data.data;

            if (id == 0) {
                //$scope.modificaGestione(data.data.gestione_oggi[0].id_gestione);
                //$scope.gestione = idGestione;
                $scope.periodo = data.data.gestione_oggi[0].id_periodi_contrattuali;
                $scope.gestione = data.data.gestione_oggi[0].id_gestione;
            } else {
                //$scope.modificaGestione(id);
                $scope.gestione = id;
            }
            $scope.listaRate = data.data.listaRate;

            if ($scope.imposteRegistro.imposte_registro[0] == undefined) {
                $scope.rataSelezionata = -1;
            } else {
                $scope.rataSelezionata = $scope.imposteRegistro.imposte_registro[0].idRata;
            }
            $scope.idNuovaRata = angular.copy($scope.rataSelezionata);

            $scope.personeInteressate = [];

            if ($scope.rataSelezionata > 0) {
                for (var $i = 0; $i < $scope.imposteRegistro.imposte_registro.length; $i++) {
                    if ($scope.imposteRegistro.imposte_registro[$i].data_versamento == null ||
                        $scope.imposteRegistro.imposte_registro[$i].data_versamento == '0000-00-00') {
                        $scope.imposteRegistro.imposte_registro[$i].impostaVersata = false;
                    } else {
                        $scope.imposteRegistro.imposte_registro[$i].impostaVersata = true;
                    }
                    $scope.imposteRegistro.imposte_registro[$i].id_codice_identificativo = '' + $scope.imposteRegistro.imposte_registro[$i].id_codice_identificativo;
                    $scope.imposteRegistro.imposte_registro[$i].dettagli = jsonParse($scope.imposteRegistro.imposte_registro[$i].dettagli);
                    $scope.codiceIdentificativo = $scope.imposteRegistro.rli[0].codice_identificativo;
                    for (var j = 0; j < $scope.imposteRegistro.listaRate.length; j++) {
                        if ($scope.imposteRegistro.listaRate[j].id == $scope.imposteRegistro.imposte_registro[$i].idRata) {
                            if ($scope.imposteRegistro.listaRate[j].bloccata == 1) {
                                $scope.imposteRegistro.imposte_registro[$i].bloccata = true;
                            }
                            else {
                                $scope.imposteRegistro.imposte_registro[$i].bloccata = false;
                            }
                        }
                    }

                    for (var $j = 0; $j < $scope.imposteRegistro.rli.length; $j++) {

                        if ($scope.imposteRegistro.imposte_registro[$i].id_rli == $scope.imposteRegistro.rli[$j].id) {

                            $scope.imposteRegistro.imposte_registro[$i].dati_rli = $scope.imposteRegistro.rli[$j];

                            $scope.imposteRegistro.imposte_registro[$i].sommaDettagli = 0;
                            angular.forEach($scope.imposteRegistro.imposte_registro[$i].dettagli, function (d) {
                                $scope.imposteRegistro.imposte_registro[$i].sommaDettagli += d.importi;
                            });

                            angular.forEach(jsonParse($scope.imposteRegistro.imposte_registro[$i].dati_rli.locatori), function (loc) {
                                if (!$filter('filter')($scope.personeInteressate, {id: loc.id}, true)[0]) {
                                    $scope.personeInteressate.push(loc);
                                }
                            });
                            angular.forEach(jsonParse($scope.imposteRegistro.imposte_registro[$i].dati_rli.conduttori), function (con) {
                                if (!$filter('filter')($scope.personeInteressate, {id: con.id}, true)[0]) {
                                    $scope.personeInteressate.push(con);
                                }
                            });
                            angular.forEach(jsonParse($scope.imposteRegistro.imposte_registro[$i].dati_rli.garanti), function (gar) {
                                if (gar.id > 0) {
                                    if (!$filter('filter')($scope.personeInteressate, {id: gar.id}, true)[0]) {
                                        $scope.personeInteressate.push(gar);
                                    }
                                }
                            });


                        }

                    }
                }
            }

            $scope.elencoCodiciCoobbligati = data.data.elencoCoobbligati;

            $scope.locatori = jsonParse(data.data.anagrafica_contratto.proprietari);
            $scope.primoLocatore = $scope.locatori[0].descrizione;

            $scope.conduttori = jsonParse(data.data.anagrafica_contratto.conduttori);
            $scope.primoConduttore = $scope.conduttori[0].descrizione;

            $scope.unitaImmobiliari = data.data.anagrafica_contratto.unita_immobiliari;
            $scope.primoStabile = $scope.unitaImmobiliari[0].descrizione;

            $scope.caricamentoCompletato = true;

        });
    };

    $scope.caricaDatiAnagrafici = function (idContribuente, tipo) {
        $http.post(params['form'] + '/contratto/controller/impostaDiRegistroHandler.php',
            {
                'function': 'caricaDatiAnagraficaDaId',
                'id': idContribuente,
                'tipo': tipo
            }
        ).then(function (data, status, headers, config) {
            if (tipo == 'contribuente') {
                $scope.imposteRegistro.datiContribuente = data.data.dati_anagrafici;
                $scope.imposteRegistro.datiContribuente[0].nascita_data = formatDataDbToIta($scope.imposteRegistro.datiContribuente[0].nascita_data);
                // TODO controllare domicilio fiscale quando tiro su indirizzi
                $scope.imposteRegistro.datiContribuente[0].indirizzi = jsonParse($scope.imposteRegistro.datiContribuente[0].indirizzi);
            } else if (tipo == 'coobbligato') {
                $scope.imposteRegistro.datiCoobbligato = data.data.dati_anagrafici;
                stampalog($scope.imposteRegistro.datiCoobbligato);
                // TODO controllare domicilio fiscale quando tiro su indirizzi
                $scope.imposteRegistro.datiCoobbligato[0].indirizzi = jsonParse($scope.imposteRegistro.datiCoobbligato[0].indirizzi);
            }
        });
    };

    $scope.modificaGestione = function (idGestione) {
        $scope.listaRate = [];
        angular.forEach($scope.imposteRegistro.periodi_contrattuali, function (pc) {
            angular.forEach(pc.gestione, function (g) {
                if (g.id == idGestione) {
                    angular.forEach(g.pianoRateT, function (r) {
                        angular.forEach(r.pianoRateD, function (d) {
                            $scope.listaRate.push({
                                    'id': d.rate[0].id,
                                    'descrizione': d.rate[0].descrizione,
                                    'bloccata': d.rate[0].bloccata
                                }
                            );
                        });
                        $scope.gestione = idGestione;
                        return;
                    });
                }
                ;
            });
        });
        $scope.gestione = idGestione;
    };

    $scope.modificaPeriodo = function (id) {
        //$scope.resetFormNuovoDettaglio();
        $scope.periodo = id;
        $scope.gestione = 0;
        $scope.rate = 0;
        $scope.showDettaglio = -1;
    };

    $scope.caricaDettagliModale = function (elenco, etichetta) {
        $scope.elencoModale = elenco;
        $scope.etichettaModale = etichetta;
    };

    $scope.assegnaRata = function (id) {
        $scope.idNuovaRata = id;
    };


    /* ========================================= GESTIONE CONTRATTO ================================================= */

    $scope.gestioneContratto = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "gestioneContratto", id);
    };

    /* ========================================= SPOSTA IMPOSTA DI REGISTRO ========================================= */

    $scope.salvaImposta = function (impReg, idRata) {
        stampalog(idRata);
        $http.post(params['form'] + '/contratto/controller/impostaDiRegistroHandler.php',
            {
                'function': 'salvaImposta',
                'impostaRegistro': impReg,
                'idRata': idRata
            }
        ).then(function (data, status, headers, config) {
            stampalog(data.data);
            if (data.data.status == "ok") {
                swal({
                    title: "Imposta di registro aggiornata!",
                    text: '',
                    type: "success"
                }, function () {
                    location.reload();
                });
            }
            else {
                swal("Elaborazione non riuscita", "", "error");
            }
        });
    };


    $scope.aggiungiDettaglio = function () {
        if (
            $scope.nuovo_dettaglio.dettagli.tipo.length == 1 &&
            $scope.nuovo_dettaglio.dettagli.anno > 2000 &&
            $scope.nuovo_dettaglio.dettagli.anno < 2100 &&
            $scope.nuovo_dettaglio.dettagli.elementi_identificativi.length >= 16 &&
            $scope.nuovo_dettaglio.dettagli.importi > 0
        ) {
            $scope.imposteRegistro.imposte_registro[0].dettagli.push($scope.nuovo_dettaglio.dettagli);
            $scope.imposteRegistro.imposte_registro[0].importo_totale =
                $scope.imposteRegistro.imposte_registro[0].importo_totale +
                $scope.nuovo_dettaglio.dettagli.importi;

            $scope.mostraFormNuovoDettaglio = false;
        }
        else {
            swal("Errore", "Valori non corretti", "error");
        }
    };

    $scope.eliminaDettaglio = function (pos) {
        $scope.imposteRegistro.imposte_registro[0].importo_totale =
            $scope.imposteRegistro.imposte_registro[0].importo_totale -
            $scope.imposteRegistro.imposte_registro[0].dettagli[pos].importi;

        $scope.imposteRegistro.imposte_registro[0].dettagli.splice(pos, 1);
    };

}]);

/******************
 *   FILTRI   * ================================================================================================
 ******************/

ngApp.filter('formatDate', function () {
    return function (date) {
        if (date == null) return '';
        return date.substring(8, 10) + '/' + date.substring(5, 7) + '/' + date.substring(0, 4);
        ;
    };
});