<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 15/12/17
 * Time: 10.38
 */
require_once '../../../src/function/functionDate.php';
require_once '../../../src/function/functionLogin.php';

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';
require_once '../../../src/model/DrakkarTraceLog.php';

require_once '../../../src/model/ContrattoNote.php';

use Click\Affitti\TblBase\ContrattoNote;

function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        $note = new ContrattoNote($con);
        $note->setOrderBase(' ultima_modifica_data ASC');
        $note->setWhereBase(" cestino = $request->statoCestino ");
        $result['note'] = $note->findByIdxIdContratto($request->id,ContrattoNote::FETCH_KEYARRAY);
        $result['noteEmpty'] =$note->getEmptyDbKeyArray();

        $result['status'] = 'ok';

        return json_encode($result);
    } catch
    (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

/*===========================================OCCUPAZIONE SENZA TITOLO=================================================*/

function aggiungiNota($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $note = new ContrattoNote($con);
        $note->setIdContratto($request->obj->id_contratto);
        $note->setTitolo($request->obj->titolo);
        $note->setDescrizione($request->obj->descrizione);
        $note->setCestino('0');
        $note->setUltimaModificaUtente(getLoginDataFromSession('id',1));
        $note->setUltimaModificaData(date("Y-m-d G:i:s"));
        $note->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

function eliminaNota($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $note = new ContrattoNote($con);
        $note->findByPk($request->id);
        if($note->getId()>0){
            $note->setCestino('1');
            $note->setUltimaModificaUtente(getLoginDataFromSession('id',1));
            $note->setUltimaModificaData(date("Y-m-d G:i:s"));
            $note->saveOrUpdate();
        }
        else{
            return 'refresh';
        }

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

function ripristinaNota($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $note = new ContrattoNote($con);
        $note->findByPk($request->id);
        $note->setCestino('0');
        $note->setUltimaModificaUtente(getLoginDataFromSession('id',1));
        $note->setUltimaModificaData(date("Y-m-d G:i:s"));
        $note->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

function modificaNota($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        $note = new ContrattoNote($con);
        $note->findByPk($request->id);
        $result['titolo'] =$note->getTitolo();
        $result['descrizione'] =$note->getDescrizione();

        $result['status'] = 'ok';

        return json_encode($result);

    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

function aggiornaNota($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $note = new ContrattoNote($con);
        $note->findByPk($request->idNota);
        $note->setTitolo($request->obj->titolo);
        $note->setDescrizione($request->obj->descrizione);
        $note->setCestino('0');
        $note->setUltimaModificaUtente(getLoginDataFromSession('id',1));
        $note->setUltimaModificaData(date("Y-m-d G:i:s"));
        $note->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
