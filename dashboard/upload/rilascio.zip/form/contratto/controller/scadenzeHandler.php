<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 15/12/17
 * Time: 10.38
 */
require_once '../../../src/function/functionDate.php';

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';

require_once '../../../src/model/PeriodiContrattuali.php';
require_once '../../../src/model/TipiIva.php';
require_once '../../../src/model/RateDettagli.php';
require_once '../../../src/model/Rate.php';
require_once '../../../src/model/ContrattiConAnagrafiche.php';

use Click\Affitti\TblBase\PeriodiContrattuali;
use Click\Affitti\TblBase\TipiIva;
use Click\Affitti\TblBase\RateDettagli;
use Click\Affitti\TblBase\Rate;
use Click\Affitti\Viste\ContrattiConAnagrafiche;


function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $tmp = new PeriodiContrattuali($con);
        $result['periodi_contrattuali'] = $tmp->findByIdContrattoConDettagli($request->id,'rate',
            PeriodiContrattuali::FETCH_KEYARRAY);

        $result['rata_oggi'] = $tmp->findRataByToDay($request->id,PeriodiContrattuali::FETCH_KEYARRAY);

        $tipiIva = new TipiIva($con);
        $result['elencoTipiIva'] = $tipiIva->findAll(false, TipiIva::FETCH_KEYARRAY);

        $tipiSpesa = new RateDettagli($con);
        $result['elencoTipiSpesa'] = $tipiSpesa->getElencoTipiImporto(true);

        $rata = new Rate($con);
        $result['nuovaScadenza'] = $rata->getEmptyDbKeyArray();

        $anagrafiche = new ContrattiConAnagrafiche($con);
        $result['anagrafica_contratto'] = $anagrafiche->findByPk($request->id,ContrattiConAnagrafiche::FETCH_KEYARRAY);

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

function salvaRata($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $rata = new Rate($con);

        if(!(is_null($request->obj->id))) {
            $rata->findByPk($request->obj->id);
        }else{
            $rata->setIdGestione($request->obj->idGestione);
        }
        $rata->setDescrizione($request->obj->descrizione);
        $rata->setDataScadenza($request->obj->data_scadenza);
        $rata->setPeriodoInizio($request->obj->periodo_inizio);
        $rata->setPeriodoFine($request->obj->periodo_fine);

        $rata->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

function eliminaRata($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $rata = new Rate($con);
        $rata->deleteByPk($request->id);

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

function bloccaSbloccaRata($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $rate = new Rate($con);
        $rate->findByPk($request->id);
        $rate->setBloccata($request->stato);
        $rate->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
