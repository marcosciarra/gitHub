<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 05/01/18
 * Time: 9.10
 */

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';
require_once '../../../src/model/DrakkarTraceLog.php';
require_once '../../../src/function/functionLogin.php';

require_once '../../../src/model/Contratti.php';
require_once '../../../src/model/ContrattoAffitto.php';
require_once '../../../src/model/UnitaImmobiliariContratti.php';
require_once '../../../src/model/Rli.php';
require_once '../../../src/model/Gestioni.php';
require_once '../../../src/model/PianoRateTesta.php';

use Click\Affitti\TblBase\Contratti;
use Click\Affitti\Viste\ContrattoAffitto;
use Click\Affitti\TblBase\UnitaImmobiliariContratti;
use Click\Affitti\TblBase\Rli;
use Click\Affitti\TblBase\Gestioni;
use Click\Affitti\TblBase\PianoRateTesta;


function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $contrattoAffitto = new ContrattoAffitto($con);

        // CARICO DATI
        $contratti = new Contratti($con, $request->cestino);
        $uic = new UnitaImmobiliariContratti($con);

        $maxCanone = 0;

        $contratti->setWhereBase(" contratti.elaborato = 1 and contratti.cestino = 0 ");
        $contratti->setOrderBase(" data_inizio DESC");
        foreach ($contratti->getElencoContratti(true, Contratti::FETCH_KEYARRAY) as $contr) {
            $contr['contratti'] = $contr;
            $contr['elenco_ui'] = $uic->elencoImmobiliPerContratto($contr['id'], UnitaImmobiliariContratti::FETCH_KEYARRAY);
            $result['contratti'][] = $contr;
        }

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
