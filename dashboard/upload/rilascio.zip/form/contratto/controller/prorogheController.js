ngApp.controller("prorogheController", ["$scope", "$http", "$filter", function ($scope, $http, $filter) {

    var url = window.location.href;
    var params = decodeUrl(url);
    stampalog(params);

    $scope.caricamentoCompletato = false;

    /*--------------------------------------------------CARICA DATI---------------------------------------------------*/

    $scope.init = function () {

        $scope.elencoUtenti = [];
        $scope.elencoLocatori = [];
        $scope.elencoConduttori = [];
        $scope.elencoStabili = [];
        $scope.filtroUtenti = [];
        $scope.filtroStabili = [];
        $scope.filtroLocatori = [];
        $scope.filtroConduttori = [];
        $scope.caricaFiltri();


        $scope.dataVersamento = new Date();

        var d = new Date;
        var app = new Date(d.setDate(d.getDate()));
        var app = new Date(app.setMonth(app.getMonth()));
        $scope.filtroDataInizio = app;
        $http.post(params['form'] + '/template/controller/homeHandler.php',
            {
                'function': 'sommaData',
                'data_inizio': getYYYYMMGGFromJsDate($scope.filtroDataInizio)
            }
        ).then(function (data, status, headers, config) {
            $scope.filtroDataFine = getJsDateFromYYYYMMGG(data.data);
            $scope.selezionatiTutti = true;
            $scope.visualizzaArretrati = false;

            $scope.caricaDati();
        });


    };

    $scope.caricaDati = function () {
        $http.post(params['form'] + '/contratto/controller/prorogheHandler.php',
            {
                'function': 'caricaDati',
                'data_inizio': getYYYYMMGGFromJsDate($scope.filtroDataInizio),
                'data_fine': getYYYYMMGGFromJsDate($scope.filtroDataFine)
            }
        ).then(function (data, status, headers, config) {

            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }
            $scope.elencoContratti = [];
            stampalog(data.data);
            if (data.data.elenco != null) {
                for (var i = 0; i < data.data.elenco.length; i++) {
                    if (data.data.elenco[i].contribuente.ragione_sociale) {
                        data.data.elenco[i].contratto.contribuente = data.data.elenco[i].contribuente.ragione_sociale;
                    } else {
                        data.data.elenco[i].contratto.contribuente = data.data.elenco[i].contribuente.cognome + ' ' + data.data.elenco[i].contribuente.nome;
                    }
                    if (data.data.elenco[i].coobbligato.ragione_sociale) {
                        data.data.elenco[i].contratto.coobbligato = data.data.elenco[i].coobbligato.ragione_sociale;
                    } else {
                        data.data.elenco[i].contratto.coobbligato = data.data.elenco[i].coobbligato.cognome + ' ' + data.data.elenco[i].coobbligato.nome;
                    }
                    data.data.elenco[i].imposta_registro.dettagli = jsonParse(data.data.elenco[i].imposta_registro.dettagli);
                    data.data.elenco[i].imposta_registro.codice = data.data.elenco[i].imposta_registro.dettagli[0].codice;
                    if (data.data.elenco[i].contribuente.email != undefined)
                        data.data.elenco[i].contribuente.email = jsonParse(data.data.elenco[i].contribuente.email);
                    if (data.data.elenco[i].contribuente.indirizzi != undefined)
                        data.data.elenco[i].contribuente.indirizzi = jsonParse(data.data.elenco[i].contribuente.indirizzi);
                    if (data.data.elenco[i].contribuente.telefoni != undefined)
                        data.data.elenco[i].contribuente.telefoni = jsonParse(data.data.elenco[i].contribuente.telefoni);
                    if (data.data.elenco[i].contribuente.cellulari != undefined)
                        data.data.elenco[i].contribuente.cellulari = jsonParse(data.data.elenco[i].contribuente.cellulari);

                    data.data.elenco[i].selezionato = true;
                    data.data.elenco[i].contratto.proprietari = jsonParse(data.data.elenco[i].contratto.proprietari);
                    data.data.elenco[i].contratto.conduttori = jsonParse(data.data.elenco[i].contratto.conduttori);
                    $scope.elencoContratti.push(data.data.elenco[i]);
                }
            }
            $scope.arretrati = [];
            if (data.data.arretrati != null) {
                for (var i = 0; i < data.data.arretrati.length; i++) {
                    if (data.data.arretrati[i].contribuente.ragione_sociale) {
                        data.data.arretrati[i].contratto.contribuente = data.data.arretrati[i].contribuente.ragione_sociale;
                    } else {
                        data.data.arretrati[i].contratto.contribuente = data.data.arretrati[i].contribuente.cognome + ' ' + data.data.arretrati[i].contribuente.nome;
                    }
                    if (data.data.arretrati[i].coobbligato.ragione_sociale) {
                        data.data.arretrati[i].contratto.coobbligato = data.data.arretrati[i].coobbligato.ragione_sociale;
                    } else {
                        data.data.arretrati[i].contratto.coobbligato = data.data.arretrati[i].coobbligato.cognome + ' ' + data.data.arretrati[i].coobbligato.nome;
                    }
                    data.data.arretrati[i].imposta_registro.dettagli = jsonParse(data.data.arretrati[i].imposta_registro.dettagli);
                    data.data.arretrati[i].imposta_registro.codice = data.data.arretrati[i].imposta_registro.dettagli[0].codice;
                    if (data.data.arretrati[i].contribuente.email != undefined)
                        data.data.arretrati[i].contribuente.email = jsonParse(data.data.arretrati[i].contribuente.email);
                    if (data.data.arretrati[i].contribuente.indirizzi != undefined)
                        data.data.arretrati[i].contribuente.indirizzi = jsonParse(data.data.arretrati[i].contribuente.indirizzi);
                    if (data.data.arretrati[i].contribuente.telefoni != undefined)
                        data.data.arretrati[i].contribuente.telefoni = jsonParse(data.data.arretrati[i].contribuente.telefoni);
                    if (data.data.arretrati[i].contribuente.cellulari != undefined)
                        data.data.arretrati[i].contribuente.cellulari = jsonParse(data.data.arretrati[i].contribuente.cellulari);

                    data.data.arretrati[i].selezionato = false;
                    data.data.arretrati[i].contratto.proprietari = jsonParse(data.data.arretrati[i].contratto.proprietari);
                    data.data.arretrati[i].contratto.conduttori = jsonParse(data.data.arretrati[i].contratto.conduttori);
                    $scope.arretrati.push(data.data.arretrati[i]);
                }
            }

            //CARICAMENTO SELECT
            //Tipo contratto (Abitativo...)
            $scope.elencoTipiContratto = data.data.elencoTipiContratto;

            $scope.elencoCopia = angular.copy($scope.elencoContratti);
            $scope.arretratiCopia = angular.copy($scope.arretrati);

            $scope.caricamentoCompletato = true;
        });
    };

    /*---------------------------------------------------SALVA DATI---------------------------------------------------*/

    $scope.elaboraSelezionati = function () {
        stampalog('In elaborazione');
        stampalog($scope.elencoContrattiFiltrati);
        swal({
                title: "Elaborare i contratti selezionati?",
                text: "",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: "btn-danger",
                confirmButtonText: "Si, elabora!",
                cancelButtonText: "No, annulla!",
                closeOnConfirm: false,
                closeOnCancel: false,
                showLoaderOnConfirm: true
            },
            function (isConfirm) {
                if (isConfirm) {
                    $http.post(params['form'] + '/contratto/controller/prorogheHandler.php',
                        {
                            'function': 'elaboraSelezionati',
                            'dataVersamento': getYYYYMMGGFromJsDate($scope.dataVersamento),
                            'contratti': $scope.elencoContrattiFiltrati,
                            'arretrati': $scope.arretratiFiltrati
                        }
                    ).then(function (data, status, headers, config) {
                        stampalog(data.data);
                        if (data.data.status == "ok") {
                            swal({
                                title: "Creazione F24 conclusa!",
                                text: '',
                                type: "success"
                            }, function () {


                                $http.post(params['form'] + '/contratto/controller/prorogheHandler.php',
                                    {
                                        'function': 'elencoFlussi',
                                        'codiceFlusso': data.data.codiceFlusso
                                    }
                                ).then(function (data, status, headers, config) {

                                    if (data.data.status == 'ko') {
                                        swal(data.data.error.title, data.data.error.message, 'error');
                                        return;
                                    } else {
                                        stampalog(data.data.elencoFlussi);
                                        for (var i = 0; i < data.data.elencoFlussi.length; i++) {
                                            window.open(params['baseurl'] + '/stampe/proroghe/tabulatoF24Pdf.php?codiceFlusso=' + data.data.elencoFlussi[i].codice_flusso);
                                            window.open(params['baseurl'] + '/stampe/proroghe/f24Pdf.php?codiceFlusso=' + data.data.elencoFlussi[i].codice_flusso);
                                        }
                                        location.reload();
                                    }
                                });
                            });
                        } else {
                            swal("Elaborazione non riuscita", "", "error");
                        }
                    });
                } else {
                    swal("Elaborazione annullata", "", "error");
                }
            });
    };

    /* =================================== MODALE DETTAGLI ===================================================== */

    $scope.caricaDettagliModale = function (elenco, etichetta) {
        $scope.elencoModale = elenco;
        $scope.etichettaModale = etichetta;
    };

    /* =================================== FILTRI E ORDINAMENTI ===================================================== */

    $scope.stampaTipoContratto = function (id) {
        return $filter('filter')($scope.elencoTipiContratto, {id: id})[0].descrizione;
    };

    $scope.selezionaDeselezionaTutti = function (flag) {
        $scope.selezionatiTutti = flag;
        for (var i = 0; i < $scope.elencoContrattiFiltrati.length; i++) {
            $scope.elencoContrattiFiltrati[i].selezionato = flag;
        }
        for (var i = 0; i < $scope.arretrati.length; i++) {
            $scope.arretrati[i].selezionato = flag;
        }
    };

    $scope.filtri = function () {
        $scope.caricaDati();
    };

    $scope.vediArretrati = function () {
        /*
        var d = new Date();
        $scope.filtroDataInizio = d;
        $scope.caricaDati();
        */
        var contratti = angular.copy($scope.elencoContrattiFiltrati);
        var arretrati = angular.copy($scope.arretrati);
        $scope.elencoContrattiFiltrati = arretrati;
    };

    /*******************
     *   ESPORTA PDF   * ================================================================================================
     *******************/

    $scope.visualizzaImpoStampa = false;
    $scope.showImpostazioniStampa = function () {
        $scope.visualizzaImpoStampa = !$scope.visualizzaImpoStampa;
    };

    $scope.stampa = getStrutturaBasePDF();
    $scope.stampa.nomeFile = "ELENCO PROROGHE (F24)";

    $scope.getHeaderTable = function () {
        return ["CONTRATTO", "STABILE", "CONTRIBUENTE", "COOBBLIGATO", "ELIDE", "CODICE", "PROR./RIN.", "CANONE", "IMPORTO"];
    };

    $scope.creaFileDaScaricare = function () {
        $scope.fileExport = new Array();
        for (var i = 0; i < $scope.arretratiFiltrati.length; i++) {
            app = new Array();
            if ($scope.arretratiFiltrati[i].selezionato) {
                $scope.arretratiFiltrati[i].contratto.descrizione != null ? app.push("" + $scope.arretratiFiltrati[i].contratto.descrizione) : app.push("");
                if ($scope.arretratiFiltrati[i].immobili[0].stabili.descrizione != null) {
                    var codiceStabile = $scope.arretratiFiltrati[i].immobili[0].stabili.codice_stabile != null ? $scope.arretratiFiltrati[i].immobili[0].stabili.codice_stabile + " " : "";
                    var descrizioneStabile = $scope.arretratiFiltrati[i].immobili[0].stabili.descrizione != null ? $scope.arretratiFiltrati[i].immobili[0].stabili.descrizione : "";
                    app.push("" + codiceStabile + descrizioneStabile);
                } else {
                    app.push("");
                }
                $scope.arretratiFiltrati[i].contratto.contribuente != null ? app.push("" + $scope.arretratiFiltrati[i].contratto.contribuente) : app.push("");
                $scope.arretratiFiltrati[i].contratto.coobbligato != null ? app.push("" + $scope.arretratiFiltrati[i].contratto.coobbligato) : app.push("");
                $scope.arretratiFiltrati[i].elemento_identificativo != null ? app.push("" + $scope.arretratiFiltrati[i].elemento_identificativo) : app.push("");
                $scope.arretratiFiltrati[i].imposta_registro.codice != null ? app.push("" + $scope.arretratiFiltrati[i].imposta_registro.codice) : app.push("");
                var dataScad = getYYYYMMGGFromJsDate($scope.arretratiFiltrati[i].data_registrazione);
                dataScad != null ? app.push("" + stampaDataFormattata(dataScad)) : app.push("");
                $scope.arretratiFiltrati[i].canone != null ? app.push("" + $scope.arretratiFiltrati[i].canone.toLocaleString('it-IT', {
                    style: 'currency',
                    currency: 'EUR'
                })) : app.push("");
                $scope.arretratiFiltrati[i].imposta_registro.importo_totale != null ? app.push("" + $scope.arretratiFiltrati[i].imposta_registro.importo_totale.toLocaleString('it-IT', {
                    style: 'currency',
                    currency: 'EUR'
                })) : app.push("");
                $scope.fileExport.push(app);
            }
        }
        for (var i = 0; i < $scope.elencoContrattiFiltrati.length; i++) {
            app = new Array();
            if ($scope.elencoContrattiFiltrati[i].selezionato) {
                $scope.elencoContrattiFiltrati[i].contratto.descrizione != null ? app.push("" + $scope.elencoContrattiFiltrati[i].contratto.descrizione) : app.push("");
                if ($scope.elencoContrattiFiltrati[i].immobili[0].stabili.descrizione != null) {
                    var codiceStabile = $scope.elencoContrattiFiltrati[i].immobili[0].stabili.codice_stabile != null ? $scope.elencoContrattiFiltrati[i].immobili[0].stabili.codice_stabile + " " : "";
                    var descrizioneStabile = $scope.elencoContrattiFiltrati[i].immobili[0].stabili.descrizione != null ? $scope.elencoContrattiFiltrati[i].immobili[0].stabili.descrizione : "";
                    app.push("" + codiceStabile + descrizioneStabile);
                } else {
                    app.push("");
                }
                $scope.elencoContrattiFiltrati[i].contratto.contribuente != null ? app.push("" + $scope.elencoContrattiFiltrati[i].contratto.contribuente) : app.push("");
                $scope.elencoContrattiFiltrati[i].contratto.coobbligato != null ? app.push("" + $scope.elencoContrattiFiltrati[i].contratto.coobbligato) : app.push("");
                $scope.elencoContrattiFiltrati[i].elemento_identificativo != null ? app.push("" + $scope.elencoContrattiFiltrati[i].elemento_identificativo) : app.push("");
                $scope.elencoContrattiFiltrati[i].imposta_registro.codice != null ? app.push("" + $scope.elencoContrattiFiltrati[i].imposta_registro.codice) : app.push("");
                var dataScad = getYYYYMMGGFromJsDate($scope.elencoContrattiFiltrati[i].data_registrazione);
                dataScad != null ? app.push("" + stampaDataFormattata(dataScad)) : app.push("");
                $scope.elencoContrattiFiltrati[i].canone != null ? app.push("" + $scope.elencoContrattiFiltrati[i].canone.toLocaleString('it-IT', {
                    style: 'currency',
                    currency: 'EUR'
                })) : app.push("");
                $scope.elencoContrattiFiltrati[i].imposta_registro.importo_totale != null ? app.push("" + $scope.elencoContrattiFiltrati[i].imposta_registro.importo_totale.toLocaleString('it-IT', {
                    style: 'currency',
                    currency: 'EUR'
                })) : app.push("");
                $scope.fileExport.push(app);
            }
        }

        //stampalog("File da scaricare:");
        //stampalog($scope.fileExport);

        return $scope.fileExport;
    };

    $scope.scaricaPDF = function () {
        var title = 'ELENCO PROROGHE (F24)';
        title += ' - Imposte di registro in scadenda dal ' + stampaDataFormattata($scope.filtroDataInizio);
        title += ' al ' + stampaDataFormattata($scope.filtroDataFine);
        var elencoDaStampare = $scope.creaFileDaScaricare();
        if (elencoDaStampare.length > 0) {
            scaricaPDF($scope.stampa, $scope.getHeaderTable(), elencoDaStampare, title);
        } else {
            swal('Errore', 'Nessun contratto selezionato', 'error');
            return;
        }
    };

    stampaDataFormattata = function (data) {
        return $filter('date')(data, "dd/MM/yyyy");
    };

    /*---------------------------------------------------REDIRECT-----------------------------------------------------*/

    $scope.modificaRata = function (idContratto) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "rateizzazioneContratto", idContratto);
    };


    //---------------------------------------------------SEZIONE FILTRI-----------------------------------------------//
    $scope.caricaFiltri = function () {
        $http.post($scope.params['form'] + "/template/controller/homeHandler.php",
            {'function': 'caricaFiltri'}
        ).then(function (data, status, headers, config) {
            // stampalog(data.data);
            $scope.filtriSelectPagina = data.data;
        });
    };

    $scope.settings = {
        dynamicTitle: true,
        enableSearch: true,
        showSelectAll: false,
        keyboardControls: true,
        scrollable: true,
        showCheckAll: false,
        showUncheckAll: true,
        closeOnSelect: false,
        scrollableHeight: '300px',
        externalIdProp: '', //PERMETTE DI AGGIUNGERE ALL'ARRAY DEI SELEZIONATI TUTTO L'OGGETTO
        idProp: 'id', //definisco i campi di cui è composto l'oggetto
        displayProp: 'descrizione' //definisco i campi di cui è composto l'oggetto
    };
    $scope.customTextUtenti = {
        buttonDefaultText: 'Utenti',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextStabili = {
        buttonDefaultText: 'Stabili',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextLocatori = {
        buttonDefaultText: 'Locatori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextConduttori = {
        buttonDefaultText: 'Conduttori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.multiSelectEventUtenti = {
        onItemSelect: function (obj) {
            $scope.filtroUtenti.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroUtenti.length; i++) {
                if ($scope.filtroUtenti[i] == obj.id) {
                    $scope.filtroUtenti.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function () {
            $scope.filtroUtenti = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventStabili = {
        onItemSelect: function (obj) {
            $scope.filtroStabili.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroStabili.length; i++) {
                if ($scope.filtroStabili[i] == obj.id) {
                    $scope.filtroStabili.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroStabili = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventLocatori = {
        onItemSelect: function (obj) {
            $scope.filtroLocatori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroLocatori.length; i++) {
                if ($scope.filtroLocatori[i] == obj.id) {
                    $scope.filtroLocatori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroLocatori = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventConduttori = {
        onItemSelect: function (obj) {
            $scope.filtroConduttori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroConduttori.length; i++) {
                if ($scope.filtroConduttori[i] == obj.id) {
                    $scope.filtroConduttori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroConduttori = [];
            $scope.filtriGenerici();
        }
    };
    $scope.svuotaMultiselect = function () {
        $scope.multiSelectEventUtenti.onDeselectAll();
        $scope.multiSelectEventLocatori.onDeselectAll();
        $scope.multiSelectEventConduttori.onDeselectAll();
        $scope.multiSelectEventStabili.onDeselectAll();
        $scope.elencoUtenti = [];
        $scope.elencoLocatori = [];
        $scope.elencoConduttori = [];
        $scope.elencoStabili = [];
    };
    $scope.filtriGenerici = function () {

        $scope.elencoContratti = [];
        var flag;
        for (var i = 0; i < $scope.elencoCopia.length; i++) {
            flag = false;

            if ($scope.filtroUtenti.length == 0) {
                flag = true;
            } else {
                for (var k = 0; k < $scope.filtroUtenti.length; k++) {
                    if ($scope.elencoCopia[i].contratto.id_utente_riferimento == $scope.filtroUtenti[k]) {
                        flag = true;
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroStabili.length == 0) {
                    flag = true;
                } else {
                    flag = false;
                    for (var j = 0; j < $scope.elencoCopia[i].immobili.length; j++) {
                        for (var k = 0; k < $scope.filtroStabili.length; k++) {
                            if ($scope.elencoCopia[i].immobili[j].id_stabili == $scope.filtroStabili[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroLocatori.length == 0) {
                    flag = true;
                } else {
                    flag = false;
                    for (var j = 0; j < $scope.elencoCopia[i].contratto.proprietari.length; j++) {
                        for (var k = 0; k < $scope.filtroLocatori.length; k++) {
                            if ($scope.elencoCopia[i].contratto.proprietari[j].id == $scope.filtroLocatori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroConduttori.length == 0) {
                    flag = true;
                } else {
                    flag = false;
                    for (var j = 0; j < $scope.elencoCopia[i].contratto.conduttori.length; j++) {
                        for (var k = 0; k < $scope.filtroConduttori.length; k++) {
                            if ($scope.elencoCopia[i].contratto.conduttori[j].id == $scope.filtroConduttori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                $scope.elencoContratti.push($scope.elencoCopia[i]);
            }
        }

        $scope.arretrati = [];
        for (var i = 0; i < $scope.arretratiCopia.length; i++) {
            flag = false;

            if ($scope.filtroUtenti.length == 0) {
                flag = true;
            } else {
                for (var k = 0; k < $scope.filtroUtenti.length; k++) {
                    if ($scope.arretratiCopia[i].contratto.id_utente_riferimento == $scope.filtroUtenti[k]) {
                        flag = true;
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroStabili.length == 0) {
                    flag = true;
                } else {
                    flag = false;
                    for (var j = 0; j < $scope.arretratiCopia[i].immobili.length; j++) {
                        for (var k = 0; k < $scope.filtroStabili.length; k++) {
                            if ($scope.arretratiCopia[i].immobili[j].id_stabili == $scope.filtroStabili[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroLocatori.length == 0) {
                    flag = true;
                } else {
                    flag = false;
                    for (var j = 0; j < $scope.arretratiCopia[i].contratto.proprietari.length; j++) {
                        for (var k = 0; k < $scope.filtroLocatori.length; k++) {
                            if ($scope.arretratiCopia[i].contratto.proprietari[j].id == $scope.filtroLocatori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroConduttori.length == 0) {
                    flag = true;
                } else {
                    flag = false;
                    for (var j = 0; j < $scope.arretratiCopia[i].contratto.conduttori.length; j++) {
                        for (var k = 0; k < $scope.filtroConduttori.length; k++) {
                            if ($scope.arretratiCopia[i].contratto.conduttori[j].id == $scope.filtroConduttori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                $scope.arretrati.push($scope.arretratiCopia[i]);
            }
        }
    };


}])
;