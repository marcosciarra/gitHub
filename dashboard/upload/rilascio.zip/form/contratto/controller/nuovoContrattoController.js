ngApp.controller("nuovoContrattoController", ["$scope", "$http", "$filter", "ngToast", function ($scope, $http, $filter, $ngToast) {

    var url = window.location.href;
    var params = decodeUrl(url, 'id');

    /* ============================================= CARICA DATI ==================================================== */
    $scope.init = function () {
        $scope.inizializzaForm();
        $scope.caricaDati();
        $scope.canonePresente = false;
        $scope.spesaPresente = false;
    };

    $scope.inizializzaForm = function () {
        $scope.caricamentoCompletato = false;

        $scope.comodatoGratuito=0;

        $scope.unitaImmobiliariContratti = [];
        $scope.contrattoAffitto = null;

        $scope.schedaSpese = 0;
        $scope.MostraPulsantiCanoniOneri = false;
        $scope.mostraPulsantiUnitaImmobiliare = false;
        $scope.mostraPulsantiCauzione = false;
        $scope.status = 1;
        $scope.styleStatus1 = 'active';

        //PREPARO DATI PER SELECT IN PAGINA
        $scope.tipo_assoggettazione = [
            {id: 'N', descrizione: 'NON ASSOGGETTATO AD IVA'},
            {id: 'S', descrizione: 'ASSOGGETTATO AD IVA'}
        ];
        $scope.tipo_pagamento = [
            {id: 'A', descrizione: 'ANTICIPATA'},
            {id: 'P', descrizione: 'POSTICIPATA'}
        ];
        $scope.tabelle_istat = [
            {id: 'foi', descrizione: 'FOI'}
        ];
        $scope.noIstat = false;
        $scope.tipo_istat = [
            {id: 'a75', descrizione: 'ANNUALE 75%'},
            {id: 'a100', descrizione: 'ANNUALE 100%'}
            // {id: 'a75', descrizione: 'ANNUALE 75%'},
            // {id: 'a100', descrizione: 'ANNUALE 100%'},
            // {id: 'b75', descrizione: 'BIENNALE 75%'},
            // {id: 'b100', descrizione: 'BIENNALE 100%'}
        ];
        $scope.mesi_istat = [
            {id: '0', descrizione: 'NO ISTAT'},
            {id: '1', descrizione: 'GENNAIO'},
            {id: '2', descrizione: 'FEBBRAIO'},
            {id: '3', descrizione: 'MARZO'},
            {id: '4', descrizione: 'APRILE'},
            {id: '5', descrizione: 'MAGGIO'},
            {id: '6', descrizione: 'GIUGNO'},
            {id: '7', descrizione: 'LUGLIO'},
            {id: '8', descrizione: 'AGOSTO'},
            {id: '9', descrizione: 'SETTEMBRE'},
            {id: '10', descrizione: 'OTTOBRE'},
            {id: '11', descrizione: 'NOVEMBRE'},
            {id: '12', descrizione: 'DICEMBRE'}
        ];
        $scope.mesi_conguaglio_istat = [
            {id: '0', descrizione: '0 MESI'},
            {id: '1', descrizione: '1 MESE'},
            {id: '2', descrizione: '2 MESI'},
            {id: '3', descrizione: '3 MESI'},
            {id: '4', descrizione: '4 MESI'},
            {id: '5', descrizione: '5 MESI'},
            {id: '6', descrizione: '6 MESI'},
            {id: '7', descrizione: '7 MESI'},
            {id: '8', descrizione: '8 MESI'},
            {id: '9', descrizione: '9 MESI'},
            {id: '10', descrizione: '10 MESI'},
            {id: '11', descrizione: '11 MESI'},
            {id: '12', descrizione: '12 MESI'}
        ];
        $scope.tipo_gestione = [
            {id: 'CS', descrizione: 'GESTIONE COMPLETA'},
            {id: 'S', descrizione: 'RISCOSSIONE CANONE'},
            {id: 'C', descrizione: 'GESTIONE CONTRATTO'}
        ];
        $scope.tipoScadenza = [
            {id: '0', descrizione: 'SCADENZE PERIODO CONTRATTUALE'},
            {id: '1', descrizione: 'SCADENZE PERIODO SOLARE'}
        ];
        $scope.tipoRimessa = [
            {id: 'N', descrizione: 'NESSUNA RIMESSA'},
            {id: 'P', descrizione: 'PERCENTUALE SU CANONE ANNUO'},
            {id: 'Q', descrizione: 'QUOTA FISSA'}
        ];
        $scope.numero_rate = [
            {id: '1', descrizione: '1'},
            {id: '2', descrizione: '2'},
            {id: '3', descrizione: '3'},
            {id: '4', descrizione: '4'},
            {id: '6', descrizione: '6'},
            {id: '12', descrizione: '12'}
        ];
        $scope.elenco_tipo_restituzione_interessi = [
            {id: 'N', descrizione: 'NESSUN CALCOLO'},
            {id: 'A', descrizione: 'ANNUALI'},
            {id: 'C', descrizione: 'RISOLUZIONE (CAPITALE)'},
            {id: 'V', descrizione: 'RISOLUZIONE (VERSATO)'}
        ];
        $scope.pagamento_imposta_registro = [
            {id: '0', descrizione: 'RICHIESTA ANNUALE'},
            {id: '1', descrizione: 'RICHIESTA UNA TANTUM'}
        ];
        $scope.tipo_pagamento_imposta = [
            {id: 'A', descrizione: 'ANTICIPATA'},
            {id: 'P', descrizione: 'POSTICIPATA'}
        ];
        $scope.speseUnitaImmobiliari = [
            {id: 0, descrizione: 'GENERICA'}
        ];

    };

    $scope.unisciPropInqGara = function () {
        $scope.personeInteressate = [];
        if ($scope.contrattoAffitto.contratto.proprietari != null) {
            for (var i = 0; i < $scope.contrattoAffitto.contratto.proprietari.length; i++) {
                $scope.personeInteressate.push($scope.contrattoAffitto.contratto.proprietari[i]);
            }
        }
        if ($scope.contrattoAffitto.contratto.conduttori != null) {
            for (var i = 0; i < $scope.contrattoAffitto.contratto.conduttori.length; i++) {
                $scope.personeInteressate.push($scope.contrattoAffitto.contratto.conduttori[i]);
            }
        }
        if ($scope.contrattoAffitto.contratto.garanti != null) {
            for (var i = 0; i < $scope.contrattoAffitto.contratto.garanti.length; i++) {
                $scope.personeInteressate.push($scope.contrattoAffitto.contratto.garanti[i]);
            }
        }
    };

    /*---------------------------------------------------CARICA DATI--------------------------------------------------*/

    $scope.caricaDati = function () {
        $http.post(params['form'] + '/contratto/controller/nuovoContrattoHandler.php',
            {
                'function': 'caricaDati',
                'id': params['id']
            }
        ).then(function (data, status, headers, config) {

            stampalog(data.data.status);
            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }

            stampalog('Carico Dati');
            stampalog(data.data);

            //Oggetto Canone globale
            $scope.contrattoAffitto = data.data.contrattoAffitto;
            //Unità immobiliare
            $scope.unitaImmobiliari = data.data.unitaImmobiliariContratti;
            $scope.unitaImmobiliariEmpty = angular.copy(data.data.unitaImmobiliariContratti);
            //Canone e Oneri
            $scope.spesa = data.data.spesa;
            $scope.spesaEmpty = angular.copy(data.data.spesa);
            //Cauzioni
            $scope.cauzioni = data.data.cauzioni;
            $scope.cauzioniEmpty = angular.copy(data.data.cauzioni);

            //NORMALIZZO JSON DELLE ANAGRAFICHE
            if (data.data.contrattoAffitto.contratto.proprietari != null) {
                $scope.contrattoAffitto.contratto.proprietari = jsonParse(data.data.contrattoAffitto.contratto.proprietari);
            }
            else {
                $scope.contrattoAffitto.contratto.proprietari = [];
            }
            if (data.data.contrattoAffitto.contratto.conduttori != null) {
                $scope.contrattoAffitto.contratto.conduttori = jsonParse(data.data.contrattoAffitto.contratto.conduttori);
            }
            else {
                $scope.contrattoAffitto.contratto.conduttori = [];
            }
            if (data.data.contrattoAffitto.contratto.garanti != null) {
                $scope.contrattoAffitto.contratto.garanti = jsonParse(data.data.contrattoAffitto.contratto.garanti);
            }
            else {
                $scope.contrattoAffitto.contratto.garanti = [];
            }


            //====================
            //CARICAMENTO SELECT
            //====================
            //Tipo contratto (Abitativo...)
            $scope.elencoTipiContratto = data.data.elencoTipiContratto;
            //Intestatari
            $scope.elencoAnagrafica = data.data.elencoAnagrafica;
            //Unità Immobiliari

            //fixme: fix temporaneo per cardani
           // $scope.elencoUnitaImmobiliari = data.data.elencoUnitaImmobiliari;
            // $scope.elencoUnitaImmobiliari = data.data.elencoUnitaImmobiliariElenco;

            $scope.elencoUnitaImmobiliariElenco = data.data.elencoUnitaImmobiliariElenco;

            //Tipologie di spese (canone e oneri)
            $scope.elencoTipiSpesa = data.data.elencoTipiSpesa;
            $scope.elencoTipiSaldo = data.data.elencoTipiSaldo;
            //TipiCauzione
            $scope.elencoTipiCauzione = data.data.elencoTipiCauzione;
            //Agenzia Immobiliare
            $scope.elencoAgenziaImmobiliare = data.data.elencoAgenziaImmobiliare;
            //Tipi IVA
            $scope.elencoTipiIva = data.data.elencoTipiIva;
            //Gruppi fatturazione
            $scope.gruppiFat = data.data.gruppiFat;
            $scope.gruppiFatBackup = angular.copy(data.data.gruppiFat);
            //Tipi cedolare secca
            $scope.elencoTipiCedolareSecca = data.data.elencoTipiCedolareSecca;
            //Codici Coobbligati
            $scope.elencoCodiciCoobbligati = data.data.elencoCoobbligati;
            //Elenco tipi imposte
            $scope.elencoTipoImposte = data.data.elencoTipoImposte;
            //Elenco utenti
            $scope.elencoUtenti = data.data.elencoUtenti;
            //Elenco tipi pagamento
            $scope.elencoTipiPagamento = data.data.elencoTipiPagamento;
            //====================

            if ($scope.gruppiFat == null) {
                swal({
                        title: "Impossibile procedere",
                        text: "Creare almeno un gruppo di fatturazione",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-success",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.href = $scope.params['home'] + encodeUrl("configurazioni", "gruppiAvvisoPagamento");
                    });
            }
            $scope.elencoUnitaImmobiliari = [];
            $scope.unitaImmobiliareSelezionata = [];
            //PRESET
            if (params['id'] === undefined) {
                $scope.contrattoAffitto.contratto.id_tipo_contratto = 1;
                $scope.cambiaTipoContratto($scope.contrattoAffitto.contratto.id_tipo_contratto);
                $scope.contrattoAffitto.contratto.tipoFatturazione = 'A';
                $scope.contrattoAffitto.contrattiDettagli.tipo_tabella_istat = 'foi';
                $scope.contrattoAffitto.contrattiDettagli.colonna_tabella_istat =
                    (tipoContratto($scope.contrattoAffitto.contratto.id_tipo_contratto) == 'A') ? 'a75' : 'a100';
                $scope.contrattoAffitto.contratto.tipo_gestione = 'CS';
                $scope.contrattoAffitto.contrattiDettagli.tipo_rimessa = 'N';
                $scope.contrattoAffitto.contrattiDettagli.bollettazione_tipo = 'A';
                $scope.contrattoAffitto.contratto.data_inizio = new Date(today());
                $scope.contrattoAffitto.contratto.data_stipula = new Date(today());
                $scope.contrattoAffitto.contrattiPreferenze.tipo_scadenza = '1';
                $scope.controllaTipoScadenza();

                $scope.contrattoAffitto.contrattiDettagli.data_consegna_chiavi = new Date(today());

                if ($scope.elencoAgenziaImmobiliare != '') {
                    $scope.contrattoAffitto.contratto.id_agenzia_immobiliare = $scope.elencoAgenziaImmobiliare[0].id;
                    $scope.aggiornaGruppoFatturazione($scope.contrattoAffitto.contratto.id_agenzia_immobiliare);
                }
                else {
                    swal("Errore", "Censire almeno una società di fatturazione", "error");
                    return;
                }

                $scope.unitaImmobiliari.percentuale = 100;
                $scope.spesa.tipo_spesa = 'C';
                $scope.spesa.tipo_saldo = 'F';
                $scope.spesa.numero_rate = '4';
                $scope.spesa.id_tipi_iva = 1;
                $scope.spesa.imponibile = 0;
                $scope.spesa.importo = 0;
                $scope.spesa.id_unita_immobiliari = 0;

                $scope.contrattoAffitto.contrattiPreferenze.imposta_registro_perc_locatore = '50';
                $scope.contrattoAffitto.contrattiDettagli.data_registrazione = new Date(today());
                $scope.contrattoAffitto.rli.pagamento_una_tantum = '0';
                $scope.contrattoAffitto.rli.cedolare_secca = $scope.contrattoAffitto.rli.cedolare_secca * 1;
                $scope.contrattoAffitto.rli.tipo_contratto_rli = 'L1';
                $scope.contrattoAffitto.contratto.id_utente_riferimento = 0;
            }
            else {
                if ($scope.contrattoAffitto.contratto.data_stipula != null) {
                    $scope.contrattoAffitto.contratto.data_stipula = new Date($scope.contrattoAffitto.contratto.data_stipula);
                }
                if ($scope.contrattoAffitto.contratto.data_inizio != null) {
                    $scope.contrattoAffitto.contratto.data_inizio = new Date($scope.contrattoAffitto.contratto.data_inizio);
                }
                if ($scope.contrattoAffitto.contrattiDettagli.data_consegna_chiavi != null) {
                    $scope.contrattoAffitto.contrattiDettagli.data_consegna_chiavi = new Date($scope.contrattoAffitto.contrattiDettagli.data_consegna_chiavi);
                }
                if ($scope.contrattoAffitto.contrattiDettagli.data_registrazione != null) {
                    $scope.contrattoAffitto.contrattiDettagli.data_registrazione = new Date($scope.contrattoAffitto.contrattiDettagli.data_registrazione);
                }
                if ($scope.contrattoAffitto.contrattiPreferenze.data_scadenza_raccordo != null) {
                    $scope.contrattoAffitto.contrattiPreferenze.data_scadenza_raccordo = new Date($scope.contrattoAffitto.contrattiPreferenze.data_scadenza_raccordo);
                }
                $scope.contrattoAffitto.contratto.id_tipo_contratto = data.data.contrattoAffitto.contratto.id_tipo_contratto;
                $scope.unitaImmobiliari.percentuale = 100;

                $scope.spesa.numero_rate = '4';
                $scope.spesa.id_tipi_iva = 1;

                //Normalizzazione di Array dei canoni oneri
                for (var i = 0; i < $scope.contrattoAffitto.canoniOneri.length; i++) {
                    $scope.contrattoAffitto.canoniOneri[i].rateizzazione = jsonParse($scope.contrattoAffitto.canoniOneri[i].rateizzazione);
                    for (var j = 0; j < $scope.contrattoAffitto.canoniOneri[i].rateizzazione.length; j++) {
                        $scope.contrattoAffitto.canoniOneri[i].rateizzazione[j].dataScadenza = new Date($scope.contrattoAffitto.canoniOneri[i].rateizzazione[j].dataScadenza);
                    }
                }
                $scope.contrattoAffitto.contrattiPreferenze.tipo_scadenza = '' + $scope.contrattoAffitto.contrattiPreferenze.tipo_scadenza;
                $scope.contrattoAffitto.contrattiDettagli.bollettazione_tipo = '' + $scope.contrattoAffitto.contrattiDettagli.bollettazione_tipo;

                for (var i = 0; i < $scope.contrattoAffitto.unitaImmobiliariContratti.length; i++) {
                    $scope.speseUnitaImmobiliari.push(
                        {
                            id: $scope.contrattoAffitto.unitaImmobiliariContratti[i].id_unita_immobiliare,
                            descrizione: $scope.stampaNome($scope.contrattoAffitto.unitaImmobiliariContratti[i].id_unita_immobiliare)
                        }
                    );
                }
                $scope.spesa.id_unita_immobiliari = 0;
                $scope.contrattoAffitto.contratto.id_utente_riferimento = data.data.contrattoAffitto.contratto.id_utente_riferimento;
                $scope.contrattoAffitto.rli.cedolare_secca = 1 * $scope.contrattoAffitto.rli.cedolare_secca;

                $scope.unitaImmobiliareSelezionata = [];
                for (var i = 0; i < $scope.contrattoAffitto.contratto.proprietari.length; i++) {
                    $scope.caricaUI($scope.contrattoAffitto.contratto.proprietari[i].id);
                }

            }
            $scope.contrattoAffitto.contrattiDettagli.quota_rimessa = parseInt($scope.contrattoAffitto.contrattiDettagli.quota_rimessa);
            $scope.contrattoAffitto.contrattiPreferenze.imposta_registro_perc_locatore = '' + $scope.contrattoAffitto.contrattiPreferenze.imposta_registro_perc_locatore;
            $scope.contrattoAffitto.rli.pagamento_una_tantum = '' + $scope.contrattoAffitto.rli.pagamento_una_tantum;
            $scope.cauzioni.tipo_restituzione_interessi = 'N';
            $scope.contrattoAffitto.contrattiDettagli.id_gruppo_fatturazione = $scope.gruppiFat[0]['id'];
            $scope.contrattoAffitto.contrattiDettagli.bollo_registrazione=$scope.contrattoAffitto.contrattiDettagli.bollo_registrazione*1;

            $scope.calcolaPeriodo();
            $scope.leggiAnno();
            $scope.calcolaMesiConguaglio();
            $scope.controllaAssoggettazione();
            $scope.caricaContiCorrente();

            $scope.caricamentoCompletato = true;
        });
    };

    $scope.caricaContiCorrente = function () {
        elencoContiCorrente = [];

        elencoContiCorrente.push($scope.contrattoAffitto.contratto.id_agenzia_immobiliare);
        if ($scope.contrattoAffitto.contratto.proprietari != null) {
            for (var i = 0; i < $scope.contrattoAffitto.contratto.proprietari.length; i++) {
                elencoContiCorrente.push($scope.contrattoAffitto.contratto.proprietari[i].id);
            }
        }

        $http.post(params['form'] + '/contratto/controller/nuovoContrattoHandler.php',
            {
                'function': 'caricaElencoBancheContratto',
                'arrayId': elencoContiCorrente
            }
        ).then(function (data, status, headers, config) {
            $scope.elencoContiCorrente = data.data.elencoContiCorrente;
            if ($scope.elencoContiCorrente.length == 1) {
                $scope.contrattoAffitto.contrattiDettagli.id_conto_corrente = $scope.elencoContiCorrente[0].id;
                $scope.contrattoAffitto.rli.id_conto_corrente = $scope.elencoContiCorrente[0].id;
            }
        });
    };


    $scope.controllaTipoScadenza = function () {
        if ($scope.contrattoAffitto.contrattiPreferenze.tipo_scadenza == '1') {
            var anno = $scope.contrattoAffitto.contratto.data_inizio.getFullYear();
            $scope.contrattoAffitto.contrattiPreferenze.data_prima_scadenza = new Date(anno, 0, 1);
        }
        else {
            $scope.contrattoAffitto.contrattiPreferenze.data_prima_scadenza = $scope.contrattoAffitto.contratti.data_inizio;
        }
    };


    $scope.controllaTipoRichiesta = function () {
        if ($scope.contrattoAffitto.contratto.tipo_pagamento_rata == 'P' && $scope.contrattoAffitto.contrattiPreferenze.tipo_scadenza == '2') {
            $scope.contrattoAffitto.contrattiPreferenze.tipo_scadenza = '1';
        }
    };


    $scope.cambiaTipoContratto = function (id) {
        for (var i = 0; i < $scope.elencoTipiContratto.length; i++) {
            if ($scope.elencoTipiContratto[i].id == id) {
                $scope.contrattoAffitto.contratto.mesi_preavviso_locatore = $scope.elencoTipiContratto[i].preavviso_locatore;
                $scope.contrattoAffitto.contratto.mesi_preavviso_conduttore = $scope.elencoTipiContratto[i].preavviso_conduttore;
                if ($scope.elencoTipiContratto[i].percentuale_istat == 'NI') {
                    $scope.noIstat = true;
                    $scope.contrattoAffitto.contrattiDettagli.mese_riferimento_istat = "0";
                    $scope.contrattoAffitto.contrattiDettagli.mesi_conguaglio_istat = "0";
                } else {
                    $scope.contrattoAffitto.contrattiDettagli.colonna_tabella_istat = ($scope.elencoTipiContratto[i].tipo_uso == 'A') ? 'a75' : 'a100';
                    $scope.noIstat = false;
                }
                $scope.tipoIstat = $scope.elencoTipiContratto[i].percentuale_istat;
                return;
            }
        }
    };

    function tipoContratto(id) {
        for (var i = 0; i < $scope.elencoTipiContratto.length; i++) {
            if ($scope.elencoTipiContratto[i].id == id) {
                return $scope.elencoTipiContratto[i].tipo_uso;
            }
        }
    }

    function calcolaScadenza(dataPartenza, numeroRate, rataRichiesta) {

        var dataAppoggio = new Date(dataPartenza);
        var mesiDaSommare = 1;
        if (rataRichiesta < 1) rataRichiesta = 1;
        if ($scope.contrattoAffitto.contratto.tipo_pagamento_rata == 'A') rataRichiesta--;
        switch (numeroRate) {
            case '1':
                if (rataRichiesta > 1) rataRichiesta = 1;
                mesiDaSommare = 12 * rataRichiesta;
                break;
            case '2':
                if (rataRichiesta > 2) rataRichiesta = 2;
                mesiDaSommare = 6 * rataRichiesta;
                break;
            case '3':
                if (rataRichiesta > 3) rataRichiesta = 3;
                mesiDaSommare = 4 * rataRichiesta;
                break;
            case '4':
                if (rataRichiesta > 4) rataRichiesta = 4;
                mesiDaSommare = 3 * rataRichiesta;
                break;
            case '6':
                if (rataRichiesta > 6) rataRichiesta = 6;
                mesiDaSommare = 2 * rataRichiesta;
                break;
            case '12':
                if (rataRichiesta > 12) rataRichiesta = 12;
                mesiDaSommare = 1 * rataRichiesta;
                break;
        }
        if ($scope.contrattoAffitto.contratto.tipo_pagamento_rata == 'A') {
            var dataReturn = new Date(dataAppoggio.setMonth(dataAppoggio.getMonth() + mesiDaSommare));
        }
        else {
            dataAppoggio.setMonth(dataAppoggio.getMonth() + mesiDaSommare);
            dataAppoggio.setDate(dataAppoggio.getDate() - 1);
            var dataReturn = new Date(dataAppoggio);
        }
        return dataReturn;
    }

    /* ========================================= CANONI ED ONERI ==================================================== */


    $scope.cambiaScheda = function (tab) {
        $scope.schedaSpese = tab;
    };

    $scope.calcolaMesiConguaglio = function () {

        // var mesePrimaScadenza = 1 * (getYYYYMMGGFromJsDate($scope.contrattoAffitto.contrattiPreferenze.data_prima_scadenza).substr(5, 2));
        // var meseRiferimento = 1 * $scope.contrattoAffitto.contrattiDettagli.mese_riferimento_istat;
        // if (meseRiferimento > mesePrimaScadenza) {
        //     mesePrimaScadenza = mesePrimaScadenza + 12;
        // }
        // $scope.contrattoAffitto.contrattiDettagli.mesi_conguaglio_istat = (mesePrimaScadenza - meseRiferimento + 1).toString();
        $scope.contrattoAffitto.contrattiDettagli.mesi_conguaglio_istat = '1';
    };

    $scope.aggiungiSpesa = function () {
        //Da eliminare perchè prenderò la struttura dal db
        $strutturaBase = {nomeRata: '', dataScadenza: '', percentuale: ''};
        $scope.spesa.rateizzazione = [];
        for (var i = 0; i < $scope.spesa.numero_rate; i++) {

            $strutturaRateizzazione = angular.copy($strutturaBase);

            $strutturaRateizzazione.nomeRata = 'Rata ' + (i + 1);
            $strutturaRateizzazione.dataScadenza =
                calcolaScadenza(
                    $scope.contrattoAffitto.contrattiPreferenze.data_prima_scadenza,
                    $scope.spesa.numero_rate,
                    (i + 1)
                );
            switch ($scope.spesa.numero_rate) {
                case '1':
                    $strutturaRateizzazione.percentuale = 100;
                    break;
                case '2':
                    $strutturaRateizzazione.percentuale = 50;
                    break;
                case '3':
                    $strutturaRateizzazione.percentuale = ((i + 1) == $scope.spesa.numero_rate) ? 33.3334 : 33.3333;
                    break;
                case '4':
                    $strutturaRateizzazione.percentuale = 25;
                    break;
                case '6':
                    $strutturaRateizzazione.percentuale = ((i + 1) == $scope.spesa.numero_rate) ? 16.667 : 16.6666;
                    break;
                case '12':
                    $strutturaRateizzazione.percentuale = ((i + 1) == $scope.spesa.numero_rate) ? 8.3337 : 8.3333;
                    break;
            }
            $scope.spesa.rateizzazione.push($strutturaRateizzazione);
        }
        $scope.contrattoAffitto.canoniOneri.push($scope.spesa);
        $scope.schedaSpese = $scope.contrattoAffitto.canoniOneri.length - 1;
        $scope.spesa = angular.copy($scope.spesaEmpty);
        $scope.spesa.imponibile = 0;
        $scope.spesa.importo = 0;
        $scope.spesa.numero_rate = '4';
        $scope.spesa.id_tipi_iva = 1;
        $scope.spesa.id_unita_immobiliari = 0;
        $scope.spesa.tipo_spesa = 'O';
        $scope.spesa.tipo_saldo = 'C';
        $scope.MostraPulsantiCanoniOneri = false;
    };

    $scope.eliminaSpesa = function (spesa) {
        var spesaDaEliminare = $scope.contrattoAffitto.canoniOneri.indexOf(spesa);
        $scope.contrattoAffitto.canoniOneri.splice(spesaDaEliminare, 1);
        $ngToast.create({className: 'success', content: 'Spesa eliminata!', dismissButton: true, timeout: 1500});
    };

    $scope.controllaPresenzaCanoni = function () {
        if ($scope.contrattoAffitto.canoniOneri != null) {
            $scope.canonePresente = false;
            $scope.spesaPresente = false;

            for (var i = 0; i < $scope.contrattoAffitto.canoniOneri.length; i++) {
                if ($scope.contrattoAffitto.canoniOneri[i].tipo_spesa == "C") {
                    $scope.canonePresente = true;
                }
                if ($scope.contrattoAffitto.canoniOneri[i].tipo_spesa == "O") {
                    $scope.spesaPresente = true;
                }
            }
        }
    };

    /* ======================================= UNITA IMMOBILIARE ==================================================== */

    $scope.aggiungiUnitaImmobiliare = function () {
        $scope.contrattoAffitto.unitaImmobiliariContratti.push($scope.unitaImmobiliari);
        $scope.speseUnitaImmobiliari.push(
            {
                id: $scope.unitaImmobiliari.id_unita_immobiliare,
                descrizione: $scope.stampaNome($scope.unitaImmobiliari.id_unita_immobiliare)
            }
        );
        $scope.unitaImmobiliareSelezionata = [];
        $scope.unitaImmobiliari = angular.copy($scope.unitaImmobiliariEmpty);
        $scope.mostraPulsantiUnitaImmobiliare = false;
        $scope.unitaImmobiliari.percentuale = 100;
    };

    $scope.eliminaUnitaImmobiliare = function (uic) {
        var flag = false;
        for (var i = 0; i < $scope.contrattoAffitto.unitaImmobiliariContratti.length; i++) {
            if ($scope.contrattoAffitto.unitaImmobiliariContratti[i].id_unita_immobiliare == uic.id_unita_immobiliare) {
                var uicDaEliminare = i;
                flag = true;
                break;
            }
        }
        if (flag) {
            flag = false;
            for (var i = 0; i < $scope.contrattoAffitto.canoniOneri.length; i++) {
                if ($scope.contrattoAffitto.canoniOneri[i].id_unita_immobiliari == uic.id_unita_immobiliare) {
                    flag = true;
                    break;
                }
            }
            if (flag) {
                swal("Errore", "Impossibile eliminare l'unità immobiliare.\nUna o più spese sono associate all'unità immobiliare.", "error");
                return;
            }
            else {
                for (var i = 0; i < $scope.speseUnitaImmobiliari.length; i++) {
                    if ($scope.speseUnitaImmobiliari[i].id == uic.id_unita_immobiliare) {
                        $scope.speseUnitaImmobiliari.splice(i, 1);
                        $scope.contrattoAffitto.unitaImmobiliariContratti.splice(uicDaEliminare, 1);
                    }
                }
                $ngToast.create({
                    className: 'success',
                    content: 'Unità immobiliare eliminata',
                    dismissButton: true,
                    timeout: 1500
                });
            }
        }
    };


    /* ============================================= CAUZIONI ======================================================= */

    $scope.aggiungiCauzione = function () {
        $scope.contrattoAffitto.cauzioni.push($scope.cauzioni);
        $scope.cauzioni = angular.copy($scope.cauzioniEmpty);
        $scope.cauzioni.tipo_restituzione_interessi = 'N';
        $scope.mostraPulsantiCauzione = false;
    };

    $scope.eliminaCauzione = function (cauzione) {
        var cauzioneDaEliminare = $scope.contrattoAffitto.cauzioni.indexOf(cauzione);
        $scope.contrattoAffitto.cauzioni.splice(cauzioneDaEliminare, 1);
        $ngToast.create({className: 'success', content: 'Cauzione eliminata', dismissButton: true, timeout: 1500});
    };


    /* ========================================== CONTROLLI DI FORM ================================================= */

    $scope.presettaTipoSaldo = function () {
        if ($scope.spesa.tipo_spesa == 'C') {
            $scope.spesa.tipo_saldo = 'F';
        } else if ($scope.spesa.tipo_spesa == 'O') {
            $scope.spesa.tipo_saldo = 'C';
        }
    };

    $scope.controllaCampiCanoniOneri = function () {

        if ($scope.spesa.tipo_saldo != '' &&
            $scope.spesa.tipo_spesa != '' &&
            $scope.spesa.descrizione != '' &&
            $scope.spesa.numero_rate != '' &&
            $scope.spesa.numero_rate > 0 &&
            $scope.spesa.numero_rate < 13 &&
            $scope.spesa.importo != '' &&
            $scope.spesa.importo > 0) {
            $scope.MostraPulsantiCanoniOneri = true;
        }
        else {
            $scope.MostraPulsantiCanoniOneri = false;
        }
    };

    //CONTROLLO UNITA' IMMOBILIARI COLLEGATE

    $scope.controllaCampiUnitaImmobiliare = function () {

        if ($scope.unitaImmobiliareSelezionata != '' &&
            $scope.percentualeUnitaImmobiliareSelezionata != '' &&
            $scope.percentualeUnitaImmobiliareSelezionata > 0 &&
            $scope.percentualeUnitaImmobiliareSelezionata < 101
        ) {
            $scope.mostraPulsantiUnitaImmobiliare = true;
        }
        else {
            $scope.mostraPulsantiUnitaImmobiliare = false;
        }
    };

    //CONTROLLO CAUZIONI

    $scope.controllaCauzione = function () {
        if ($scope.cauzioni.id_tipo_cauzione != '' &&
            $scope.cauzioni.id_tipo_cauzione != undefined &&
            $scope.cauzioni.descrizione != '' &&
            $scope.cauzioni.data_cauzione != '' &&
            $scope.cauzioni.data_cauzione != undefined &&
            $scope.cauzioni.importo > 0
        ) {
            $scope.mostraPulsantiCauzione = true;
        }
        else {
            $scope.mostraPulsantiCauzione = false;
        }
    };

    $scope.leggiAnno = function () {
        var dataAppoggio = new Date($scope.contrattoAffitto.contrattiDettagli.data_registrazione);
        $scope.contrattoAffitto.rli.anno_stipula = dataAppoggio.getFullYear().toString();
        var dataAppoggio = new Date($scope.contrattoAffitto.contratto.data_inizio);
        $scope.contrattoAffitto.contrattiDettagli.mese_riferimento_istat = (dataAppoggio.getMonth()).toString();

    };

    $scope.controllaAssoggettazione = function () {
        var tipo = $scope.contrattoAffitto.contratto.tipo_assoggettazione;
        $scope.tipoRichiesta = [];

        if (tipo == 'N') {
            $scope.flag_tipo_assoggettazione = true;
            $scope.contrattoAffitto.rli.tipo_contratto_rli = 'L1';
            $scope.tipoRichiesta = [
                {id: 'A', descrizione: 'AVVISO DI PAGAMENTO'},
                {id: 'M', descrizione: 'MAV'},
                {id: 'R', descrizione: 'RID'}
            ];
        }
        else {
            $scope.flag_tipo_assoggettazione = false;
            $scope.contrattoAffitto.rli.tipo_contratto_rli = 'S2';
            $scope.tipoRichiesta = [
                {id: 'A', descrizione: 'AVVISO DI PAGAMENTO'},
                {id: 'F', descrizione: 'FATTURA'},
                {id: 'M', descrizione: 'MAV'},
                {id: 'R', descrizione: 'RID'}
            ];
        }
    };

    $scope.$watchGroup(["contrattoAffitto.rli.codice_ufficio", "contrattoAffitto.rli.anno_stipula",
        "contrattoAffitto.rli.serie", "contrattoAffitto.rli.numero", "contrattoAffitto.rli.sottonumero"], function () {

        if ($scope.contrattoAffitto) {
            if ($scope.contrattoAffitto.rli.codice_ufficio != "" && $scope.contrattoAffitto.rli.codice_ufficio != null &&
                $scope.contrattoAffitto.rli.anno_stipula != "" && $scope.contrattoAffitto.rli.anno_stipula != null &&
                $scope.contrattoAffitto.rli.serie != "" && $scope.contrattoAffitto.rli.serie != null &&
                $scope.contrattoAffitto.rli.numero != "" && $scope.contrattoAffitto.rli.numero != null &&
                $scope.contrattoAffitto.rli.sottonumero != "" && $scope.contrattoAffitto.rli.sottonumero != null
            ) {
                $scope.creaCodiceIdentificativo();
            } else {
                $scope.contrattoAffitto.rli.codice_identificativo = null;
            }
        }
    });

    $scope.creaCodiceIdentificativo = function () {

        //Standardizzo i dati nel form
        $scope.contrattoAffitto.rli.codice_ufficio = $scope.contrattoAffitto.rli.codice_ufficio.substr(-3).toUpperCase();
        $scope.contrattoAffitto.rli.anno_stipula = $scope.contrattoAffitto.rli.anno_stipula.substr(-4);
        $scope.contrattoAffitto.rli.serie = $scope.contrattoAffitto.rli.serie.substr(-2);
        $scope.contrattoAffitto.rli.numero = $scope.contrattoAffitto.rli.numero.substr(-6);
        $scope.contrattoAffitto.rli.sottonumero = $scope.contrattoAffitto.rli.sottonumero.substr(-3);

        //Creo codice Identificativo
        var ufficio = $scope.contrattoAffitto.rli.codice_ufficio.substr(-3);
        var anno = $scope.contrattoAffitto.rli.anno_stipula.substr(-2);
        var serie = $scope.contrattoAffitto.rli.serie.substr(-2);
        var numero = $scope.contrattoAffitto.rli.numero.substr(-6);
        var sottonumero = $scope.contrattoAffitto.rli.sottonumero.substr(-3);
        $scope.contrattoAffitto.rli.codice_identificativo = ufficio + anno + serie + numero + sottonumero;

        return;
    };

    $scope.cambiaMeseIstat = function () {
        if ($scope.tipoIstat != 'NI') {
            $app = getYYYYMMGGFromJsDate($scope.contrattoAffitto.contratto.data_inizio);
            $app = (1 * $app.substr(5, 2)) - 1;
            if ($app == 0) $app = 12;
            $app = '' + $app;
            $scope.contrattoAffitto.contrattiDettagli.mese_riferimento_istat = $app;
            $scope.calcolaMesiConguaglio($app);
        }
    };

    $scope.cambiaAnnoContrattoRli = function () {
        $app = getYYYYMMGGFromJsDate($scope.contrattoAffitto.contrattiDettagli.data_registrazione);
        $app = '' + (1 * $app.substr(0, 4));
        $scope.contrattoAffitto.rli.anno_stipula = $app;
    };

    $scope.aggiornaGruppoFatturazione = function (idAnagrafica) {
        $scope.gruppiFat = [];
        $scope.contrattoAffitto.contrattiDettagli.id_gruppo_fatturazione = 0;
        if ($scope.gruppiFatBackup.length != null) {
            for (var i = 0; i < $scope.gruppiFatBackup.length; i++) {
                if ($scope.gruppiFatBackup[i].id_anagrafica == idAnagrafica) {
                    $scope.gruppiFat.push($scope.gruppiFatBackup[i]);
                    if ($scope.contrattoAffitto.contrattiDettagli.id_gruppo_fatturazione == 0) {
                        $scope.contrattoAffitto.contrattiDettagli.id_gruppo_fatturazione =
                            $scope.gruppiFatBackup[i].id;
                    }
                }
            }
        }
    };

    /* ================================================ SALVATAGGIO ================================================= */

    $scope.salva = function (elabora) {

        if (!dateCorrette()) {
            swal("Controllare le date", "Uno o più date non corrette", "error");
            return;
        }

        if ($scope.contrattoAffitto.contratto.id_societa_fatturazione == '') {
            swal("Errore", "Selezionare il gestore", "error");
            return;
        }
        if ($scope.contrattoAffitto.contratto.proprietari.length < 1) {
            swal("Errore", "Selezionare almeno un locatore", "error");
            return;
        }
        if ($scope.contrattoAffitto.contratto.conduttori.length < 1) {
            swal("Errore", "Selezionare almeno un conduttore", "error");
            return;
        }
        if (elabora) {
            if ($scope.contrattoAffitto.contratto.tipo_gestione != 'C') {
                if ($scope.contrattoAffitto.contrattiDettagli.id_conto_corrente < 1) {
                    swal("Errore", "Selezionare la banca di addebiti", "error");
                    return;
                }
            }
            if ($scope.contrattoAffitto.contratto.tipo_gestione != 'S') {
                if ($scope.contrattoAffitto.rli.id_conto_corrente < 1) {
                    swal("Errore", "Selezionare la banca di addebiti per gli adempimenti fiscali", "error");
                    return;
                }
            }
            if ($scope.contrattoAffitto.unitaImmobiliariContratti.length < 1) {
                swal("Errore", "Selezionare almeno una unità immobiliare", "error");
                return;
            }
            if ($scope.contrattoAffitto.canoniOneri.length < 1) {
                if($scope.comodatoGratuito==0) {
                    swal("Errore", "Controllare che ci sia almeno un canone affitto selezionato", "error");
                    return;
                }
            }
            if ($scope.contrattoAffitto.contrattiDettagli.id_gruppo_fatturazione < 1) {
                swal("Errore", "Selezionare il gruppo per gli avvisi di pagamento", "error");
                return;
            }

            for (var i = 0; i < $scope.contrattoAffitto.canoniOneri.length; i++) {

                var percentuale = 0;
                rateizzazione = $scope.contrattoAffitto.canoniOneri[i].rateizzazione;
                for (var j = 0; j < rateizzazione.length; j++) {

                    var appPerc = rateizzazione[j].percentuale * 10000;
                    percentuale = percentuale + appPerc;
                }
                percentuale = percentuale / 10000;
                if (percentuale != 100) {
                    swal("Errore", "Errore nella somme delle percentuali di suddivisione di una o più tipologie di spesa", "error");
                    return;
                }
            }
            if($scope.comodatoGratuito==0) {
                if ($scope.contrattoAffitto.canoniOneri.length < 1) {
                    swal("Errore", "Controllare che ci sia almeno un canone affitto selezionato", "error");
                    return;
                }
                else {
                    var flag = false;
                    for (var i = 0; i < $scope.contrattoAffitto.canoniOneri.length; i++) {
                        if ($scope.contrattoAffitto.canoniOneri[i].tipo_spesa == "C") {
                            flag = true;
                            break;
                        }
                    }
                    if (!flag) {
                        swal("Errore", "Controllare che ci sia almeno un canone affitto selezionato", "error");
                        return;
                    }
                }
            }
        }
        /*
        ============================
        MORMALIZZAZIONE DELLE DATE
        ============================
         */
        $scope.contrattoAffitto.contratto.data_inizio =
            getYYYYMMGGFromJsDate($scope.contrattoAffitto.contratto.data_inizio);
        $scope.contrattoAffitto.contratto.data_stipula =
            getYYYYMMGGFromJsDate($scope.contrattoAffitto.contratto.data_stipula);
        $scope.contrattoAffitto.contrattiDettagli.data_consegna_chiavi =
            getYYYYMMGGFromJsDate($scope.contrattoAffitto.contrattiDettagli.data_consegna_chiavi);
        $scope.contrattoAffitto.contrattiDettagli.data_registrazione =
            getYYYYMMGGFromJsDate($scope.contrattoAffitto.contrattiDettagli.data_registrazione);
        $scope.contrattoAffitto.contrattiPreferenze.data_prima_scadenza =
            getYYYYMMGGFromJsDate($scope.contrattoAffitto.contrattiPreferenze.data_prima_scadenza);
        $scope.contrattoAffitto.contrattiPreferenze.data_scadenza_raccordo =
            getYYYYMMGGFromJsDate($scope.contrattoAffitto.contrattiPreferenze.data_scadenza_raccordo);
        var data1 = null;
        var data2 = null;

        for (var i = 0; i < $scope.contrattoAffitto.canoniOneri.length; i++) {
            for (var j = 0; j < $scope.contrattoAffitto.canoniOneri[i].rateizzazione.length; j++) {
                if (j == 0) {
                    data1 = new Date($scope.contrattoAffitto.canoniOneri[i].rateizzazione[j].dataScadenza);
                }
                if (j == 0) {
                    data2 = new Date($scope.contrattoAffitto.canoniOneri[i].rateizzazione[j].dataScadenza);
                }
                var dataApp = new Date($scope.contrattoAffitto.canoniOneri[i].rateizzazione[j].dataScadenza);
                if (dataApp < data1) {
                    data1 = new Date($scope.contrattoAffitto.canoniOneri[i].rateizzazione[j].dataScadenza);
                }
                if (dataApp > data2) {
                    data2 = new Date($scope.contrattoAffitto.canoniOneri[i].rateizzazione[j].dataScadenza);
                }

                var app = $scope.contrattoAffitto.canoniOneri[i].rateizzazione[j]['dataScadenza'];
                $scope.contrattoAffitto.canoniOneri[i].rateizzazione[j].dataScadenza =
                    getYYYYMMGGFromJsDate(app);
            }
            var diff = Math.floor((data2 - data1) / (1000 * 60 * 60 * 24));
            if (diff >= 364) {
                swal("Errore", "Controllare le date di scadenza delle rate canoni", "error");
                return;
            }

        }
        for (var i = 0; i < $scope.contrattoAffitto.cauzioni.length; i++) {
            var app = $scope.contrattoAffitto.cauzioni[i]['data_cauzione'];
            $scope.contrattoAffitto.cauzioni[i]['data_cauzione'] =
                getYYYYMMGGFromJsDate(app);
            var appPreavviso = $scope.contrattoAffitto.cauzioni[i]['data_scadenza'];
            $scope.contrattoAffitto.cauzioni[i]['data_scadenza'] =
                getYYYYMMGGFromJsDate(appPreavviso);
        }

        //METTERE TUTTE LE DATE DI SCADENZA CON LO STESSO ANNO PER POI ORDINARLE
        for (var i = 0; i < $scope.contrattoAffitto.canoniOneri.length; i++) {
            for (var j = 0; j < $scope.contrattoAffitto.canoniOneri[i].rateizzazione.length; j++) {
                var dataApp = $scope.contrattoAffitto.canoniOneri[i].rateizzazione[j].dataScadenza;
                dataApp = dataApp.split('-');
                if (j == 0) {
                    var annoValido = dataApp[0];
                }
                $scope.contrattoAffitto.canoniOneri[i].rateizzazione[j].dataScadenza =
                    annoValido + '-' + dataApp[1] + '-' + dataApp[2];
            }
            $scope.contrattoAffitto.canoniOneri[i].rateizzazione =
                sortJSON($scope.contrattoAffitto.canoniOneri[i].rateizzazione, 'dataScadenza', 'up');
        }


        /*
        ============================
         */

        stampalog('Valori da salvare');
        stampalog($scope.contrattoAffitto);
        //PASSAGGIO DEI DATI ALL'HANDLER
        $http.post(params['form'] + '/contratto/controller/nuovoContrattoHandler.php',
            {
                'function': 'salvaDati',
                'contratto': $scope.contrattoAffitto
            }
        ).then(function (data, status, headers, config) {
            stampalog(data);

            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }

            if (data.data.status == "ok") {
                swal({
                        title: "Salvataggio contratto eseguito",
                        text: "",
                        type: "success",
                        showCancelButton: false,
                        confirmButtonClass: "btn-success",
                        confirmButtonText: "Ok",
                        showLoaderOnConfirm: true,
                        closeOnConfirm: false
                    },
                    function () {
                        if (elabora) {
                            $http.post(params['form'] + '/contratto/controller/nuovoContrattoHandler.php',
                                {
                                    'function': 'elaboraContratto',
                                    'idContratto': data.data.idContratto
                                }
                            ).then(function (data, status, headers, config) {
                                stampalog(data);

                                if (data.data.status != "ok") {
                                    swal(data.data.error.title, data.data.error.message, 'error');
                                    return;
                                }

                                if (data.data.status == "ok") {
                                    swal({
                                            title: "Elaborazione contratto eseguito",
                                            text: "",
                                            type: "success",
                                            showCancelButton: false,
                                            confirmButtonClass: "btn-success",
                                            confirmButtonText: "Ok",
                                            closeOnConfirm: false
                                        },
                                        function () {
                                            window.location.href = $scope.params['home'] + encodeUrl("contratto", "contratto");
                                        });
                                }
                            });
                        }
                        else {
                            window.location.href = $scope.params['home'] + encodeUrl("contratto", "contratto");
                        }
                    });
            } else {
                swal({
                    title: "Salvataggio non riuscito",
                    text: "",
                    type: "error",
                    showCancelButton: false,
                    confirmButtonClass: "btn-danger",
                    confirmButtonText: "Ok",
                    closeOnConfirm: true
                })
            }
        });
    };

    /* ============================================== GESTIONE DATE ================================================= */
    $scope.formattaDataDbToIta = function (date) {
        var today = new Date(date);
        var dd = '' + today.getDate();
        var mm = '' + (today.getMonth() + 1);
        var yyyy = today.getFullYear();
        return dd + '/' + mm + '/' + yyyy;
    };


    $scope.calcolaPeriodo = function () {
        var dataAppoggio = new Date($scope.contrattoAffitto.contratto.data_inizio);
        if (isValidDate(getYYYYMMGGFromJsDate(dataAppoggio))) {
            $scope.mostraPeriodo = true;

            for (var i = 0; i < $scope.elencoTipiContratto.length; i++) {
                if ($scope.elencoTipiContratto[i].id == $scope.contrattoAffitto.contratto.id_tipo_contratto) {
                    var coefficiente = 1;
                    if ($scope.elencoTipiContratto[i].tipo_periodo == 'A') {
                        coefficiente = 12;
                    }
                    primoPeriodo = $scope.elencoTipiContratto[i].primo_rinnovo * coefficiente;
                    secondoPeriodo = $scope.elencoTipiContratto[i].secondo_rinnovo * coefficiente;
                }
            }

            $scope.inizioPrimoRinnovo = dataAppoggio.getDate() + '/' + (dataAppoggio.getMonth() + 1) + '/' + dataAppoggio.getFullYear();
            dataAppoggio.setMonth(dataAppoggio.getMonth() + primoPeriodo);
            dataAppoggio.setDate(dataAppoggio.getDate() - 1);
            $scope.finePrimoRinnovo = dataAppoggio.getDate() + '/' + (dataAppoggio.getMonth() + 1) + '/' + dataAppoggio.getFullYear();
            dataAppoggio.setDate(dataAppoggio.getDate() + 1);
            $scope.inizioSecondoRinnovo = dataAppoggio.getDate() + '/' + (dataAppoggio.getMonth() + 1) + '/' + dataAppoggio.getFullYear();
            dataAppoggio.setMonth(dataAppoggio.getMonth() + secondoPeriodo);
            dataAppoggio.setDate(dataAppoggio.getDate() - 1);
            $scope.fineSecondoRinnovo = dataAppoggio.getDate() + '/' + (dataAppoggio.getMonth() + 1) + '/' + dataAppoggio.getFullYear();

            if ($scope.contrattoAffitto.contrattiPreferenze.tipo_scadenza == '0') {
                $scope.contrattoAffitto.contrattiPreferenze.data_prima_scadenza = $scope.contrattoAffitto.contratto.data_inizio;
            }
        } else {
            $scope.mostraPeriodo = false;
        }
    };

    /* =============================================== FUNZIONI ===================================================== */
    /*--------------------------------------------------------FILTER--------------------------------------------------*/
    $scope.stampaDescrizioneCauzione = function (stringa) {
        return $filter('limitTo')(stringa, 30, 0);
    };

    $scope.stampaTipoImposta = function (id) {
        if (id != null && id != 0) {
            return $filter('filter')($scope.elencoTipoImposte, {codice: id})[0].percentuale + ' %';
        }
    };

    $scope.stampaTipoSpesa = function (id) {
        return $filter('filter')($scope.elencoTipiSpesa, {id: id})[0].descrizione;
    };

    $scope.stampaTipoSaldo = function (id) {
        return $filter('filter')($scope.elencoTipiSaldo, {id: id})[0].descrizione;
    };

    $scope.stampaNome = function (id) {
        if (id != null && id != 0) {
            return $filter('filter')($scope.elencoUnitaImmobiliariElenco, {id: id})[0].descrizione;
        }
        return 'Immobile generico';
    };

    $scope.stampaTipoCauzione = function (id) {
        return $filter('filter')($scope.elencoTipiCauzione, {id: id})[0].descrizione;
    };

    $scope.stampaContratto = function (id) {
        if ($scope.elencoTipiContratto) {
            return $filter('filter')($scope.elencoTipiContratto, {id: id})[0].descrizione;
        }
        return;
    };

    $scope.stampaRestituzioneCauzione = function (id) {
        return $filter('filter')($scope.elenco_tipo_restituzione_interessi, {id: id})[0].descrizione;
    };

    $scope.calcolaLordo = function () {
        aliquota = $filter('filter')($scope.elencoTipiIva, {id: $scope.spesa.id_tipi_iva})[0].aliquota;
        $scope.spesa.importo = Math.round($scope.spesa.imponibile * (1 + (aliquota / 100)) * 100) / 100;
    };

    $scope.calcolaImponibile = function () {
        aliquota = $filter('filter')($scope.elencoTipiIva, {id: $scope.spesa.id_tipi_iva})[0].aliquota;
        $scope.spesa.imponibile = Math.round($scope.spesa.importo / (1 + (aliquota / 100)) * 100) / 100;
    };

    /* ======================================= PARAMETRI MULTISELECT================================================= */

    $scope.settings = {
        dynamicTitle: true,
        enableSearch: true,
        showSelectAll: false,
        keyboardControls: true,
        scrollable: true,
        showCheckAll: false,
        showUncheckAll: true,
        closeOnSelect: true,
        scrollableHeight: '200px',
        externalIdProp: '', //PERMETTE DI AGGIUNGERE ALL'ARRAY DEI SELEZIONATI TUTTO L'OGGETTO
        idProp: 'id', //definisco i campi di cui è composto l'oggetto
        displayProp: 'descrizione' //definisco i campi di cui è composto l'oggetto
    };

    $scope.settingsGaranti = {
        dynamicTitle: true,
        enableSearch: true,
        showSelectAll: false,
        keyboardControls: true,
        scrollable: true,
        showCheckAll: false,
        showUncheckAll: true,
        closeOnSelect: true,
        scrollableHeight: '200px',
        selectionLimit: 2,
        externalIdProp: '', //PERMETTE DI AGGIUNGERE ALL'ARRAY DEI SELEZIONATI TUTTO L'OGGETTO
        idProp: 'id', //definisco i campi di cui è composto l'oggetto
        displayProp: 'descrizione' //definisco i campi di cui è composto l'oggetto
    };

    $scope.customTextLocatori = {
        buttonDefaultText: 'Locatori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextConduttori = {
        buttonDefaultText: 'Conduttori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextGaranti = {
        buttonDefaultText: 'Garanti',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };


    $scope.settingsUnitaImmobiliari = {
        dynamicTitle: true,
        enableSearch: true,
        keyboardControls: true,
        scrollable: true,
        closeOnSelect: true,
        scrollableHeight: '200px',
        selectionLimit: 1,
        externalIdProp: '', //PERMETTE DI AGGIUNGERE ALL'ARRAY DEI SELEZIONATI TUTTO L'OGGETTO
        id: 'id', //definisco i campi di cui è composto l'oggetto
        displayProp: 'descrizione', //definisco i campi di cui è composto l'oggetto
        smartButtonMaxItems: 1,
        smartButtonTextConverter: function (itemText, originalItem) {
            if (itemText.length > 40) {
                return itemText.substring(0, 40) + "...";
            } else {
                return itemText;
            }
        }
    };

    $scope.customTextUnitaImmobiliari = {
        buttonDefaultText: 'Unità Immobiliari',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };


    $scope.multiSelectEventUi = {
        onItemSelect: function (obj) {
            $scope.unitaImmobiliari.id_unita_immobiliare = obj.id;
        },
        onItemDeselect: function () {
            $scope.unitaImmobiliari.id_unita_immobiliare = null;
        }
    };


    $scope.multiSelectEvent = {
        onItemSelect: function (obj) {
            $scope.caricaContiCorrente();
            //fixme: fix temporaneo per cardani
           $scope.caricaUI(obj.id);
        },
        onItemDeselect: function (obj) {
            $scope.caricaContiCorrente();

            //fixme: fix temporaneo per cardani
           $scope.scaricaUI(obj.id);
        },
        onDeselectAll: function (obj) {
            $scope.svuotaMultiselect();
        }

    };

    $scope.svuotaMultiselect = function () {
        $scope.elencoUnitaImmobiliari=[];
    };


    $scope.caricaUI = function (idProp) {
        for (var i = 0; i < $scope.elencoUnitaImmobiliariElenco.length; i++) {
            if ($scope.elencoUnitaImmobiliariElenco[i].proprietari != undefined) {
                var app = jsonParse($scope.elencoUnitaImmobiliariElenco[i].proprietari);
                for (var j = 0; j < app.length; j++) {
                    if (app[j].id == idProp) {
                        if ($scope.elencoUnitaImmobiliari.indexOf($scope.elencoUnitaImmobiliariElenco[i]) < 0) {
                            $scope.elencoUnitaImmobiliari.push($scope.elencoUnitaImmobiliariElenco[i]);
                        }
                    }
                }
            }
        }
    };


    $scope.scaricaUI = function (idProp) {
        for (var i = 0; i < $scope.elencoUnitaImmobiliari.length; i++) {
            if ($scope.elencoUnitaImmobiliari[i].proprietari != undefined) {
                var app = jsonParse($scope.elencoUnitaImmobiliari[i].proprietari);
                for (var j = 0; j < app.length; j++) {
                    if (app[j].id == idProp) {
                        $scope.elencoUnitaImmobiliari.splice(i, 1);
                        i--;
                    }
                }
            }
        }
    };

    /* controlla tutte le date nel contratto al 'salva' */
    function dateCorrette() {
        var tmp = true;
        if ($scope.contrattoAffitto.canoniOneri.length > 0) {
            angular.forEach($scope.contrattoAffitto.canoniOneri, function (co) {
                angular.forEach(co.rateizzazione, function (r) {
                    if (!isValidDate(getYYYYMMGGFromJsDate(r.dataScadenza))) {
                        tmp = false;
                    }
                });
            });
        }
        if (!tmp) {
            return false;
        }

        if (
            !isValidDate(getYYYYMMGGFromJsDate($scope.contrattoAffitto.contratto.data_stipula)) ||
            !isValidDate(getYYYYMMGGFromJsDate($scope.contrattoAffitto.contratto.data_inizio)) ||
            !isValidDate(getYYYYMMGGFromJsDate($scope.contrattoAffitto.contrattiDettagli.data_registrazione)) ||
            !isValidDate(getYYYYMMGGFromJsDate($scope.contrattoAffitto.contrattiDettagli.data_consegna_chiavi)) ||
            !isValidDate(getYYYYMMGGFromJsDate($scope.contrattoAffitto.contrattiPreferenze.data_prima_scadenza))
        ) {
            return false;
        }

        if (
            $scope.contrattoAffitto.contrattiPreferenze.tipo_scadenza == "2" &&
            !isValidDate(getYYYYMMGGFromJsDate($scope.contrattoAffitto.contrattiPreferenze.data_scadenza_raccordo))
        ) {
            return false;
        }

        return true;
    }

}])
;