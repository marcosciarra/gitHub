<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 15/12/17
 * Time: 10.38
 */

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';
require_once '../../../src/function/functionDate.php';
require_once '../../../src/function/functionLogin.php';

require_once '../../../src/model/Contratti.php';
require_once '../../../src/model/ContrattoAffitto.php';
require_once '../../../src/model/UnitaImmobiliariContratti.php';
require_once '../../../src/model/ElaboraContratto.php';

require_once '../../../src/model/DrakkarTraceLog.php';

use Click\Affitti\TblBase\Contratti;
use Click\Affitti\Viste\ContrattoAffitto;
use Click\Affitti\TblBase\UnitaImmobiliariContratti;


function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $contrattoAffitto = new ContrattoAffitto($con);

        // CARICO DATI
        $contratti = new Contratti($con);
        $uic = new UnitaImmobiliariContratti($con);

        $contratti->setOrderBase(" data_fine ASC ");
        $result['contratti'] = [];
        foreach ($contratti->getElencoContrattiDisdettabili($request->statoContratto, $request->escludiPreavviso, $request->data_inizio,$request->data_fine,Contratti::FETCH_KEYARRAY) as $contratti) {
            $dataApp = explode('-', $contratti['data_fine']);
            $contratti['data_inizio'] = $contratti['data_inizio'];
            $contratti['data_disdetta'] = date("Y-m-d", mktime(0, 0, 0, $dataApp[1] - $contratti['mesi_preavviso_locatore'], $dataApp[2], $dataApp[0]));
            $contratti['data_prossima_scadenza'] = date("Y-m-d", mktime(0, 0, 0, $dataApp[1], $dataApp[2], $dataApp[0]+$contratti['secondo_rinnovo']));
            $contratti['immobili'] = $uic->elencoImmobiliPerContratto($contratti['id'],UnitaImmobiliariContratti::FETCH_KEYARRAY);
            $contratti['selezionato'] = true;
            $contratti['rinnovabile'] = true;
            $result['contratti'][] = $contratti;
        }

        // CARICO SELECT
        $temp = $contrattoAffitto->getTipoContratto()->getEmptyDbKeyArray();
        $temp['id'] = 0;
        $temp['descrizione'] = 'Tutti i contratti';
        $result['elencoTipiContratto'] = $contrattoAffitto->getTipoContratto()->findAllConDescrizione(ContrattoAffitto::FETCH_KEYARRAY);
        array_unshift($result['elencoTipiContratto'], $temp);

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


function salvaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
        $contratto=new Contratti($con);
        $elaboraContratto = new \Click\Affitti\Viste\ElaboraContratto($con,$conExt);

        if ($request->action=='D'){
            //GESTIONE DISDETTE
            foreach ($request->obj as $disdette){
                if($disdette->selezionato){
                    $contratto->findByPk($disdette->id);
                    $contratto->setStatoContratto('D');
                    if ($request->cestinaAutomatico)
                        $contratto->setDisdettaInData($contratto->getScadenzaContratto());
                    $contratto->saveOrUpdate();
                }
            }
        }
        else{
            //GESTIONE RINNOVI
            foreach ($request->obj as $rinnovi){
                if($rinnovi->selezionato){
                    $contratto->findByPk($rinnovi->id);
                    $contratto->setOccupazioneSenzaTitolo(0);
                    //Elaborazione periodo contrattuale successivo
                    $elaboraContratto->elaborazioneContratto($rinnovi->id);
                }
            }
        }

        $con->commit();
        new \Drakkar\Log\DrakkarTraceLog(getLoginDataFromSession('id',1));

        $result['status'] = 'ok';
        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
