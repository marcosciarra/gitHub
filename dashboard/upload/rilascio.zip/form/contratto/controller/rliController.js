ngApp.controller("rliController", ["$scope", "$http", "$filter", function ($scope, $http, $filter) {

    var url = window.location.href;
    var params = decodeUrl(url, 'id');
    stampalog('URL');
    stampalog(params);

    $scope.init = function () {
        $scope.caricaDati(0);
        $scope.pannelloDatiGenerali = 1;
        $scope.mostraFormNuovoDettaglio = false;
    };

    /*******************
     *   CARICA DATI   * ================================================================================================
     *******************/

    $scope.caricaDati = function(id){
        $scope.caricamentoCompletato = false;
        $scope.modificaRata = false;
        $scope.idContratto = params['id'];

        $http.post(params['form'] + '/contratto/controller/rliHandler.php',
            {
                'function': 'caricaElencoRli',
                'idContratto': $scope.idContratto
            }
        ).then(function (data, status, headers, config) {
            stampalog(data.data);
            $scope.datiRli = data.data;
            $scope.contrattoRli = data.data.contrattoRli;
            $scope.periodiContrattuali = data.data.periodi_contrattuali;
            angular.forEach($scope.datiRli.rli, function (d) {
                d.conduttori = jsonParse(d.conduttori);
                d.locatori = jsonParse(d.locatori);
            });

            $scope.modificaPeriodo($scope.datiRli.gestione_oggi[0].id_periodi_contrattuali);


            //$scope.modificaGestione(id);

            $scope.caricamentoCompletato = true;

        });
    };

    $scope.caricaDatiAnagrafici = function (idContribuente,tipo) {
        $http.post(params['form'] + '/contratto/controller/rliHandler.php',
            {
                'function': 'caricaDatiAnagraficaDaId',
                'id': idContribuente,
                'tipo': tipo
            }
        ).then(function (data, status, headers, config) {
            if(tipo == 'contribuente') {
                $scope.imposteRegistro.datiContribuente = data.data.dati_anagrafici;
                $scope.imposteRegistro.datiContribuente[0].nascita_data = formatDataDbToIta($scope.imposteRegistro.datiContribuente[0].nascita_data);
                // TODO controllare domicilio fiscale quando tiro su indirizzi
                $scope.imposteRegistro.datiContribuente[0].indirizzi = jsonParse($scope.imposteRegistro.datiContribuente[0].indirizzi);
            }else if(tipo == 'coobbligato') {
                $scope.imposteRegistro.datiCoobbligato = data.data.dati_anagrafici;
                stampalog($scope.imposteRegistro.datiCoobbligato);
                // TODO controllare domicilio fiscale quando tiro su indirizzi
                $scope.imposteRegistro.datiCoobbligato[0].indirizzi = jsonParse($scope.imposteRegistro.datiCoobbligato[0].indirizzi);
            }
        });
    };

    $scope.modificaGestione = function(idGestione) {
        $scope.listaRate = [];
        angular.forEach($scope.imposteRegistro.periodi_contrattuali, function(pc) {
            angular.forEach(pc.gestione, function(g) {
                if(g.id==idGestione) {
                    angular.forEach(g.pianoRateT, function (r) {
                        angular.forEach(r.pianoRateD, function (d) {
                                $scope.listaRate.push({
                                        'id': d.rate[0].id,
                                        'descrizione': d.rate[0].descrizione,
                                        'bloccata': d.rate[0].bloccata
                                    }
                                );

                        });
                    });
                }
            });
        });
        $scope.gestione = idGestione;
    };

    $scope.modificaPeriodo = function (id) {
        //$scope.resetFormNuovoDettaglio();
        $scope.periodo = id;
        $scope.gestionePannelli(1);
        $scope.gestione = 0;
        $scope.rate = 0;
        $scope.showDettaglio = -1;
    };

    $scope.gestionePannelli = function (pannello) {
        switch (pannello) {
            case 1:
                $scope.pannelloDatiGenerali = 1;
                $scope.pannelloSoggetti = 0;
                $scope.pannelloImmobili = 0;
                break;
            case 2:
                $scope.pannelloDatiGenerali = 0;
                $scope.pannelloSoggetti = 1;
                $scope.pannelloImmobili = 0;
                break;
        }
    };

    /* ========================================= GESTIONE CONTRATTO ================================================= */

    $scope.gestioneContratto = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "gestioneContratto", id);
    };

    /* STAMPA DATA ============================================================================================ */
    $scope.stampaData = function (id,tipoData) {
        if($scope.periodiContrattuali) {
            if(tipoData=='inizio') {
                return $filter('filter')($scope.periodiContrattuali, {id: id})[0].data_inizio;
            }else if(tipoData=='fine') {
                return $filter('filter')($scope.periodiContrattuali, {id: id})[0].data_fine;
            }
        }
        return [];
    };

    /* STAMPA CANONE ============================================================================================ */
    $scope.stampaCanone = function (id) {
        if($scope.periodiContrattuali) {
            return $filter('filter')($scope.periodiContrattuali, {id: id})[0].totaleCanone;
        }
        return [];
    };

}]);

        /******************
         *   FILTRI   * ================================================================================================
         ******************/

        ngApp.filter('formatDate', function() {
            return function(date) {
                if(date==null) return '';
                return date.substring(8, 10)+'/'+date.substring(5, 7)+'/'+date.substring(0, 4);;
            };
        });