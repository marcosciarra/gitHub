ngApp.controller("stampeContrattualiController", ["$scope", "$http", "$filter", function ($scope, $http, $filter) {

    var url = window.location.href;
    var params = decodeUrl(url);
    stampalog(params);

    $scope.caricamentoCompletato = false;
    $scope.selezionatiTutti = true;
    $scope.filtroCerca = false;

    /* ============================================= CARICA DATI ==================================================== */
    $scope.init = function () {
        $scope.elencoUtenti = [];
        $scope.elencoStabili = [];
        $scope.elencoLocatori = [];
        $scope.elencoConduttori = [];
        $scope.filtroUtenti = [];
        $scope.filtroStabili = [];
        $scope.filtroLocatori = [];
        $scope.filtroConduttori = [];
        $scope.caricaFiltri();

        $scope.caricaDati('A');

    };

    $scope.caricaDati = function (statoContratto) {

        $http.post(params['form'] + '/contratto/controller/stampeContrattualiHandler.php',
            {'function': 'caricaDati', 'cestino': statoContratto}
        ).then(function (data, status, headers, config) {

            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }

            //NORMALIZZO DATI
            $scope.contratti = data.data.contratti;
            if ($scope.contratti != null) {
                for (var i = 0; i < $scope.contratti.length; i++) {
                    var temp = $scope.contratti[i].data_inizio;
                    $scope.contratti[i].proprietari = jsonParse($scope.contratti[i].proprietari);
                    $scope.contratti[i].conduttori = jsonParse($scope.contratti[i].conduttori);
                    $scope.contratti[i].garanti = jsonParse($scope.contratti[i].garanti);
                    if ($scope.contratti[i].proprietari != undefined && $scope.contratti[i].proprietari.length > 0) {
                        $scope.contratti[i].primoLocatore = $scope.contratti[i].proprietari[0].descrizione;
                    }
                    if ($scope.contratti[i].conduttori != undefined && $scope.contratti[i].conduttori.length > 0) {
                        $scope.contratti[i].primoConduttore = $scope.contratti[i].conduttori[0].descrizione;
                    }
                    if ($scope.contratti[i].elenco_ui != undefined && $scope.contratti[i].elenco_ui.length > 0) {
                        $scope.contratti[i].ui_descrizione = $scope.contratti[i].elenco_ui[0].descrizione;
                    }
                    $scope.contratti[i].selezionato = true;
                }
            }
            $scope.contrattiCopia = angular.copy($scope.contratti);

            stampalog($scope.contratti);

            $scope.filtro = false;
            $scope.caricamentoCompletato = true;
        });
    };


    /*----------------------------------------------------STAMPA------------------------------------------------------*/
    $scope.elencoContratti = function () {
        var idContratti = [];
        if ($scope.contrattiFiltrato != null) {
            for (var i = 0; i < $scope.contrattiFiltrato.length; i++) {
                if ($scope.contrattiFiltrato[i].selezionato) {
                    idContratti.push($scope.contrattiFiltrato[i].id);
                }
            }
        }
        if(idContratti.length>0) {
            window.open(params['baseurl'] + '/stampe/contratto/elencoContrattiPdf.php?idContratti=' + JSON.stringify(idContratti));
        }
        else{
            swal("Impossibile procedere", "Nessun contratto selezionato", "error");
        }
    };


    /* =================================== FILTRI E ORDINAMENTI ===================================================== */

    $scope.selezionaDeselezionaTutti = function (flag) {
        $scope.selezionatiTutti = flag;
        for (var i = 0; i < $scope.contratti.length; i++) {
            $scope.contratti[i].selezionato = flag;
        }
    };

    $scope.caricaDettagliModale = function (elenco, etichetta) {
        $scope.elencoModale = elenco;
        $scope.etichettaModale = etichetta;
    };

    $scope.mostraNascondiFiltri = function () {
        if ($scope.filtroCerca == false) {
            $scope.filtroCerca = true;
        }
        else {
            $scope.filtroCerca = false;
        }
    };

    //---------------------------------------------------SEZIONE FILTRI-----------------------------------------------//
    $scope.caricaFiltri = function () {
        $http.post($scope.params['form'] + "/template/controller/homeHandler.php",
            {'function': 'caricaFiltri'}
        ).then(function (data, status, headers, config) {
            // stampalog(data.data);
            $scope.filtriSelectPagina = data.data;
        });
    };
    $scope.settings = {
        dynamicTitle: true,
        enableSearch: true,
        showSelectAll: false,
        keyboardControls: true,
        scrollable: true,
        showCheckAll: false,
        showUncheckAll: true,
        closeOnSelect: false,
        scrollableHeight: '300px',
        externalIdProp: '', //PERMETTE DI AGGIUNGERE ALL'ARRAY DEI SELEZIONATI TUTTO L'OGGETTO
        idProp: 'id', //definisco i campi di cui è composto l'oggetto
        displayProp: 'descrizione' //definisco i campi di cui è composto l'oggetto
    };
    $scope.customTextUtenti = {
        buttonDefaultText: 'Utenti',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextStabili = {
        buttonDefaultText: 'Stabili',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextLocatori = {
        buttonDefaultText: 'Locatori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextConduttori = {
        buttonDefaultText: 'Conduttori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.multiSelectEventUtenti = {
        onItemSelect: function (obj) {
            $scope.filtroUtenti.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroUtenti.length; i++) {
                if ($scope.filtroUtenti[i] == obj.id) {
                    $scope.filtroUtenti.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function () {
            $scope.filtroUtenti = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventStabili = {
        onItemSelect: function (obj) {
            $scope.filtroStabili.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroStabili.length; i++) {
                if ($scope.filtroStabili[i] == obj.id) {
                    $scope.filtroStabili.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroStabili = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventLocatori = {
        onItemSelect: function (obj) {
            $scope.filtroLocatori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroLocatori.length; i++) {
                if ($scope.filtroLocatori[i] == obj.id) {
                    $scope.filtroLocatori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroLocatori = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventConduttori = {
        onItemSelect: function (obj) {
            $scope.filtroConduttori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroConduttori.length; i++) {
                if ($scope.filtroConduttori[i] == obj.id) {
                    $scope.filtroConduttori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroConduttori = [];
            $scope.filtriGenerici();
        }
    };
    $scope.svuotaMultiselect = function () {
        $scope.multiSelectEventUtenti.onDeselectAll();
        $scope.multiSelectEventLocatori.onDeselectAll();
        $scope.multiSelectEventConduttori.onDeselectAll();
        $scope.multiSelectEventStabili.onDeselectAll();
        $scope.elencoUtenti = [];
        $scope.elencoLocatori = [];
        $scope.elencoConduttori = [];
        $scope.elencoStabili = [];
    };
    $scope.filtriGenerici = function () {
        $scope.contratti = [];
        var flag;
        for (var i = 0; i < $scope.contrattiCopia.length; i++) {
            flag = false;

            if ($scope.filtroUtenti.length == 0) {
                flag = true;
            }
            else {
                for (var k = 0; k < $scope.filtroUtenti.length; k++) {
                    if ($scope.contrattiCopia[i].contratti.id_utente_riferimento == $scope.filtroUtenti[k]) {
                        flag = true;
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroStabili.length == 0) {
                    flag = true;
                }
                else {
                    flag = false;
                    for (var j = 0; j < $scope.contrattiCopia[i].elenco_ui.length; j++) {
                        for (var k = 0; k < $scope.filtroStabili.length; k++) {
                            if ($scope.contrattiCopia[i].elenco_ui[j].id_stabili == $scope.filtroStabili[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroLocatori.length == 0) {
                    flag = true;
                }
                else {
                    flag = false;
                    for (var j = 0; j < $scope.contrattiCopia[i].proprietari.length; j++) {
                        for (var k = 0; k < $scope.filtroLocatori.length; k++) {
                            if ($scope.contrattiCopia[i].proprietari[j].id == $scope.filtroLocatori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroConduttori.length == 0) {
                    flag = true;
                }
                else {
                    flag = false;
                    for (var j = 0; j < $scope.contrattiCopia[i].conduttori.length; j++) {
                        for (var k = 0; k < $scope.filtroConduttori.length; k++) {
                            if ($scope.contrattiCopia[i].conduttori[j].id == $scope.filtroConduttori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                $scope.contratti.push($scope.contrattiCopia[i]);
            }
        }
    };

}])
;