ngApp.controller("disdetteController", ["$scope", "$http", "$filter", function ($scope, $http, $filter) {

    var url = window.location.href;
    var params = decodeUrl(url);
    stampalog(params);

    $scope.caricamentoCompletato = false;
    $scope.operazione = "D";
    $scope.escludiPreavviso = false;
    $scope.selezionatiTutti = true;

    var d = new Date();
    $scope.meseCorrente = d.getMonth() + 1;

    /*--------------------------------------------------CARICA DATI---------------------------------------------------*/

    $scope.init = function () {
        $scope.filtroUtenti = [];
        $scope.filtroStabili = [];
        $scope.filtroLocatori = [];
        $scope.filtroConduttori = [];
        $scope.elencoUtenti = [];
        $scope.elencoLocatori = [];
        $scope.elencoConduttori = [];
        $scope.elencoStabili = [];

        $scope.caricaFiltri();

        var d = new Date;
        var app = new Date(d.setDate(d.getDate()));
        var app = new Date(app.setMonth(app.getMonth()));
        $scope.filtroDataInizio = app;
        $http.post(params['form'] + '/template/controller/homeHandler.php',
            {
                'function': 'sommaData',
                'data_inizio': getYYYYMMGGFromJsDate($scope.filtroDataInizio)
            }
        ).then(function (data, status, headers, config) {
            stampalog(data.data);
            $scope.filtroDataFine = getJsDateFromYYYYMMGG(data.data);
            $scope.caricaDati();
        });


    };

    $scope.caricaDati = function () {

        $http.post(params['form'] + '/contratto/controller/disdetteHandler.php',
            {
                'function': 'caricaDati',
                'data_inizio': getYYYYMMGGFromJsDate($scope.filtroDataInizio),
                'data_fine': getYYYYMMGGFromJsDate($scope.filtroDataFine),
                'escludiPreavviso': $scope.escludiPreavviso,
                'statoContratto': 'A'
            }
        ).then(function (data, status, headers, config) {

            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }

            //CARICAMENTO SELECT
            //Tipo contratto (Abitativo...)
            $scope.elencoTipiContratto = data.data.elencoTipiContratto;
            stampalog(data.data);
            $scope.contratti = [];

            if (data.data.contratti != null) {
                for (var i = 0; i < data.data.contratti.length; i++) {
                    data.data.contratti[i].proprietari = jsonParse(data.data.contratti[i].proprietari);
                    data.data.contratti[i].conduttori = jsonParse(data.data.contratti[i].conduttori);

                    if (data.data.contratti[i].proprietari[0].descrizione.length > 25) {
                        data.data.contratti[i].primoLocatore = data.data.contratti[i].proprietari[0].descrizione.substring(0, 25) + ' [...]';
                    } else {
                        data.data.contratti[i].primoLocatore = data.data.contratti[i].proprietari[0].descrizione;
                    }

                    if (data.data.contratti[i].conduttori[0].descrizione.length > 25) {
                        data.data.contratti[i].primoConduttore = data.data.contratti[i].conduttori[0].descrizione.substring(0, 25) + ' [...]';
                    } else {
                        data.data.contratti[i].primoConduttore = data.data.contratti[i].conduttori[0].descrizione;
                    }

                    if (data.data.contratti[i].immobili[0].descrizione.length > 25) {
                        data.data.contratti[i].primoImmobile = data.data.contratti[i].immobili[0].descrizione.substring(0, 25) + ' [...]';
                    } else {
                        data.data.contratti[i].primoImmobile = data.data.contratti[i].immobili[0].descrizione;
                    }

                    data.data.contratti[i].dataInizioFormattata = formattaDataDbToIta(data.data.contratti[i].data_disdetta);
                    data.data.contratti[i].dataDisdettaFormattata = formattaDataDbToIta(data.data.contratti[i].data_disdetta);
                    data.data.contratti[i].dataFineFormattata = formattaDataDbToIta(data.data.contratti[i].data_fine);

                    $scope.contratti.push(data.data.contratti[i]);

                }
            }
            $scope.contrattiCopia = angular.copy($scope.contratti);
            $scope.cestinaAutomatico = false;

            $scope.caricamentoCompletato = true;
        });
    };

    /*---------------------------------------------------SALVA DATI---------------------------------------------------*/

    $scope.salvaDati = function () {
        $scope.caricamentoCompletato = false;

        $http.post(params['form'] + '/contratto/controller/disdetteHandler.php',
            {
                'function': 'salvaDati',
                'obj': $scope.contrattiFiltrati,
                'action': $scope.operazione,
                'cestinaAutomatico': $scope.cestinaAutomatico

            }
        ).then(function (data, status, headers, config) {
            $scope.caricamentoCompletato = true;

            if (data.data.status == "ko") {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            } else {
                swal({
                    title: "Elaborazione effettuata",
                    text: '',
                    type: "success"
                }, function () {
                    if ($scope.selezionato == 'D') {
                        // CREO LA STAMPA DEL TABULATO DELLE DISDETTE
                    }
                    else {
                        // CREO LA STAMPA DEL TABULATO DEI RINNOVI
                    }
                    location.reload();
                });
            }

        })
    };

    /*--------------------------------------------------STAMPE--------------------------------------------------------*/

    $scope.stampaLettera = function () {
        var primoId = true;
        if ($scope.contrattiFiltrati != null) {
            var app = '';
            for (var i = 0; i < $scope.contrattiFiltrati.length; i++) {
                if ($scope.contrattiFiltrati[i].selezionato) {
                    if (primoId) {
                        app = $scope.contrattiFiltrati[i].id;
                        primoId = false;
                    }
                    else {
                        app = app + ',' + $scope.contrattiFiltrati[i].id;
                    }
                }
            }
        }

        window.open(params['baseurl'] + '/stampe/disdette/letteraDisdettaPdf.php?idContratto=' + app);
    };


    $scope.stampaLetteraSingola = function (idContratto) {
        var app = [idContratto];
        window.open(params['baseurl'] + '/stampe/disdette/letteraDisdettaPdf.php?idContratto=' + app);
    };


    $scope.caricaDettagliModale = function (elenco, etichetta) {
        $scope.elencoModale = elenco;
        $scope.etichettaModale = etichetta;
    };

    $scope.filtraContratti = function () {
        $scope.contratti = [];

        if ($scope.contrattiCopia) {
            for (var i = ($scope.contrattiCopia.length - 1); i >= 0; i--) {
                var dataTemp = new Date($scope.contrattiCopia[i].data_inizio);
                if (dataTemp.getMonth() + 1 == $scope.meseCorrente) {
                    $scope.contratti.push($scope.contrattiCopia[i]);
                }
            }
        }
        stampalog($scope.contratti);
    };


    $scope.stampaTipoContratto = function (id) {
        return $filter('filter')($scope.elencoTipiContratto, {id: id})[0].descrizione;
    };


    /*================================================== ESPORTA PDF =================================================*/

    $scope.visualizzaImpoStampa = false;
    $scope.showImpostazioniStampa = function () {
        $scope.visualizzaImpoStampa = !$scope.visualizzaImpoStampa;
    };

    $scope.stampa = getStrutturaBasePDF();
    $scope.stampa.nomeFile = "ELENCO DISDETTE";

    $scope.getHeaderTable = function () {
        return ["LOCATORE", "CONDUTTORE", "IMMOBILE", "DESCRIZIONE", "DATA DISDETTA", "DATA SCADENZA"];
    };

    $scope.creaFileDaScaricare = function () {
        $scope.fileExport = new Array();

        for (var i = 0; i < $scope.contrattiFiltrati.length; i++) {

            if ($scope.contrattiFiltrati[i].selezionato) {
                app = new Array();
                $scope.contrattiFiltrati[i].proprietari[0] != null ? app.push("" + $scope.contrattiFiltrati[i].proprietari[0].descrizione) : app.push("");
                $scope.contrattiFiltrati[i].conduttori[0] != null ? app.push("" + $scope.contrattiFiltrati[i].conduttori[0].descrizione) : app.push("");
                $scope.contrattiFiltrati[i].immobili[0] != null ? app.push("" + $scope.contrattiFiltrati[i].immobili[0].descrizione) : app.push("");
                $scope.contrattiFiltrati[i].descrizione != null ? app.push("" + $scope.contrattiFiltrati[i].descrizione) : app.push("");
                $scope.contrattiFiltrati[i].dataDisdettaFormattata != null ? app.push("" + $scope.contrattiFiltrati[i].dataDisdettaFormattata) : app.push("");
                $scope.contrattiFiltrati[i].dataFineFormattata != null ? app.push("" + $scope.contrattiFiltrati[i].dataFineFormattata) : app.push("");

                $scope.fileExport.push(app);
            }

        }

        //stampalog("File da scaricare:");
        //stampalog($scope.fileExport);

        return $scope.fileExport;
    };

    $scope.scaricaPDF = function () {
        var title = 'ELENCO DISDETTE';
        title += ' - Contratti in scadenza dal ' + stampaDataFormattata($scope.filtroDataInizio);
        title += ' al ' + stampaDataFormattata($scope.filtroDataFine);
        var elencoDaStampare = $scope.creaFileDaScaricare();
        if (elencoDaStampare.length > 0) {
            scaricaPDF($scope.stampa, $scope.getHeaderTable(), elencoDaStampare, title);
        } else {
            swal('Errore', 'Nessun contratto selezionato', 'error');
            return;
        }
    };

    stampaDataFormattata = function (data) {
        return $filter('date')(data, "dd/MM/yyyy");
    };


    /* =================================== FILTRI E ORDINAMENTI ===================================================== */

    $scope.selezionaDeselezionaTutti = function (flag) {
        $scope.selezionatiTutti = flag;
        for (var i = 0; i < $scope.contratti.length; i++) {
            $scope.contratti[i].selezionato = flag;
        }
    };

    $scope.cambiaOperazione = function () {
        if ($scope.operazione == 'R') {
            for (var i = 0; i < $scope.contratti.length; i++) {
                for (var j = 0; j < $scope.elencoTipiContratto.length; j++) {
                    if ($scope.contratti[i].id_tipo_contratto == $scope.elencoTipiContratto[j].id) {
                        if ($scope.elencoTipiContratto[j].secondo_rinnovo == 0) {
                            $scope.contratti[i].selezionato = false;
                            $scope.contratti[i].rinnovabile = false;
                        }
                    }
                }
            }
        }
        else {
            for (var i = 0; i < $scope.contratti.length; i++) {
                for (var j = 0; j < $scope.elencoTipiContratto.length; j++) {
                    if ($scope.contratti[i].id_tipo_contratto == $scope.elencoTipiContratto[j].id) {
                        $scope.contratti[i].rinnovabile = true;
                    }
                }
            }
        }
    };

    $scope.filtri = function () {
        $scope.caricaDati();
    };


    //---------------------------------------------------SEZIONE FILTRI-----------------------------------------------//
    $scope.caricaFiltri = function () {
        $http.post($scope.params['form'] + "/template/controller/homeHandler.php",
            {'function': 'caricaFiltri'}
        ).then(function (data, status, headers, config) {
            // stampalog(data.data);
            $scope.filtriSelectPagina = data.data;
        });
    };
    $scope.settings = {
        dynamicTitle: true,
        enableSearch: true,
        showSelectAll: false,
        keyboardControls: true,
        scrollable: true,
        showCheckAll: false,
        showUncheckAll: true,
        closeOnSelect: false,
        scrollableHeight: '300px',
        externalIdProp: '', //PERMETTE DI AGGIUNGERE ALL'ARRAY DEI SELEZIONATI TUTTO L'OGGETTO
        idProp: 'id', //definisco i campi di cui è composto l'oggetto
        displayProp: 'descrizione' //definisco i campi di cui è composto l'oggetto
    };
    $scope.customTextUtenti = {
        buttonDefaultText: 'Utenti',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextStabili = {
        buttonDefaultText: 'Stabili',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextLocatori = {
        buttonDefaultText: 'Locatori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextConduttori = {
        buttonDefaultText: 'Conduttori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.multiSelectEventUtenti = {
        onItemSelect: function (obj) {
            $scope.filtroUtenti.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroUtenti.length; i++) {
                if ($scope.filtroUtenti[i] == obj.id) {
                    $scope.filtroUtenti.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function () {
            $scope.filtroUtenti = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventStabili = {
        onItemSelect: function (obj) {
            $scope.filtroStabili.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroStabili.length; i++) {
                if ($scope.filtroStabili[i] == obj.id) {
                    $scope.filtroStabili.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroStabili = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventLocatori = {
        onItemSelect: function (obj) {
            $scope.filtroLocatori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroLocatori.length; i++) {
                if ($scope.filtroLocatori[i] == obj.id) {
                    $scope.filtroLocatori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroLocatori = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventConduttori = {
        onItemSelect: function (obj) {
            $scope.filtroConduttori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroConduttori.length; i++) {
                if ($scope.filtroConduttori[i] == obj.id) {
                    $scope.filtroConduttori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroConduttori = [];
            $scope.filtriGenerici();
        }
    };
    $scope.svuotaMultiselect = function () {
        $scope.multiSelectEventUtenti.onDeselectAll();
        $scope.multiSelectEventLocatori.onDeselectAll();
        $scope.multiSelectEventConduttori.onDeselectAll();
        $scope.multiSelectEventStabili.onDeselectAll();
        $scope.elencoUtenti = [];
        $scope.elencoLocatori = [];
        $scope.elencoConduttori = [];
        $scope.elencoStabili = [];
    };
    $scope.filtriGenerici = function () {
        $scope.contratti = [];
        var flag;
        for (var i = 0; i < $scope.contrattiCopia.length; i++) {
            flag = false;

            if ($scope.filtroUtenti.length == 0) {
                flag = true;
            }
            else {
                for (var k = 0; k < $scope.filtroUtenti.length; k++) {
                    if ($scope.contrattiCopia[i].id_utente_riferimento == $scope.filtroUtenti[k]) {
                        flag = true;
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroStabili.length == 0) {
                    flag = true;
                }
                else {
                    flag = false;
                    for (var j = 0; j < $scope.contrattiCopia[i].immobili.length; j++) {
                        for (var k = 0; k < $scope.filtroStabili.length; k++) {
                            if ($scope.contrattiCopia[i].immobili[j].id_stabili == $scope.filtroStabili[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroLocatori.length == 0) {
                    flag = true;
                }
                else {
                    flag = false;
                    for (var j = 0; j < $scope.contrattiCopia[i].proprietari.length; j++) {
                        for (var k = 0; k < $scope.filtroLocatori.length; k++) {
                            if ($scope.contrattiCopia[i].proprietari[j].id == $scope.filtroLocatori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroConduttori.length == 0) {
                    flag = true;
                }
                else {
                    flag = false;
                    for (var j = 0; j < $scope.contrattiCopia[i].conduttori.length; j++) {
                        for (var k = 0; k < $scope.filtroConduttori.length; k++) {
                            if ($scope.contrattiCopia[i].conduttori[j].id == $scope.filtroConduttori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                $scope.contratti.push($scope.contrattiCopia[i]);
            }
        }
    };

}])
;