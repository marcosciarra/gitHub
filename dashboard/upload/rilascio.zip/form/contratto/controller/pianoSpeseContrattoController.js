ngApp.controller("pianoSpeseContrattoController", ["$scope", "$http", "$filter", function ($scope, $http, $filter) {

    var url = window.location.href;
    var params = decodeUrl(url, 'id');
    stampalog('URL');
    stampalog(params);

    $scope.init = function () {
        $scope.caricaDati();
        $scope.mostraFormNuovoDettaglio = false;
    };

    $scope.resetFormNuovoDettaglio = function () {
        $scope.mostraFormNuovoDettaglio = false;
    };

    /*================================================CARICADATI======================================================*/
    $scope.caricaDati = function () {
        $http.post(params['form'] + '/contratto/controller/pianoSpeseContrattoHandler.php',
            {
                'function': 'caricaDati',
                'id': params['id']
            }
        ).then(function (data, status, headers, config) {

            stampalog(data.data.status);
            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }

            stampalog('Carico Dati');
            stampalog(data.data);
            $scope.pianoRate = data.data;
            $scope.spesa = data.data.spesa;
            $scope.elencoTipiSpesa = data.data.tipi_spesa;
            $scope.elencoTipiSaldo = data.data.tipi_saldo;
            $scope.elencoTipiIva = data.data.tipi_iva;
            $scope.anagrafica_contratto = data.data.anagrafica_contratto;

            $scope.locatori = jsonParse(data.data.anagrafica_contratto.proprietari);
            $scope.primoLocatore = $scope.locatori[0].descrizione;

            $scope.conduttori = jsonParse(data.data.anagrafica_contratto.conduttori);
            $scope.primoConduttore = $scope.conduttori[0].descrizione;

            $scope.unitaImmobiliari = data.data.anagrafica_contratto.unita_immobiliari;
            $scope.primoStabile = $scope.unitaImmobiliari[0].descrizione;

            //Duplico i dati per poter controllare quali modifiche devo processare
            $scope.pianoRate.periodi_contrattuali_origine = angular.copy($scope.pianoRate.periodi_contrattuali);

            //Preset
            $scope.showDettaglio = -1;
            $scope.idContratto = params['id'];
            $scope.periodo = data.data.gestione_oggi[0].id_periodi_contrattuali;
            $scope.gestione = data.data.gestione_oggi[0].id_gestione;

            //Preset spesa
            $scope.presetNuovaSpesa();
            $scope.caricamentoCompletato = true;

        });
    };


    $scope.caricaRate = function (idGestione) {
        $http.post(params['form'] + '/contratto/controller/pianoSpeseContrattoHandler.php',
            {
                'function': 'caricaScadenze',
                'idGestione': idGestione
            }
        ).then(function (data, status, headers, config) {
            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }
            $scope.rateEsercizio = data.data.rateEsercizio;

            for (var i = 0; i < $scope.rateEsercizio.length; i++) {
                $scope.rateEsercizio[i].data_formattata = formatDataDbToIta($scope.rateEsercizio[i].data_scadenza);
            }

            //Inizializzo l'array delle rate
            $scope.rateScadenza = [];
            $scope.new_rt = {
                nomeRata: 'Rata ',
                dataScadenza: '',
                percentuale: 100
            };
            stampalog($scope.new_rt);
            $scope.percentuale = 0;
        });
    };

    $scope.aggiungiRata = function () {
        $scope.percentuale = $scope.percentualeTotale();
        if ($scope.new_rt.data_scadenza != '' && $scope.new_rt.percentuale > 0 && $scope.new_rt.percentuale <= 100) {
            if (($scope.percentuale + $scope.new_rt.percentuale) <= 100) {
                $scope.rateScadenza.push($scope.new_rt);
                $scope.new_rt = {
                    nomeRata: 'Rata ',
                    dataScadenza: '',
                    percentuale: 0
                };
                $scope.percentuale = $scope.percentualeTotale();
            }
            else {
                swal('Errore', 'Non è possibile superare il 100% totale.', 'error');
            }
        }
        else {
            swal('Errore', 'Controllare i dati prima di procedere.', 'error');
        }
    };


    $scope.cambiaTipoSpesa = function (tipoSpesa) {
        if (tipoSpesa == 'C') {
            $scope.spesa.tipo_saldo='F';
        }
        else{
            $scope.spesa.tipo_saldo='C';
        }
    };


    $scope.eliminaRata = function (indice) {
        $scope.rateScadenza.splice(indice, 1);
        $scope.percentuale = $scope.percentualeTotale();
    };


    $scope.percentualeTotale = function () {
        var pecentuale = 0;
        for (var i = 0; i < $scope.rateScadenza.length; i++) {
            pecentuale = pecentuale + $scope.rateScadenza[i].percentuale;
        }
        return pecentuale;
    };

    $scope.presetNuovaSpesa = function () {
        $scope.spesa.descrizione = '';
        $scope.spesa.tipo_spesa = 'O';
        $scope.spesa.tipo_saldo = 'C';
        $scope.spesa.imponibile = 0;
        $scope.spesa.id_tipo_iva = 1;
        $scope.spesa.importo = 0;
    };


    $scope.caricaDettagliModale = function (elenco, etichetta) {
        $scope.elencoModale = elenco;
        $scope.etichettaModale = etichetta;
    };

    /*============================================= NAVIGAZIONE PAGINA ===============================================*/

    $scope.modificaPeriodo = function (id) {
        $scope.resetFormNuovoDettaglio();
        $scope.periodo = id;
        $scope.gestione = 0;
        $scope.rate = 0;
        $scope.showDettaglio = -1;
    };
    $scope.modificaGestione = function (id) {
        $scope.resetFormNuovoDettaglio();
        $scope.gestione = id;
        $scope.rate = 0;
        $scope.showDettaglio = -1;
    };
    $scope.modificaRata = function (id) {
        $scope.resetFormNuovoDettaglio();
        $scope.rate = id;
        $scope.showDettaglio = id;
    };

    /*================================================ FILTER ========================================================*/

    $scope.stampaTipoIva = function (id) {
        return $filter('filter')($scope.elencoTipiIva, {id: id})[0].aliquota;
    };
    $scope.stampaTipoSpesa = function (id) {
        return $filter('filter')($scope.elencoTipiSpesa, {key: id})[0].val;
    };
    $scope.stampaTipoSaldo = function (id) {
        return $filter('filter')($scope.elencoTipiSaldo, {key: id})[0].val;
    };

    /*============================================ LORDO / IMPONIBILE ================================================*/

    $scope.calcolaLordo = function (imponibile, idTipoIva, idTesta) {
        var aliquota = $filter('filter')($scope.elencoTipiIva, {id: idTipoIva})[0].aliquota;
        for (var i = 0; i < $scope.pianoRate.periodi_contrattuali.length; i++) {
            for (var j = 0; j < $scope.pianoRate.periodi_contrattuali[i].gestione.length; j++) {
                for (var k = 0; k < $scope.pianoRate.periodi_contrattuali[i].gestione[j].pianoRateT.length; k++) {
                    if ($scope.pianoRate.periodi_contrattuali[i].gestione[j].pianoRateT[k].id == idTesta) {
                        $scope.pianoRate.periodi_contrattuali[i].gestione[j].pianoRateT[k].importo = Math.round(imponibile * (1 + (aliquota / 100)) * 100) / 100;
                        break;
                    }
                }
            }
        }
    };

    $scope.calcolaImponibile = function (importo, idTipoIva, idTesta) {
        var aliquota = $filter('filter')($scope.elencoTipiIva, {id: idTipoIva})[0].aliquota;
        for (var i = 0; i < $scope.pianoRate.periodi_contrattuali.length; i++) {
            for (var j = 0; j < $scope.pianoRate.periodi_contrattuali[i].gestione.length; j++) {
                for (var k = 0; k < $scope.pianoRate.periodi_contrattuali[i].gestione[j].pianoRateT.length; k++) {
                    if ($scope.pianoRate.periodi_contrattuali[i].gestione[j].pianoRateT[k].id == idTesta) {
                        $scope.pianoRate.periodi_contrattuali[i].gestione[j].pianoRateT[k].imponibile = Math.round(importo / (1 + (aliquota / 100)) * 100) / 100;
                        break;
                    }
                }
            }
        }
    };

    $scope.calcolaLordoNuovaSpesa = function (imponibile, idTipoIva) {
        var aliquota = $filter('filter')($scope.elencoTipiIva, {id: idTipoIva})[0].aliquota;
        $scope.spesa.importo = Math.round(imponibile * (1 + (aliquota / 100)) * 100) / 100;
        return;
    };

    $scope.calcolaImponibileNuovaSpesa = function (importo, idTipoIva) {
        var aliquota = $filter('filter')($scope.elencoTipiIva, {id: idTipoIva})[0].aliquota;
        $scope.spesa.imponibile = Math.round(importo / (1 + (aliquota / 100)) * 100) / 100;
        return;
    };

    /* ========================================= GESTIONE CONTRATTO ================================================= */

    $scope.gestioneContratto = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "gestioneContratto", id);
    };

    /*===================================================AGGIORNA SPESE===============================================*/

    $scope.aggiungiSpesa = function (idGestione, ricorsivo) {

        $scope.caricamentoCompletato = false;

        $http.post(params['form'] + '/contratto/controller/pianoSpeseContrattoHandler.php',
            {
                'function': 'aggiungiNuovaSpese',
                'idContratto': params['id'],
                'idGestione': idGestione,
                'spesa': $scope.spesa,
                'rateScadenza': $scope.rateScadenza,
                'ricorsivo': ricorsivo
            }
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                swal({
                        title: "Nuovo Canone/Onere aggiunto",
                        text: "",
                        type: "success",
                        showCancelButton: false,
                        confirmButtonClass: "btn-success",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.href = $scope.params['home'] + encodeUrl("contratto", "pianoSpeseContratto", params['id']);
                    });
            }
            else {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }
        });
    };

    /*===================================================ELIMINA SPESE===============================================*/

    $scope.eliminaSpesa = function (idPianoRateT, idCanoniOneri) {
        for (var i = 0; i < $scope.pianoRate.periodi_contrattuali.length; i++) {
            for (var j = 0; j < $scope.pianoRate.periodi_contrattuali[i].gestione.length; j++) {
                for (var k = 0; k < $scope.pianoRate.periodi_contrattuali[i].gestione[j].pianoRateT.length; k++) {
                    if ($scope.pianoRate.periodi_contrattuali[i].gestione[j].pianoRateT[k].id == idPianoRateT) {
                        $scope.caricamentoCompletato = false;
                        var dataInizioGestione = $scope.pianoRate.periodi_contrattuali[i].gestione[j].data_inizio;
                        $http.post(params['form'] + '/contratto/controller/pianoSpeseContrattoHandler.php',
                            {
                                'function': 'eliminaSpesa',
                                'idPianoRateT': idPianoRateT,
                                'idContratto': params['id'],
                                'idCanoneOnere': idCanoniOneri,
                                'dataInizioGestione': dataInizioGestione
                            }
                        ).then(function (data, status, headers, config) {
                            stampalog(data.data);
                            if (data.data == 'ok') {
                                swal({
                                        title: "Piano spesa eliminato",
                                        text: "",
                                        type: "success",
                                        showCancelButton: false,
                                        confirmButtonClass: "btn-success",
                                        confirmButtonText: "Ok",
                                        closeOnConfirm: false
                                    },
                                    function () {
                                        window.location.href = $scope.params['home'] + encodeUrl("contratto", "pianoSpeseContratto", params['id']);
                                    });
                            }
                            else {
                                swal(data.data.error.title, data.data.error.message, 'error');
                                return;
                            }
                        });
                    }
                }
            }
        }
    };

    /*===================================================AGGIORNA SPESE===============================================*/

    $scope.aggiornaSpesa = function (idPianoRateT, idCanoniOneri, ricorsivo) {
        for (var i = 0; i < $scope.pianoRate.periodi_contrattuali.length; i++) {
            for (var j = 0; j < $scope.pianoRate.periodi_contrattuali[i].gestione.length; j++) {
                for (var k = 0; k < $scope.pianoRate.periodi_contrattuali[i].gestione[j].pianoRateT.length; k++) {
                    if ($scope.pianoRate.periodi_contrattuali[i].gestione[j].pianoRateT[k].id == idPianoRateT) {
                        $scope.caricamentoCompletato = false;
                        var dataInizioGestione = $scope.pianoRate.periodi_contrattuali[i].gestione[j].data_inizio;
                        $http.post(params['form'] + '/contratto/controller/pianoSpeseContrattoHandler.php',
                            {
                                'function': 'modificaPianoSpese',
                                'idContratto': params['id'],
                                'idCanoneOnere': idCanoniOneri,
                                'dataInizioGestione': dataInizioGestione,
                                'ricorsivo': ricorsivo,
                                'newPianoSpesa': $scope.pianoRate.periodi_contrattuali[i].gestione[j].pianoRateT[k],
                                'oldPianoSpesa': $scope.pianoRate.periodi_contrattuali_origine[i].gestione[j].pianoRateT[k]
                            }
                        ).then(function (data, status, headers, config) {
                            stampalog(data.data);
                            if (data.data == 'ok') {
                                swal({
                                        title: "Piano spesa aggiornato",
                                        text: "",
                                        type: "success",
                                        showCancelButton: false,
                                        confirmButtonClass: "btn-success",
                                        confirmButtonText: "Ok",
                                        closeOnConfirm: false
                                    },
                                    function () {
                                        window.location.href = $scope.params['home'] + encodeUrl("contratto", "pianoSpeseContratto", params['id']);
                                    });
                            }
                            else {
                                swal(data.data.error.title, data.data.error.message, 'error');
                                return;
                            }
                        });
                    }
                }
            }
        }
    };
}]);

/*====================================================== FILTRI ======================================================*/

ngApp.filter('formatDate', function () {
    return function (date) {
        return date.substring(8, 10) + '/' + date.substring(5, 7) + '/' + date.substring(0, 4);
    };
});