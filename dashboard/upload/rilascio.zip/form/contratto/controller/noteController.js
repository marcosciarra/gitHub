ngApp.controller("configurazioniController", ["$scope", "$http", "$filter", "ngToast", function ($scope, $http, $filter, $ngToast) {

    var url = window.location.href;
    var params = decodeUrl(url, 'id');
    stampalog('URL');
    stampalog(params);
    $scope.statoCestino = '0';
    $scope.flagModifica = false;
    $scope.idModifica = 0;

    $scope.init = function () {
        $scope.caricaDati();
    };

    /******************
     *   CARICADATI   * ================================================================================================
     ******************/

    $scope.caricaDati = function () {
        $http.post(params['form'] + '/contratto/controller/noteHandler.php',
            {
                'function': 'caricaDati',
                'id': params['id'],
                'statoCestino': $scope.statoCestino
            }
        ).then(function (data, status, headers, config) {

            stampalog(data.data.status);
            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }
            $scope.note = data.data.note;
            $scope.noteEmpty = data.data.noteEmpty;
            $scope.noteEmpty.id_contratto = params['id'];
            $scope.nuoveNote = angular.copy($scope.noteEmpty);

            stampalog('Carico Dati');
            stampalog($scope.note);
            stampalog($scope.noteEmpty);

            $scope.caricamentoCompletato = true;

        });
    };

    $scope.aggiungiNota = function () {
        $http.post(params['form'] + '/contratto/controller/noteHandler.php',
            {'function': 'aggiungiNota', 'obj': $scope.nuoveNote}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                $ngToast.create({
                    className: 'success',
                    content: 'Nota aggiunta',
                    dismissButton: true,
                    timeout: 1500
                });
                $scope.note.push($scope.nuoveNote);
                $scope.nuoveNote = angular.copy($scope.noteEmpty);
            } else {
                swal({
                        title: "Errore",
                        text: "Impossibile aggiungere la nota",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });

            }
        });
    };

    $scope.eliminaNota = function (id) {
        $http.post(params['form'] + '/contratto/controller/noteHandler.php',
            {'function': 'eliminaNota', 'idContratto': params['id'], 'id': id}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                $ngToast.create({
                    className: 'warning',
                    content: 'Nota eliminata',
                    dismissButton: true,
                    timeout: 1500
                });
                for (var i = 0; i < $scope.note.length; i++) {
                    if ($scope.note[i].id == id) {
                        $scope.note.splice(i, 1);
                    }
                }
                $scope.nuoveNote = angular.copy($scope.noteEmpty);
            } else {
                if (data.data = 'refresh') {
                    swal({
                            title: "Errore",
                            text: "Riprovare dopo l'aggiornamento della pagina",
                            type: "error",
                            showCancelButton: false,
                            confirmButtonClass: "btn-danger",
                            confirmButtonText: "Ok",
                            closeOnConfirm: false
                        },
                        function () {
                            window.location.reload();
                        });
                }
                else {
                    swal({
                            title: "Errore",
                            text: "Impossibile eliminare la nota",
                            type: "error",
                            showCancelButton: false,
                            confirmButtonClass: "btn-danger",
                            confirmButtonText: "Ok",
                            closeOnConfirm: false
                        },
                        function () {
                            window.location.reload();
                        });
                }

            }
        });
    };

    $scope.ripristinaNota = function (id) {
        $http.post(params['form'] + '/contratto/controller/noteHandler.php',
            {'function': 'ripristinaNota', 'idContratto': params['id'], 'id': id}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                $ngToast.create({
                    className: 'success',
                    content: 'Nota ripristinata',
                    dismissButton: true,
                    timeout: 1500
                });
                for (var i = 0; i < $scope.note.length; i++) {
                    if ($scope.note[i].id == id) {
                        $scope.note.splice(i, 1);
                    }
                }
                $scope.nuoveNote = angular.copy($scope.noteEmpty);
            } else {
                swal({
                        title: "Errore",
                        text: "Impossibile ripristinare la nota",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });
            }

        });
    };

    $scope.modificaNota = function (id) {
        if(id>0) {
            $scope.idModifica = id;
            $scope.flagModifica = true;
            $http.post(params['form'] + '/contratto/controller/noteHandler.php',
                {'function': 'modificaNota', 'idContratto': params['id'], 'id': id}
            ).then(function (data, status, headers, config) {
                if (data.data.status != 'ok') {
                    swal({
                            title: "Errore",
                            text: "Impossibile modificare la nota",
                            type: "error",
                            showCancelButton: false,
                            confirmButtonClass: "btn-danger",
                            confirmButtonText: "Ok",
                            closeOnConfirm: false
                        },
                        function () {
                            window.location.reload();
                        });
                }
                else {
                    $scope.nuoveNote.titolo = data.data.titolo;
                    $scope.nuoveNote.descrizione = data.data.descrizione;
                }
            });
        }
        else{
            swal({
                    title: "Errore",
                    text: "Impossibile modificare la nota. Rrovare dopo il ricaricamento della pagina.",
                    type: "error",
                    showCancelButton: false,
                    confirmButtonClass: "btn-danger",
                    confirmButtonText: "Ok",
                    closeOnConfirm: false
                },
                function () {
                    window.location.reload();
                });
        }
    };


    $scope.aggiornaNota = function () {
        $http.post(params['form'] + '/contratto/controller/noteHandler.php',
            {'function': 'aggiornaNota', 'obj': $scope.nuoveNote,'idNota':$scope.idModifica}
        ).then(function (data, status, headers, config) {
            if (data.data == 'ok') {
                window.location.reload();
            } else {
                swal({
                        title: "Errore",
                        text: "Impossibile aggiornare la nota",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Ok",
                        closeOnConfirm: false
                    },
                    function () {
                        window.location.reload();
                    });
            }
        });
    };

    $scope.gestioneContratto = function () {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "gestioneContratto", params['id']);
    };


}])
;