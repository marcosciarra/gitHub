<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 15/12/17
 * Time: 10.38
 */
require_once '../../../src/function/functionDate.php';

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';

require_once '../../../src/model/PeriodiContrattuali.php';
require_once '../../../src/model/TipiIva.php';
require_once '../../../src/model/RateDettagli.php';
require_once '../../../src/model/Rate.php';
require_once '../../../src/model/FatturazioneTesta.php';
require_once '../../../src/model/FatturazioneDettagli.php';
require_once '../../../src/model/ContrattiConAnagrafiche.php';
require_once '../../../src/model/Gestioni.php';


use Click\Affitti\TblBase\PeriodiContrattuali;
use Click\Affitti\TblBase\TipiIva;
use Click\Affitti\TblBase\RateDettagli;
use Click\Affitti\TblBase\Rate;
use Click\Affitti\TblBase\FatturazioneTesta;
use Click\Affitti\TblBase\FatturazioneDettagli;
use Click\Affitti\Viste\ContrattiConAnagrafiche;
use Click\Affitti\TblBase\Gestioni;


function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $tmp = new PeriodiContrattuali($con);
        $result['periodi_contrattuali'] = $tmp->findByIdContrattoConDettagli($request->id, 'rate',
            PeriodiContrattuali::FETCH_KEYARRAY);
        $result['rata_oggi'] = $tmp->findRataByToDay($request->id, PeriodiContrattuali::FETCH_KEYARRAY);

        $tipiIva = new TipiIva($con);
        $result['elencoTipiIva'] = $tipiIva->findAll(false, TipiIva::FETCH_KEYARRAY);

        $tipiSpesa = new RateDettagli($con);
        $result['elencoTipiSpesa'] = $tipiSpesa->getElencoTipiImporto(true);

        $anagrafiche = new ContrattiConAnagrafiche($con);
        $result['anagrafica_contratto'] = $anagrafiche->findByPk($request->id, ContrattiConAnagrafiche::FETCH_KEYARRAY);

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

function caricaDatiRata($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        $rate = new Rate($con);
        $rate->findByPk($request->idRata);
        $result['idGestione'] = $rate->getIdGestione();

        $gestioni = new Gestioni($con);
        $gestioni->findByPk($result['idGestione']);
        $result['idPeriodo'] = $gestioni->getIdPeriodoContrattuale();

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

function salvaDettaglio($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $dettaglioRata = new RateDettagli($con);
        $dettaglioRata->creaObjJson($request->object, true);
        $k = $dettaglioRata->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

function eliminaDettaglio($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $dettaglioRata = new RateDettagli($con);
        $dettaglioRata->deleteByPk($request->id);

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

function bloccaSbloccaRata($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $rate = new Rate($con);
        $rate->findByPk($request->id);
        $rate->setBloccata($request->stato);
        $rate->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

function sbloccaEliminaRata($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $rate = new Rate($con);
        $rate->findByPk($request->id);
        $rate->setBloccata(0);
        $rate->saveOrUpdate();


        $FattureT = new FatturazioneTesta($con);
        $FattureT->deleteByPk($request->idFattura);
        $FattureT->saveOrUpdate();

        $FattureD = new FatturazioneDettagli($con);
        $FattureD->deleteByIdFatturazioneTesta($request->idFattura);
        $FattureD->saveOrUpdate();


        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
