<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 15/12/17
 * Time: 10.38
 */
require_once '../../../src/function/functionDate.php';

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';

require_once '../../../src/model/PeriodiContrattuali.php';
require_once '../../../src/model/Gestioni.php';
require_once '../../../src/model/TipiIva.php';
require_once '../../../src/model/RateDettagli.php';
require_once '../../../src/model/PianoRateTesta.php';
require_once '../../../src/model/Rate.php';
require_once '../../../src/model/AggiornaContratto.php';
require_once '../../../src/model/CanoniOneri.php';
require_once '../../../src/model/ContrattiConAnagrafiche.php';

use Click\Affitti\TblBase\PeriodiContrattuali;
use Click\Affitti\TblBase\CanoniOneri;
use Click\Affitti\TblBase\TipiIva;
use Click\Affitti\Viste\AggiornaContratto;
use Click\Affitti\TblBase\PianoRateTesta;
use Click\Affitti\TblBase\Gestioni;
use Click\Affitti\Viste\ContrattiConAnagrafiche;
use Click\Affitti\TblBase\Rate;

function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $tmp = new PeriodiContrattuali($con);
        $result['periodi_contrattuali'] = $tmp->findByIdContrattoConDettagli($request->id, 'pianoRate',
            PeriodiContrattuali::FETCH_KEYARRAY);
        $result['gestione_oggi'] = $tmp->findGestioneByToDay($request->id, PeriodiContrattuali::FETCH_KEYARRAY);

        $canoniOneri = new CanoniOneri($con);
        $result['tipi_spesa'] = $canoniOneri->getTipoSpesaValuesList(true);
        $result['tipi_saldo'] = $canoniOneri->getTipoSaldoValuesList(true);

        $result['spesa'] = $canoniOneri->getEmptyDbKeyArray();

        $tipiIva = new TipiIva($con);
        $result['tipi_iva'] = $tipiIva->findAll(false, TipiIva::FETCH_KEYARRAY);

        $anagrafiche = new ContrattiConAnagrafiche($con);
        $result['anagrafica_contratto'] = $anagrafiche->findByPk($request->id, ContrattiConAnagrafiche::FETCH_KEYARRAY);

        $result['anagrafica_contratto'] = $anagrafiche->findByPk($request->id, ContrattiConAnagrafiche::FETCH_KEYARRAY);

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


function caricaScadenze($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        $rate = new Rate($con);
        $result['rateEsercizio'] = $rate->findByIdxIdGestione($request->idGestione, Rate::FETCH_KEYARRAY);

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


function aggiungiNuovaSpese($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
        $con->beginTransaction();
        $canoniOneri = new CanoniOneri($con);

        $canoniOneri->setIdContratto($request->idContratto);
        $canoniOneri->setDescrizione($request->spesa->descrizione);
        $canoniOneri->setTipoSpesa($request->spesa->tipo_spesa);
        $canoniOneri->setTipoSaldo($request->spesa->tipo_saldo);
        $canoniOneri->setImponibile($request->spesa->imponibile);
        $canoniOneri->setImporto($request->spesa->importo);
        $canoniOneri->setIdTipiIva($request->spesa->id_tipo_iva);
        $canoniOneri->setNumeroRate(count($request->rateScadenza));
        $canoniOneri->setRateizzazione(json_encode($request->rateScadenza));
        //Identifica che il canone è stato inserito dopo l'inserimento del contratto
        $canoniOneri->setInserimentoSuccessivo(1);

        if ($request->ricorsivo == false) {
            $aggContratto = new AggiornaContratto($con, $conExt);
            $aggContratto->aggiungiSpesa($request->idGestione, $canoniOneri);
        } else {
            $gest = new Gestioni($con);
            $gest->findByPk($request->idGestione);
            /** @var Gestioni $gestioni */
            $gest->setOrderBase(' gestioni.data_inizio ASC');
            foreach ($gest->elencoGestioniDaDataByIdContratto($request->idContratto, $gest->getDataInizio(), true) as $gestioni) {
                $aggContratto = new AggiornaContratto($con, $conExt);
                $aggContratto->aggiungiSpesa($gestioni->getId(), $canoniOneri);
            }
        }

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

function eliminaSpesa($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
        $con->beginTransaction();

        $aggContratto = new AggiornaContratto($con, $conExt);
        $aggContratto->eliminazioneSpesa(
            $request->idPianoRateT,
            $request->idContratto,
            $request->idCanoneOnere,
            $request->dataInizioGestione
        );

        $con->commit();
        return 'ok';


    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}


function modificaPianoSpese($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
        $con->beginTransaction();

        $aggContratto = new AggiornaContratto($con, $conExt);
        /*-------------------------------------------------DESCRIZIONE------------------------------------------------*/

        if ($request->newPianoSpesa->descrizione != $request->oldPianoSpesa->descrizione) {
            $aggContratto->cambioDescrizione(
                $request->newPianoSpesa->descrizione,
                $request->idContratto,
                $request->idCanoneOnere,
                $request->dataInizioGestione,
                $request->ricorsivo
            );
        }
        /*-------------------------------------------------SALDO------------------------------------------------------*/

        if ($request->newPianoSpesa->tipo_saldo != $request->oldPianoSpesa->tipo_saldo) {
            $aggContratto->cambioTipoSaldo(
                $request->newPianoSpesa->tipo_saldo,
                $request->idContratto,
                $request->idCanoneOnere,
                $request->dataInizioGestione,
                $request->ricorsivo
            );
        }
        /*-------------------------------------------------SPESA------------------------------------------------------*/

        if ($request->newPianoSpesa->tipo_spesa != $request->oldPianoSpesa->tipo_spesa) {
            $aggContratto->cambioTipoSpese(
                $request->newPianoSpesa->tipo_spesa,
                $request->idContratto,
                $request->idCanoneOnere,
                $request->dataInizioGestione,
                $request->ricorsivo
            );
        }
        /*-------------------------------------------------IMPONIBILE-------------------------------------------------*/

        if ($request->newPianoSpesa->imponibile != $request->oldPianoSpesa->imponibile) {
            $aggContratto->cambioImporti(
                $request->newPianoSpesa->imponibile,
                $request->idContratto,
                $request->idCanoneOnere,
                $request->dataInizioGestione,
                $request->ricorsivo
            );
        }

        /*--------------------------------------------------TIPI IVA--------------------------------------------------*/

        if ($request->newPianoSpesa->id_tipo_iva != $request->oldPianoSpesa->id_tipo_iva) {
            $aggContratto->cambioTipoIva(
                $request->newPianoSpesa->id_tipo_iva,
                $request->idContratto,
                $request->idCanoneOnere,
                $request->dataInizioGestione,
                $request->ricorsivo
            );
        }

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}

/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
