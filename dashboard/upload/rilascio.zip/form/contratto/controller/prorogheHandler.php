<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 15/12/17
 * Time: 10.38
 */

require_once '../../../conf/conf.php';
require_once '../../../src/function/functionLogin.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';
require_once '../../../src/model/DrakkarTraceLog.php';

require_once '../../../src/model/Contratti.php';
require_once '../../../src/model/ContrattoAffitto.php';
require_once '../../../src/model/UnitaImmobiliariContratti.php';
require_once '../../../src/model/PagamentoF24.php';
require_once '../../../src/model/AggiornamentoF24.php';

require_once '../../../src/flussi/CreaF24Elide.php';


require_once '../../../lib/flussi/flussicbi/f24/bean/GeneraRecordFlussiF24.php';
require_once '../../../lib/flussi/flussicbi/f24/model/FlussoF24Elide.php';
require_once '../../../lib/flussi/flussicbi/f24/model/RecordF4.php';
require_once '../../../lib/flussi/flussicbi/f24/model/RecordEF.php';
require_once '../../../lib/flussi/flussicbi/f24/model/Record10.php';
require_once '../../../lib/flussi/flussicbi/f24/model/Record20.php';
require_once '../../../lib/flussi/flussicbi/f24/model/Record40_17.php';
require_once '../../../lib/flussi/flussicbi/f24/model/Record40_18.php';
require_once '../../../lib/flussi/flussicbi/f24/model/Record50_01.php';
require_once '../../../lib/flussi/flussicbi/f24/model/Record50_02.php';
require_once '../../../src/model/ImpostaRegistro.php';
require_once '../../../src/model/Rli.php';
require_once '../../../lib/flussi/utility/StringUtility.php';
require_once '../../../lib/flussi/utility/GestioneFlussi.php';


use Click\Affitti\TblBase\Contratti;
use Click\Affitti\Viste\ContrattoAffitto;
use Click\Affitti\TblBase\UnitaImmobiliariContratti;
use Click\Affitti\TblBase\AggiornamentoF24;

use Click\Flussi\CreaF24Elide;


function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $proroghe = new \Click\Affitti\Viste\PagamentoF24($con);
        $result = [];
        $result['elenco'] = $proroghe->findProrogheByPeriodo($request->data_inizio, $request->data_fine, \Click\Affitti\Viste\PagamentoF24::FETCH_KEYARRAY);

        // CERCO ARRETRATI
        $app = explode('-', $request->data_inizio);
        $data = date('Y-m-d H:i:s', mktime(0, 0, 0, $app[1], $app[2] - 1, $app[0]));
        $result['arretrati'] = $proroghe->findProrogheArretrate($request->data_inizio, \Click\Affitti\Viste\PagamentoF24::FETCH_KEYARRAY);
        $result['dataArr'] = $data;

        // CARICO SELECT
        $contrattoAffitto = new ContrattoAffitto($con);
        $temp = $contrattoAffitto->getTipoContratto()->getEmptyDbKeyArray();
        $temp['id'] = 0;
        $temp['descrizione'] = 'Tutti i contratti';
        $result['elencoTipiContratto'] = $contrattoAffitto->getTipoContratto()->findAllConDescrizione(ContrattoAffitto::FETCH_KEYARRAY);
        array_unshift($result['elencoTipiContratto'], $temp);

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


function elaboraSelezionati($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $data = $request->dataVersamento;
        // unisco arretrati a elenco contratti (poi controllo i selezionati)
        foreach ($request->arretrati as $a) {
            $request->contratti[] = $a;
        }

        $idF24Cbi = [];

        foreach ($request->contratti as $c) {
            if ($c->selezionato) {
                $ir = new \Click\Affitti\TblBase\ImpostaRegistro($con);
                $ir->findByPk($c->imposta_registro->id);
                $ir->setDataVersamento($data);
                $ir->saveOrUpdate();

                $aggiornamento = new AggiornamentoF24($con);
                $aggiornamento->setIdImpostaRegistro($ir->getId());
                $aggiornamento->setContribuente($c->contribuente);
                $aggiornamento->setCfCoobbligato($c->coobbligato->codice_fiscale);
                $aggiornamento->setCodiceIdentificativo($c->imposta_registro->id_codice_identificativo);
                if (isset($c->imposta_registro->codice_ufficio))
                    $aggiornamento->setCodiceUfficio($c->imposta_registro->codice_ufficio);
                $aggiornamento->setCodiceAtto(
                    $c->imposta_registro->serie . $c->imposta_registro->numero . $c->imposta_registro->sottonumero);
                $aggiornamento->setContoCorrente($c->conto_corrente);
                $aggiornamento->setDettagli($c->imposta_registro->dettagli);
                $aggiornamento->setDataVersamento($data);
                $aggiornamento->saveOrUpdateAndLog(getLoginDataFromSession('id'));
                $idF24Cbi[] = $ir->getId();
            }
        }


        $f24Elide = new CreaF24Elide($con, $idF24Cbi, $data);
        $codiceFlusso = $f24Elide->generaFlusso();
        $f24Elide->scriviFlusso();
        $con->commit();

        $result['codiceFlusso'] = $codiceFlusso;
        $result['status'] = 'ok';

        //CHIAMATA A CREAZIONE F24 passando $idF24Cbi

        return json_encode($result);

    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


function elencoFlussi($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $aggF24 = new AggiornamentoF24($con);
        $result = [];
        $result['elencoFlussi'] = $aggF24->getArrayCodiceFlusso($request->codiceFlusso . '%');

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
