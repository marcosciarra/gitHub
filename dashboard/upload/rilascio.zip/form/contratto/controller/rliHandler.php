<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 15/12/17
 * Time: 10.38
 */
require_once '../../../src/function/functionDate.php';

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';

require_once '../../../src/model/PeriodiContrattuali.php';
require_once '../../../src/model/ElaboraContratto.php';
require_once '../../../src/model/Rli.php';
require_once '../../../src/model/Anagrafiche.php';
require_once '../../../src/model/TipoContrattoRli.php';

use Click\Affitti\TblBase\PeriodiContrattuali;
use Click\Affitti\Viste\ElaboraContratto;
use Click\Affitti\TblBase\Rli;
use Click\Affitti\TblBase\Anagrafiche;
use Click\Affitti\TblBase\TipoContrattoRli;

function caricaElencoRli($request){
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);

        $tmp = new PeriodiContrattuali($con);
        $result['periodi_contrattuali'] = $tmp->findByIdContrattoConDettagli($request->idContratto, 'pianoRate',
            PeriodiContrattuali::FETCH_KEYARRAY);
        for($i=0;$i<sizeof($result['periodi_contrattuali']);$i++){
            $totaleCanone = 0;
            for($j=0;$j<sizeof($result['periodi_contrattuali'][$i]['gestione'][0]['pianoRateT']);$j++){
                if($result['periodi_contrattuali'][$i]['gestione'][0]['pianoRateT'][$j]['tipo_saldo']=='F'){
                    $totaleCanone += $result['periodi_contrattuali'][$i]['gestione'][0]['pianoRateT'][$j]['importo'];
                }
            }
            $result['periodi_contrattuali'][$i]['totaleCanone'] = $totaleCanone;
        }
        $result['gestione_oggi'] = $tmp->findGestioneByToDay($request->idContratto, PeriodiContrattuali::FETCH_KEYARRAY);

        $tipoContr = new TipoContrattoRli($conExt);
        $result['contrattoRli'] = $tipoContr->findAll(true,TipoContrattoRli::FETCH_KEYARRAY);

        $rli = new Rli($con);
        $result['rli'] = $rli->findByIdContratto($request->idContratto, Rli::FETCH_KEYARRAY);

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }

}

function caricaDatiAnagraficaDaId($request){
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        $anagrafica = new Anagrafiche($con);
        $result['dati_anagrafici'] = $anagrafica->findById($request->id,Anagrafiche::FETCH_KEYARRAY);

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
