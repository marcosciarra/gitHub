<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 15/12/17
 * Time: 10.38
 */
require_once '../../../src/function/functionDate.php';

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';

require_once '../../../src/model/PeriodiContrattuali.php';
require_once '../../../src/model/RateDettagli.php';
require_once '../../../src/model/Rate.php';
require_once '../../../src/model/ElaboraContratto.php';
require_once '../../../src/model/ImpostaRegistro.php';
require_once '../../../src/model/Rli.php';
require_once '../../../src/model/Anagrafiche.php';
require_once '../../../src/model/CodiceCoobbligato.php';
require_once '../../../src/model/CodiceTributi.php';
require_once '../../../src/model/ContrattiConAnagrafiche.php';


use Click\Affitti\TblBase\PeriodiContrattuali;
use Click\Affitti\TblBase\RateDettagli;
use Click\Affitti\Viste\ElaboraContratto;
use Click\Affitti\TblBase\Rate;
use Click\Affitti\TblBase\ImpostaRegistro;
use Click\Affitti\TblBase\Rli;
use Click\Affitti\TblBase\Anagrafiche;
use Click\Affitti\TblBase\CodiceCoobbligato;
use Click\Affitti\TblBase\CodiceTributi;
use Click\Affitti\Viste\ContrattiConAnagrafiche;


function caricaImposteDaIdGestione($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $tmp = new PeriodiContrattuali($con);
        $result['periodi_contrattuali'] = $tmp->findByIdContrattoConDettagli($request->idContratto, 'pianoRate',
            PeriodiContrattuali::FETCH_KEYARRAY);
        $imposteRegistro = new ImpostaRegistro($con);
        $rate = new Rate($con);

        if ($request->idGestione == 0) {
            $result['gestione_oggi'] = $tmp->findGestioneByToDay($request->idContratto, PeriodiContrattuali::FETCH_KEYARRAY);
            $result['imposte_registro'] = $imposteRegistro->findImposteRegistroDaIdContratto($request->idContratto, $result['gestione_oggi'][0]['id_gestione'], ImpostaRegistro::FETCH_KEYARRAY);
            $result['listaRate'] = $rate->findByIdContratto($request->idContratto, Rate::FETCH_KEYARRAY);

        } else {
            $result['imposte_registro'] = $imposteRegistro->findImposteRegistroDaIdContratto($request->idContratto, $request->idGestione, ImpostaRegistro::FETCH_KEYARRAY);
            $result['listaRate'] = $rate->findByIdContratto($request->idContratto, Rate::FETCH_KEYARRAY);
        }

        $rli = new Rli($con);
        $result['rli'] = $rli->findByIdContratto($request->idContratto, Rli::FETCH_KEYARRAY);

        $datiPersona = new Anagrafiche($con);

        $result['personeInteressate'] = [];

        /** @var Rli $rli */
        foreach ($result['rli'] as $rli) {
            $result['datiContribuente'] = $datiPersona->findByPk($rli['id_contribuente'], Anagrafiche::FETCH_KEYARRAY);
            $result['datiContribuente']['indirizzi'] = json_decode($result['datiContribuente']['indirizzi']);
            $result['datiCoobbligato'] = $datiPersona->findByPk($rli['id_coobbligato'], Anagrafiche::FETCH_KEYARRAY);
            $result['datiCoobbligato']['indirizzi'] = json_decode($result['datiCoobbligato']['indirizzi']);
        }

        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
        $codiceCoobbligato = new CodiceCoobbligato($conExt);
        $result['elencoCoobbligati'] = $codiceCoobbligato->findAll(false, CodiceCoobbligato::FETCH_KEYARRAY);

        $anagrafiche = new ContrattiConAnagrafiche($con);
        $result['anagrafica_contratto'] = $anagrafiche->findByPk($request->idContratto,ContrattiConAnagrafiche::FETCH_KEYARRAY);


        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }

}

function caricaNuovoDettaglio($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
        $imposteRegistro = new ImpostaRegistro($con);
        $result['nuovoDettaglio'] = $imposteRegistro->getEmptyDbKeyArray();
        $result['nuovoDettaglio']['dettagli'] = array(
            'tipo' => 'F',
            'elementi_identificativi' => '',
            'codice' => '',
            'anno' => date("Y"),
            'importi' => ''
        );
        $codiciTributi = new CodiceTributi($conExt);
        $result['elencoCodiciTributi'] = $codiciTributi->findAllConCodiceDescrizione( CodiceTributi::FETCH_KEYARRAY);
        return json_encode($result);

    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

function caricaDatiAnagraficaDaId($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        $anagrafica = new Anagrafiche($con);
        $result['dati_anagrafici'] = $anagrafica->findByPk($request->id, Anagrafiche::FETCH_KEYARRAY);
        $result['dati_anagrafici']['indirizzi'] = json_decode($result['dati_anagrafici']['indirizzi']);

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


function salvaImposta($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        $impReg=new ImpostaRegistro($con);
        $impReg->findByPk($request->impostaRegistro->id);
        $impReg->setDettagli(json_encode($request->impostaRegistro->dettagli));
        $impReg->saveOrUpdate();

        $rateDettagli = new RateDettagli($con);
        /** @var RateDettagli $rateDettagli */
        foreach ($rateDettagli->findByIdxIdImpostaRegistro($request->impostaRegistro->id) as $rateDettagli) {
            break;
        }
        $rateDettagli->setIdRata($request->idRata);
        $rateDettagli->saveOrUpdate();

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
