ngApp.controller("corrispondenzaController", ["$scope", "$http", "$filter", "ngToast", function ($scope, $http, $filter, $ngToast) {

    var url = window.location.href;
    var params = decodeUrl(url, 'id');
    stampalog('URL');
    stampalog(params);

    $scope.init = function () {
        $scope.caricaDati();
    };

    /******************
     *   CARICADATI   * ================================================================================================
     ******************/

    $scope.caricaDati = function () {
        $http.post(params['form'] + '/contratto/controller/corrispondenzaHandler.php',
            {
                'function': 'caricaDati',
                'id': params['id'],
                'statoCestino': $scope.statoCestino
            }
        ).then(function (data, status, headers, config) {

            stampalog(data.data.status);
            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }
            $scope.note = data.data.note;

            $scope.caricamentoCompletato = true;

        });
    };

    $scope.gestioneContratto = function () {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "gestioneContratto", params['id']);
    };


}])
;