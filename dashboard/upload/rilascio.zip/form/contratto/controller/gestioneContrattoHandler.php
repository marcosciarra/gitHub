<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 23/02/18
 * Time: 16.44
 */

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';


require_once '../../../src/model/Anagrafiche.php';
require_once '../../../src/model/UnitaImmobiliari.php';
require_once '../../../src/model/UnitaImmobiliariContratti.php';
require_once '../../../src/model/ContrattoAffitto.php';
require_once '../../../src/model/CanoniOneri.php';
require_once '../../../src/model/TipiCauzione.php';
require_once '../../../src/model/Cauzioni.php';
require_once '../../../src/model/ContiCorrenti.php';
require_once '../../../src/model/TipiIva.php';
require_once '../../../src/model/PeriodiContrattuali.php';
require_once '../../../src/model/Gestioni.php';
require_once '../../../src/model/MovimentiDettagli.php';

require_once '../../../src/model/ContrattoNote.php';

use Click\Affitti\TblBase\Anagrafiche;
use Click\Affitti\TblBase\UnitaImmobiliari;
use Click\Affitti\TblBase\UnitaImmobiliariContratti;
use Click\Affitti\Viste\ContrattoAffitto;
use Click\Affitti\TblBase\CanoniOneri;
use Click\Affitti\TblBase\TipiCauzione;
use Click\Affitti\TblBase\Cauzioni;
use Click\Affitti\TblBase\ContiCorrenti;
use Click\Affitti\TblBase\TipiIva;
use Click\Affitti\TblBase\PeriodiContrattuali;
use Click\Affitti\TblBase\Gestioni;
use Click\Affitti\TblBase\ContrattoNote;
use Click\Affitti\TblBase\MovimentiDettagli;


function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        $contrattoAffitto = new ContrattoAffitto($con);
        $unitaImmobiliari = new UnitaImmobiliari($con);
        $tipiCauzione = new TipiCauzione($con);
        $contiCorrente = new ContiCorrenti($con);
        $periodo = new PeriodiContrattuali($con);
        $note = new ContrattoNote($con);

        $result['contrattoAffitto'] = $contrattoAffitto->findByPk($request->id, ContrattoAffitto::FETCH_KEYARRAY);

        $periodo->findByPk($periodo->findIdPeriodoContrattualeByData(date('Y-m-d'),$request->id));
        $result['contratto_data_inizio'] = $result['contrattoAffitto']['contratto']['data_inizio'];
        $result['periodo_data_inizio'] = $periodo->getDataInizio();
        $result['periodo_data_fine'] = $periodo->getDataFine();

        $periodo->setOrderBase(' progressivo DESC ');
        /** @var PeriodiContrattuali $periodo */
        foreach ($periodo->findByIdContratto($request->id) as $periodo){
            break;
        }
        $result['contratto_data_fine'] = $periodo->getDataFine();

        $note->setWhereBase(' cestino=0 ');
        $result['note'] = $note->findByIdContratto($request->id,ContrattoNote::FETCH_KEYARRAY);

        // CARICO SELECT
        $result['elencoTipiContratto'] = $contrattoAffitto->getTipoContratto()->findAllConDescrizione(ContrattoAffitto::FETCH_KEYARRAY);
        $result['elencoUnitaImmobiliari'] = $unitaImmobiliari->findAllPerSelect(UnitaImmobiliari::FETCH_KEYARRAY);
        $result['elencoTipiSpesa'] = $contrattoAffitto->getElencoTipoSaldo(true);
        $result['elencoTipiSaldo'] = $contrattoAffitto->getElencoTipoSpesa(true);
        $result['elencoTipiCauzione'] = $tipiCauzione->findAll(false, TipiCauzione::FETCH_KEYARRAY);

        $p = $periodo->getDataDifferenzaContrattoByToDay($request->id);
        if (isset($p->giorniPassati) && $p->giorniPassati > 0) {
            $result['tempoContratto'] = round((100 * $p->giorniPassati) / $p->giorniPeriodo, 0);
        } else {
            $result['tempoContratto'] = 0;
        }

        $p = $periodo->getDataDifferenzaPeriodoByToDay($request->id);
        if (isset($p->giorniPassati)) {
            $result['tempoPeriodo'] = round((100 * $p->giorniPassati) / $p->giorniPeriodo, 0);
        } else {
            $result['tempoPeriodo'] = 0;
        }


        $movimentiD=new MovimentiDettagli($con);
        $result['fatturato'] = $movimentiD->getFatturatoByIdContratto($request->id);
        $result['saldo'] = $movimentiD->getSaldoByIdContratto($request->id);

        $result['status'] = 'ok';
        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }

}


/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
