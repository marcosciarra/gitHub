ngApp.controller("immobileController", ["$scope", "$http", function ($scope, $http) {

    var url = window.location.href;
    var params = decodeUrl(url);
    stampalog(params);

    $scope.caricamentoCompletato = false;

    $scope.init = function () {
        $scope.caricaDati();
        $scope.filtroCestinoSelezionato = 0;
    };

    /**********************
     *   FILTRO CESTINO   * ============================================================================================
     **********************/

    $scope.filtroCestino = [{value: 0, label: "attive"}, {value: 1, label: "cancellate"}];
    $scope.filtri = function () {
        $scope.stabili = [];
        for (var i = ($scope.stabiliApp.length - 1); i >= 0; i--) {
            if ($scope.stabiliApp[i].cestino == $scope.filtroCestinoSelezionato) {
                $scope.stabili.push($scope.stabiliApp[i]);
            }
        }
    };

    /******************
     *   CARICADATI   * ================================================================================================
     ******************/

    $scope.caricaDati = function () {
        $http.post(params['form'] + '/immobili/controller/stabiliHandler.php',
            {'function': 'caricaDati'}
        ).then(function (data, status, headers, config) {
            $scope.stabili = data.data.stabili;
            if ($scope.stabili != null) {
                for (var i = 0; i < $scope.stabili.length; i++) {
                    if ($scope.stabili[i]['codice_stabile'] != '' && $scope.stabili[i]['codice_stabile'] != undefined)
                        $scope.stabili[i]['descrizione'] = $scope.stabili[i]['descrizione'] + ' (' + $scope.stabili[i]['codice_stabile'] + ')';

                    $scope.stabili[i]['indirizzo'] = JSON.parse($scope.stabili[i]['indirizzo']);

                    $scope.stabili[i]['indirizzoVisualizzato'] = $scope.stabili[i]['indirizzo'].tipoIndirizzo + ' ' +
                        $scope.stabili[i]['indirizzo'].indirizzo + ', ' + $scope.stabili[i]['indirizzo'].civico;

                    $scope.stabili[i]['comuneVisualizzato'] = $scope.stabili[i]['indirizzo'].comune + ' (' +
                        $scope.stabili[i]['indirizzo'].provincia + ')';
                }
            }
            $scope.stabiliApp = angular.copy($scope.stabili);
            $scope.filtri();
            stampalog($scope.stabili);
            $scope.caricamentoCompletato = true;
        });
    };

    /*********************
     *   GEST STATO UI   * ================================================================================================
     *********************/

    $scope.gestisciCestino = function (idStabile, operazione) {
        if (operazione == 'attiva') {
            swal({
                    title: "Cancellare lo stabile?",
                    text: "",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonClass: "btn-danger",
                    confirmButtonText: "Si, cancella!",
                    cancelButtonText: "No, annulla!",
                    closeOnConfirm: false,
                    closeOnCancel: false
                },
                function (isConfirm) {
                    if (isConfirm) {

                        $http.post($scope.params['form'] + '/immobili/controller/stabiliHandler.php',
                            {'function': 'gestisciStatoUI', 'idStabile': idStabile}
                        ).then(function (data, status, headers, config) {
                            window.location.href = $scope.params['home'] + encodeUrl("immobili", "stabili");
                        })
                    }
                    else {
                        swal("Cancellazione annullata", "", "error");
                    }
                });
        } else {
            swal({
                    title: "Riattivare lo stabile?",
                    text: "",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonClass: "btn-danger",
                    confirmButtonText: "Si, attiva!",
                    cancelButtonText: "No, annulla!",
                    closeOnConfirm: false,
                    closeOnCancel: false
                },
                function (isConfirm) {
                    if (isConfirm) {

                        $http.post($scope.params['form'] + '/immobili/controller/stabiliHandler.php',
                            {'function': 'gestisciStatoUI', 'idStabile': idStabile}
                        ).then(function (data, status, headers, config) {
                            window.location.href = $scope.params['home'] + encodeUrl("immobili", "stabili");
                        })
                    }
                    else {
                        swal("Ripristino annullato", "", "error");
                    }
                });
        }
    }

    /*******************
     *   MODIFICA UI   * ================================================================================================
     *******************/

    $scope.modifica = function (id) {
        window.location.href = params['home'] + encodeUrl('immobili', 'gestioneStabile', id);
    };

    /*******************
     *   ESPORTA PDF   * ================================================================================================
     *******************/

    $scope.visualizzaImpoStampa = false;
    $scope.showImpostazioniStampa = function () {
        $scope.visualizzaImpoStampa = !$scope.visualizzaImpoStampa;
    };

    $scope.stampa = getStrutturaBasePDF();
    $scope.stampa.nomeFile = "stabili";

    $scope.getHeaderTable = function () {
        return ["STABILE", "INDIRIZZO", "COMUNE"];
    };

    $scope.creaFileDaScaricare = function () {
        $scope.fileExport = new Array();

        for (i = 0; i < $scope.stabiliFiltrati.length; i++) {

            app = new Array();
            $scope.stabiliFiltrati[i].descrizione != null ? app.push("" + $scope.stabiliFiltrati[i].descrizione) : app.push("");
            $scope.stabiliFiltrati[i].indirizzoVisualizzato != null ? app.push("" + $scope.stabiliFiltrati[i].indirizzoVisualizzato) : app.push("");
            $scope.stabiliFiltrati[i].comuneVisualizzato != null ? app.push("" + $scope.stabiliFiltrati[i].comuneVisualizzato) : app.push("");

            $scope.fileExport.push(app);
        }

        //stampalog("File da scaricare:");
        //stampalog($scope.fileExport);

        return $scope.fileExport;
    };

    $scope.scaricaPDF = function () {
        scaricaPDF($scope.stampa, $scope.getHeaderTable(), $scope.creaFileDaScaricare());
    };

}]);