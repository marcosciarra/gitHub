<?php

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';
require_once '../../../src/model/DrakkarTraceLog.php';
require_once '../../../src/function/functionLogin.php';

require_once '../../../src/model/Stabili.php';
require_once '../../../src/model/UnitaImmobiliari.php';

use Click\Affitti\TblBase\Stabili;
use Click\Affitti\TblBase\UnitaImmobiliari;

function caricaDati()
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        // CARICO DATI
        $stabili = new Stabili($con);
        $stabili->setOrderBase(' descrizione DESC ');

        $result['stabili'] = [];
        foreach ($stabili->findAll(false, Stabili::FETCH_KEYARRAY) as $stabili) {
            $ui = new UnitaImmobiliari($con);
            $ui->setWhereBase( ' cestino=0 ');
            $ui->setOrderBase( ' descrizione ASC ');
            $stabili['num_immobili'] = count($ui->findByIdxIdStabili($stabili['id']));
            $result['stabili'][] = $stabili;
        }

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

function gestisciStatoUI($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $stabili = new Stabili($con);
        $stabili->findByPk($request->idStabile);
        ($stabili->getCestino() == 1) ? $stabili->setCestino(0) : $stabili->setCestino(1);
        $stabili->saveOrUpdateAndLog(getLoginDataFromSession('id'));
        //////////////////////////////////////////////
        $con->commit();
        return ($stabili->getCestino());
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return $e;
    }
}

/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
