<?php

require_once '../../../conf/conf.php';
require_once '../../../src/function/functionLogin.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';
require_once '../../../src/model/DrakkarTraceLog.php';

require_once '../../../src/model/Stabili.php';
require_once '../../../src/model/UnitaImmobiliari.php';
require_once '../../../src/model/Comuni.php';
require_once '../../../src/model/TipiUso.php';
require_once '../../../src/model/CategorieCatastali.php';
require_once '../../../src/model/Anagrafiche.php';
require_once '../../../src/model/TipoSoggetto.php';

use Click\Affitti\TblBase\Comuni;
use Click\Affitti\TblBase\UnitaImmobiliari;
use Click\Affitti\TblBase\TipiUso;
use Click\Affitti\TblBase\CategorieCatastali;
use Click\Affitti\TblBase\Anagrafiche;
use Click\Affitti\TblBase\TipoSoggetto;
use Click\Affitti\TblBase\Stabili;


function caricaDati($request)
{
    $result = array();
    try {
        // CARICO DATI UNITA IMMOBILIARE
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
        //echo $con->getSkema();
        $stabili = new Stabili($con);
        if ($request->idStabile) {
            $result['stabili'] = $stabili->findByPk($request->idStabile, Stabili::FETCH_KEYARRAY);
            $ui = new UnitaImmobiliari($con);
            $ui->setWhereBase(" cestino = 0 and id_stabili = $request->idStabile ");
            $ui->setOrderBase(" descrizione ASC ");
            $result['immobili'] = $ui->getElencoUI(false, UnitaImmobiliari::FETCH_KEYARRAY);
        } else {
            $result['stabili'] = $stabili->getEmptyDbKeyArray();
            $result['nuovoIndirizzo'] = $stabili->getEmptyIndirizzo();
        }

        $categoriaCat = new CategorieCatastali($conExt);
        $result['elencoCategorieCatastali'] = $categoriaCat->findAll(false, CategorieCatastali::FETCH_KEYARRAY);

        $anagrafica = new Anagrafiche($con);
        $anagrafica->setWhereBase(' cestino=0 AND amministratore_condominio IS NOT NULL');
        $anagrafica->setOrderBase(' descrizione ASC ' );
        $result['elencoAmministratori'] = $anagrafica->findAllPerSelect(Anagrafiche::FETCH_KEYARRAY);
        $anagrafica->setWhereBase(' cestino=0 AND fornitore IS NOT NULL');
        $anagrafica->setOrderBase(' descrizione ASC ' );
        $result['elencoFornitori'] = $anagrafica->findAllPerSelect(Anagrafiche::FETCH_KEYARRAY);

        $result['elencoFornitore'] = $result['stabili']['fornitori_riferimento'];

        // RETURN
        $result['status'] = 'ok';
        return json_encode($result);

    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        echo json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        echo json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


function getListaComuniCorti($request)
{
    // CARICO DATI LISTA COMUNI CON NOME CORTO

    $con = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
    $comuni = new \Click\Affitti\TblBase\Comuni($con);
    $result = $comuni->getListaComuniCorti(Comuni::FETCH_KEYARRAY);

    return json_encode($result);

}

function aggiornaCitta($request)
{
    // CARICO DATI LISTA COMUNI
    $con = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
    //echo $con->getSkema();
    $anagrafiche = new \Click\Affitti\TblBase\Comuni($con);
    //$app=$anagrafiche->findAll(false, Anagrafiche::FETCH_KEYARRAY,1,0);
    $result = $anagrafiche->getLista2($request->c);

    // RETURN
    return json_encode($result);
}

function caricaDatiComune($request)
{
    // CARICO DATI LISTA COMUNI
    $con = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
    //echo $con->getSkema();
    $anagrafiche = new \Click\Affitti\TblBase\Comuni($con);
    //$app=$anagrafiche->findAll(false, Anagrafiche::FETCH_KEYARRAY,1,0);
    $result = $anagrafiche->getInfoComuneById($request->id);

    // RETURN
    return json_encode($result);
}


function salvaDati($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        if ($request->object->id_amministratore == null)
            $request->object->id_amministratore = Stabili::NULL_VALUE;

        $stabili = new Stabili($con);
        if (count($request->elencoFornitore) > 0) {
            $request->object->fornitori_riferimento = json_encode($request->elencoFornitore);
        } else {
            $request->object->fornitori_riferimento = Stabili::NULL_VALUE;
        }
        $stabili->creaObjJson($request->object, true);
        $stabili->saveOrUpdateAndLog(getLoginDataFromSession('id'));
        $con->commit();

        $result['status'] = $stabili->getId();
        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

/**/
ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;