<?php

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';
require_once '../../../src/model/DrakkarTraceLog.php';
require_once '../../../src/function/functionLogin.php';

require_once '../../../src/model/UnitaImmobiliari.php';
require_once '../../../src/model/Stabili.php';

use Click\Affitti\TblBase\UnitaImmobiliari;
use Click\Affitti\TblBase\Stabili;

function caricaDati()
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        // CARICO DATI
        $ui = new UnitaImmobiliari($con);
        $ui->setOrderBase(' descrizione DESC ');
        $result['ui'] = $ui->getElencoUI(false, UnitaImmobiliari::FETCH_KEYARRAY);
        $stabili = new Stabili($con);
        $stabili->setWhereBase(' cestino=0 ');
        $stabili->setOrderBase(' descrizione ASC ');
        $result['elencoStabili'] = $stabili->findAllPerSelect(Stabili::FETCH_KEYARRAY);
        array_unshift($result['elencoStabili'],['id' => 0, 'descrizione' => 'Tutti']);

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

function gestisciStatoUI($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $ui = new UnitaImmobiliari($con);
        $ui->findByPk($request->idUI);
        $ui->setCestino(!$ui->getCestino());
        $ui->setIndirizzo(json_decode($ui->getIndirizzo()));
        //$ui->saveOrUpdate();
        $ui->saveOrUpdateAndLog(getLoginDataFromSession('id'));
        //////////////////////////////////////////////
        $con->commit();
        return ($ui->getCestino());
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return $e;
    }
}

/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
