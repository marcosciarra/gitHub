ngApp.controller("immobileController", ["$scope", "$http", function ($scope, $http) {

    var url = window.location.href;
    var params = decodeUrl(url);
    stampalog(params);

    $scope.statoOccupazione = [
        {id: 0, descrizione: 'Tutti'},
        {id: 1, descrizione: 'Allocati'},
        {id: 2, descrizione: 'Parzialmente allocati'},
        {id: 3, descrizione: 'Sfitti'}
    ];

    $scope.caricamentoCompletato = false;

    $scope.init = function () {
        $scope.filtroStabile = 0;
        $scope.filtroCestinoSelezionato = 0;
        $scope.filtroOccupazione = 0;
        $scope.caricaDati();
    };

    /**********************
     *   FILTRO CESTINO   * ============================================================================================
     **********************/

    $scope.filtroCestino = [{value: 0, label: "attive"}, {value: 1, label: "cancellate"}];
    $scope.filtri = function () {
        $scope.elencoUI = [];
        if ($scope.elencoUIApp != null) {
            for (var i = ($scope.elencoUIApp.length - 1); i >= 0; i--) {
                if ($scope.elencoUIApp[i].cestino == $scope.filtroCestinoSelezionato) {
                    if ($scope.elencoUIApp[i].id_stabili == $scope.filtroStabile || $scope.filtroStabile == 0) {
                        switch ($scope.filtroOccupazione) {
                            case 0:
                                $scope.elencoUI.push($scope.elencoUIApp[i]);
                                break;
                            case 1:
                                if ($scope.elencoUIApp[i].percentuale >= 100) {
                                    $scope.elencoUI.push($scope.elencoUIApp[i]);
                                }
                                break;
                            case 2:
                                if ($scope.elencoUIApp[i].percentuale > 0 && $scope.elencoUIApp[i].percentuale < 100) {
                                    $scope.elencoUI.push($scope.elencoUIApp[i]);
                                }
                                break;
                            case 3:
                                if ($scope.elencoUIApp[i].percentuale == null) {
                                    $scope.elencoUI.push($scope.elencoUIApp[i]);
                                }
                                break;
                        }
                    }
                }
            }
        }
    };

    /******************
     *   CARICADATI   * ================================================================================================
     ******************/

    $scope.caricaDati = function () {
        $http.post(params['form'] + '/immobili/controller/immobileHandler.php',
            {'function': 'caricaDati'}
        ).then(function (data, status, headers, config) {
            $scope.elencoStabili = data.data.elencoStabili;
            $scope.elencoUI = data.data.ui;
            if ($scope.elencoUI != null) {
                for (var i = 0; i < $scope.elencoUI.length; i++) {
                    $scope.elencoUI[i]['indirizzo'] = JSON.parse($scope.elencoUI[i]['indirizzo']);

                    // stampalog($scope.elencoUI[i]['indirizzo']);
                    if ($scope.elencoUI[i]['indirizzo'] != null) {
                        $scope.elencoUI[i]['indirizzoVisualizzato'] = $scope.elencoUI[i]['indirizzo'].tipoIndirizzo + ' ' +
                            $scope.elencoUI[i]['indirizzo'].indirizzo + ', ' + $scope.elencoUI[i]['indirizzo'].civico;

                        $scope.elencoUI[i]['comuneVisualizzato'] = $scope.elencoUI[i]['indirizzo'].comune + ' (' +
                            $scope.elencoUI[i]['indirizzo'].provincia + ')';
                    }
                }
            }
            $scope.elencoUIApp = angular.copy($scope.elencoUI);
            $scope.filtri();
            stampalog($scope.elencoUI);
            stampalog($scope.elencoStabili);
            $scope.caricamentoCompletato = true;
        });
    };

    /*********************
     *   GEST STATO UI   * ================================================================================================
     *********************/

    $scope.gestisciCestino = function (idUI,operazione) {
        if(operazione == 'attiva'){
            swal({
                    title: "Cancellare l'immobile?",
                    text: "",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonClass: "btn-danger",
                    confirmButtonText: "Si, cancella!",
                    cancelButtonText: "No, annulla!",
                    closeOnConfirm: false,
                    closeOnCancel: false
                },
                function (isConfirm) {
                    if (isConfirm) {
                        $http.post($scope.params['form'] + '/immobili/controller/immobileHandler.php',
                            {'function': 'gestisciStatoUI', 'idUI': idUI}
                        ).then(function (data, status, headers, config) {
                            window.location.href = $scope.params['home'] + encodeUrl("immobili", "immobile");
                        })
                    }
                    else {
                        swal("Cancellazione annullata", "", "error");
                    }
                });
        }else{
            swal({
                    title: "Riattivare l'immobile?",
                    text: "",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonClass: "btn-danger",
                    confirmButtonText: "Si, attiva!",
                    cancelButtonText: "No, annulla!",
                    closeOnConfirm: false,
                    closeOnCancel: false
                },
                function (isConfirm) {
                    if (isConfirm) {

                        $http.post($scope.params['form'] + '/immobili/controller/immobileHandler.php',
                            {'function': 'gestisciStatoUI', 'idUI': idUI}
                        ).then(function (data, status, headers, config) {
                            window.location.href = $scope.params['home'] + encodeUrl("immobili", "immobile");
                        })
                    }
                    else {
                        swal("Ripristino annullato", "", "error");
                    }
                });
        }
    };

    /*******************
     *   MODIFICA UI   * ================================================================================================
     *******************/

    $scope.modifica = function (id) {
        window.location.href = params['home'] + encodeUrl('immobili', 'gestioneUnitaImmobiliari', id);
    };

    /*******************
     *   ESPORTA PDF   * ================================================================================================
     *******************/

    $scope.visualizzaImpoStampa = false;
    $scope.showImpostazioniStampa = function () {
        $scope.visualizzaImpoStampa = !$scope.visualizzaImpoStampa;
    };

    $scope.stampa = getStrutturaBasePDF();
    $scope.stampa.nomeFile = "immobili";

    $scope.getHeaderTable = function () {
        return ["UI", "INDIRIZZO", "COMUNE"];
    };

    $scope.creaFileDaScaricare = function () {
        $scope.fileExport = new Array();

        for (i = 0; i < $scope.elencoUIFiltrati.length; i++) {

            app = new Array();
            $scope.elencoUIFiltrati[i].descrizione != null ? app.push("" + $scope.elencoUIFiltrati[i].descrizione) : app.push("");
            $scope.elencoUIFiltrati[i].indirizzoVisualizzato != null ? app.push("" + $scope.elencoUIFiltrati[i].indirizzoVisualizzato) : app.push("");
            $scope.elencoUIFiltrati[i].comuneVisualizzato != null ? app.push("" + $scope.elencoUIFiltrati[i].comuneVisualizzato) : app.push("");

            $scope.fileExport.push(app);
        }

        //stampalog("File da scaricare:");
        //stampalog($scope.fileExport);

        return $scope.fileExport;
    };

    $scope.scaricaPDF = function () {
        scaricaPDF($scope.stampa, $scope.getHeaderTable(), $scope.creaFileDaScaricare());
    };

}]);