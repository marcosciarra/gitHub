ngApp.controller('gestioneUnitaImmobiliariController', ['$scope', '$http', '$filter', 'FileUploader', "ngToast", function ($scope, $http, $filter, FileUploader, $ngToast) {

    var params = decodeUrl(window.location.href, ['id_UI']);
    $scope.showRefresh = true;
    $scope.showIndietro = true;
    $scope.comuniCorti = [];
    $scope.elencoProprietari = [];
    $scope.proprietari = [];
    $scope.indiceDettagli = null;
    $scope.elencoAmministratore = [];
    $scope.elencoFornitore = [];

    //PREPARO DATI PER SELECT IN PAGINA
    $scope.statoImmobile = [
        {descrizione: 'DI LUSSO'},
        {descrizione: 'OTTIMO'},
        {descrizione: 'BUONO'},
        {descrizione: 'ABITABILE'},
        {descrizione: 'RESTAURATO'},
        {descrizione: 'DA RESTAURARE'}
    ];
    $scope.tipoRiscaldamento = [
        {descrizione: 'CENTRALIZZATO'},
        {descrizione: 'TERMOAUTONOMO'}
    ];
    $scope.elencoDettagli =
        {
            stato_unita: 2,
            numero_locali: '',
            numero_camere: '',
            numero_bagni: '',
            tipo_riscaldamento: 0,
            classe_energetica: '',
            aria_condizionata: 0,
            camino: 0,
            mq_coperti: '',
            mq_scoperti: '',
            superficie_commerciale: '',
            superficie_lorda: '',
            superficie_netta: '',
            esposizione_nord: 0,
            esposizione_sud: 0,
            esposizione_ovest: 0,
            esposizione_est: 0,
            arredato: 0,
            ascensore: 0,
            posto_auto: 0,
            posto_auto_privato: 0,
            box: 0,
            cantina: 0,
            mansarda: 0,
            balcone: 0,
            terrazzo: 0,
            giardino: 0
        };


    //sostituisce l'onload, da richiamare nel tag in cui si definisce il controller
    $scope.init = function () {
        $scope.caricamentoCompletato = false;
        $scope.getStrutturaUI();
        $scope.caricaComuniCorti();
        $scope.visualizza = 'datiImmobiliari';
    };
    $scope.mostraSezione = function (tab) {
        $scope.visualizza = tab;
    };

    $scope.caricaComuniCorti = function () {
        $http.post($scope.params['form'] + '/immobili/controller/gestioneUnitaImmobiliariHandler.php',
            {'function': 'getListaComuniCorti'}
        ).then(function (data, status, headers, config) {
            $scope.listaComuni = data.data;
            $scope.listaComuniApp = data.data;
            stampalog(data.data);
        })
    };

    $scope.ricercaCitta = function (c) {
        //var indice = $scope.listaComuni.indexOf(c);
        //stampalog($scope.listaComuni);
        //stampalog(indice);
        var appoggio = $filter('filter')($scope.listaComuni, {denominazione: c}, true)[0];

        if (c.length > 4 || appoggio != undefined) {
            $http.post($scope.params['form'] + '/immobili/controller/gestioneUnitaImmobiliariHandler.php',
                {'function': 'aggiornaCitta', 'c': c}
            ).then(function (data, status, headers, config) {
                if (c.length > 4) {
                    $scope.listaComuni = $scope.listaComuni.concat(data.data);
                }
                stampalog($scope.listaComuni);
                appoggio = $filter('filter')($scope.listaComuni, {denominazione: c}, true)[0];
                //stampalog(appoggio);
                if (appoggio != undefined) {
                    //stampalog($scope.listaComuni[0].id);
                    $http.post($scope.params['form'] + '/immobili/controller/gestioneUnitaImmobiliariHandler.php',
                        {'function': 'caricaDatiComune', 'id': appoggio.id}
                    ).then(function (data, status, headers, config) {
                        // setto campi
                        stampalog(data.data);
                        $scope.nuovaUI.indirizzo.codice_comune = data.data.codice_catastale;
                        $scope.nuovaUI.indirizzo.cap = data.data.cap;
                        $scope.nuovaUI.indirizzo.provincia = data.data.sigla_automobilistica;
                        $scope.nuovaUI.indirizzo.stato = data.data.alpha2;
                        $scope.listaComuni = $scope.listaComuniApp;
                    })
                }

                //se non trova nessun comune con quel nome setta stato a 'EE'
                if ($scope.listaComuni.length == 0) {
                    $scope.nuovaUI.indirizzo.stato = 'EE';
                }
            })
        }
        stampalog($scope.nuovaUI.indirizzo.cap);
    };

    /*******************
     *   CARICA DATI   * ================================================================================================
     *******************/
    $scope.getStrutturaUI = function () {

        var idUI = 0;
        if (params['id_UI'] !== undefined)
            idUI = params['id_UI'];

        $http.post($scope.params['form'] + '/immobili/controller/gestioneUnitaImmobiliariHandler.php',
            {'function': 'caricaDati', 'idUI': idUI}
        ).then(function (data, status, headers, config) {
            //if(idUI != 0)
            $scope.nuovaUI = data.data.ui;

            if (data.data.status == "ko") {
                swal("Errore", "Caricamento non riuscito", "error");
                return;
            }

            if (idUI == 0) {
                $scope.nuovaUI.indirizzo = data.data.nuovoIndirizzo;
            } else {
                $scope.nuovaUI.indirizzo = jsonParse(data.data.ui.indirizzo);
            }

            //stampalog($scope.nuovaUI.indirizzo);

            //Lista comuni
            $scope.listaComuni = data.data.listaComuni;

            //Tipi Uso ('cast' a INT)
            $scope.nuovaUI.id_tipo_uso = 1 * $scope.nuovaUI.id_tipo_uso;
            if ($scope.nuovaUI.dettagli == null || $scope.nuovaUI.dettagli == undefined) {
                $scope.nuovaUI.dettagli = $scope.elencoDettagli;
            }
            else{
                $scope.nuovaUI.dettagli=jsonParse($scope.nuovaUI.dettagli);
            }

            $scope.elencoTipiUso = data.data.elencoTipiUso;
            $scope.elencoCategorieCatastali = data.data.elencoCategorieCatastali;
            $scope.emptyProprietari = data.data.emptyProprietari;
            $scope.elencoAnagrafiche = data.data.elencoAnagrafiche;
            $scope.elencoTipiSoggetto = data.data.elencoTipiSoggetto;
            if (data.data.ui.proprietari != null)
                $scope.elencoProprietari = jsonParse(data.data.ui.proprietari);

            //$scope.presettaDati();


            /*------------------------------------------DETTAGLI IMMOBILE---------------------------------------------*/
            $scope.uiTipiDettagli = data.data.uiTipiDettagli;
            stampalog('TIPI');
            stampalog($scope.uiTipiDettagli);
            $scope.uiDettagliEliminati = [];
            $scope.uiDettagli = data.data.uiDettagli;
            for (var i = 0; i < $scope.uiDettagli.length; i++) {
                $scope.uiDettagli[i].nome_file = jsonParse($scope.uiDettagli[i].nome_file);
            }

            $scope.uiDettagliEmpty = data.data.uiDettagliEmpty;
            $scope.uiDettagliEmpty.id_unita_immobiliari = params['id_UI'];
            $scope.uiDettagliEmpty.data_scadenza_filtri = '';
            $scope.uiDettagliEmpty.nome_file = [];

            stampalog('Elenco Dettagli');
            stampalog($scope.uiDettagli);
            $scope.uiDettagliBackup = angular.copy($scope.uiDettagli);


            $scope.elencoStabili = data.data.elencoStabili;

            $scope.newUiDettagli = angular.copy($scope.uiDettagliEmpty);

            for (var i = 0; i < $scope.uiDettagli.length; i++) {
                if ($scope.uiDettagli[i].data_scadenza != null) {
                    $scope.uiDettagli[i].data_scadenza_filtri = formattaDataDbToIta($scope.uiDettagli[i].data_scadenza);
                    $scope.uiDettagli[i].data_scadenza = new Date($scope.uiDettagli[i].data_scadenza);
                    $scope.uiDettagli[i].nome_file = jsonParse($scope.uiDettagli[i].nome_file);
                }
            }

            stampalog($scope.elencoStabili);
            stampalog($scope.uiDettagli);
            $scope.elencoAmministratori = data.data.elencoAmministratori;
            $scope.elencoFornitori = data.data.elencoFornitori;
            $scope.elencoAmministratoreStabile = data.data.elencoAmministratoreStabile;
            $scope.elencoFornitoreStabile = data.data.elencoFornitoreStabile;

            $scope.elencoAmministratore = [];
            if ($scope.nuovaUI.id_amministratore > 0 && $scope.nuovaUI.id_amministratore != null) {
                $scope.elencoAmministratore = [$filter('filter')($scope.elencoAmministratori, {id: $scope.nuovaUI.id_amministratore}, true)[0]];
            }

            $scope.elencoFornitore = data.data.elencoFornitore;
            if ($scope.elencoFornitore == null) {
                $scope.elencoFornitore = [];
            } else {
                $scope.elencoFornitore = jsonParse($scope.elencoFornitore);
            }

            $scope.elencoAmministratoreStabile = data.data.elencoAmministratoreStabile;

            $scope.elencoFornitoreStabile = data.data.elencoFornitoreStabile;
            if ($scope.elencoFornitoreStabile == null) {
                $scope.elencoFornitoreStabile = [];
            } else {
                $scope.elencoFornitoreStabile = jsonParse($scope.elencoFornitoreStabile);
            }
            // stampalog($scope.elencoFornitoreStabile);

        });

        $scope.caricamentoCompletato = true;
    };

    /**********************
     *   CONTROLLA DATI   * ================================================================================================
     **********************/

    $scope.$watchGroup(["nuovaUI.indirizzo.comune", "nuovaUI.indirizzo.cap", "nuovaUI.indirizzo.provincia", "nuovaUI.indirizzo.stato",
        "nuovaUI.indirizzo.indirizzo", "nuovaUI.indirizzo.civico", "nuovaUI.id_stabili"], function () {
        if ($scope.nuovaUI) {
            if (
                $scope.nuovaUI.indirizzo.comune != '' &&
                $scope.nuovaUI.indirizzo.comune != undefined &&
                $scope.nuovaUI.indirizzo.comune != null &&
                $scope.nuovaUI.indirizzo.cap != '' &&
                $scope.nuovaUI.indirizzo.cap != undefined &&
                $scope.nuovaUI.indirizzo.cap != null &&
                $scope.nuovaUI.indirizzo.provincia != '' &&
                $scope.nuovaUI.indirizzo.provincia != undefined &&
                $scope.nuovaUI.indirizzo.provincia != null &&
                $scope.nuovaUI.indirizzo.stato != '' &&
                $scope.nuovaUI.indirizzo.stato != undefined &&
                $scope.nuovaUI.indirizzo.stato != null &&
                $scope.nuovaUI.indirizzo.indirizzo != '' &&
                $scope.nuovaUI.indirizzo.indirizzo != undefined &&
                $scope.nuovaUI.indirizzo.indirizzo != null &&
                $scope.nuovaUI.indirizzo.civico != '' &&
                $scope.nuovaUI.indirizzo.civico != undefined &&
                $scope.nuovaUI.indirizzo.civico != null &&
                $scope.nuovaUI.id_stabili != null

            ) {
                $scope.datiCorretti = true;
            } else {
                $scope.datiCorretti = false;
            }
        }
    });

    /*********************
     *   PRESETTA DATI   * ================================================================================================
     *********************/

    $scope.presettaDati = function () {
    };

    /*****************
     *   SALVADATI   * ================================================================================================
     *****************/

    $scope.salvaDati = function () {
        stampalog($scope.nuovaUI);

        if ($scope.elencoProprietari.length <= 0) {
            swal("Errore", "Selezionare almeno un proprietario", "error");
            return;
        }

        $perc = 0;
        for (i = 0; i < $scope.elencoProprietari.length; i++) {
            if (isNaN($scope.elencoProprietari[i].percentuale_possesso))
                $scope.elencoProprietari[i].percentuale_possesso = 0;
            $perc = $perc + $scope.elencoProprietari[i].percentuale_possesso;
        }
        if ($perc != 100) {
            swal("Errore", "Controllare le percentuali di possesso", "error");
            return;
        }

        if ($scope.nuovaUI.id_stabili < 1) {
            swal("Errore", "Associare l'unità immobiliare ad uno stabile", "error");
            return;
        }

        // se descrizione vuota concateno via e civico
        if ($scope.nuovaUI.descrizione == '' || $scope.nuovaUI.descrizione == undefined || $scope.nuovaUI.descrizione == null) {
            $scope.nuovaUI.descrizione = $scope.nuovaUI.indirizzo.tipoIndirizzo + " " + $scope.nuovaUI.indirizzo.indirizzo + " " + $scope.nuovaUI.indirizzo.civico;
        }
        $scope.nuovaUI.proprietari = $scope.elencoProprietari;

        // stampalog('file da salvare');
        // stampalog($scope.uiDettagli);
        // stampalog($scope.uiDettagliBackup);

        $http.post(params['form'] + '/immobili/controller/gestioneUnitaImmobiliariHandler.php',
            {
                'function': 'salvaDati',
                'object': $scope.nuovaUI,
                'elencoFornitore': $scope.elencoFornitore
            }
        ).then(function (data, status, headers, config) {
            stampalog(data);

            if (data.data.status == "ko") {
                swal("Errore", "Salvataggio non riuscito", "error");
            } else {

                $scope.salvaDettaglio(data.data.id);
                swal({
                    title: "Salvataggio eseguito",
                    text: "",
                    type: "success"
                }, function () {
                    window.location.href = $scope.params['home'] + encodeUrl("immobili", "immobile");
                });
            }
        });
    };


    $scope.anagraficaCorrispondente = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("anagrafica", "gestioneAnagrafica", id);
    };


    $scope.elencoUnitaImmobiliari = function () {
        window.location.href = $scope.params['home'] + encodeUrl("immobili", "immobile");
    };


    $scope.settings = {
        dynamicTitle: true,
        enableSearch: true,
        showSelectAll: false,
        keyboardControls: true,
        scrollable: true,
        showCheckAll: false,
        showUncheckAll: true,
        closeOnSelect: false,
        scrollableHeight: '200px',
        externalIdProp: '', //PERMETTE DI AGGIUNGERE ALL'ARRAY DEI SELEZIONATI TUTTO L'OGGETTO
        idProp: 'id', //definisco i campi di cui è composto l'oggetto
        displayProp: 'descrizione' //definisco i campi di cui è composto l'oggetto
    };

    $scope.customTextLocatori = {
        buttonDefaultText: 'Locatori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };

    $scope.multiSelectEvent = {
        onItemSelect: function (obj) {
            $appProprietario = angular.copy($scope.emptyProprietari);
            $appProprietario.id_proprietario = obj.id;
            $appProprietario.descrizione = obj.descrizione;
            $appProprietario.percentuale_possesso = 100;
            // $scope.elencoProprietari.push($appProprietario);
            // stampalog($scope.elencoProprietari);
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.elencoProprietari.length; i++) {
                if ($scope.elencoProprietari[i].id_proprietario == obj.id) {
                    $scope.elencoProprietari.splice(i, 1);
                    i--;
                }
            }
        }
    };


    $scope.aggiungiDettaglio = function () {

        if ($scope.newUiDettagli.data_scadenza == null) {
            $scope.newUiDettagli.data_scadenza_filtri = null;
        } else {
            $scope.newUiDettagli.data_scadenza_filtri = formattaDataDbToIta(getYYYYMMGGFromJsDate($scope.newUiDettagli.data_scadenza));
        }
        $scope.newUiDettagli.data_scadenza = ($scope.newUiDettagli.data_scadenza);

        $scope.uiDettagli.push($scope.newUiDettagli);
        $scope.newUiDettagli = angular.copy($scope.uiDettagliEmpty);

        stampalog($scope.uiDettagli);
    };

    $scope.eliminaDettaglio = function (id) {

        for (var i = 0; i < $scope.uiDettagli.length; i++) {
            if ($scope.uiDettagli[i].id == id) {
                $scope.uiDettagliEliminati.push($scope.uiDettagli[i]);
                $scope.uiDettagli.splice(i, 1);
            }
        }
    };


    $scope.salvaDettaglio = function (idUi) {

        for (var i = 0; i < $scope.uiDettagli.length; i++) {
            $scope.uiDettagli[i].data_scadenza = getYYYYMMGGFromJsDate($scope.uiDettagli[i].data_scadenza);
        }
        // stampalog($scope.uiDettagliEliminati);
        $http.post(params['form'] + '/immobili/controller/gestioneUnitaImmobiliariHandler.php',
            {
                'function': 'salvaDettaglio',
                'dettagli': $scope.uiDettagli,
                'dettagliBackup': $scope.uiDettagliBackup,
                'eliminabili': $scope.uiDettagliEliminati,
                'idUi': idUi
            }
        ).then(function (data, status, headers, config) {
            stampalog(data);

            if (data.data.status == "ko") {
                swal("Errore", "Salvataggio non riuscito", "error");
            }
        });
    };

    $scope.eliminaImmobile = function (idUi) {
        $http.post(params['form'] + '/immobili/controller/gestioneUnitaImmobiliariHandler.php',
            {
                'function': 'eliminaImmobile',
                'idUi': idUi
            }
        ).then(function (data, status, headers, config) {
            stampalog(data);

            switch (data.data.status) {
                case "ok":
                    swal({
                        title: "Eliminazione effettuata",
                        text: "",
                        type: "success"
                    }, function () {
                        window.location.href = $scope.params['home'] + encodeUrl("immobili", "immobile");
                    });
                    break;
                case "ko":
                    swal("Errore", "Eliminazione non riuscita", "error");
                    break;
                default:
                    swal("Errore", "Eliminazione non riuscita. Ci sono " + data.data.status + " contratti collegati.", "error");
                    break;
            }

        });
    };

    $scope.caricaDatiStabile = function (id) {
        for (var i = 0; i < $scope.elencoStabili.length; i++) {
            if ($scope.elencoStabili[i].id == id) {
                if ($scope.elencoStabili[i].indirizzo != null) {
                    var indirizzo = jsonParse($scope.elencoStabili[i].indirizzo);
                    $scope.nuovaUI.indirizzo.comune = indirizzo.comune;
                    $scope.nuovaUI.indirizzo.codice_comune = indirizzo.codice_comune;
                    $scope.nuovaUI.indirizzo.cap = indirizzo.cap;
                    $scope.nuovaUI.indirizzo.provincia = indirizzo.provincia;
                    $scope.nuovaUI.indirizzo.stato = indirizzo.stato;
                    $scope.nuovaUI.indirizzo.tipoIndirizzo = indirizzo.tipoIndirizzo;
                    $scope.nuovaUI.indirizzo.indirizzo = indirizzo.indirizzo;
                    $scope.nuovaUI.indirizzo.civico = indirizzo.civico;

                    $scope.nuovaUI.foglio = $scope.elencoStabili[i].foglio;
                    $scope.nuovaUI.sezione_urbana = $scope.elencoStabili[i].sezione_urbana;
                    $scope.nuovaUI.particella = $scope.elencoStabili[i].particella;
                    $scope.nuovaUI.subparticella = $scope.elencoStabili[i].subparticella;
                    $scope.nuovaUI.foglio = $scope.elencoStabili[i].foglio;
                    $scope.nuovaUI.foglio = $scope.elencoStabili[i].foglio;
                    $scope.nuovaUI.foglio = $scope.elencoStabili[i].foglio;
                    return;
                }
            }
        }
    };

    /*--------------------------------------------------UPLOAD--------------------------------------------------------*/


    $scope.strutturaJson = {
        "nomeFile": "",
        "descrizione": ""
    };

    $scope.caricaDettagliModale = function (elenco) {
        $scope.elencoModale = elenco;
    };

    var uploader = $scope.uploader = new FileUploader({
        url: '../src/function/upload.php'
    });

    uploader.onCompleteItem = function (fileItem, response, status, headers) {
        // $scope.nuovaSchedaAnagrafica.file_firma = response['fileName'];
        $scope.newJson = angular.copy($scope.strutturaJson);
        $scope.newJson.descrizione = response.fileNameOriginale;
        $scope.newJson.nomeFile = response.fileName;
        if ($scope.uiDettagli[$scope.indiceDettagli].nome_file == null)
            $scope.uiDettagli[$scope.indiceDettagli].nome_file = [];
        $scope.uiDettagli[$scope.indiceDettagli].nome_file.push($scope.newJson);

        stampalog($scope.uiDettagli);
        // stampalog(response);
        // stampalog($scope.indiceDettagli);
    };

    $scope.eliminaFileDettaglio = function (indice) {
        $scope.uiDettagli[$scope.indiceDettagli].nome_file.splice(indice, 1);
    };

    $scope.svuotaCodaUpload = function () {
        uploader.queue = [];
    };

    $scope.selezionaRecord = function (indice) {
        $scope.indiceDettagli = indice;
    };


    // $scope.stampaNomeAmministratoreStabile = function (id) {
    //     if (id != null && id != 0) {
    //         return $filter('filter')($scope.elencoAmministratori, {id: id})[0].descrizione;
    //     }
    // };

    $scope.stampaNomeAmministratore = function (id) {
        if (id != null && id != 0) {
            return $filter('filter')($scope.elencoAmministratori, {id: id})[0].descrizione;
        }
    };

    /*----------------------------------------------MULTISELECT-------------------------------------------------------*/
    $scope.settingsAmministratore = {
        dynamicTitle: true,
        enableSearch: true,
        showSelectAll: false,
        keyboardControls: true,
        scrollable: true,
        showCheckAll: false,
        showUncheckAll: true,
        closeOnSelect: false,
        scrollableHeight: '200px',
        selectionLimit: 1,
        externalIdProp: '', //PERMETTE DI AGGIUNGERE ALL'ARRAY DEI SELEZIONATI TUTTO L'OGGETTO
        id: 'id', //definisco i campi di cui è composto l'oggetto
        displayProp: 'descrizione' //definisco i campi di cui è composto l'oggetto
    };

    $scope.settingsFornitore = {
        dynamicTitle: true,
        enableSearch: true,
        showSelectAll: false,
        keyboardControls: true,
        scrollable: true,
        showCheckAll: false,
        showUncheckAll: true,
        closeOnSelect: false,
        scrollableHeight: '200px',
        externalIdProp: '', //PERMETTE DI AGGIUNGERE ALL'ARRAY DEI SELEZIONATI TUTTO L'OGGETTO
        id: 'id', //definisco i campi di cui è composto l'oggetto
        displayProp: 'descrizione' //definisco i campi di cui è composto l'oggetto
    };

    $scope.customTextAmministratore = {
        buttonDefaultText: 'Amministratore',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };

    $scope.customTextFornitore = {
        buttonDefaultText: 'Fornitore',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };

    $scope.multiSelectEventAmm = {
        onItemSelect: function (obj) {
            $scope.nuovaUI.id_amministratore = obj.id;
        },
        onItemDeselect: function () {
            $scope.nuovaUI.id_amministratore = null;
        },
        onDeselectAll: function () {
            $scope.nuovaUI.id_amministratore = null;
        }
    };
    $scope.multiSelectEventFor = {
        onItemSelect: function (obj) {
            // $scope.stabili.id_amministratore = obj.id;
        },
        onItemDeselect: function () {
            // $scope.stabili.id_amministratore = null;
        }
    };

}]);