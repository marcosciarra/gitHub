<?php

require_once '../../../conf/conf.php';
require_once '../../../src/function/functionLogin.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';
require_once '../../../src/model/DrakkarTraceLog.php';

require_once '../../../src/model/UnitaImmobiliari.php';
require_once '../../../src/model/UnitaImmobiliariContratti.php';
require_once '../../../src/model/UnitaImmobiliariDettagli.php';
require_once '../../../src/model/Comuni.php';
require_once '../../../src/model/TipiUso.php';
require_once '../../../src/model/CategorieCatastali.php';
require_once '../../../src/model/Anagrafiche.php';
require_once '../../../src/model/TipoSoggetto.php';
require_once '../../../src/model/Stabili.php';
require_once '../../../src/model/Contratti.php';

use Click\Affitti\TblBase\UnitaImmobiliari;
use Click\Affitti\TblBase\Comuni;
use Click\Affitti\TblBase\TipiUso;
use Click\Affitti\TblBase\CategorieCatastali;
use Click\Affitti\TblBase\Anagrafiche;
use Click\Affitti\TblBase\TipoSoggetto;
use Click\Affitti\TblBase\UnitaImmobiliariDettagli;
use Click\Affitti\TblBase\Stabili;
use Click\Affitti\TblBase\Contratti;
use Click\Affitti\TblBase\UnitaImmobiliariContratti;

function getListaComuniCorti($request)
{
    // CARICO DATI LISTA COMUNI CON NOME CORTO

    $con = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
    $anagrafiche = new \Click\Affitti\TblBase\Comuni($con);
    $result = $anagrafiche->getListaComuniCorti(Comuni::FETCH_KEYARRAY);

    return json_encode($result);

}

function aggiornaCitta($request)
{
    // CARICO DATI LISTA COMUNI
    $con = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
    //echo $con->getSkema();
    $anagrafiche = new \Click\Affitti\TblBase\Comuni($con);
    //$app=$anagrafiche->findAll(false, Anagrafiche::FETCH_KEYARRAY,1,0);
    $result = $anagrafiche->getLista2($request->c);

    // RETURN
    return json_encode($result);
}

function caricaDatiComune($request)
{
    // CARICO DATI LISTA COMUNI
    $con = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
    //echo $con->getSkema();
    $anagrafiche = new \Click\Affitti\TblBase\Comuni($con);
    //$app=$anagrafiche->findAll(false, Anagrafiche::FETCH_KEYARRAY,1,0);
    $result = $anagrafiche->getInfoComuneById($request->id);

    // RETURN
    return json_encode($result);
}

function caricaDati($request)
{
    $result = array();
    try {
        // CARICO DATI UNITA IMMOBILIARE
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
        //echo $con->getSkema();
        $ui = new \Click\Affitti\TblBase\UnitaImmobiliari($con);
        if ($request->idUI)
            $result['ui'] = $ui->findByPk($request->idUI, UnitaImmobiliari::FETCH_KEYARRAY);
        else {
            $result['ui'] = $ui->getEmptyDbKeyArray();
            $result['nuovoIndirizzo'] = $ui->getEmptyIndirizzo();
        }

        $tipiUso = new TipiUso($con);
        $result['elencoTipiUso'] = $tipiUso->findAll(false, TipiUso::FETCH_KEYARRAY);
        $categoriaCat = new CategorieCatastali($conExt);
        $result['elencoCategorieCatastali'] = $categoriaCat->findAllPerSelect(false, TipiUso::FETCH_KEYARRAY);

        $result['emptyProprietari'] = $ui->getEmptyElencoProprietari();
        $anagrafica = new Anagrafiche($con);
        $anagrafica->setWhereBase(' cestino=0 ');
        $anagrafica->setOrderBase(' descrizione ASC ');
        $result['elencoAnagrafiche'] = $anagrafica->findAllPerSelect(Anagrafiche::FETCH_KEYARRAY);
        $tipiSoggetto = new TipoSoggetto($conExt);
        $result['elencoTipiSoggetto'] = $tipiSoggetto->findAll(false, TipiUso::FETCH_KEYARRAY);

        $uiDettagli = new UnitaImmobiliariDettagli($con);
        $result['uiDettagli'] = $uiDettagli->findByIdxUnitaImmobiliari($request->idUI, UnitaImmobiliariDettagli::FETCH_KEYARRAY);
        $result['uiDettagliEmpty'] = $uiDettagli->getEmptyDbKeyArray();
        $result['uiTipiDettagli'] = $uiDettagli->getTipoValuesList(true);

        $stabili = new Stabili($con);

        $stabili->setWhereBase(' cestino=0 ');
        $stabili->setOrderBase(' descrizione ASC ');
        $result['elencoStabili'] = $stabili->findAll(false, Stabili::FETCH_KEYARRAY);

        $anagrafica = new Anagrafiche($con);
        $anagrafica->setWhereBase(' cestino=0 AND amministratore_condominio IS NOT NULL');
        $anagrafica->setOrderBase(' descrizione ASC ');
        $result['elencoAmministratori'] = $anagrafica->findAllPerSelect(Anagrafiche::FETCH_KEYARRAY);
        $anagrafica->setWhereBase(' cestino=0 AND fornitore IS NOT NULL');
        $anagrafica->setOrderBase(' descrizione ASC ');
        $result['elencoFornitori'] = $anagrafica->findAllPerSelect(Anagrafiche::FETCH_KEYARRAY);

        $result['elencoAmministratore'] = $result['ui']['id_amministratore'];
        $result['elencoFornitore'] = $result['ui']['fornitori_riferimento'];


        $stabile = new Stabili($con);
        $st = $stabile->findByPk($result['ui']['id_stabili'], Stabili::FETCH_KEYARRAY);
        $result['elencoAmministratoreStabile'] = $st['id_amministratore'];
        $result['elencoFornitoreStabile'] = $st['fornitori_riferimento'];


        // RETURN
        $result['status'] = 'ok';
        return json_encode($result);

    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        echo json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        echo json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

function salvaDati($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $ui = new UnitaImmobiliari($con);
        $request->object->proprietari = json_encode($request->object->proprietari);

        if ($request->object->id_amministratore == null)
            $request->object->id_amministratore = UnitaImmobiliari::NULL_VALUE;

        if (count($request->elencoFornitore) > 0) {
            $request->object->fornitori_riferimento = json_encode($request->elencoFornitore);
        } else {
            $request->object->fornitori_riferimento = Stabili::NULL_VALUE;
        }

        $ui->creaObjJson($request->object, true);
        //$ui->saveOrUpdate();
        $ui->saveOrUpdateAndLog(getLoginDataFromSession('id'));
        $con->commit();

        $result['id'] = $ui->getId();
        $result['status'] = 'ok';
        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        $result['status'] = 'ko';
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        $result['status'] = 'ko';
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


function eliminaImmobile($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $uic = new UnitaImmobiliariContratti($con);
        if (count($uic->findByIdxIdUnitaImmobiliare($request->idUi, UnitaImmobiliariContratti::FETCH_KEYARRAY)) == 0) {
            $ui = new UnitaImmobiliari($con);
            $ui->deleteByPk($request->idUi);
            $con->commit();
            $result['status'] = 'ok';
        }
        else{
            $result['status'] = count($uic->findByIdxIdUnitaImmobiliare($request->idUi, UnitaImmobiliariContratti::FETCH_KEYARRAY));
        }
        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        $result['status'] = 'ko';
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        $result['status'] = 'ko';
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


function salvaDettaglio($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $uiD = new UnitaImmobiliariDettagli($con);

        $con->beginTransaction();

        //Controllo se ho file già caricati precedentemente da eliminare
        if (count($request->eliminabili) > 0) {
            for ($i = 0; $i < count($request->eliminabili); $i++) {
                for ($j = 0; $j < count($request->eliminabili[$i]->nome_file); $j++) {
                    $nomeFile = $request->eliminabili[$i]->nome_file[$j]->nomeFile;
                    $nomeFile = UPLOAD_URL . DIRECTORY_SEPARATOR . $nomeFile;
                    if (file_exists($nomeFile))
                        unlink($nomeFile);
                }
                $uiD->deleteByPk($request->eliminabili[$i]->id);
            }
        }

        //Controllo se ci sono dei file da eliminare tra i dettagli già caricati precedentemente
        for ($i = 0; $i < count($request->dettagliBackup); $i++) {
            for ($j = 0; $j < count($request->dettagliBackup[$i]->nome_file); $j++) {
                $fileTrovato = false;
                for ($m = 0; $m < count($request->dettagli); $m++) {
                    for ($n = 0; $n < count($request->dettagli[$m]->nome_file); $n++) {
                        if ($request->dettagliBackup[$i]->nome_file[$j]->nomeFile == $request->dettagli[$m]->nome_file[$n]->nomeFile) {
                            $fileTrovato = true;
                        }
                    }
                }
                if ($fileTrovato == false) {
                    $nomeFile = $request->dettagliBackup[$i]->nome_file[$j]->nomeFile;
                    $nomeFile = UPLOAD_URL . DIRECTORY_SEPARATOR . $nomeFile;
                    if (file_exists($nomeFile))
                        unlink($nomeFile);
                }
            }
        }

        //Controllo tutti i file che non hanno la U come inizio file e li rinomino con la U all'inizio e
        //li sposto dalla cartella Temp alla cartella Upload
        for ($i = 0; $i < count($request->dettagli); $i++) {
            for ($j = 0; $j < count($request->dettagli[$i]->nome_file); $j++) {
                $nomeFile = $request->dettagli[$i]->nome_file[$j]->nomeFile;
                if (substr($nomeFile, 0, 1) != 'U') {
                    $oldName = $request->dettagli[$i]->nome_file[$j]->nomeFile;
                    $request->dettagli[$i]->nome_file[$j]->nomeFile = 'U' . $request->dettagli[$i]->nome_file[$j]->nomeFile;
                    $newName = $request->dettagli[$i]->nome_file[$j]->nomeFile;
                    rename(
                        UPLOAD_URL . DIRECTORY_SEPARATOR . 'temp' .
                        DIRECTORY_SEPARATOR . $oldName
                        ,
                        UPLOAD_URL .
                        DIRECTORY_SEPARATOR . $newName
                    );
                }
            }
        }


        for ($i = 0; $i < count($request->dettagli); $i++) {
            $uiD = new UnitaImmobiliariDettagli($con);
            $uiD->findByPk($request->dettagli[$i]->id);
            $uiD->setIdUnitaImmobiliari($request->idUi);
            $uiD->setTipo($request->dettagli[$i]->tipo);
            $uiD->setCodice($request->dettagli[$i]->codice);
            $uiD->setDescrizione($request->dettagli[$i]->descrizione);
            $uiD->setDataScadenza($request->dettagli[$i]->data_scadenza);
            $uiD->setNomeFile($request->dettagli[$i]->nome_file);
            $uiD->saveOrUpdateAndLog(getLoginDataFromSession('id'));
        }

        $con->commit();

        $result['status'] = 'ok';

        return json_encode($result);
    } catch
    (\Drakkar\Exception\DrakkarConnectionException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

/**/
ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;