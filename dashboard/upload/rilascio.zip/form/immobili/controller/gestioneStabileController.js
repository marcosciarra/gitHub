ngApp.controller('gestioneStabileController', ['$scope', '$http', '$filter', function ($scope, $http, $filter) {

    var params = decodeUrl(window.location.href, ['id']);
    $scope.showRefresh = true;
    $scope.showIndietro = true;
    $scope.comuniCorti = [];

    //sostituisce l'onload, da richiamare nel tag in cui si definisce il controller
    $scope.init = function () {
        $scope.caricamentoCompletato = false;
        $scope.getStruttura();
        $scope.caricaComuniCorti();
        $scope.visualizza = 'datiImmobiliari';
    };

    $scope.mostraSezione = function (tab) {
        $scope.visualizza = tab;
    };

    $scope.caricaComuniCorti = function () {
        $http.post($scope.params['form'] + '/immobili/controller/gestioneStabileHandler.php',
            {'function': 'getListaComuniCorti'}
        ).then(function (data, status, headers, config) {
            $scope.listaComuni = data.data;
            $scope.listaComuniApp = data.data;
            stampalog(data.data);
        })
    };

    $scope.ricercaCitta = function (c) {
        //var indice = $scope.listaComuni.indexOf(c);
        //stampalog($scope.listaComuni);
        //stampalog(indice);
        var appoggio = $filter('filter')($scope.listaComuni, {denominazione: c}, true)[0];

        if (c.length > 4 || appoggio != undefined) {
            $http.post($scope.params['form'] + '/immobili/controller/gestioneStabileHandler.php',
                {'function': 'aggiornaCitta', 'c': c}
            ).then(function (data, status, headers, config) {
                if (c.length > 4) {
                    $scope.listaComuni = $scope.listaComuni.concat(data.data);
                }
                stampalog($scope.listaComuni);
                appoggio = $filter('filter')($scope.listaComuni, {denominazione: c}, true)[0];
                //stampalog(appoggio);
                if (appoggio != undefined) {
                    //stampalog($scope.listaComuni[0].id);
                    $http.post($scope.params['form'] + '/immobili/controller/gestioneStabileHandler.php',
                        {'function': 'caricaDatiComune', 'id': appoggio.id}
                    ).then(function (data, status, headers, config) {
                        // setto campi
                        stampalog(data.data);
                        $scope.stabili.indirizzo.codice_comune = data.data.codice_catastale;
                        $scope.stabili.indirizzo.cap = data.data.cap;
                        $scope.stabili.indirizzo.provincia = data.data.sigla_automobilistica;
                        $scope.stabili.indirizzo.stato = data.data.alpha2;
                        $scope.listaComuni = $scope.listaComuniApp;
                    })
                }

                //se non trova nessun comune con quel nome setta stato a 'EE'
                if ($scope.listaComuni.length == 0) {
                    $scope.stabili.indirizzo.stato = 'EE';
                }
            })
        }
        stampalog($scope.stabili.indirizzo.cap);
    };

    /*******************
     *   CARICA DATI   * ================================================================================================
     *******************/
    $scope.getStruttura = function () {
        $scope.caricamentoCompletato = false;
        var idStabile = 0;
        if (params['id'] !== undefined)
            idStabile = params['id'];

        $http.post($scope.params['form'] + '/immobili/controller/gestioneStabileHandler.php',
            {'function': 'caricaDati', 'idStabile': idStabile}
        ).then(function (data, status, headers, config) {
            //if(idStabile != 0)
            //stampalog(data.data);
            $scope.stabili = data.data.stabili;

            if (data.data.status == "ko") {
                swal("Errore", "Caricamento non riuscito", "error");
                return;
            }

            if (idStabile == 0) {
                $scope.stabili.indirizzo = data.data.nuovoIndirizzo;
            } else {
                $scope.stabili.indirizzo = jsonParse(data.data.stabili.indirizzo);
            }

            //stampalog($scope.stabili.indirizzo);

            //Lista comuni
            $scope.listaComuni = data.data.listaComuni;

            //Tipi Uso ('cast' a INT)
            $scope.elencoCategorieCatastali = data.data.elencoCategorieCatastali;

            //Elenco UI per stabile
            if (idStabile == 0) {
                $scope.elencoUI = [];
            }
            else {
                $scope.elencoUI = data.data.immobili;
            }
            stampalog($scope.elencoUI);

            $scope.elencoAmministratori = data.data.elencoAmministratori;
            $scope.elencoFornitori = data.data.elencoFornitori;

            $scope.elencoAmministratore = [];
            if ($scope.stabili.id_amministratore > 0 && $scope.stabili.id_amministratore != null) {
                $scope.elencoAmministratore = [$filter('filter')($scope.elencoAmministratori, {id: $scope.stabili.id_amministratore}, true)[0]];
            }

            $scope.elencoFornitore = data.data.elencoFornitore;
            if ($scope.elencoFornitore == null) {
                $scope.elencoFornitore = [];
            }
            else {
                $scope.elencoFornitore = jsonParse($scope.elencoFornitore);
            }

            //$scope.presettaDati();
        });

        $scope.caricamentoCompletato = true;
    };

    /**********************
     *   CONTROLLA DATI   * ================================================================================================
     **********************/

    $scope.$watchGroup(["stabili.indirizzo.cap", "stabili.indirizzo.provincia", "stabili.indirizzo.stato",
        "stabili.indirizzo.indirizzo", "stabili.indirizzo.civico"], function () {
        if ($scope.stabili) {
            if (
                $scope.stabili.indirizzo.cap != '' &&
                $scope.stabili.indirizzo.cap != undefined &&
                $scope.stabili.indirizzo.cap != null &&
                $scope.stabili.indirizzo.provincia != '' &&
                $scope.stabili.indirizzo.provincia != undefined &&
                $scope.stabili.indirizzo.provincia != null &&
                $scope.stabili.indirizzo.stato != '' &&
                $scope.stabili.indirizzo.stato != undefined &&
                $scope.stabili.indirizzo.stato != null &&
                $scope.stabili.indirizzo.indirizzo != '' &&
                $scope.stabili.indirizzo.indirizzo != undefined &&
                $scope.stabili.indirizzo.indirizzo != null &&
                $scope.stabili.indirizzo.civico != '' &&
                $scope.stabili.indirizzo.civico != undefined &&
                $scope.stabili.indirizzo.civico != null

            ) {
                $scope.datiCorretti = true;
            } else {
                $scope.datiCorretti = false;
            }
        }
    });

    /*********************
     *   PRESETTA DATI   * ================================================================================================
     *********************/

    $scope.presettaDati = function () {
    };

    /*****************
     *   SALVADATI   * ================================================================================================
     *****************/

    $scope.salvaDati = function () {
        stampalog($scope.stabili);
        // se descrizione vuota concateno via e civico
        if ($scope.stabili.descrizione == '' || $scope.stabili.descrizione == undefined || $scope.stabili.descrizione == null) {
            $scope.stabili.descrizione = $scope.stabili.indirizzo.tipoIndirizzo + " " + $scope.stabili.indirizzo.indirizzo + " " + $scope.stabili.indirizzo.civico;
        }
        $http.post(params['form'] + '/immobili/controller/gestioneStabileHandler.php',
            {
                'function': 'salvaDati',
                'object': $scope.stabili,
                'elencoFornitore': $scope.elencoFornitore
            }
        ).then(function (data, status, headers, config) {
            stampalog(data);

            if (data.data.status == "ko") {
                swal("Errore", "Salvataggio non riuscito", "error");
            } else {
                swal({
                    title: "Salvataggio eseguito",
                    text: "",
                    type: "success"
                }, function () {
                    window.location.href = $scope.params['home'] + encodeUrl("immobili", "stabili");
                });
            }
        });
    };


    $scope.elencoStabili = function () {
        window.location.href = $scope.params['home'] + encodeUrl("immobili", "stabili");
    };

    $scope.modificaUI = function (idUI) {
        window.location.href = $scope.params['home'] + encodeUrl("immobili", "gestioneUnitaImmobiliari", idUI);
    };

    $scope.stampaNomeAmministratore = function (id) {
        if (id != null && id != 0) {
            return $filter('filter')($scope.elencoAmministratori, {id: id})[0].descrizione;
        }
    };

    $scope.anagraficaCorrispondente = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("anagrafica", "gestioneAnagrafica", id);
    };


    /*----------------------------------------------MULTISELECT-------------------------------------------------------*/
    $scope.settingsAmministratore = {
        dynamicTitle: true,
        enableSearch: true,
        showSelectAll: false,
        keyboardControls: true,
        scrollable: true,
        showCheckAll: false,
        showUncheckAll: true,
        closeOnSelect: false,
        scrollableHeight: '200px',
        selectionLimit: 1,
        externalIdProp: '', //PERMETTE DI AGGIUNGERE ALL'ARRAY DEI SELEZIONATI TUTTO L'OGGETTO
        id: 'id', //definisco i campi di cui è composto l'oggetto
        displayProp: 'descrizione' //definisco i campi di cui è composto l'oggetto
    };

    $scope.settingsFornitore = {
        dynamicTitle: true,
        enableSearch: true,
        showSelectAll: false,
        keyboardControls: true,
        scrollable: true,
        showCheckAll: false,
        showUncheckAll: true,
        closeOnSelect: false,
        scrollableHeight: '200px',
        externalIdProp: '', //PERMETTE DI AGGIUNGERE ALL'ARRAY DEI SELEZIONATI TUTTO L'OGGETTO
        id: 'id', //definisco i campi di cui è composto l'oggetto
        displayProp: 'descrizione' //definisco i campi di cui è composto l'oggetto
    };

    $scope.customTextAmministratore = {
        buttonDefaultText: 'Amministratore',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };

    $scope.customTextFornitore = {
        buttonDefaultText: 'Fornitore',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };

    $scope.multiSelectEventAmm = {
        onItemSelect: function (obj) {
            $scope.stabili.id_amministratore = obj.id;
        },
        onItemDeselect: function () {
            $scope.stabili.id_amministratore = null;
        },
        onDeselectAll: function () {
            $scope.stabili.id_amministratore = null;
        }
    };
    $scope.multiSelectEventFor = {
        onItemSelect: function (obj) {
            // $scope.stabili.id_amministratore = obj.id;
        },
        onItemDeselect: function () {
            // $scope.stabili.id_amministratore = null;
        }
    };

}]);