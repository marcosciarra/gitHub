ngApp.controller("scadenzeController", ["$scope", "$http", "$filter", function ($scope, $http, $filter) {

    var url = window.location.href;
    var params = decodeUrl(url, ['data_inizio', 'data_fine']);
    stampalog(params);

    $scope.caricamentoCompletato = false;
    $scope.pannelloDx = '';
    $scope.filtro = false;
    $scope.elencoUtenti = [];
    $scope.elencoStabili = [];
    $scope.elencoLocatori = [];
    $scope.elencoConduttori = [];
    $scope.filtroUtenti = [];
    $scope.filtroStabili = [];
    $scope.filtroLocatori = [];
    $scope.filtroConduttori = [];

    /*--------------------------------------------------CARICA DATI---------------------------------------------------*/

    $scope.init = function () {
        $scope.dataVersamento = new Date();

        $scope.filtroDataFine = getJsDateFromYYYYMMGG(params['data_fine']);
        $scope.filtroDataInizio = getJsDateFromYYYYMMGG(params['data_inizio']);


        $scope.selezionatiTutti = true;
        $scope.visualizzaArretrati = false;

        $scope.doc = true;
        // $scope.pIstat = true;
        $scope.vIstat = true;
        $scope.regContr = true;
        $scope.pror = true;
        $scope.disd = true;
        $scope.scadCont = true;
        $scope.cauzCont = true;
        $scope.immCont = true;
        $scope.rli = true;
        $scope.eFatture = true;

        $scope.caricaDati();
    };

    $scope.caricaDati = function () {
        $scope.caricamentoCompletato = false;
        $scope.caricaFiltri();
        $http.post(params['form'] + '/cruscotto/controller/scadenzeHandler.php',
            {
                'function': 'caricaDati',
                'data_inizio': getYYYYMMGGFromJsDate($scope.filtroDataInizio),
                'data_fine': getYYYYMMGGFromJsDate($scope.filtroDataFine)
            }
        ).then(function (data, status, headers, config) {

            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }

            $scope.scadenze = data.data.scadenze;


            for (var i = 0; i < $scope.scadenze.length; i++) {
                $scope.scadenze[i].selezionato = true;
                if ($scope.scadenze[i].contratto != null) {
                    if ($scope.scadenze[i].contratto.anagrafica_locatori != null) {
                        if ($scope.scadenze[i].contratto.anagrafica_locatori[0].ragione_sociale != undefined) {
                            $scope.scadenze[i].proprietario =
                                $scope.scadenze[i].contratto.anagrafica_locatori[0].ragione_sociale;
                        } else {
                            $scope.scadenze[i].proprietario =
                                $scope.scadenze[i].contratto.anagrafica_locatori[0].cognome + ' ' +
                                $scope.scadenze[i].contratto.anagrafica_locatori[0].nome;
                        }
                    }
                    if ($scope.scadenze[i].contratto.anagrafica_conduttori != null) {
                        if ($scope.scadenze[i].contratto.anagrafica_conduttori[0].ragione_sociale != undefined) {
                            $scope.scadenze[i].inquilino =
                                $scope.scadenze[i].contratto.anagrafica_conduttori[0].ragione_sociale;
                        } else {
                            $scope.scadenze[i].inquilino =
                                $scope.scadenze[i].contratto.anagrafica_conduttori[0].cognome + ' ' +
                                $scope.scadenze[i].contratto.anagrafica_conduttori[0].nome;
                        }
                    }
                    if ($scope.scadenze[i].contratto.unita_immobiliari != null) {
                        $scope.scadenze[i].immobile = $scope.scadenze[i].contratto.unita_immobiliari[0].descrizione;
                    }

                    if ($scope.scadenze[i].contratto.anagrafica_locatori != null) {
                        for (var j = 0; j < $scope.scadenze[i].contratto.anagrafica_locatori.length; j++) {
                            if ($scope.scadenze[i].contratto.anagrafica_locatori[j].ragione_sociale != undefined) {
                                $scope.scadenze[i].contratto.anagrafica_locatori[j].descrizione =
                                    $scope.scadenze[i].contratto.anagrafica_locatori[j].ragione_sociale;
                            } else {
                                $scope.scadenze[i].contratto.anagrafica_locatori[j].descrizione =
                                    $scope.scadenze[i].contratto.anagrafica_locatori[j].cognome + ' ' +
                                    $scope.scadenze[i].contratto.anagrafica_locatori[j].nome;
                            }
                        }
                    }
                    if ($scope.scadenze[i].contratto.anagrafica_conduttori != null) {
                        for (var j = 0; j < $scope.scadenze[i].contratto.anagrafica_conduttori.length; j++) {
                            if ($scope.scadenze[i].contratto.anagrafica_conduttori[j].ragione_sociale != undefined) {
                                $scope.scadenze[i].contratto.anagrafica_conduttori[j].descrizione =
                                    $scope.scadenze[i].contratto.anagrafica_conduttori[j].ragione_sociale;
                            } else {
                                $scope.scadenze[i].contratto.anagrafica_conduttori[j].descrizione =
                                    $scope.scadenze[i].contratto.anagrafica_conduttori[j].cognome + ' ' +
                                    $scope.scadenze[i].contratto.anagrafica_conduttori[j].nome;
                            }
                        }
                    }
                }
            }

            $scope.backupScadenze = angular.copy($scope.scadenze);

            stampalog(data.data.scadenze);

            $scope.aggiornaScadenze();

            $scope.filtro = false;
            $scope.caricamentoCompletato = true;

        });
    };

    $scope.aggiornaScadenze = function () {
        $scope.scadenze = [];
        for (var i = 0; i < $scope.backupScadenze.length; i++) {
            if ($scope.backupScadenze[i]['tipo'] == 'D' && $scope.doc == true) $scope.scadenze.push($scope.backupScadenze[i]);
            // if($scope.backupScadenze[i]['tipo']=='PI' && $scope.pIstat==true) $scope.scadenze.push($scope.backupScadenze[i]);
            if ($scope.backupScadenze[i]['tipo'] == 'VI' && $scope.vIstat == true) $scope.scadenze.push($scope.backupScadenze[i]);
            if ($scope.backupScadenze[i]['tipo'] == 'CR' && $scope.regContr == true) $scope.scadenze.push($scope.backupScadenze[i]);
            if ($scope.backupScadenze[i]['tipo'] == 'R' && $scope.pror == true) $scope.scadenze.push($scope.backupScadenze[i]);
            if ($scope.backupScadenze[i]['tipo'] == 'CD' && $scope.disd == true) $scope.scadenze.push($scope.backupScadenze[i]);
            if ($scope.backupScadenze[i]['tipo'] == 'CS' && $scope.scadCont == true) $scope.scadenze.push($scope.backupScadenze[i]);
            if ($scope.backupScadenze[i]['tipo'] == 'CA' && $scope.cauzCont == true) $scope.scadenze.push($scope.backupScadenze[i]);
            if ($scope.backupScadenze[i]['tipo'] == 'UI' && $scope.immCont == true) $scope.scadenze.push($scope.backupScadenze[i]);
            if ($scope.backupScadenze[i]['tipo'] == 'RL' && $scope.rli == true) $scope.scadenze.push($scope.backupScadenze[i]);
            if ($scope.backupScadenze[i]['tipo'] == 'EF' && $scope.eFatture == true) $scope.scadenze.push($scope.backupScadenze[i]);
        }
    };

    /* =================================== FILTRI E ORDINAMENTI ===================================================== */

    $scope.selezionaDeselezionaTutti = function (flag) {
        $scope.selezionatiTutti = flag;
        for (var i = 0; i < $scope.scadenze.length; i++) {
            $scope.scadenze[i].selezionato = flag;
        }
    };

    $scope.filtri = function () {
        $scope.caricaDati();
        $scope.svuotaMultiselect();
    };

    /*******************
     *   ESPORTA PDF   * ================================================================================================
     *******************/

    $scope.visualizzaImpoStampa = false;
    $scope.showImpostazioniStampa = function () {
        $scope.visualizzaImpoStampa = !$scope.visualizzaImpoStampa;
    };

    $scope.stampa = getStrutturaBasePDF();
    $scope.stampa.nomeFile = "ELENCO SCADENZE";

    $scope.getHeaderTable = function () {
        return ["TIPO SCADENZA", "PROPRIETARI", "INQUILINI", "IMMOBILI", "SCADENZA"];
    };

    $scope.creaFileDaScaricare = function () {
        $scope.fileExport = new Array();

        for (var i = 0; i < $scope.scadenze.length; i++) {
            if ($scope.scadenze[i].selezionato) {
                app = new Array();
                $scope.scadenze[i].descrizione != null ? app.push("" + $scope.scadenze[i].descrizione) : app.push("");
                $scope.scadenze[i].proprietario != null ? app.push("" + $scope.scadenze[i].proprietario) : app.push("");
                $scope.scadenze[i].inquilino != null ? app.push("" + $scope.scadenze[i].inquilino) : app.push("");
                $scope.scadenze[i].immobile != null ? app.push("" + $scope.scadenze[i].immobile) : app.push("");
                var dataScad = getYYYYMMGGFromJsDate($scope.scadenze[i].data);
                if ($scope.scadenze[i].data == '')
                    dataScad = null;
                dataScad != null ? app.push("" + stampaDataFormattata(dataScad)) : app.push("");

                $scope.fileExport.push(app);
            }

        }

        //stampalog("File da scaricare:");
        //stampalog($scope.fileExport);

        return $scope.fileExport;
    };

    $scope.scaricaPDF = function () {
        var title = 'ELENCO SCADENZE';
        // title += ' - Imposte di registro in scadenda dal ' + stampaDataFormattata($scope.filtroDataInizio);
        // title += ' al ' + stampaDataFormattata($scope.filtroDataFine);
        var elencoDaStampare = $scope.creaFileDaScaricare();
        if (elencoDaStampare.length > 0) {
            scaricaPDF($scope.stampa, $scope.getHeaderTable(), elencoDaStampare, title);
        } else {
            swal('Errore', 'Nessun contratto selezionato', 'error');
            return;
        }
    };

    stampaDataFormattata = function (data) {
        return $filter('date')(data, "dd/MM/yyyy");
    };


    $scope.apriContratto = function (idContratto) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "gestioneContratto", idContratto);
    };
    $scope.apriImmobile = function (idContratto) {
        window.location.href = $scope.params['home'] + encodeUrl("immobili", "gestioneUnitaImmobiliari", idContratto);
    };
    $scope.apriEfatture = function () {
        window.location.href = $scope.params['home'] + encodeUrl("fatturazione", "eFatture");
    };

    $scope.caricaDettagliModale = function (elenco, etichetta) {
        $scope.elencoModale = elenco;
        $scope.etichettaModale = etichetta;
    };


    //---------------------------------------------------SEZIONE FILTRI-----------------------------------------------//
    $scope.caricaFiltri = function () {
        $http.post($scope.params['form'] + "/template/controller/homeHandler.php",
            {'function': 'caricaFiltri'}
        ).then(function (data, status, headers, config) {
            // stampalog(data.data);
            $scope.filtriSelectPagina = data.data;
        });
    };
    $scope.settings = {
        dynamicTitle: true,
        enableSearch: true,
        showSelectAll: false,
        keyboardControls: true,
        scrollable: true,
        showCheckAll: false,
        showUncheckAll: true,
        closeOnSelect: false,
        scrollableHeight: '300px',
        externalIdProp: '', //PERMETTE DI AGGIUNGERE ALL'ARRAY DEI SELEZIONATI TUTTO L'OGGETTO
        idProp: 'id', //definisco i campi di cui è composto l'oggetto
        displayProp: 'descrizione' //definisco i campi di cui è composto l'oggetto
    };
    $scope.customTextUtenti = {
        buttonDefaultText: 'Utenti',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextStabili = {
        buttonDefaultText: 'Stabili',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextLocatori = {
        buttonDefaultText: 'Locatori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextConduttori = {
        buttonDefaultText: 'Conduttori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.multiSelectEventUtenti = {
        onItemSelect: function (obj) {
            $scope.filtroUtenti.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroUtenti.length; i++) {
                if ($scope.filtroUtenti[i] == obj.id) {
                    $scope.filtroUtenti.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function () {
            $scope.filtroUtenti = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventStabili = {
        onItemSelect: function (obj) {
            $scope.filtroStabili.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroStabili.length; i++) {
                if ($scope.filtroStabili[i] == obj.id) {
                    $scope.filtroStabili.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroStabili = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventLocatori = {
        onItemSelect: function (obj) {
            $scope.filtroLocatori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroLocatori.length; i++) {
                if ($scope.filtroLocatori[i] == obj.id) {
                    $scope.filtroLocatori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroLocatori = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventConduttori = {
        onItemSelect: function (obj) {
            $scope.filtroConduttori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroConduttori.length; i++) {
                if ($scope.filtroConduttori[i] == obj.id) {
                    $scope.filtroConduttori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroConduttori = [];
            $scope.filtriGenerici();
        }
    };
    $scope.svuotaMultiselect = function () {
        $scope.multiSelectEventUtenti.onDeselectAll();
        $scope.multiSelectEventLocatori.onDeselectAll();
        $scope.multiSelectEventConduttori.onDeselectAll();
        $scope.multiSelectEventStabili.onDeselectAll();
        $scope.elencoUtenti = [];
        $scope.elencoLocatori = [];
        $scope.elencoConduttori = [];
        $scope.elencoStabili = [];
    };
    $scope.filtriGenerici = function () {
        $scope.scadenze = [];
        var flag;
        for (var i = 0; i < $scope.backupScadenze.length; i++) {
            flag = false;

            if ($scope.filtroUtenti.length == 0) {
                flag = true;
            } else {
                for (var k = 0; k < $scope.filtroUtenti.length; k++) {
                    if ($scope.backupScadenze[i].contratto.id_utente_riferimento == $scope.filtroUtenti[k]) {
                        flag = true;
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroStabili.length == 0) {
                    flag = true;
                } else {
                    flag = false;
                    for (var j = 0; j < $scope.backupScadenze[i].contratto.unita_immobiliari.length; j++) {
                        for (var k = 0; k < $scope.filtroStabili.length; k++) {
                            if ($scope.backupScadenze[i].contratto.unita_immobiliari[j].id_stabili == $scope.filtroStabili[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroLocatori.length == 0) {
                    flag = true;
                } else {
                    flag = false;
                    for (var j = 0; j < $scope.backupScadenze[i].contratto.anagrafica_locatori.length; j++) {
                        for (var k = 0; k < $scope.filtroLocatori.length; k++) {
                            if ($scope.backupScadenze[i].contratto.anagrafica_locatori[j].id == $scope.filtroLocatori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroConduttori.length == 0) {
                    flag = true;
                } else {
                    flag = false;
                    for (var j = 0; j < $scope.backupScadenze[i].contratto.anagrafica_conduttori.length; j++) {
                        for (var k = 0; k < $scope.filtroConduttori.length; k++) {
                            if ($scope.backupScadenze[i].contratto.anagrafica_conduttori[j].id == $scope.filtroConduttori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                $scope.scadenze.push($scope.backupScadenze[i]);
            }
        }
    };

}])
;