<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 05/01/18
 * Time: 9.10
 */

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';

require_once '../../../src/function/functionGeneric.php';
require_once '../../../src/function/functionDate.php';

require_once '../../../src/model/Anagrafiche.php';
require_once '../../../src/model/Contratti.php';
require_once '../../../src/model/ContrattiConAnagrafiche.php';
require_once '../../../src/model/ContrattiDettagli.php';
require_once '../../../src/model/Rate.php';
require_once '../../../src/model/Istat.php';
require_once '../../../src/model/PagamentoF24.php';
require_once '../../../src/model/Cauzioni.php';
require_once '../../../src/model/UnitaImmobiliari.php';
require_once '../../../src/model/UnitaImmobiliariDettagli.php';
require_once '../../../src/model/Rli.php';
require_once '../../../src/model/FatturazioneTesta.php';

use Click\Affitti\TblBase\Anagrafiche;
use Click\Affitti\TblBase\Contratti;
use Click\Affitti\TblBase\Rate;
use Click\Affitti\Viste\Istat;
use Click\Affitti\Viste\PagamentoF24;
use Click\Affitti\TblBase\ContrattiDettagli;
use Click\Affitti\Viste\ContrattiConAnagrafiche;
use Click\Affitti\TblBase\Cauzioni;
use Click\Affitti\TblBase\UnitaImmobiliariDettagli;
use Click\Affitti\TblBase\UnitaImmobiliari;
use Click\Affitti\TblBase\Rli;
use Click\Affitti\TblBase\FatturazioneTesta;

function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);

        $dataInizio = $request->data_inizio;
        $dataFine = $request->data_fine;
        $mese = date('m', time()) + 1;

        // CARICO DATI
        $anagrafiche = new Anagrafiche($con);
        $contratti = new Contratti($con, 'A');
        $contrattiD = new ContrattiDettagli($con);
        $rate = new Rate($con);
        $istat = new Istat($con, $con,'Foi');
        $f24 = new PagamentoF24($con);
        $cauzioni = new Cauzioni($con);
        $ui = new UnitaImmobiliari($con);
        $immobili = new UnitaImmobiliariDettagli($con);
        $rli = new Rli($con);
        $fattureT = new FatturazioneTesta($con);


//        /*-----------------------------------------------PREAVVISO ISTAT----------------------------------------------*/
//        $result['preavvisoIstat'] = $contrattiD->findByMeseRiferimentiIstat($mese, ContrattiDettagli::FETCH_KEYARRAY);
//        foreach ($result['preavvisoIstat'] as $preavviso) {
//            $contrAnag = new ContrattiConAnagrafiche($con, 'A');
//            $result['scadenze'] [] =
//                preparaScadenza(
//                    'PI',
//                    '',
//                    'Preavviso ISTAT (mese ' . $preavviso['mese_riferimento_istat'] . ')',
//                    $contrAnag->findByPk($preavviso['id'], ContrattiConAnagrafiche::FETCH_KEYARRAY));
//        }
        /*-----------------------------------------------VARIAZIONE ISTAT---------------------------------------------*/
        $result['istat'] = $istat->findElencoAggiornamentoIstat(false, Istat::FETCH_KEYARRAY);
        $result['istat'] = $istat->findElencoAggiornamentoIstat(false, Istat::FETCH_KEYARRAY);

        $result['scadenze'] = [];
        foreach ($result['istat'] as $doc) {
            $contrAnag = new ContrattiConAnagrafiche($con, 'A');
            $data = substr($doc['data_inizio'], 0, 4);
            $data .= '-';
            $data .= substr('00' . $doc['mese_riferimento_istat'], -2);;
            $data .= '-';
            $data .= substr($doc['data_inizio'], -2);
            $result['scadenze'] [] =
                preparaScadenza(
                    $doc['idContratto'],
                    'VI',
                    $data,
                    'Variazione ISTAT',
                    $contrAnag->findByPk($doc['idContratto'], ContrattiConAnagrafiche::FETCH_KEYARRAY)
                );
        }
        /*-----------------------------------------------CONTRATTO DA REGISTRARE--------------------------------------*/
        $result['contrattiDaRegistrare'] = $contratti->getContrattiSenzaRegistrazione(Contratti::FETCH_KEYARRAY);
        foreach ($result['contrattiDaRegistrare'] as $cdr) {
            $contrAnag = new ContrattiConAnagrafiche($con, 'A');
            $result['scadenze'] [] =
                preparaScadenza(
                    $cdr['id'],
                    'CR',
                    '',
                    'Contratto da registrare',
                    $contrAnag->findByPk($cdr['id'], ContrattiConAnagrafiche::FETCH_KEYARRAY)
                );
        }
        /*-----------------------------------------------DOCUMENTI----------------------------------------------------*/
        $result['documenti'] =
            ($rate->findRatePerFattura($dataInizio, $dataFine, 'A', Rate::FETCH_KEYARRAY)) +
            ($rate->findRatePerFattura($dataInizio, $dataFine, 'F', Rate::FETCH_KEYARRAY)) +
            ($rate->findRatePerFattura($dataInizio, $dataFine, 'M', Rate::FETCH_KEYARRAY)) +
            ($rate->findRatePerFattura($dataInizio, $dataFine, 'R', Rate::FETCH_KEYARRAY));
        foreach ($result['documenti'] as $doc) {
            $contrAnag = new ContrattiConAnagrafiche($con, 'A');
            $result['scadenze'] [] =
                preparaScadenza(
                    $doc['idContratto'],
                    'D',
                    $doc['data_scadenza'],
                    $doc['descrizione'],
                    $contrAnag->findByPk($doc['idContratto'], ContrattiConAnagrafiche::FETCH_KEYARRAY)
                );
        }
        /*-----------------------------------------------EFATTURE-----------------------------------------------------*/
        $result['eFatture'] =$fattureT->findElencoFatturePerXml();
        $rate=new Rate($con);
        foreach ($result['eFatture'] as $doc) {
            $contrAnag = new ContrattiConAnagrafiche($con, 'A');
            $idContratto=$rate->findIdContrattoByIdRata($doc['id_rata']);
            $result['scadenze'] [] =
                preparaScadenza(
                    $idContratto,
                    'EF',
                    $doc['data_emissione'],
                    'Fattura elettronica del '.formattaDate($doc['data_scadenza'],'d/m/Y'),
                    $contrAnag->findByPk($idContratto, ContrattiConAnagrafiche::FETCH_KEYARRAY)
                );
        }
        /*-----------------------------------------------PROROGHE-----------------------------------------------------*/
        $result['proroghe'] = $f24->findProrogheByPeriodo($dataInizio, $dataFine, Contratti::FETCH_KEYARRAY);
        foreach ($result['proroghe'] as $doc) {
            $contrAnag = new ContrattiConAnagrafiche($con, 'A');
            $result['scadenze'] [] =
                preparaScadenza(
                    $doc['contratto']['id'],
                    'R',
                    $doc['imposta_registro']['data_scadenza'],
                    'Rinnovo contratto',
                    $contrAnag->findByPk($doc['contratto']['id'], ContrattiConAnagrafiche::FETCH_KEYARRAY)
                );
        }
        /*-----------------------------------------------DISDETTE-----------------------------------------------------*/
        $result['disdette'] = $contratti->getElencoContrattiDisdettabili('A', false, $dataInizio, $dataFine, Contratti::FETCH_KEYARRAY);
        foreach ($result['disdette'] as $dis) {
            $contrAnag = new ContrattiConAnagrafiche($con, 'A');
            $result['scadenze'] [] =
                preparaScadenza(
                    $dis['id'],
                    'CD',
                    $dis['data_preavviso'],
                    'Disdetta contratto il ' . formattaDate($dis['data_fine'], 'd/m/Y', '-'),
                    $contrAnag->findByPk($dis['id'], ContrattiConAnagrafiche::FETCH_KEYARRAY)
                );
        }
        /*-----------------------------------------------CONTRATTO IN SCADENZA----------------------------------------*/
        $result['contrattoInScadenza'] = $contratti->getElencoContrattiDisdettabili('A', true, $dataInizio, $dataFine, Contratti::FETCH_KEYARRAY);
        foreach ($result['contrattoInScadenza'] as $cs) {
            $contrAnag = new ContrattiConAnagrafiche($con, 'A');
            $result['scadenze'] [] =
                preparaScadenza(
                    $cs['id'],
                    'CS',
                    $cs['data_preavviso'],
                    'Conclusione contratto',
                    $contrAnag->findByPk($cs['id'], ContrattiConAnagrafiche::FETCH_KEYARRAY)
                );
        }
        /*-----------------------------------------------CAUZIONI SCADENZA--------------------------------------------*/
        $result['cauzioniInScadenza'] = $cauzioni->findByDataScadenza($dataInizio, $dataFine, Cauzioni::FETCH_KEYARRAY);
        foreach ($result['cauzioniInScadenza'] as $cs) {
            $contrAnag = new ContrattiConAnagrafiche($con, 'A');
            $result['scadenze'] [] =
                preparaScadenza(
                    $cs['id_contratto'],
                    'CA',
                    $cs['data_preavviso'],
                    'Scadenza cauzione',
                    $contrAnag->findByPk($cs['id_contratto'], ContrattiConAnagrafiche::FETCH_KEYARRAY)
                );
        }
        /*-----------------------------------------------RLI----------------------------------------------------------*/
        $result['rli'] = $rli->findElencoRliDaCreare($dataInizio, $dataFine, Rli::FETCH_KEYARRAY);
        foreach ($result['rli'] as $cs) {
            $contrAnag = new ContrattiConAnagrafiche($con, 'A');
            $result['scadenze'] [] =
                preparaScadenza(
                    $cs['id_contratto'],
                    'RL',
                    $cs['data_scadenza'],
                    'RLI da registrare',
                    $contrAnag->findByPk($cs['id_contratto'], ContrattiConAnagrafiche::FETCH_KEYARRAY)
                );
        }
        /*-----------------------------------------------UNITA IMMOBILIARI--------------------------------------------*/
        $result['scadenzeImmobili'] = $immobili->findScadenzeImmobili($dataInizio, $dataFine, UnitaImmobiliariDettagli::FETCH_KEYARRAY);
        foreach ($result['scadenzeImmobili'] as $cs) {
            $appImm['anagrafica_conduttori'] = null;
            $appImm['anagrafica_locatori'] = null;
            $appImm['unita_immobiliari'] = $ui->findById($cs['id_unita_immobiliari'], UnitaImmobiliari::FETCH_KEYARRAY);
            $result['scadenze'] [] =
                preparaScadenza(
                    $cs['id_unita_immobiliari'],
                    'UI',
                    $cs['data_scadenza'],
                    'Scadenza ' . $cs['descrizione'],
                    $appImm
                );
        }
        if (count($result['scadenze']) > 0)
            array_sort_by_column($result['scadenze'], 'data');

        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


function preparaScadenza($idContratto, $tipo, $data, $descrizione, $contratto = null)
{
    $scadenza = [];
    $scadenza['id_contratto'] = $idContratto;
    $scadenza['selezionato'] = true;
    $scadenza['tipo'] = $tipo;
    $scadenza['data'] = $data;
    $scadenza['descrizione'] = $descrizione;
    $scadenza['contratto'] = $contratto;

    return $scadenza;
}

/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
