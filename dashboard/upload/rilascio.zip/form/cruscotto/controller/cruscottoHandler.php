<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 05/01/18
 * Time: 9.10
 */

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';

require_once '../../../src/model/Anagrafiche.php';
require_once '../../../src/model/Contratti.php';
require_once '../../../src/model/ContrattiDettagli.php';
require_once '../../../src/model/Rate.php';
require_once '../../../src/model/Istat.php';
require_once '../../../src/model/PagamentoF24.php';
require_once '../../../src/model/Cauzioni.php';
require_once '../../../src/model/UnitaImmobiliariDettagli.php';
require_once '../../../src/model/Rli.php';
require_once '../../../src/model/FatturazioneTesta.php';

use Click\Affitti\TblBase\Anagrafiche;
use Click\Affitti\TblBase\Contratti;
use Click\Affitti\TblBase\Rate;
use Click\Affitti\Viste\Istat;
use Click\Affitti\Viste\PagamentoF24;
use Click\Affitti\TblBase\ContrattiDettagli;
use Click\Affitti\TblBase\Cauzioni;
use Click\Affitti\TblBase\UnitaImmobiliariDettagli;
use Click\Affitti\TblBase\Rli;
use Click\Affitti\TblBase\FatturazioneTesta;

function caricaDati()
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);

        $anno = date('Y', time());
        $mese = date('m', time());
        $giorno = date('d', time());
        $dataInizio = date('Y-m-d', mktime(0, 0, 0, $mese, $giorno, $anno));
        $dataFine = date('Y-m-d', mktime(0, 0, 0, $mese + 1, $giorno - 1, $anno));

        // CARICO DATI
        $anagrafiche = new Anagrafiche($con);
        $contratti = new Contratti($con, 'A');
        $contrattiD = new ContrattiDettagli($con);
        $rate = new Rate($con);
        $istat = new Istat($con, $con, 'Foi');
        $f24 = new PagamentoF24($con);
        $cauzioni = new Cauzioni($con);
        $immobili = new UnitaImmobiliariDettagli($con);
        $rli = new Rli($con);
        $fattureT = new FatturazioneTesta($con);

        $anagrafiche->setLimitBase(5);
        $result['anagrafiche'] = $anagrafiche->getElencoAnagrafiche(false, Anagrafiche::FETCH_KEYARRAY);
        $contratti->setLimitBase(5);
        $contratti->setOrderBase(' contratti.id desc ');
        $result['contratti'] = $contratti->getElencoContrattiCruscotto(false, Contratti::FETCH_KEYARRAY);
        $result['contrattiDaElaborare'] = count($contratti->findByContaContratti(0, Contratti::FETCH_KEYARRAY));
        $result['contrattiAttivi'] = count($contratti->findByContaContratti(1, Contratti::FETCH_KEYARRAY));
        $result['contrattiDaRegistrare'] = count($contratti->getContrattiSenzaRegistrazione(Contratti::FETCH_KEYARRAY));

        $result['countIstat'] = count($istat->findElencoAggiornamentoIstat(false, Istat::FETCH_KEYARRAY));
        $result['countPreavvisoIstat'] = count($contrattiD->findByMeseRiferimentiIstat($mese + 1, ContrattiDettagli::FETCH_KEYARRAY));
        $result['countScadenzeImmobili'] = count($immobili->findScadenzeImmobili($dataInizio, $dataFine, UnitaImmobiliariDettagli::FETCH_KEYARRAY));

        //TODO :: CONTROLLARE FUNZIONAMENTO E CALCOLO DELL'ELENCO DEI CONTRATTI DA RINNOVARE
        $result['countRinnovi'] = count($f24->findProrogheByPeriodo($dataInizio, $dataFine, Contratti::FETCH_KEYARRAY));
        // FIXME aggiunta parametro 'stato'->A [attivo]
        $result['countDisdette'] = count($contratti->getElencoContrattiDisdettabili('A', false, $dataInizio, $dataFine, Contratti::FETCH_KEYARRAY));
        $result['countContrattoInScadenza'] = count($contratti->getElencoContrattiDisdettabili('A', true, $dataInizio, $dataFine, Contratti::FETCH_KEYARRAY));

        $result['countDocumenti'] =
            count($rate->findRatePerFattura($dataInizio, $dataFine, 'A', Rate::FETCH_KEYARRAY)) +
            count($rate->findRatePerFattura($dataInizio, $dataFine, 'F', Rate::FETCH_KEYARRAY)) +
            count($rate->findRatePerFattura($dataInizio, $dataFine, 'M', Rate::FETCH_KEYARRAY)) +
            count($rate->findRatePerFattura($dataInizio, $dataFine, 'R', Rate::FETCH_KEYARRAY));

        $result['countCauzioni'] = count($cauzioni->findByDataScadenza($dataInizio, $dataFine, Cauzioni::FETCH_KEYARRAY));
        $result['countRli'] = count($rli->findElencoRliDaCreare($dataInizio, $dataFine, Rli::FETCH_KEYARRAY));
        $result['countEFattura'] = count($fattureT->findElencoFatturePerXml());

        $result['dataInizio'] = $dataInizio;
        $result['dataFine'] = $dataFine;
        $result['status'] = 'ok';

        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}

function gestisciStatoAnagrafica($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $anagrafica = new Anagrafiche($con);
        $anagrafica->findByPk($request->id);
        $anagrafica->setCestino(!$anagrafica->getCestino());
        $anagrafica->saveOrUpdate();
        $con->commit();
        return ($anagrafica->getCestino());
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return $e;
    }
}


/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
