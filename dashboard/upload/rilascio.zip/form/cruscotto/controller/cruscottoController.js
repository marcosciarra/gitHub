ngApp.controller("cruscottoController", ["$scope", "$http", "$filter", "ngToast", function ($scope, $http, $filter, ngToast) {

    var url = window.location.href;
    var params = decodeUrl(url);
    stampalog(params);

    $scope.caricamentoCompletato = false;
    $scope.filtroCerca = false;

    /******************
     *   CARICADATI   * ================================================================================================
     ******************/

    $scope.init = function () {
        $scope.caricaDati();
    };

    $scope.modificaAnagrafica = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("anagrafica", "gestioneAnagrafica", id);
    };

    $scope.modificaContratto = function (id) {
        window.location.href = $scope.params['home'] + encodeUrl("contratto", "gestioneContratto", id);
    };

    $scope.paginaScadenzario = function () {
        window.location.href = $scope.params['home'] + encodeUrl("cruscotto", "scadenze", [$scope.dataInizio, $scope.dataFine]);
    };


    $scope.caricaDati = function () {
        $http.post(params['form'] + '/cruscotto/controller/cruscottoHandler.php',
            {'function': 'caricaDati'}
        ).then(function (data, status, headers, config) {

            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }
            stampalog(data.data);
            for (var i = 0; i < data.data.contratti.length; i++) {
                data.data.contratti[i].proprietari = jsonParse(data.data.contratti[i].proprietari);
                data.data.contratti[i].conduttori = jsonParse(data.data.contratti[i].conduttori);
                if (data.data.contratti[i].proprietari.length > 0) {
                    data.data.contratti[i].primoLocatore = data.data.contratti[i].proprietari[0].descrizione;
                }
                if (data.data.contratti[i].conduttori.length > 0) {
                    data.data.contratti[i].primoConduttore = data.data.contratti[i].conduttori[0].descrizione;
                }
            }
            $scope.dataInizio = data.data.dataInizio;
            $scope.dataFine = data.data.dataFine;

            $scope.anagrafiche = data.data.anagrafiche;
            $scope.contratti = data.data.contratti;
            $scope.contrattiDaElaborare = data.data.contrattiDaElaborare;
            $scope.contrattiDaRegistrare = data.data.contrattiDaRegistrare;
            $scope.contrattiAttivi = data.data.contrattiAttivi;
            $scope.countDocumenti = data.data.countDocumenti;
            $scope.countIstat = data.data.countIstat;
            $scope.countRinnovi = data.data.countRinnovi;
            $scope.countDisdette = data.data.countDisdette;
            $scope.countPreavvisoIstat = data.data.countPreavvisoIstat;
            $scope.countContrattoInScadenza = data.data.countContrattoInScadenza;
            $scope.countCauzioni = data.data.countCauzioni;
            $scope.countScadenzeImmobili = data.data.countScadenzeImmobili;
            $scope.countRli = data.data.countRli;
            $scope.countEFattura = data.data.countEFattura;

            $scope.caricamentoCompletato = true;
        });
    };

}])
;