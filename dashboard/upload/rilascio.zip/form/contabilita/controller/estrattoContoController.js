ngApp.controller("estrattoContoController", ["$scope", "$http", "$filter", "ngToast", function ($scope, $http, $filter, $ngToast) {

    var url = window.location.href;
    var params = decodeUrl(url, 'id');
    stampalog(params);

    $scope.tipoPagamento = [
        {id: 'A', descrizione: 'ASSEGNO'},
        {id: 'B', descrizione: 'BONIFICO'},
        {id: 'C', descrizione: 'CONTANTI'}
    ];

    $scope.contrattoScelto = 0;
    $scope.caricamentoCompletato = false;

    /*--------------------------------------------------CARICA DATI---------------------------------------------------*/

    $scope.init = function () {
        $scope.filtroUtenti = [];
        $scope.filtroStabili = [];
        $scope.filtroLocatori = [];
        $scope.filtroConduttori = [];
        $scope.elencoUtenti = [];
        $scope.elencoLocatori = [];
        $scope.elencoConduttori = [];
        $scope.elencoStabili = [];

        $scope.caricaFiltri();
        $scope.caricaDati();

        var today = new Date();
        $scope.filtroDataInizio = getJsDateFromYYYYMMGG(today.getFullYear() + '-01-01');
        $scope.filtroDataFine = today;

    };

    $scope.caricaDati = function () {
        $http.post(params['form'] + '/contabilita/controller/estrattoContoHandler.php',
            {
                'function': 'caricaDati'
            }
        ).then(function (data, status, headers, config) {
            stampalog(data.data.status);
            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }
            stampalog('Carico Dati');
            stampalog(data.data.contratti);
            $scope.contratti = data.data.contratti;
            if ($scope.contratti != null) {
                if ($scope.contratti.length > 0) {
                    for (var i = 0; i < $scope.contratti.length; i++) {
                        $scope.contratti[i].conduttori = jsonParse($scope.contratti[i].conduttori);
                        $scope.contratti[i].proprietari = jsonParse($scope.contratti[i].proprietari);
                        $scope.contratti[i].primoLocatore = $scope.contratti[i].proprietari[0].descrizione;
                        $scope.contratti[i].primoConduttore = $scope.contratti[i].conduttori[0].descrizione;
                        $scope.contratti[i].primoImmobile = $scope.contratti[i].elenco_ui[0].descrizione;
                    }
                }
            }

            $scope.contrattiCopia = angular.copy($scope.contratti);
            $scope.caricamentoCompletato = true;
        });
    };


    $scope.caricaMovimentiContratto = function (idContratto) {
        $scope.contrattoScelto = idContratto;
        $scope.caricamentoCompletato = false;
        $http.post(params['form'] + '/contabilita/controller/estrattoContoHandler.php',
            {
                'function': 'caricaMovimentiContratto',
                'idContratto': idContratto,
                'filtroDataInizio': getYYYYMMGGFromJsDate($scope.filtroDataInizio),
                'filtroDataFine': getYYYYMMGGFromJsDate($scope.filtroDataFine)
            }
        ).then(function (data, status, headers, config) {
            // stampalog(data.data.status);
            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }
            stampalog('Carico Dati');
            stampalog(data.data.movimenti);
            $scope.movimenti = data.data.movimenti;

            $scope.caricamentoCompletato = true;
        });
    };


    $scope.salvaModificheMovimento = function (movimento, tipoMovimento) {
        switch (tipoMovimento) {
            case 'R':
                $http.post(params['form'] + '/contabilita/controller/estrattoContoHandler.php',
                    {
                        'function': 'salvaDocumento',
                        'idMovimentoTesta': movimento.id,
                        'descrizione': movimento.descrizione
                    }
                ).then(function (data, status, headers, config) {
                    if (data.data.status == 'ko') {
                        swal(data.data.error.title, data.data.error.message, 'error');
                        return;
                    }
                    $ngToast.create({
                        className: 'success',
                        content: 'Movimento aggiornato',
                        dismissButton: true,
                        timeout: 1500
                    });
                });
                break;
            case 'I':
                $http.post(params['form'] + '/contabilita/controller/estrattoContoHandler.php',
                    {
                        'function': 'salvaIncasso',
                        'idMovimentoTesta': movimento.id,
                        'tipoPagamento': movimento.tipo_pagamento,
                        'idContoCorrente': movimento.id_conto_corrente,
                        'idSottoconto': movimento.id_sottoconto,
                        'descrizione': movimento.descrizione
                    }
                ).then(function (data, status, headers, config) {
                    if (data.data.status == 'ko') {
                        swal(data.data.error.title, data.data.error.message, 'error');
                        return;
                    }
                    $ngToast.create({
                        className: 'success',
                        content: 'Incasso aggiornato',
                        dismissButton: true,
                        timeout: 1500
                    });
                });
                break;
        }
    };


    $scope.eliminaDocumento = function (idMovimentoT, idContratto, tipoMovimento) {
        switch (tipoMovimento) {
            case 'R':
                swal({
                        title: "Eliminare il documento?",
                        text: "",
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Si, elabora!",
                        cancelButtonText: "No, annulla!",
                        closeOnConfirm: false,
                        closeOnCancel: false,
                        showLoaderOnConfirm: true
                    },
                    function (isConfirm) {
                        if (isConfirm) {
                            $http.post(params['form'] + '/contabilita/controller/estrattoContoHandler.php',
                                {
                                    'function': 'eliminaDocumento',
                                    'idMovimentoTesta': idMovimentoT
                                }
                            ).then(function (data, status, headers, config) {
                                if (data.data.status == 'ko') {
                                    swal(data.data.error.title, data.data.error.message, 'error');
                                    return;
                                }
                                swal({
                                    title: "Documento eliminato",
                                    text: '',
                                    type: "success"
                                }, function () {
                                    $scope.caricaMovimentiContratto(idContratto);
                                });
                            });
                        }
                        else {
                            swal("Eliminazione annullata", "", "error");
                        }
                    });
                break;
            case 'I':
                swal({
                        title: "Eliminare l'incasso?",
                        text: "",
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Si, elabora!",
                        cancelButtonText: "No, annulla!",
                        closeOnConfirm: false,
                        closeOnCancel: false,
                        showLoaderOnConfirm: true
                    },
                    function (isConfirm) {
                        if (isConfirm) {
                            $http.post(params['form'] + '/contabilita/controller/estrattoContoHandler.php',
                                {
                                    'function': 'eliminaIncasso',
                                    'idMovimentoTesta': idMovimentoT
                                }
                            ).then(function (data, status, headers, config) {
                                if (data.data.status == 'ko') {
                                    swal(data.data.error.title, data.data.error.message, 'error');
                                    return;
                                }
                                swal({
                                    title: "Incasso eliminato",
                                    text: '',
                                    type: "success"
                                }, function () {
                                    $scope.caricaMovimentiContratto(idContratto);
                                });
                            });
                        }
                        else {
                            swal("Eliminazione annullata", "", "error");
                        }
                    });
                break;
        }
    };


    $scope.caricaModaleMovimento = function (movimento) {
        $scope.movimentoModale = movimento;
        stampalog($scope.movimentoModale);
        // $scope.movimentoModale.data_documento = new Date($scope.movimentoModale.data_documento);
        // if ($scope.movimentoModale.data_scadenza != null)
        //     $scope.movimentoModale.data_scadenza = new Date($scope.movimentoModale.data_scadenza);

        for (var i = 0; i < $scope.movimentoModale.dettagli.length; i++) {
            $scope.movimentoModale.dettagli[i].importo = 1 * $scope.movimentoModale.dettagli[i].importo;
        }

        $scope.movimentoModale.sommaImporto = $scope.calcolaSommaImporti();
    };


    $scope.calcolaSommaImporti = function () {
        $scope.movimentoModale.sommaImporto = 0;
        for (var i = 0; i < $scope.movimentoModale.dettagli.length; i++) {
            if ($scope.movimentoModale.dettagli[i].tipo_dettaglio == 'P')
                $scope.movimentoModale.sommaImporto = (1 * $scope.movimentoModale.dettagli[i].importo) + $scope.movimentoModale.sommaImporto;
        }
        return $scope.movimentoModale.sommaImporto;
    };
    /*---------------------------------------------FUNZIONI IN PAGINA-------------------------------------------------*/


    /*
    Apre il Pdf della fattura
     */
    $scope.stampaDettaglio = function (id) {
        window.open(params['baseurl'] + '/stampe/avvisiPagamento/avvisoPagamentoPdf.php?idFattura=' + id);
    };

    $scope.stampaRicevuta = function (id_movimento_banca_testa) {
        idBanca=[];
        idBanca.push(id_movimento_banca_testa);
        idBanca= JSON.stringify(idBanca);
        window.open(params['baseurl'] + '/stampe/ricevutaPagamento/ricevutaPagamentoPdf.php?idMovimentoBancaT=' + idBanca);
    };

    $scope.stampaEstrattoConto = function (id_contratto) {
        window.open(
            params['baseurl'] +
            '/stampe/estrattoConto/estrattoContoPdf.php?idContratto=' + id_contratto +
            '&dataInizio=' + getYYYYMMGGFromJsDate($scope.filtroDataInizio) +
            '&dataFine=' + getYYYYMMGGFromJsDate($scope.filtroDataFine)
        );
    };

    $scope.caricaDettagliModale = function (elenco, etichetta) {
        $scope.elencoModale = elenco;
        $scope.etichettaModale = etichetta;
    };

    //---------------------------------------------------SEZIONE FILTRI-----------------------------------------------//
    $scope.caricaFiltri = function () {
        $http.post($scope.params['form'] + "/template/controller/homeHandler.php",
            {'function': 'caricaFiltri'}
        ).then(function (data, status, headers, config) {
            // stampalog(data.data);
            $scope.filtriSelectPagina = data.data;
        });
    };
    $scope.settings = {
        dynamicTitle: true,
        enableSearch: true,
        showSelectAll: false,
        keyboardControls: true,
        scrollable: true,
        showCheckAll: false,
        showUncheckAll: true,
        closeOnSelect: false,
        scrollableHeight: '300px',
        externalIdProp: '', //PERMETTE DI AGGIUNGERE ALL'ARRAY DEI SELEZIONATI TUTTO L'OGGETTO
        idProp: 'id', //definisco i campi di cui è composto l'oggetto
        displayProp: 'descrizione' //definisco i campi di cui è composto l'oggetto
    };
    $scope.customTextUtenti = {
        buttonDefaultText: 'Utenti',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextStabili = {
        buttonDefaultText: 'Stabili',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextLocatori = {
        buttonDefaultText: 'Locatori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextConduttori = {
        buttonDefaultText: 'Conduttori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.multiSelectEventUtenti = {
        onItemSelect: function (obj) {
            $scope.filtroUtenti.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroUtenti.length; i++) {
                if ($scope.filtroUtenti[i] == obj.id) {
                    $scope.filtroUtenti.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function () {
            $scope.filtroUtenti = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventStabili = {
        onItemSelect: function (obj) {
            $scope.filtroStabili.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroStabili.length; i++) {
                if ($scope.filtroStabili[i] == obj.id) {
                    $scope.filtroStabili.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroStabili = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventLocatori = {
        onItemSelect: function (obj) {
            $scope.filtroLocatori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroLocatori.length; i++) {
                if ($scope.filtroLocatori[i] == obj.id) {
                    $scope.filtroLocatori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroLocatori = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventConduttori = {
        onItemSelect: function (obj) {
            $scope.filtroConduttori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroConduttori.length; i++) {
                if ($scope.filtroConduttori[i] == obj.id) {
                    $scope.filtroConduttori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroConduttori = [];
            $scope.filtriGenerici();
        }
    };
    $scope.svuotaMultiselect = function () {
        $scope.multiSelectEventUtenti.onDeselectAll();
        $scope.multiSelectEventLocatori.onDeselectAll();
        $scope.multiSelectEventConduttori.onDeselectAll();
        $scope.multiSelectEventStabili.onDeselectAll();
        $scope.elencoUtenti = [];
        $scope.elencoLocatori = [];
        $scope.elencoConduttori = [];
        $scope.elencoStabili = [];
    };
    $scope.filtriGenerici = function () {
        $scope.contratti = [];
        var flag;
        for (var i = 0; i < $scope.contrattiCopia.length; i++) {
            flag = false;

            if ($scope.filtroUtenti.length == 0) {
                flag = true;
            }
            else {
                for (var k = 0; k < $scope.filtroUtenti.length; k++) {
                    if ($scope.contrattiCopia[i].id_utente_riferimento == $scope.filtroUtenti[k]) {
                        flag = true;
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroStabili.length == 0) {
                    flag = true;
                }
                else {
                    flag = false;
                    for (var j = 0; j < $scope.contrattiCopia[i].elenco_ui.length; j++) {
                        for (var k = 0; k < $scope.filtroStabili.length; k++) {
                            if ($scope.contrattiCopia[i].elenco_ui[j].id_stabili == $scope.filtroStabili[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroLocatori.length == 0) {
                    flag = true;
                }
                else {
                    flag = false;
                    for (var j = 0; j < $scope.contrattiCopia[i].proprietari.length; j++) {
                        for (var k = 0; k < $scope.filtroLocatori.length; k++) {
                            if ($scope.contrattiCopia[i].proprietari[j].id == $scope.filtroLocatori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroConduttori.length == 0) {
                    flag = true;
                }
                else {
                    flag = false;
                    for (var j = 0; j < $scope.contrattiCopia[i].conduttori.length; j++) {
                        for (var k = 0; k < $scope.filtroConduttori.length; k++) {
                            if ($scope.contrattiCopia[i].conduttori[j].id == $scope.filtroConduttori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                $scope.contratti.push($scope.contrattiCopia[i]);
            }
        }
    };

}])
;