<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 23/02/18
 * Time: 16.44
 */

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';

require_once '../../../src/model/FatturazioneTesta.php';
require_once '../../../src/model/MovimentiTesta.php';

use Click\Affitti\TblBase\FatturazioneTesta;
use Click\Affitti\TblBase\MovimentiTesta;


function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        $fattureT=new FatturazioneTesta($con);
        $result['movimenti_da_contabilizzare'] = count($fattureT->findElencoFatturePerContabilita(0));
        $movimentiT=new MovimentiTesta($con);
        $result['incassi_da_registrare'] = $movimentiT->getSommaElencoFattureDaPagare();


        $result['status'] = 'ok';
        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }

}


/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
