<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 23/02/18
 * Time: 16.44
 */

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';

require_once '../../../src/model/Contratti.php';
require_once '../../../src/model/UnitaImmobiliariContratti.php';
require_once '../../../src/model/ContrattiDettagli.php';
require_once '../../../src/model/MovimentiTesta.php';
require_once '../../../src/model/MovimentiDettagli.php';
require_once '../../../src/model/MovimentiBancaTesta.php';
require_once '../../../src/model/MovimentiBancaDettagli.php';
require_once '../../../src/model/ContiCorrenti.php';
require_once '../../../src/model/FatturazioneTesta.php';
require_once '../../../src/model/UnitaImmobiliariContratti.php';

require_once '../../../src/model/Contabilita.php';


use Click\Affitti\TblBase\Contratti;
use Click\Affitti\Viste\ContrattiConAnagrafiche;
use Click\Affitti\Viste\Contabilita;
use Click\Affitti\TblBase\MovimentiTesta;
use Click\Affitti\TblBase\MovimentiDettagli;
use Click\Affitti\TblBase\FatturazioneTesta;
use Click\Affitti\TblBase\MovimentiBancaTesta;
use Click\Affitti\TblBase\MovimentiBancaDettagli;
use Click\Affitti\TblBase\UnitaImmobiliariContratti;

function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        // CARICO DATI
        $contratti = new Contratti($con);
        $contratti->setOrderBase(" data_inizio DESC");
        $uic = new UnitaImmobiliariContratti($con);
        foreach ($contratti->getElencoContratti(true, Contratti::FETCH_KEYARRAY) as $contr) {
            if($contr['elaborato']==1) {
                $contr['contratti'] = $contr;
                $contr['elenco_ui'] = $uic->elencoImmobiliPerContratto($contr['id'], UnitaImmobiliariContratti::FETCH_KEYARRAY);
                $result['contratti'][] = $contr;
            }
        }

        $result['status'] = 'ok';
        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }

}


function caricaMovimentiContratto($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);

        $contabilita = new Contabilita($con, $conExt);
        $result['movimenti'] = $contabilita->estrattoContoByIdContratto($request->idContratto, $request->filtroDataInizio, $request->filtroDataFine);

        $result['status'] = 'ok';
        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }

}


/*---------------------------------------------------INCASSO----------------------------------------------------------*/
function salvaIncasso($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
        $con->beginTransaction();

        $contabilita = new Contabilita($con, $conExt);

        $movimentoT = new MovimentiTesta($con);
        $movimentoT->findByPk($request->idMovimentoTesta);

        //Cambio tipo pagamento
        if ($movimentoT->getTipoPagamento() != $request->tipoPagamento)
            $contabilita->modificaTipoPagamentoPerIncasso($request->idMovimentoTesta, $request->tipoPagamento);

        //Cambio conto corrente
        if ($movimentoT->getIdContoCorrente() != $request->idContoCorrente)
            $contabilita->modificaContoCorrenteIncasso($request->idMovimentoTesta, $request->idContoCorrente);

        $movimentoD = new MovimentiDettagli($con);
        /** @var MovimentiDettagli $movimentoD */
        foreach ($movimentoD->findByIdMovimentiTesta($request->idMovimentoTesta) as $movimentoD) {
            //Cambio conto corrente
            if ($movimentoD->getPartita() == 'A') {
                if ($movimentoD->getIdSottoconto() != $request->idContoCorrente)
                    $contabilita->modificaAnagraficaChePagaIncasso($request->idMovimentoTesta, $request->idSottoconto);
            }

            //Cambio descrizione movimento
            if ($movimentoD->getDescrizione() != $request->descrizione) {
                $movimentoD->setDescrizione($request->descrizione);
                $movimentoD->saveOrUpdate();
            }
        }

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}



function eliminaIncasso($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
        $con->beginTransaction();

        $contabilita = new Contabilita($con, $conExt);
        $contabilita->eliminaIncasso($request->idMovimentoTesta);

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}
/*---------------------------------------------------DOCUMENTO--------------------------------------------------------*/
function salvaDocumento($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $movimentoD = new MovimentiDettagli($con);
        /** @var MovimentiDettagli $movimentoD */
        foreach ($movimentoD->findByIdMovimentiTesta($request->idMovimentoTesta) as $movimentoD) {
            if ($movimentoD->getTipoDettaglio() == 'C') {
                $movimentoD->setDescrizione($request->descrizione);
                $movimentoD->saveOrUpdate();
            }
        }

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}


function eliminaDocumento($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $con->beginTransaction();

        $movimentoD = new MovimentiDettagli($con);
        /** @var MovimentiDettagli $movD */
        foreach ($movimentoD->findByIdxIdMovimentiTesta($request->idMovimentoTesta) as $movD) {
            $movimentoD->deleteByPk($movD->getId());
        }
        $movimentoT = new MovimentiTesta($con);
        $movimentoT->findByPk($request->idMovimentoTesta);
        $idFatturaT = $movimentoT->getIdFatturaTesta();
        $movimentoT->deleteByPk($request->idMovimentoTesta);

        $fattureT = new FatturazioneTesta($con);
        $fattureT->findByPk($idFatturaT);
        $fattureT->setContabilizzato(0);
        $fattureT->saveOrUpdate();

        $con->commit();
        return 'ok';
    } catch (Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return 'ko';
    }
}


/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
