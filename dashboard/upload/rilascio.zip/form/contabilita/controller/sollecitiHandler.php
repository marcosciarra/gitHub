<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 23/02/18
 * Time: 16.44
 */

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';

require_once '../../../src/model/Contratti.php';
require_once '../../../src/model/ContrattiDettagli.php';
require_once '../../../src/model/MovimentiTesta.php';
require_once '../../../src/model/MovimentiDettagli.php';
require_once '../../../src/model/ContiCorrenti.php';
require_once '../../../src/model/FatturazioneTesta.php';
require_once '../../../src/model/UnitaImmobiliariContratti.php';

require_once '../../../src/model/Contabilita.php';


use Click\Affitti\TblBase\MovimentiTesta;
use Click\Affitti\TblBase\MovimentiDettagli;
use Click\Affitti\TblBase\Contratti;
use Click\Affitti\TblBase\ContrattiDettagli;
use Click\Affitti\TblBase\ContiCorrenti;
use Click\Affitti\Viste\Contabilita;
use Click\Affitti\TblBase\FatturazioneTesta;
use Click\Affitti\TblBase\UnitaImmobiliariContratti;

function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        $contratto = new Contratti($con);
        $contrattoD = new ContrattiDettagli($con);
        $movimentiT = new MovimentiTesta($con);
        $movimentiD = new MovimentiDettagli($con);
        $uic = new UnitaImmobiliariContratti($con);

        foreach ($movimentiT->getElencoFattureDaPagare() as $mov) {
            $idContratto = $mov['id_contratto'];
            //MovimentiTesta
            $app['documento'] = $mov;
            //MovimentiDettagli
            $app['documento']['dettagli'] = $movimentiD->getElencoFattureByIdContratto($idContratto);
            //ContoCorrente predefinito
            $contrattoD->findByPk($idContratto);
            $app['documento']['id_conto_corrente'] = $contrattoD->getIdContoCorrente();
            //Elenco Anagrafiche per contratto
            $contratto->findByPk($idContratto);
            $app['documento']['anagrafiche'] = [];
            $app['documento']['anagrafiche'][] = $contratto->getIdAgenziaImmobiliare();
            foreach (json_decode($contratto->getProprietari()) as $p) {
                $app['documento']['anagrafiche'][] = $p->id;
            }
            $app['documento']['immobili'] = $uic->elencoImmobiliPerContratto($idContratto, UnitaImmobiliariContratti::FETCH_KEYARRAY);
            $app['documento']['id_utente_riferimento'] = $contratto->getIdUtenteRiferimento();

            $result['solleciti'][] = $app['documento'];
        }

        $result['status'] = 'ok';
        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }

}


function elaboraSelezionati($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
        $con->beginTransaction();
        $codiceGruppo = time();

        foreach ($request->solleciti as $doc) {
            if ($doc->selezionato) {
                foreach ($doc->dettagli as $det) {
                    if ($det->selezionato) {
                        //Dare in pasto la fattura al metodo che la contabilizza
                        $contab = new Contabilita($con, $conExt);
                        $contab->incassoFattura(
                            $det->id_fattura_testa,
                            $det->id_movimenti_testa,
                            $doc->id_contratto,
                            $doc->tipoPagamento,
                            $doc->id_conto_corrente,
                            $doc->conduttoreChePaga,
                            $doc->descrizioneIncasso,
                            $det->data,
                            $det->importo,
                            $codiceGruppo
                        );
                    }
                }
            }
        }

        $con->commit();

        $result['status'] = 'ok';

        return json_encode($result);

    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


function caricaElencoBancheContratto($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        $cc = new ContiCorrenti($con);
        $result['elencoContiCorrente'] = $cc->getElencoContiContratto($request->arrayId, ContiCorrenti::FETCH_KEYARRAY);

        $result['status'] = 'ok';

        return json_encode($result);

    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
