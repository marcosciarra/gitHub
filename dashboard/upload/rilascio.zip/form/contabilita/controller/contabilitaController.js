ngApp.controller("contabilitaController", ["$scope", "$http", "$filter", "ngToast", function ($scope, $http, $filter, $ngToast) {

    var url = window.location.href;
    var params = decodeUrl(url, 'id');
    stampalog(params);

    $scope.caricamentoCompletato = false;
    $scope.filtroCerca = false;
    $scope.pannelloNote = 0;
    $scope.pannelloContratto = 1;
    $scope.pannelloIntestatari = 0;
    $scope.pannelloImmobili = 0;
    $scope.pannelloCanoni = 0;
    $scope.pannelloCauzioni = 0;
    $scope.pannelloRli = 0;

    $scope.mesi_istat = [
        {id: '0', descrizione: 'NO ISTAT'},
        {id: '1', descrizione: 'GENNAIO'},
        {id: '2', descrizione: 'FEBBRAIO'},
        {id: '3', descrizione: 'MARZO'},
        {id: '4', descrizione: 'APRILE'},
        {id: '5', descrizione: 'MAGGIO'},
        {id: '6', descrizione: 'GIUGNO'},
        {id: '7', descrizione: 'LUGLIO'},
        {id: '8', descrizione: 'AGOSTO'},
        {id: '9', descrizione: 'SETTEMBRE'},
        {id: '10', descrizione: 'OTTOBRE'},
        {id: '11', descrizione: 'NOVEMBRE'},
        {id: '12', descrizione: 'DICEMBRE'}
    ];

    /******************
     *   CARICADATI   * ================================================================================================
     ******************/

    $scope.init = function () {
        $scope.caricaDati();
    };

    $scope.caricaDati = function () {
        $http.post(params['form'] + '/contabilita/controller/contabilitaHandler.php',
            {
                'function': 'caricaDati'
            }
        ).then(function (data, status, headers, config) {
            stampalog(data.data.status);
            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }
            stampalog('Carico Dati');
            stampalog(data.data);

            $scope.movimenti_da_contabilizzare = data.data.movimenti_da_contabilizzare;
            $scope.incassi_da_registrare = data.data.incassi_da_registrare;

            $scope.caricamentoCompletato = true;
        });
    };

    /* ====================================== CARICAMENTO PAGINA===================================================== */

    $scope.autoregistrazioneFatture = function () {
        window.location.href = $scope.params['home'] + encodeUrl("contabilita", "autoregistrazioneFatture");
    };

    $scope.incassi = function () {
        window.location.href = $scope.params['home'] + encodeUrl("contabilita", "incassi");
    };

    $scope.solleciti = function () {
        window.location.href = $scope.params['home'] + encodeUrl("contabilita", "solleciti");
    };

    $scope.etrattoConto = function () {
        window.location.href = $scope.params['home'] + encodeUrl("contabilita", "estrattoConto");
    };

}])
;