<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 23/02/18
 * Time: 16.44
 */

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';
require_once '../../../src/function/functionDate.php';

require_once '../../../src/model/Contratti.php';
require_once '../../../src/model/FatturazioneTesta.php';
require_once '../../../src/model/UnitaImmobiliariContratti.php';
require_once '../../../src/model/Rate.php';
require_once '../../../src/model/Contabilita.php';


use Click\Affitti\TblBase\FatturazioneTesta;
use Click\Affitti\Viste\Contabilita;
use Click\Affitti\TblBase\UnitaImmobiliariContratti;
use Click\Affitti\TblBase\Rate;
use Click\Affitti\TblBase\Contratti;

function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        $fattureT = new FatturazioneTesta($con);
        $rate = new Rate($con);
        $uic = new UnitaImmobiliariContratti($con);
        $contratto = new Contratti($con);
        $fattureT->setOrderBase(' codice_gruppo asc, data_scadenza asc ');

        $result['documenti'] = [];
        foreach ($fattureT->findElencoFatturePerContabilita(0) as $doc) {
            $app['documento'] = $doc;
            $app['documento']['id_contratto'] = $rate->findIdContrattoByIdRata($doc['id_rata']);
            $app['documento']['immobili'] = $uic->elencoImmobiliPerContratto(17, UnitaImmobiliariContratti::FETCH_KEYARRAY);
            $contratto->findByPk($app['documento']['id_contratto']);
            $app['documento']['id_utente_riferimento'] = $contratto->getIdUtenteRiferimento();;

            $result['documenti'][] = $app['documento'];
        }

        $result['status'] = 'ok';
        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }

}


function elaboraSelezionati($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
        $con->beginTransaction();

        $fattureT = new FatturazioneTesta($con);
        $codiceGruppo = time();
        foreach ($request->documenti as $d) {
            if ($d->selezionato) {
                $fattureT->findByPk($d->id);
                //Dare in pasto la fattura al metodo che la contabilizza
                $contabilita = new Contabilita($con, $conExt);
                $contabilita->autoregistrazioneFattura($fattureT->getId(), $codiceGruppo);
                $fattureT->setContabilizzato(1);
                $fattureT->saveOrUpdate();
            }
        }

        $con->commit();

        $result['status'] = 'ok';

        return json_encode($result);

    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
