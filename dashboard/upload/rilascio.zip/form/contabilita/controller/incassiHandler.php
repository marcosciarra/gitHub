<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 23/02/18
 * Time: 16.44
 */

require_once '../../../conf/conf.php';
require_once '../../../src/model/DrakkarDbConnector.php';
require_once '../../../src/model/DrakkarErrorFunction.php';
require_once '../../../src/function/functionDate.php';

require_once '../../../src/model/Contratti.php';
require_once '../../../src/model/ContrattiDettagli.php';
require_once '../../../src/model/MovimentiTesta.php';
require_once '../../../src/model/MovimentiDettagli.php';
require_once '../../../src/model/MovimentiBancaTesta.php';
require_once '../../../src/model/MovimentiBancaDettagli.php';
require_once '../../../src/model/ContiCorrenti.php';
require_once '../../../src/model/FatturazioneTesta.php';
require_once '../../../src/model/UnitaImmobiliariContratti.php';

require_once '../../../src/model/Contabilita.php';


use Click\Affitti\TblBase\MovimentiTesta;
use Click\Affitti\TblBase\MovimentiDettagli;
use Click\Affitti\TblBase\Contratti;
use Click\Affitti\TblBase\ContrattiDettagli;
use Click\Affitti\TblBase\ContiCorrenti;
use Click\Affitti\Viste\Contabilita;
use Click\Affitti\TblBase\FatturazioneTesta;
use Click\Affitti\TblBase\UnitaImmobiliariContratti;
use Click\Affitti\TblBase\MovimentiBancaTesta;
use Click\Affitti\TblBase\MovimentiBancaDettagli;

function caricaDati($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        $contratto = new Contratti($con);
        $contrattoD = new ContrattiDettagli($con);
        $movimentiT = new MovimentiTesta($con);
        $movimentiD = new MovimentiDettagli($con);
        $uic = new UnitaImmobiliariContratti($con);

        foreach ($movimentiT->getElencoFattureDaPagare() as $mov) {
            $idContratto = $mov['id_contratto'];
            //MovimentiTesta
            $app['documento'] = $mov;
            //MovimentiDettagli
            $app['documento']['dettagli'] = $movimentiD->getElencoFattureByIdContratto($idContratto);
            //ContoCorrente predefinito
            $contrattoD->findByPk($idContratto);
            $app['documento']['id_conto_corrente'] = $contrattoD->getIdContoCorrente();
            //Elenco Anagrafiche per contratto
            $contratto->findByPk($idContratto);
            $app['documento']['anagrafiche'] = [];
            $app['documento']['anagrafiche'][] = $contratto->getIdAgenziaImmobiliare();
            foreach (json_decode($contratto->getProprietari()) as $p) {
                $app['documento']['anagrafiche'][] = $p->id;
            }
            $app['documento']['immobili'] = $uic->elencoImmobiliPerContratto($idContratto, UnitaImmobiliariContratti::FETCH_KEYARRAY);
            $app['documento']['id_utente_riferimento'] = $contratto->getIdUtenteRiferimento();

            $result['incassi'][] = $app['documento'];
        }

        $result['status'] = 'ok';
        return json_encode($result);
    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }

}


function elaboraSelezionati($request)
{
    try {
        $con = new \Drakkar\DrakkarDbConnector();
        $conExt = new \Drakkar\DrakkarDbConnector(CONNESSIONE_COMUNE);
        $con->beginTransaction();
        $codiceGruppo = time();

        foreach ($request->incassi as $doc) {
            if ($doc->selezionato) {
                foreach ($doc->dettagli as $det) {
                    if ($det->selezionato) {
                        //Dare in pasto la fattura al metodo che la contabilizza
                        $contab = new Contabilita($con, $conExt);
                        $fatturT = new FatturazioneTesta($con);
                        $fatturT->findByPk($det->id_fattura_testa);

                        $descrizioneIncasso = str_replace('#dataScadenza#', formattaDate($fatturT->getDataScadenza(), 'd/m/Y'), $doc->descrizioneIncasso);
                        $descrizioneIncasso = str_replace('#dataIncasso#', formattaDate($det->data, 'd/m/Y'), $descrizioneIncasso);

                        $contab->incassoFattura(
                            $det->id_fattura_testa,
                            $det->id_movimenti_testa,
                            $doc->id_contratto,
                            $doc->tipoPagamento,
                            $doc->id_conto_corrente,
                            $doc->conduttoreChePaga,
                            $descrizioneIncasso,
                            $det->data,
                            $det->importo,
                            $codiceGruppo
                        );
                    }
                }
            }
        }

        /*
         * Creazione automatica dei movimenti di banca
         * Questo sarà ammesso solo nel caso in cui ci sia l'Opzione che lo permette
         */
        $movimentiT = new MovimentiTesta($con);
        $result['elenco_id_banca'] = [];
        foreach ($movimentiT->getElencoImportiMovimentiByCodiceGruppoAndIdContratto($codiceGruppo) as $mov) {
            $bancaT = new MovimentiBancaTesta($con);

            $bancaT->setIdContiCorrente($mov['id_conto_corrente']);
            $bancaT->setDataContabile($mov['data_documento']);
            $bancaT->setDataValuta($mov['data_documento']);
            $bancaT->setDescrizione('Incasso di ' . $mov['importo']);
            $bancaT->setImporto($mov['importo']);
            //Tipo di pagamento
            $bancaT->setCausale($bancaT->getCodiceCausale('click', 'E', $mov['tipo_pagamento']));

            $bancaT->setContabilizzato(1);
            $idBancaT = $bancaT->saveOrUpdate();
            $result['elenco_id_banca'][] = $idBancaT;

            $movimentiTesta = new MovimentiTesta($con);
            /** @var MovimentiTesta $appMovT */
            foreach ($movimentiTesta->findByIdxIdContrattoCodiceGruppo($mov['id_contratto'], $codiceGruppo) as $appMovT) {
                $movimentiD = new MovimentiDettagli($con);
                /** @var MovimentiDettagli $dettagli */
                foreach ($movimentiD->findByIdxIdMovimentiTestaTipoDettaglio($appMovT->getId(), 'C') as $dettagli) {
                    $bancaD = new MovimentiBancaDettagli($con);
                    $bancaD->setIdMovimentiTesta($appMovT->getId());
                    $bancaD->setIdMovimentiBancaTesta($idBancaT);
                    $bancaD->setImporto($dettagli->getImporto());
                    $bancaD->setDescrizione('Incasso di ' . $dettagli->getImporto());
                    $bancaD->saveOrUpdate();
                }
            }
        }


        $con->commit();

        $result['status'] = 'ok';

        return json_encode($result);

    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        $con->rollBack();
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


function caricaElencoBancheContratto($request)
{
    $result = array();
    try {
        $con = new \Drakkar\DrakkarDbConnector();

        $cc = new ContiCorrenti($con);
        $result['elencoContiCorrente'] = $cc->getElencoContiContratto($request->arrayId, ContiCorrenti::FETCH_KEYARRAY);

        $result['status'] = 'ok';

        return json_encode($result);

    } catch (\Drakkar\Exception\DrakkarConnectionException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::connectionException($e));
    } catch (\Drakkar\Exception\DrakkarException $e) {
        return json_encode(\Drakkar\Exception\DrakkarErrorFunction::genericException($e));
    }
}


/**/

ob_start();
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$function = $request->function;
$r = $function($request);
echo $r;
