ngApp.controller("autoregistrazioneFattureController", ["$scope", "$http", "$filter", "ngToast", function ($scope, $http, $filter, $ngToast) {

    var url = window.location.href;
    var params = decodeUrl(url, 'id');
    stampalog(params);

    $scope.caricamentoCompletato = false;

    /*--------------------------------------------------CARICA DATI---------------------------------------------------*/

    $scope.init = function () {
        $scope.filtroUtenti = [];
        $scope.filtroStabili = [];
        $scope.filtroLocatori = [];
        $scope.filtroConduttori = [];
        $scope.elencoUtenti = [];
        $scope.elencoLocatori = [];
        $scope.elencoConduttori = [];
        $scope.elencoStabili = [];

        $scope.selezionatiTutti = true;

        $scope.caricaFiltri();
        $scope.caricaDati();
    };

    $scope.caricaDati = function () {
        $http.post(params['form'] + '/contabilita/controller/autoregistrazioneFattureHandler.php',
            {
                'function': 'caricaDati'
            }
        ).then(function (data, status, headers, config) {
            stampalog(data.data.status);
            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }
            stampalog('Carico Dati');
            stampalog(data.data);
            $scope.documenti = data.data.documenti;
            if ($scope.documenti.length > 0) {
                for (var i = 0; i < $scope.documenti.length; i++) {
                    $scope.documenti[i].proprietari = jsonParse($scope.documenti[i].proprietari);
                    $scope.documenti[i].conduttori = jsonParse($scope.documenti[i].conduttori);
                    $scope.documenti[i].primoLocatore = $scope.documenti[i].proprietari[0].descrizione;
                    $scope.documenti[i].primoConduttore = $scope.documenti[i].conduttori[0].descrizione;
                    $scope.documenti[i].dataScadenzaFormat = formatDataDbToIta($scope.documenti[i].data_scadenza);
                    $scope.documenti[i].dataEmissioneFormat = formatDataDbToIta($scope.documenti[i].data_emissione);
                    $scope.documenti[i].selezionato = true;
                }
            }

            $scope.documentiCopia = angular.copy($scope.documenti);
            $scope.caricamentoCompletato = true;
        });
    };

    /*---------------------------------------------------SALVA DATI---------------------------------------------------*/

    $scope.elaboraSelezionati = function () {
        swal({
                title: "Contabilizzare i documenti selezionati?",
                text: "",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: "btn-danger",
                confirmButtonText: "Si, elabora!",
                cancelButtonText: "No, annulla!",
                closeOnConfirm: false,
                closeOnCancel: false,
                showLoaderOnConfirm: true
            },
            function (isConfirm) {
                if (isConfirm) {
                    $http.post(params['form'] + '/contabilita/controller/autoregistrazioneFattureHandler.php',
                        {
                            'function': 'elaboraSelezionati',
                            'documenti': $scope.documentiFiltrati
                        }
                    ).then(function (data, status, headers, config) {
                        stampalog(data.data);
                        if (data.data.status == "ok") {
                            swal({
                                title: "Documenti contabilizzati",
                                text: '',
                                type: "success"
                            }, function () {
                                window.location.href = $scope.params['home'] + encodeUrl("contabilita", "contabilita");
                            });
                        }
                        else {
                            swal("Contabilizzazione non riuscita", "", "error");
                        }
                    });
                }
                else {
                    swal("Contabilizzazione annullata", "", "error");
                }
            });
    };


    /*
    Selsezione / Deseleziona tutti gli elementi nella tabella
     */
    $scope.selezionaDeselezionaTutti = function (flag) {
        $scope.selezionatiTutti = flag;
        for (var i = 0; i < $scope.documenti.length; i++) {
            $scope.documenti[i].selezionato = flag;
        }
    };

    /*
    Apre il Pdf della fattura
     */
    $scope.stampaDettaglio = function (id) {
        window.open(params['baseurl'] + '/stampe/avvisiPagamento/avvisoPagamentoPdf.php?idFattura=' + id);
    };

    $scope.caricaDettagliModale = function (elenco, etichetta) {
        $scope.elencoModale = elenco;
        $scope.etichettaModale = etichetta;
    };

    //---------------------------------------------------SEZIONE FILTRI-----------------------------------------------//
    $scope.caricaFiltri = function () {
        $http.post($scope.params['form'] + "/template/controller/homeHandler.php",
            {'function': 'caricaFiltri'}
        ).then(function (data, status, headers, config) {
            // stampalog(data.data);
            $scope.filtriSelectPagina = data.data;
        });
    };
    $scope.settings = {
        dynamicTitle: true,
        enableSearch: true,
        showSelectAll: false,
        keyboardControls: true,
        scrollable: true,
        showCheckAll: false,
        showUncheckAll: true,
        closeOnSelect: false,
        scrollableHeight: '300px',
        externalIdProp: '', //PERMETTE DI AGGIUNGERE ALL'ARRAY DEI SELEZIONATI TUTTO L'OGGETTO
        idProp: 'id', //definisco i campi di cui è composto l'oggetto
        displayProp: 'descrizione' //definisco i campi di cui è composto l'oggetto
    };
    $scope.customTextUtenti = {
        buttonDefaultText: 'Utenti',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextStabili = {
        buttonDefaultText: 'Stabili',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextLocatori = {
        buttonDefaultText: 'Locatori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextConduttori = {
        buttonDefaultText: 'Conduttori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.multiSelectEventUtenti = {
        onItemSelect: function (obj) {
            $scope.filtroUtenti.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroUtenti.length; i++) {
                if ($scope.filtroUtenti[i] == obj.id) {
                    $scope.filtroUtenti.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function () {
            $scope.filtroUtenti = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventStabili = {
        onItemSelect: function (obj) {
            $scope.filtroStabili.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroStabili.length; i++) {
                if ($scope.filtroStabili[i] == obj.id) {
                    $scope.filtroStabili.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroStabili = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventLocatori = {
        onItemSelect: function (obj) {
            $scope.filtroLocatori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroLocatori.length; i++) {
                if ($scope.filtroLocatori[i] == obj.id) {
                    $scope.filtroLocatori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroLocatori = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventConduttori = {
        onItemSelect: function (obj) {
            $scope.filtroConduttori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroConduttori.length; i++) {
                if ($scope.filtroConduttori[i] == obj.id) {
                    $scope.filtroConduttori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroConduttori = [];
            $scope.filtriGenerici();
        }
    };
    $scope.svuotaMultiselect = function () {
        $scope.multiSelectEventUtenti.onDeselectAll();
        $scope.multiSelectEventLocatori.onDeselectAll();
        $scope.multiSelectEventConduttori.onDeselectAll();
        $scope.multiSelectEventStabili.onDeselectAll();
        $scope.elencoUtenti = [];
        $scope.elencoLocatori = [];
        $scope.elencoConduttori = [];
        $scope.elencoStabili = [];
    };
    $scope.filtriGenerici = function () {
        $scope.documenti = [];
        var flag;
        for (var i = 0; i < $scope.documentiCopia.length; i++) {
            flag = false;

            if ($scope.filtroUtenti.length == 0) {
                flag = true;
            }
            else {
                for (var k = 0; k < $scope.filtroUtenti.length; k++) {
                    if ($scope.documentiCopia[i].id_utente_riferimento == $scope.filtroUtenti[k]) {
                        flag = true;
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroStabili.length == 0) {
                    flag = true;
                }
                else {
                    flag = false;
                    for (var j = 0; j < $scope.documentiCopia[i].immobili.length; j++) {
                        for (var k = 0; k < $scope.filtroStabili.length; k++) {
                            if ($scope.documentiCopia[i].immobili[j].id_stabili == $scope.filtroStabili[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroLocatori.length == 0) {
                    flag = true;
                }
                else {
                    flag = false;
                    for (var j = 0; j < $scope.documentiCopia[i].proprietari.length; j++) {
                        for (var k = 0; k < $scope.filtroLocatori.length; k++) {
                            if ($scope.documentiCopia[i].proprietari[j].id == $scope.filtroLocatori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroConduttori.length == 0) {
                    flag = true;
                }
                else {
                    flag = false;
                    for (var j = 0; j < $scope.documentiCopia[i].conduttori.length; j++) {
                        for (var k = 0; k < $scope.filtroConduttori.length; k++) {
                            if ($scope.documentiCopia[i].conduttori[j].id == $scope.filtroConduttori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                $scope.documenti.push($scope.documentiCopia[i]);
            }
        }
    };

}])
;