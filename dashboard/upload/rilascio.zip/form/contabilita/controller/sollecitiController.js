ngApp.controller("sollecitiController", ["$scope", "$http", "$filter", "ngToast", function ($scope, $http, $filter, $ngToast) {

    var url = window.location.href;
    var params = decodeUrl(url, 'id');
    stampalog(params);

    $scope.contrattoScelto = 0;
    $scope.caricamentoCompletato = false;

    $scope.tipoPagamento = [
        {id: 'A', descrizione: 'ASSEGNO'},
        {id: 'B', descrizione: 'BONIFICO'},
        {id: 'C', descrizione: 'CONTANTI'}
    ];


    /*--------------------------------------------------CARICA DATI---------------------------------------------------*/

    $scope.init = function () {
        $scope.filtroUtenti = [];
        $scope.filtroStabili = [];
        $scope.filtroLocatori = [];
        $scope.filtroConduttori = [];
        $scope.elencoUtenti = [];
        $scope.elencoLocatori = [];
        $scope.elencoConduttori = [];
        $scope.elencoStabili = [];

        $scope.caricaFiltri();
        $scope.caricaDati();
    };

    $scope.caricaDati = function () {
        $http.post(params['form'] + '/contabilita/controller/sollecitiHandler.php',
            {
                'function': 'caricaDati'
            }
        ).then(function (data, status, headers, config) {
            stampalog(data.data.status);
            if (data.data.status == 'ko') {
                swal(data.data.error.title, data.data.error.message, 'error');
                return;
            }
            stampalog('Carico Dati');
            stampalog(data.data);
            $scope.solleciti = data.data.solleciti;
            if ($scope.solleciti != null) {
                if ($scope.solleciti.length > 0) {
                    for (var i = 0; i < $scope.solleciti.length; i++) {
                        $scope.solleciti[i].proprietari = jsonParse($scope.solleciti[i].proprietari);
                        $scope.solleciti[i].conduttori = jsonParse($scope.solleciti[i].conduttori);
                        $scope.solleciti[i].primoLocatore = $scope.solleciti[i].proprietari[0].descrizione;
                        $scope.solleciti[i].primoConduttore = $scope.solleciti[i].conduttori[0].descrizione;
                        $scope.solleciti[i].conduttoreChePaga = $scope.solleciti[i].conduttori[0].id;
                        $scope.solleciti[i].versato = 0;
                        $scope.solleciti[i].tipoPagamento = 'B';
                        $scope.solleciti[i].descrizioneIncasso = 'Incasso canone affitto';
                        $scope.solleciti[i].selezionato = false;
                        if ($scope.solleciti[i].dettagli != null) {
                            for (var j = 0; j < $scope.solleciti[i].dettagli.length; j++) {
                                $scope.solleciti[i].dettagli[j].data = new Date(today());
                                $scope.solleciti[i].dettagli[j].importo = 1 * $scope.solleciti[i].dettagli[j].importo;
                                $scope.solleciti[i].dettagli[j].importoCopia = $scope.solleciti[i].dettagli[j].importo;
                                $scope.solleciti[i].dettagli[j].selezionato = false;
                            }
                        }
                    }
                }
            }

            $scope.sollecitiCopia = angular.copy($scope.solleciti);
            $scope.caricamentoCompletato = true;
        });
    };

    /*---------------------------------------------------SALVA DATI---------------------------------------------------*/

    $scope.elaboraSelezionati = function () {
        swal({
                title: "Registrare gli incassi?",
                text: "",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: "btn-danger",
                confirmButtonText: "Si, elabora!",
                cancelButtonText: "No, annulla!",
                closeOnConfirm: false,
                closeOnCancel: false,
                showLoaderOnConfirm: true
            },
            function (isConfirm) {
                if (isConfirm) {

                    for (var i = 0; i < $scope.solleciti.length; i++) {
                        for (var j = 0; j < $scope.solleciti[i].dettagli.length; j++) {
                            $scope.solleciti[i].dettagli[j].data =
                                getYYYYMMGGFromJsDate($scope.solleciti[i].dettagli[j].data);
                        }
                    }

                    $http.post(params['form'] + '/contabilita/controller/sollecitiHandler.php',
                        {
                            'function': 'elaboraSelezionati',
                            'solleciti': $scope.solleciti
                        }
                    ).then(function (data, status, headers, config) {
                        stampalog(data.data);
                        if (data.data.status == "ok") {
                            swal({
                                title: "Documenti contabilizzati",
                                text: '',
                                type: "success"
                            }, function () {
                                window.location.href = $scope.params['home'] + encodeUrl("contabilita", "solleciti");
                            });
                        }
                        else {
                            swal("Contabilizzazione non riuscita", "", "error");
                        }
                    });
                }
                else {
                    swal("Contabilizzazione annullata", "", "error");
                }
            });
    };


    /*---------------------------------------------FUNZIONI IN PAGINA-------------------------------------------------*/

    $scope.scegliContratto = function (idContratto, index) {
        $scope.contrattoScelto = idContratto;
        $scope.indiceArray = index;
    };


    $scope.caricaContiCorrente = function (elencoIdAnagrafiche) {

        $http.post(params['form'] + '/contabilita/controller/sollecitiHandler.php',
            {
                'function': 'caricaElencoBancheContratto',
                'arrayId': elencoIdAnagrafiche
            }
        ).then(function (data, status, headers, config) {
            $scope.elencoContiCorrente = data.data.elencoContiCorrente;
        });

    };


    $scope.modificaImporto = function (idContratto, indice) {
        if ($scope.solleciti != null) {
            for (var i = 0; i < $scope.solleciti.length; i++) {
                if ($scope.solleciti[i].id_contratto == idContratto) {
                    if ($scope.solleciti[i].dettagli[indice].importo > $scope.solleciti[i].dettagli[indice].importoCopia) {
                        $scope.solleciti[i].dettagli[indice].importo = $scope.solleciti[i].dettagli[indice].importoCopia;
                    }
                    if ($scope.solleciti[i].dettagli[indice].importo > 0) {
                        $scope.solleciti[i].dettagli[indice].selezionato = true;
                        $scope.solleciti[i].selezionato = true;
                    }
                    else {
                        $scope.solleciti[i].dettagli[indice].selezionato = false;
                    }
                    $scope.solleciti[i].versato = 0;
                    if ($scope.solleciti[i].dettagli != null) {
                        for (var j = 0; j < $scope.solleciti[i].dettagli.length; j++) {
                            if ($scope.solleciti[i].dettagli[j].selezionato == true) {
                                $scope.solleciti[i].versato =
                                    (1 * $scope.solleciti[i].versato) +
                                    $scope.solleciti[i].dettagli[j].importo;
                            }
                        }
                    }
                }
            }
        }
    };


    $scope.versamento = function (idContratto, indice) {
        for (var i = 0; i < $scope.solleciti.length; i++) {
            if ($scope.solleciti[i].id_contratto == idContratto) {
                $scope.solleciti[i].selezionato = true;
                $scope.solleciti[i].versato = (1 * $scope.solleciti[i].versato) + (1 * $scope.solleciti[i].dettagli[indice].importo);
                $scope.solleciti[i].dettagli[indice].selezionato = true;
            }
        }
    };


    $scope.annullaVersamento = function (idContratto, indice) {
        var tuttiEliminati = true;
        for (var i = 0; i < $scope.solleciti.length; i++) {
            if ($scope.solleciti[i].id_contratto == idContratto) {
                $scope.solleciti[i].versato = (1 * $scope.solleciti[i].versato) - (1 * $scope.solleciti[i].dettagli[indice].importo);
                $scope.solleciti[i].dettagli[indice].selezionato = false;
                for (var j = 0; j < $scope.solleciti[i].dettagli.length; j++) {
                    if ($scope.solleciti[i].dettagli[j].selezionato == true) {
                        tuttiEliminati = false;
                    }
                }
                if (tuttiEliminati == true) {
                    $scope.solleciti[i].selezionato = false;
                }
            }
        }
    };


    $scope.versamentoTotale = function (idContratto) {
        for (var i = 0; i < $scope.solleciti.length; i++) {
            if ($scope.solleciti[i].id_contratto == idContratto) {
                $scope.solleciti[i].selezionato = true;
                $scope.solleciti[i].versato = $scope.solleciti[i].importo;
                for (var j = 0; j < $scope.solleciti[i].dettagli.length; j++) {
                    $scope.solleciti[i].dettagli[j].selezionato = true;
                }
            }
        }
    };


    $scope.annullaVersamentoTotale = function (idContratto) {
        for (var i = 0; i < $scope.solleciti.length; i++) {
            if ($scope.solleciti[i].id_contratto == idContratto) {
                $scope.solleciti[i].selezionato = false;
                $scope.solleciti[i].versato = 0;
                for (var j = 0; j < $scope.solleciti[i].dettagli.length; j++) {
                    $scope.solleciti[i].dettagli[j].selezionato = false;
                    $scope.solleciti[i].dettagli[j].importo = $scope.solleciti[i].dettagli[j].importoCopia;
                }
            }
        }
    };


    /*
    Selsezione / Deseleziona tutti gli elementi nella tabella
     */
    $scope.selezionaDeselezionaTutti = function (flag) {
        $scope.selezionatiTutti = flag;
        for (var i = 0; i < $scope.solleciti.length; i++) {
            $scope.solleciti[i].selezionato = flag;
        }
    };

    /*
    Apre il Pdf della fattura
     */
    $scope.stampaDettaglio = function (id) {
        window.open(params['baseurl'] + '/stampe/avvisiPagamento/avvisoPagamentoPdf.php?idFattura=' + id);
    };

    $scope.caricaDettagliModale = function (elenco, etichetta) {
        $scope.elencoModale = elenco;
        $scope.etichettaModale = etichetta;
    };

    //---------------------------------------------------SEZIONE FILTRI-----------------------------------------------//
    $scope.caricaFiltri = function () {
        $http.post($scope.params['form'] + "/template/controller/homeHandler.php",
            {'function': 'caricaFiltri'}
        ).then(function (data, status, headers, config) {
            // stampalog(data.data);
            $scope.filtriSelectPagina = data.data;
        });
    };
    $scope.settings = {
        dynamicTitle: true,
        enableSearch: true,
        showSelectAll: false,
        keyboardControls: true,
        scrollable: true,
        showCheckAll: false,
        showUncheckAll: true,
        closeOnSelect: false,
        scrollableHeight: '300px',
        externalIdProp: '', //PERMETTE DI AGGIUNGERE ALL'ARRAY DEI SELEZIONATI TUTTO L'OGGETTO
        idProp: 'id', //definisco i campi di cui è composto l'oggetto
        displayProp: 'descrizione' //definisco i campi di cui è composto l'oggetto
    };
    $scope.customTextUtenti = {
        buttonDefaultText: 'Utenti',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextStabili = {
        buttonDefaultText: 'Stabili',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextLocatori = {
        buttonDefaultText: 'Locatori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.customTextConduttori = {
        buttonDefaultText: 'Conduttori',
        checkAll: 'Seleziona tutti',
        uncheckAll: 'Deseleziona tutti',
        searchPlaceholder: 'Cerca..',
        dynamicButtonTextSuffix: 'selezionati'
    };
    $scope.multiSelectEventUtenti = {
        onItemSelect: function (obj) {
            $scope.filtroUtenti.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroUtenti.length; i++) {
                if ($scope.filtroUtenti[i] == obj.id) {
                    $scope.filtroUtenti.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function () {
            $scope.filtroUtenti = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventStabili = {
        onItemSelect: function (obj) {
            $scope.filtroStabili.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroStabili.length; i++) {
                if ($scope.filtroStabili[i] == obj.id) {
                    $scope.filtroStabili.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroStabili = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventLocatori = {
        onItemSelect: function (obj) {
            $scope.filtroLocatori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroLocatori.length; i++) {
                if ($scope.filtroLocatori[i] == obj.id) {
                    $scope.filtroLocatori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroLocatori = [];
            $scope.filtriGenerici();
        }
    };
    $scope.multiSelectEventConduttori = {
        onItemSelect: function (obj) {
            $scope.filtroConduttori.push(obj.id);
            $scope.filtriGenerici();
        },
        onItemDeselect: function (obj) {
            for (i = 0; i < $scope.filtroConduttori.length; i++) {
                if ($scope.filtroConduttori[i] == obj.id) {
                    $scope.filtroConduttori.splice(i, 1);
                    i--;
                }
            }
            $scope.filtriGenerici();
        },
        onDeselectAll: function (obj) {
            $scope.filtroConduttori = [];
            $scope.filtriGenerici();
        }
    };
    $scope.svuotaMultiselect = function () {
        $scope.multiSelectEventUtenti.onDeselectAll();
        $scope.multiSelectEventLocatori.onDeselectAll();
        $scope.multiSelectEventConduttori.onDeselectAll();
        $scope.multiSelectEventStabili.onDeselectAll();
        $scope.elencoUtenti = [];
        $scope.elencoLocatori = [];
        $scope.elencoConduttori = [];
        $scope.elencoStabili = [];
    };
    $scope.filtriGenerici = function () {
        $scope.solleciti = [];
        var flag;
        for (var i = 0; i < $scope.sollecitiCopia.length; i++) {
            flag = false;

            if ($scope.filtroUtenti.length == 0) {
                flag = true;
            }
            else {
                for (var k = 0; k < $scope.filtroUtenti.length; k++) {
                    if ($scope.sollecitiCopia[i].id_utente_riferimento == $scope.filtroUtenti[k]) {
                        flag = true;
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroStabili.length == 0) {
                    flag = true;
                }
                else {
                    flag = false;
                    for (var j = 0; j < $scope.sollecitiCopia[i].immobili.length; j++) {
                        for (var k = 0; k < $scope.filtroStabili.length; k++) {
                            if ($scope.sollecitiCopia[i].immobili[j].id_stabili == $scope.filtroStabili[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroLocatori.length == 0) {
                    flag = true;
                }
                else {
                    flag = false;
                    for (var j = 0; j < $scope.sollecitiCopia[i].proprietari.length; j++) {
                        for (var k = 0; k < $scope.filtroLocatori.length; k++) {
                            if ($scope.sollecitiCopia[i].proprietari[j].id == $scope.filtroLocatori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                if ($scope.filtroConduttori.length == 0) {
                    flag = true;
                }
                else {
                    flag = false;
                    for (var j = 0; j < $scope.sollecitiCopia[i].conduttori.length; j++) {
                        for (var k = 0; k < $scope.filtroConduttori.length; k++) {
                            if ($scope.sollecitiCopia[i].conduttori[j].id == $scope.filtroConduttori[k]) {
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (flag == true) {
                $scope.solleciti.push($scope.sollecitiCopia[i]);
            }
        }
    };

}])
;