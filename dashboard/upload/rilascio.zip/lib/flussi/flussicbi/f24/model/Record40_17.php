<?php
	
	namespace Click\Flussi\Cbi\F24;
	
	use Click\Flussi\Utility\StringUtility;


	/**
	 * Description of Record40-17 F24 su speficifiche CBI F24 6.16
	 *
	 * @author  COLOMBO Claudio
	 * @version 1.0
	 *
	 */
	class Record40_17
	{
		
		/** tipo record fisso */
		private $tipoRecord = "40";
		/** */
		private $progressivoDelegaF24 = "";
		/** */
		private $subtipoRecord = "17";
		
		/**
		 * @var
		 */
		private $progressivoTributo;
		/**
		 * @var
		 */
		private $tipo;
		/**
		 * @var
		 */
		private $elementiIdentificativi;
		/**
		 * @var
		 */
		private $codice;
		/**
		 * @var
		 */
		private $annoRiferimento;
		/**
		 * @var
		 */
		private $importoDebitoVersato;
		/**
		 * @var
		 */
		private $importoCreditoCompensato;
		/**
		 * @var
		 */
		private $codiceUfficio;
		/**
		 * @var
		 */
		private $codiceAtto;
		
		//-------------------------
		// METODI
		//-------------------------
		
		/**
		 * Record40_17 constructor.
		 *
		 * @param string $progressivoDelegaF24
		 * @param string $subtipoRecord
		 * @param $progressivoTributo
		 * @param $tipo
		 * @param $elementiIdentificativi
		 * @param $codice
		 * @param $annoRiferimento
		 * @param $importoDebitoVersato
		 * @param $codiceUfficio
		 * @param $codiceAtto
		 */
		public function __construct($progressivoDelegaF24='',
									$subtipoRecord='',
									$progressivoTributo='',
									$tipo='',
									$elementiIdentificativi='',
									$codice='',
									$annoRiferimento='',
									$importoDebitoVersato='',
									$codiceUfficio='',
									$codiceAtto='')
		{
			$this->tipoRecord = '40';
			$this->setProgressivoDelegaF24($progressivoDelegaF24);
			$this->subtipoRecord = '17';
			
			$this->setProgressivoTributo($progressivoTributo);
			$this->setTipo($tipo);
			$this->setElementiIdentificativi($elementiIdentificativi);
			$this->setCodice($codice);
			$this->setAnnoRiferimento($annoRiferimento);
			$this->setImportoCreditoCompensato(0);
			$this->setImportoDebitoVersato($importoDebitoVersato);
			$this->setCodiceUfficio($codiceUfficio);
			$this->setCodiceAtto($codiceAtto);
		}
		
		//-------------------------
		// GETTER & SETTER
		//-------------------------
		
		
		/**
		 * @return string
		 */
		public function getTipoRecord()
		{
			return $this->tipoRecord;
		}
		
		/**
		 * @return string
		 */
		public function getProgressivoDelegaF24()
		{
			return $this->progressivoDelegaF24;
		}
		
		/**
		 * @param $progressivoDelegaF24
		 */
		public function setProgressivoDelegaF24($progressivoDelegaF24)
		{
			$this->progressivoDelegaF24 = StringUtility::preparaPerFlussiCon0($progressivoDelegaF24, 7);
		}
		
		/**
		 * @return mixed
		 */
		public function getProgressivoTributo()
		{
			return $this->progressivoTributo;
		}
		
		/**
		 * @param mixed $progressivoTributo
		 */
		public function setProgressivoTributo($progressivoTributo): void
		{
			$this->progressivoTributo = StringUtility::preparaPerFlussiCon0($progressivoTributo,2);
		}
		
		/**
		 * @return mixed
		 */
		public function getTipo()
		{
			return $this->tipo;
		}
		
		/**
		 * @param mixed $tipo
		 */
		public function setTipo($tipo): void
		{
			$this->tipo = StringUtility::preparaPerFlussi($tipo,1);
		}
		
		/**
		 * @return mixed
		 */
		public function getElementiIdentificativi()
		{
			return $this->elementiIdentificativi;
		}
		
		/**
		 * @param mixed $elementiIdentificativi
		 */
		public function setElementiIdentificativi($elementiIdentificativi): void
		{
			$this->elementiIdentificativi = StringUtility::preparaPerFlussi($elementiIdentificativi,17);
		}
		
		/**
		 * @return mixed
		 */
		public function getCodice()
		{
			return $this->codice;
		}
		
		/**
		 * @param mixed $codice
		 */
		public function setCodice($codice): void
		{
			$this->codice = StringUtility::preparaPerFlussi($codice, 4);
		}
		
		/**
		 * @return mixed
		 */
		public function getAnnoRiferimento()
		{
			return $this->annoRiferimento;
		}
		
		/**
		 * @param mixed $annoRiferimento
		 */
		public function setAnnoRiferimento($annoRiferimento): void
		{
			$this->annoRiferimento = StringUtility::preparaPerFlussi($annoRiferimento, 4);
		}
		
		/**
		 * @return mixed
		 */
		public function getImportoDebitoVersato()
		{
			return $this->importoDebitoVersato;
		}
		
		/**
		 * @param mixed $importoDebitoVersato
		 */
		public function setImportoDebitoVersato($importoDebitoVersato): void
		{
			$this->importoDebitoVersato = StringUtility::doubleToStringFlussi($importoDebitoVersato, 15);
		}
		
		/**
		 * @return mixed
		 */
		public function getImportoCreditoCompensato()
		{
			return $this->importoCreditoCompensato;
		}
		
		/**
		 * @param mixed $importoCreditoCompensato
		 */
		protected function setImportoCreditoCompensato($importoCreditoCompensato): void
		{
			//$this->importoCreditoCompensato = StringUtility::preparaImportiPerFlussi($importoCreditoCompensato,14);
			$this->importoCreditoCompensato = StringUtility::preparaPerFlussiCon0('', 15);
		}
		
		/**
		 * @return mixed
		 */
		public function getCodiceUfficio()
		{
			return $this->codiceUfficio;
		}
		
		/**
		 * @param mixed $codiceUfficio
		 */
		public function setCodiceUfficio($codiceUfficio): void
		{
			$this->codiceUfficio = StringUtility::preparaPerFlussi($codiceUfficio, 3);
		}
		
		/**
		 * @return mixed
		 */
		public function getCodiceAtto()
		{
			return $this->codiceAtto;
		}
		
		/**
		 * @param mixed $codiceAtto
		 */
		public function setCodiceAtto($codiceAtto): void
		{
			$this->codiceAtto = StringUtility::preparaPerFlussi($codiceAtto, 11);
		}
		
		/**
		 * @return mixed
		 */
		public function getSubtipoRecord()
		{
			return $this->subtipoRecord;
		}
		
		
	}