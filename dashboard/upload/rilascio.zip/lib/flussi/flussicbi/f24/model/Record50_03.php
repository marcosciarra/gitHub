<?php
	
	namespace Click\Flussi\Cbi\F24;
	
	use Click\Flussi\Utility\StringUtility;
	
	
	/**
	 * Description of Record50_03 F24 su speficifiche CBI F24 6.16
	 *
	 * @author  COLOMBO Claudio
	 * @version 1.0
	 *
	 */
	class Record50_03
	{
		
		/** tipo record fisso */
		private $tipoRecord = "50";
		/** */
		private $progressivoDelegaF24 = "";
		/** */
		private $subtipoRecord = "03";
		/** */
		private $cap = "";
		/** */
		private $comune = "";
		/** */
		private $provincia = "";
		/** */
		private $indirizzo = "";
		
		//-------------------------
		// METODI
		//-------------------------
		
		/**
		 * Record50_03 constructor.
		 */
		function __construct()
		{
			$this->tipoRecord = "50";
			$this->subtipoRecord = "03";
			$this->crea('', '', '', '', '');
		}
		
		/**
		 * @param $progressivoDelegaF24
		 * @param $cap
		 * @param $comune
		 * @param $provincia
		 * @param $indirizzo
		 */
		function crea($progressivoDelegaF24,
					  $cap,
					  $comune,
					  $provincia,
					  $indirizzo)
		{
			$this->setProgressivoDelegaF24($progressivoDelegaF24);
			$this->setCap($cap);
			$this->setComune($comune);
			$this->setProvincia($provincia);
			$this->setIndirizzo($indirizzo);
		}
		
		//-------------------------
		// GETTER & SETTER
		//-------------------------
		
		/**
		 * @return string
		 */
		public function getTipoRecord()
		{
			return $this->tipoRecord;
		}
		
		
		/**
		 * @return string
		 */
		public function getProgressivoDelegaF24()
		{
			return $this->progressivoDelegaF24;
		}
		
		/**
		 * @param $progressivoDelegaF24
		 */
		public function setProgressivoDelegaF24($progressivoDelegaF24)
		{
			$this->progressivoDelegaF24 = StringUtility::preparaPerFlussiCon0($progressivoDelegaF24, 7);
		}
		
		/**
		 * @return string
		 */
		public function getSubtipoRecord()
		{
			return $this->subtipoRecord;
		}
		
		/**
		 * @param $subtipoRecord
		 */
		public function setSubtipoRecord($subtipoRecord)
		{
			$this->subtipoRecord = $subtipoRecord;
		}
		
		/**
		 * @return string
		 */
		public function getCap()
		{
			return $this->cap;
		}
		
		/**
		 * @param $cap
		 */
		public function setCap($cap)
		{
			$this->cap = StringUtility::preparaPerFlussi($cap, 5);
		}
		
		/**
		 * @return string
		 */
		public function getComune()
		{
			return $this->comune;
		}
		
		/**
		 * @param $comune
		 */
		public function setComune($comune)
		{
			$this->comune = StringUtility::preparaPerFlussi($comune, 25);
		}
		
		/**
		 * @return string
		 */
		public function getProvincia()
		{
			return $this->provincia;
		}
		
		/**
		 * @param $provincia
		 */
		public function setProvincia($provincia)
		{
			$this->provincia = StringUtility::preparaPerFlussi($provincia, 2);
		}
		
		/**
		 * @return string
		 */
		public function getIndirizzo()
		{
			return $this->indirizzo;
		}
		
		/**
		 * @param $indirizzo
		 */
		public function setIndirizzo($indirizzo)
		{
			$this->indirizzo = StringUtility::preparaPerFlussi($indirizzo, 34);
		}
		
	}