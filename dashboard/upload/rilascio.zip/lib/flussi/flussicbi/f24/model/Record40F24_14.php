<?php
require_once '../../flussi/utility/StringUtility.php';

    /**
     * Description of Record40-14 F24 su speficifiche CBI F24 6.12
     *
     * @author  COLOMBO Claudio
     * @version 1.0
     *
     */
    class Record40F24_14
    {

        /** tipo record fisso */
        private $tipoRecord = "40";
        /** */
        private $progressivoDelegaF24 = "";
        /** */
        private $subtipoRecord = "14";

        //-------------------------
        // METODI
        //-------------------------


        //-------------------------
        // GETTER & SETTER
        //-------------------------
    }

?>
