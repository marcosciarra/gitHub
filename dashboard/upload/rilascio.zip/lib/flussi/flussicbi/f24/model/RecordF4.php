<?php

namespace Click\Flussi\Cbi\F24;

use Click\Flussi\Utility\StringUtility;

/**
 * Description of Record di testa F24 su speficifiche CBI F24 6.16
 *
 * @author  COLOMBO Claudio
 * @version 1.0
 *
 */
class RecordF4
{

    /** tipo record fisso */
    private $tipoRecord = "F4";
    /**
     */
    private $mittente = "";
    /**
     */
    private $ricevente = "";
    /**
     */
    private $dataCreazione = "";
    /**
     */
    private $nomeSupporto = "";
    /**
     */
    private $riferimentiMittente = "";
    /**
     */
    private $tipoFlusso = "";
    /**
     */
    private $qualificatoreFlusso = "";
    /**
     */
    private $soggettoVeicolatore = "";
    /**
     */
    private $codiceDivisa = "E";

    //-------------------------
    // METODI
    //-------------------------

    /**
     * RecordF4 constructor.
     */
    function __construct()
    {
        $this->tipoRecord = "F4";
        $this->setMittente('');
        $this->crea('', '', '', '', '');
        $this->tipoFlusso = "2";
        $this->qualificatoreFlusso = '$';
        $this->codiceDivisa = "E";
    }

    /**
     * @param $mittente
     * @param $ricevente
     * @param $dataCreazione
     * @param $nomeSupporto
     * @param $riferimentiMittente
     * @param string $soggettoVeicolatore
     */
    function crea($mittente,
                  $ricevente,
                  $dataCreazione,
                  $nomeSupporto,
                  $soggettoVeicolatore,
                  $riferimentiMittente = '')
    {
        $this->setMittente($mittente);
        $this->setRicevente($ricevente);
        $this->setDataCreazione($dataCreazione);
        $this->setNomeSupporto($nomeSupporto);
        $this->setSoggettoVeicolatore($soggettoVeicolatore);
        $this->setRiferimentiMittente($riferimentiMittente);
    }

    //-------------------------
    // GETTER & SETTER
    //-------------------------

    /**
     * @return string
     */
    public function getTipoRecord()
    {
        return $this->tipoRecord;
    }

    /**
     * @return string
     */
    public function getMittente()
    {
        return $this->mittente;
    }

    /**
     * @param $mittente
     */
    public function setMittente($mittente)
    {
        $this->mittente = StringUtility::preparaPerFlussi($mittente, 5);
    }

    /**
     * @return string
     */
    public function getRicevente()
    {
        return $this->ricevente;
    }

    /**
     * @param $ricevente
     */
    public function setRicevente($ricevente)
    {
        $this->ricevente = StringUtility::preparaPerFlussiCon0($ricevente, 5);
    }

    /**
     * @return string
     */
    public function getDataCreazione()
    {
        return $this->dataCreazione;
    }

    /**
     * @param $dataCreazione
     */
    public function setDataCreazione($dataCreazione)
    {
        $this->dataCreazione = StringUtility::preparaPerFlussiCon0($dataCreazione, 6);
    }

    /**
     * @return string
     */
    public function getNomeSupporto()
    {
        return $this->nomeSupporto;
    }

    /**
     * @param $nomeSupporto
     */
    public function setNomeSupporto($nomeSupporto)
    {
        $this->nomeSupporto = StringUtility::preparaPerFlussi($nomeSupporto, 20);
    }

    /**
     * @return string
     */
    public function getRiferimentiMittente()
    {
        return $this->riferimentiMittente;
    }

    /**
     * @param $riferimentiMittente
     */
    public function setRiferimentiMittente($riferimentiMittente)
    {
        $this->riferimentiMittente = StringUtility::preparaPerFlussi($riferimentiMittente, 6);
    }

    /**
     * @return string
     */
    public function getTipoFlusso()
    {
        return $this->tipoFlusso;
    }

    /**
     * @return string
     */
    public function getQualificatoreFlusso()
    {
        return $this->qualificatoreFlusso;
    }


    /**
     * @return string
     */
    public function getSoggettoVeicolatore()
    {
        return $this->soggettoVeicolatore;
    }

    /**
     * @param string $soggettoVeicolatore
     */
    public function setSoggettoVeicolatore($soggettoVeicolatore = '')
    {
        $this->soggettoVeicolatore = StringUtility::preparaPerFlussi($soggettoVeicolatore, 5);

    }

    /**
     * @return string
     */
    public function getCodiceDivisa()
    {
        return $this->codiceDivisa;
    }

}
