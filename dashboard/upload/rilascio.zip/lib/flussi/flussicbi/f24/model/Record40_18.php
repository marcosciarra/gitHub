<?php
	
	namespace Click\Flussi\Cbi\F24;
	
	use Click\Flussi\Utility\StringUtility;
	

	/**
	 * Description of Record40-18 F24 su speficifiche CBI F24 6.16
	 *
	 * @author  COLOMBO Claudio
	 * @version 1.0
	 *
	 */
	class Record40_18
	{
		
		/** tipo record fisso */
		private $tipoRecord = "40";
		/**@var string */
		private $progressivoDelegaF24 = "";
		/**@var string */
		private $subtipoRecord = "18";
		
		/**
		 * @var string
		 */
		protected $segnoSaldo;
		/**
		 * @var double
		 */
		protected $saldoSezione;
		
		/**
		 * Record40_18 constructor.
		 *
		 * @param string $progressivoDelegaF24
		 * @param $segnoSaldo
		 * @param $saldoSezione
		 */
		public function __construct($progressivoDelegaF24='', $segnoSaldo='', $saldoSezione='')
		{
			$this->tipoRecord = '40';
			$this->subtipoRecord = '18';
			$this->setProgressivoDelegaF24($progressivoDelegaF24);
			$this->setSegnoSaldo($segnoSaldo);
			$this->setSaldoSezione($saldoSezione);
		}
		
		//-------------------------
		// METODI
		//-------------------------
		
		
		//-------------------------
		// GETTER & SETTER
		//-------------------------
		
		/**
		 * @return string
		 */
		public function getTipoRecord()
		{
			return $this->tipoRecord;
		}
		
		/**
		 * @return string
		 */
		public function getProgressivoDelegaF24()
		{
			return $this->progressivoDelegaF24;
		}
		
		/**
		 * @param $progressivoDelegaF24
		 */
		public function setProgressivoDelegaF24($progressivoDelegaF24)
		{
			$this->progressivoDelegaF24 = StringUtility::preparaPerFlussiCon0($progressivoDelegaF24, 7);
		}
		
		/**
		 * @return mixed
		 */
		public function getSegnoSaldo()
		{
			return $this->segnoSaldo;
		}
		
		/**
		 * @param mixed $segnoSaldo
		 */
		public function setSegnoSaldo($segnoSaldo): void
		{
			$this->segnoSaldo = StringUtility::preparaPerFlussi($segnoSaldo, 1);
		}
		
		/**
		 * @return mixed
		 */
		public function getSaldoSezione()
		{
			return $this->saldoSezione;
		}
		
		/**
		 * @param mixed $saldoSezione
		 */
		public function setSaldoSezione($saldoSezione): void
		{
			$this->saldoSezione = StringUtility::doubleToStringFlussi($saldoSezione, 15);
		}

        /**
         * @return string
         */
        public function getSubtipoRecord(): string
        {
            return $this->subtipoRecord;
        }
		
		
	}
 
