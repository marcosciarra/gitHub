<?php
	
	namespace Click\Flussi\Cbi\F24;
	
	use Click\Flussi\Utility\StringUtility;


	/**
	 * Description of Record50_02 F24 su speficifiche CBI F24 6.16
	 *
	 * @author  COLOMBO Claudio
	 * @version 1.0
	 *
	 */
	class Record50_02
	{
		
		/** tipo record fisso */
		private $tipoRecord = "50";
		/** */
		private $progressivoDelegaF24 = "";
		/** */
		private $subtipoRecord = "02";
		/** */
		private $codiceMittente = "";
		/** */
		private $abi = "";
		/** */
		private $cab = "";
		/** */
		private $codiceCliente = "";
		/** */
		private $destinatarioStampa = "";
		/** */
		private $denominazioneDestinatarioStampa = "";
		
		//-------------------------
		// METODI
		//-------------------------
		
		function __construct()
		{
			$this->tipoRecord = "50";
			$this->subtipoRecord = "02";
			$this->crea('', '', '', '', '', '', '');
		}
		
		function crea($progressivoDelegaF24,
					  $codiceMittente,
					  $abi,
					  $cab,
					  $codiceCliente,
					  $destinatarioStampa,
					  $denominazioneDestinatarioStampa)
		{
			$this->setProgressivoDelegaF24($progressivoDelegaF24);
			$this->setCodiceCliente($codiceCliente);
			$this->setCodiceMittente($codiceMittente);
			$this->setAbi($abi);
			$this->setCab($cab);
			$this->setDenominazioneDestinatarioStampa($this->denominazioneDestinatarioStampa);
			$this->setDestinatarioStampa($destinatarioStampa);
		}
		
		//-------------------------
		// GETTER & SETTER
		//-------------------------
		
		public function getTipoRecord()
		{
			return $this->tipoRecord;
		}
		
		public function getProgressivoDelegaF24()
		{
			return $this->progressivoDelegaF24;
		}
		
		public function setProgressivoDelegaF24($progressivoDelegaF24)
		{
			$this->progressivoDelegaF24 = StringUtility::preparaPerFlussiCon0($progressivoDelegaF24, 7);
		}
		
		public function getSubtipoRecord()
		{
			return $this->subtipoRecord;
		}
		
		public function getCodiceMittente()
		{
			return $this->codiceMittente;
		}
		
		public function setCodiceMittente($codiceMittente)
		{
			$this->codiceMittente = StringUtility::preparaPerFlussi($codiceMittente, 16);
		}
		
		public function getAbi()
		{
			return $this->abi;
		}
		
		public function setAbi($abi)
		{
			$this->abi = StringUtility::preparaPerFlussi($abi, 5);
		}
		
		public function getCab()
		{
			return $this->cab;
		}
		
		public function setCab($cab)
		{
			$this->cab = StringUtility::preparaPerFlussi($cab, 5);
		}
		
		public function getCodiceCliente()
		{
			return $this->codiceCliente;
		}
		
		public function setCodiceCliente($codiceCliente)
		{
			$this->codiceCliente = StringUtility::preparaPerFlussi($codiceCliente, 20);
		}
		
		public function getDestinatarioStampa()
		{
			return $this->destinatarioStampa;
		}
		
		public function setDestinatarioStampa($destinatarioStampa)
		{
			$this->destinatarioStampa = StringUtility::preparaPerFlussi($destinatarioStampa, 1);
		}
		
		public function getDenominazioneDestinatarioStampa()
		{
			return $this->denominazioneDestinatarioStampa;
		}
		
		public function setDenominazioneDestinatarioStampa($denominazioneDestinatarioStampa)
		{
			$this->denominazioneDestinatarioStampa =
				StringUtility::preparaPerFlussi($denominazioneDestinatarioStampa, 45);
		}
		
	}