<?php
	
	namespace Click\Flussi\Cbi\F24;

    use Click\Flussi\Utility\StringUtility;
	/**
	 * Description of Record EF su speficifiche CBI F24 6.16
	 *
	 * @author  COLOMBO Claudio
	 * @version 1.0
	 *
	 */
	class RecordEF
	{
		
		/** tipo record fisso */
		private $tipoRecord = "EF";
		/**
		 */
		private $mittente = "";
		/**
		 */
		private $ricevente = "";
		/**
		 */
		private $dataCreazione = "";
		/**
		 */
		private $nomeSupporto = "";
		/**
		 */
		private $riferimentiMittente = "";
		/**
		 */
		private $numeroDisposizioni = "";
		/**
		 */
		private $importiPositivi = "";
		/**
		 */
		private $importiNegativi = "";
		/**
		 */
		private $numeroRecord = "";
		/** */
		private $codiceDivisa = "E";
		
		//-------------------------
		// METODI
		//-------------------------
		
		/**
		 * RecordEF constructor.
		 */
		function __construct()
		{
			$this->tipoRecord = "EF";
			$this->crea('', '', '', '', '', '', 0, '', '');
			$this->codiceDivisa = "E";
		}
		
		/**
		 * @param $mittente
		 * @param $ricevente
		 * @param $dataCreazione
		 * @param $nomeSupporto
		 * @param $riferimentiMittente
		 * @param $numeroDisposizioni
		 * @param $importiPositivi
		 * @param $importiNegativi
		 * @param $numeroRecord
		 */
		function crea($mittente,
					  $ricevente,
					  $dataCreazione,
					  $nomeSupporto,
					  $riferimentiMittente,
					  $numeroDisposizioni,
					  $importiPositivi,
					  $importiNegativi,
					  $numeroRecord)
		{
			$this->setMittente($mittente);
			$this->setRicevente($ricevente);
			$this->setDataCreazione($dataCreazione);
			$this->setNomeSupporto($nomeSupporto);
			$this->setRiferimentiMittente($riferimentiMittente);
			$this->setNumeroDisposizioni($numeroDisposizioni);
			$this->setImportiNegativi($importiNegativi);
			$this->setImportiPositivi($importiPositivi);
			$this->setNumeroRecord($numeroRecord);
		}
		
		/**
		 *
		 * @param RecordF4F24 $recordTesta
		 */
		function creaCodaDaTesta(RecordF4 $recordTesta)
		{
			new self();
			$this->crea($recordTesta->getMittente(),
						$recordTesta->getRicevente(),
						$recordTesta->getDataCreazione(),
						$recordTesta->getNomeSupporto(),
						'', 0, 0, 0, 2
			);
		}
		
		//-------------------------
		// GETTER & SETTER
		//-------------------------
		
		/**
		 * @return string
		 */
		public function getMittente()
		{
			return $this->mittente;
		}
		
		/**
		 * @param $mittente
		 */
		public function setMittente($mittente)
		{
			$this->mittente = StringUtility::preparaPerFlussi($mittente, 5);
		}
		
		/**
		 * @return string
		 */
		public function getRicevente()
		{
			return $this->ricevente;
		}
		
		/**
		 * @param $ricevente
		 */
		public function setRicevente($ricevente)
		{
			$this->ricevente = StringUtility::preparaPerFlussi($ricevente, 5);
		}
		
		/**
		 * @return string
		 */
		public function getDataCreazione()
		{
			return $this->dataCreazione;
		}
		
		/**
		 * @param $dataCreazione
		 */
		public function setDataCreazione($dataCreazione)
		{
			$this->dataCreazione = StringUtility::preparaPerFlussi($dataCreazione, 6);;
		}
		
		/**
		 * @return string
		 */
		public function getNomeSupporto()
		{
			return $this->nomeSupporto;
		}
		
		/**
		 * @param $nomeSupporto
		 */
		public function setNomeSupporto($nomeSupporto)
		{
			$this->nomeSupporto = StringUtility::preparaPerFlussi($nomeSupporto, 20);;
		}
		
		/**
		 * @return string
		 */
		public function getTipoRecord()
		{
			return $this->tipoRecord;
		}
		
		/**
		 * @return string
		 */
		public function getRiferimentiMittente()
		{
			return $this->riferimentiMittente;
		}
		
		/**
		 * @param $riferimentiMittente
		 */
		public function setRiferimentiMittente($riferimentiMittente)
		{
			$this->riferimentiMittente = StringUtility::preparaPerFlussi($riferimentiMittente, 6);
		}
		
		/**
		 * @return string
		 */
		public function getNumeroDisposizioni()
		{
			return $this->numeroDisposizioni;
		}
		
		/**
		 * @param $numeroDisposizioni
		 */
		public function setNumeroDisposizioni($numeroDisposizioni)
		{
			$this->numeroDisposizioni = StringUtility::preparaPerFlussiCon0($numeroDisposizioni, 7);
		}
		
		/**
		 * @return string
		 */
		public function getImportiPositivi()
		{
			return $this->importiPositivi;
		}
		
		/**
		 * @param $importiPositivi
		 */
		public function setImportiPositivi($importiPositivi)
		{
			$this->importiPositivi =
				StringUtility::doubleToStringFlussi($importiPositivi,
													15
				);
		}
		
		/**
		 * @return string
		 */
		public function getImportiNegativi()
		{
			return $this->importiNegativi;
		}
		
		/**
		 * @param $importiNegativi
		 */
		public function setImportiNegativi($importiNegativi)
		{
			$this->importiNegativi = StringUtility::doubleToStringFlussi($importiNegativi,
																		 15
			);
		}
		
		/**
		 * @return string
		 */
		public function getNumeroRecord()
		{
			return $this->numeroRecord;
		}
		
		/**
		 * @param $numeroRecord
		 */
		public function setNumeroRecord($numeroRecord)
		{
			$this->numeroRecord = StringUtility::preparaPerFlussiCon0($numeroRecord, 7);
		}
		
		/**
		 * @return string
		 */
		public function getCodiceDivisa()
		{
			return $this->codiceDivisa;
		}
	}
