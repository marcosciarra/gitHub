<?php

require_once '../../flussi/utility/StringUtility.php';
    /**
     * Description of Record40-02 F24 su speficifiche CBI F24 6.12
     *
     * @author  COLOMBO Claudio
     * @version 1.0
     *
     */
    class Record40F24_02
    {

        /** tipo record fisso */
        private $tipoRecord = "40";
        /** */
        private $progressivoDelegaF24 = "";
        /** */
        private $subtipoRecord = "02";
        /** */
        private $totaleImportoADebitoVersato = "";
        /** */
        private $totaleImportoACreditoCompensato = "";
        /** */
        private $segnoSezione = "";
        /** */
        private $saldoSezione = "";

        //-------------------------
        // METODI
        //-------------------------

        /**
         *
         */
        function __construct()
        {
            $this->tipoRecord = "40";
            $this->subtipoRecord = "02";
            $this->progressivoDelegaF24 = StringUtility::preparaPerFlussiCon0(0,
                                                                              7);

            $this->totaleImportoADebitoVersato = StringUtility::doubleToStringFlussi(0,
                                                                                     15);
            $this->totaleImportoACreditoCompensato = StringUtility::doubleToStringFlussi(0,
                                                                                         15);
            $this->segnoSezione = "P";
            $this->saldoSezione = StringUtility::doubleToStringFlussi(0,
                                                                      15);
        }

        /**
         *
         * @param int $progressivoDelegaF24
         * @param float $totaleImportoADebitoVersato
         * @param float $totaleImportoACreditoCompensato
         * @param string $segnoSezione
         * @param float $saldoSezione
         */
        function crea($progressivoDelegaF24,
                      $totaleImportoADebitoVersato,
                      $totaleImportoACreditoCompensato,
                      $segnoSezione,
                      $saldoSezione)
        {
            $this->progressivoDelegaF24 = StringUtility::preparaPerFlussiCon0($progressivoDelegaF24,
                                                                              7);

            $this->totaleImportoADebitoVersato = StringUtility::doubleToStringFlussi($totaleImportoADebitoVersato,
                                                                                     15);
            $this->totaleImportoACreditoCompensato = StringUtility::doubleToStringFlussi($totaleImportoACreditoCompensato,
                                                                                         15);
            $this->segnoSezione = ($segnoSezione == 'N') ? 'N' : 'P';
            $this->saldoSezione = StringUtility::doubleToStringFlussi($saldoSezione,
                                                                      15);
        }

        //-------------------------
        // GETTER & SETTER
        //-------------------------

        public function getTipoRecord()
        {
            return $this->tipoRecord;
        }

        public function setTipoRecord($tipoRecord)
        {
            $this->tipoRecord = $tipoRecord;
        }

        public function getProgressivoDelegaF24()
        {
            return $this->progressivoDelegaF24;
        }

        public function setProgressivoDelegaF24($progressivoDelegaF24)
        {
            $this->progressivoDelegaF24 = $progressivoDelegaF24;
        }

        public function getSubtipoRecord()
        {
            return $this->subtipoRecord;
        }

        public function setSubtipoRecord($subtipoRecord)
        {
            $this->subtipoRecord = $subtipoRecord;
        }

        public function getTotaleImportoADebitoVersato()
        {
            return $this->totaleImportoADebitoVersato;
        }

        public function setTotaleImportoADebitoVersato($totaleImportoADebitoVersato)
        {
            $this->totaleImportoADebitoVersato = $totaleImportoADebitoVersato;
        }

        public function getTotaleImportoACreditoCompensato()
        {
            return $this->totaleImportoACreditoCompensato;
        }

        public function setTotaleImportoACreditoCompensato($totaleImportoACreditoCompensato)
        {
            $this->totaleImportoACreditoCompensato = $totaleImportoACreditoCompensato;
        }

        public function getSegnoSezione()
        {
            return $this->segnoSezione;
        }

        public function setSegnoSezione($segnoSezione)
        {
            $this->segnoSezione = $segnoSezione;
        }

        public function getSaldoSezione()
        {
            return $this->saldoSezione;
        }

        public function setSaldoSezione($saldoSezione)
        {
            $this->saldoSezione = $saldoSezione;
        }

    }

?>
