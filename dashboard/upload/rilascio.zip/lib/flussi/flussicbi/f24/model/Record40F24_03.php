<?php

require_once '../../flussi/utility/StringUtility.php';
    /**
     * Description of Record40-03 F24 su speficifiche CBI F24 6.12
     *
     * @author  COLOMBO Claudio
     * @version 1.0
     *
     */
    class Record40F24_03
    {

        /** tipo record fisso */
        private $tipoRecord = "40";
        /** */
        private $progressivoDelegaF24 = "";
        /** */
        private $subtipoRecord = "03";
        /** */
        private $progressivoContributo = "";
        /** */
        private $codiceSede = "";
        /** */
        private $causaleContributo = "";
        /** */
        private $inps = "";
        /** */
        private $periodoDiRiferimentoInizio = "";
        /** */
        private $periodoDiRiferimentoFine = "";
        /** */
        private $importoADebitoVersato = "";
        /** */
        private $importoACreditoCompensato = "";

        //-------------------------
        // METODI
        //-------------------------

        /**
         *
         */
        function __construct()
        {
            $this->tipoRecord = "40";
            $this->subtipoRecord = "03";
            $this->progressivoDelegaF24 = StringUtility::preparaPerFlussiCon0(0,
                                                                              7);
            $this->progressivoContributo = StringUtility::preparaPerFlussiCon0(0,
                                                                               2);

            $this->codiceSede = StringUtility::preparaPerFlussi("",
                                                                4);
            $this->causaleContributo = StringUtility::preparaPerFlussi("",
                                                                       4);
            $this->inps = StringUtility::preparaPerFlussi("",
                                                          17);
            $this->periodoDiRiferimentoInizio = StringUtility::preparaPerFlussiCon0(0,
                                                                                    6);
            $this->periodoDiRiferimentoFine = StringUtility::preparaPerFlussiCon0(0,
                                                                                  6);
            $this->importoADebitoVersato = StringUtility::preparaPerFlussiCon0(0,
                                                                               15);
            $this->importoACreditoCompensato = StringUtility::preparaPerFlussiCon0(0,
                                                                                   15);
        }

        /**
         *
         * @param type $progressivoDelegaF24
         * @param type $progressivoContributo
         * @param type $codiceSede
         * @param type $causaleContributo
         * @param type $inps
         * @param type $periodoDiRiferimentoInizio
         * @param type $periodoDiRiferimentoFine
         * @param type $importoADebitoVersato
         * @param type $importoACreditoCompensato
         */
        function crea($progressivoDelegaF24,
                      $progressivoContributo,
                      $codiceSede,
                      $causaleContributo,
                      $inps,
                      $periodoDiRiferimentoInizio,
                      $periodoDiRiferimentoFine,
                      $importoADebitoVersato,
                      $importoACreditoCompensato)
        {
            $this->progressivoDelegaF24 = StringUtility::preparaPerFlussiCon0($progressivoDelegaF24,
                                                                              7);
            $this->progressivoContributo = StringUtility::preparaPerFlussiCon0($progressivoContributo,
                                                                               2);

            $this->codiceSede = StringUtility::preparaPerFlussi($codiceSede,
                                                                4);
            $this->causaleContributo = StringUtility::preparaPerFlussi($causaleContributo,
                                                                       4);
            $this->inps = StringUtility::preparaPerFlussi($inps,
                                                          17);
            $this->periodoDiRiferimentoInizio = StringUtility::preparaPerFlussiCon0($periodoDiRiferimentoInizio,
                                                                                    6);
            $this->periodoDiRiferimentoFine = StringUtility::preparaPerFlussiCon0($periodoDiRiferimentoFine,
                                                                                  6);
            $this->importoADebitoVersato = StringUtility::preparaPerFlussiCon0($importoADebitoVersato,
                                                                               15);
            $this->importoACreditoCompensato = StringUtility::preparaPerFlussiCon0($importoACreditoCompensato,
                                                                                   15);
        }

        //-------------------------
        // GETTER & SETTER
        //-------------------------

        public function getTipoRecord()
        {
            return $this->tipoRecord;
        }

        public function setTipoRecord($tipoRecord)
        {
            $this->tipoRecord = $tipoRecord;
        }

        public function getProgressivoDelegaF24()
        {
            return $this->progressivoDelegaF24;
        }

        public function setProgressivoDelegaF24($progressivoDelegaF24)
        {
            $this->progressivoDelegaF24 = $progressivoDelegaF24;
        }

        public function getSubtipoRecord()
        {
            return $this->subtipoRecord;
        }

        public function setSubtipoRecord($subtipoRecord)
        {
            $this->subtipoRecord = $subtipoRecord;
        }

        public function getProgressivoContributo()
        {
            return $this->progressivoContributo;
        }

        public function setProgressivoContributo($progressivoContributo)
        {
            $this->progressivoContributo = $progressivoContributo;
        }

        public function getCodiceSede()
        {
            return $this->codiceSede;
        }

        public function setCodiceSede($codiceSede)
        {
            $this->codiceSede = $codiceSede;
        }

        public function getCausaleContributo()
        {
            return $this->causaleContributo;
        }

        public function setCausaleContributo($causaleContributo)
        {
            $this->causaleContributo = $causaleContributo;
        }

        /** @see inps */
        public function getInps()
        {
            return $this->inps;
        }

        public function setInps($inps)
        {
            $this->inps = $inps;
        }

        public function getPeriodoDiRiferimentoInizio()
        {
            return $this->periodoDiRiferimentoInizio;
        }

        public function setPeriodoDiRiferimentoInizio($periodoDiRiferimentoInizio)
        {
            $this->periodoDiRiferimentoInizio = $periodoDiRiferimentoInizio;
        }

        public function getPeriodoDiRiferimentoFine()
        {
            return $this->periodoDiRiferimentoFine;
        }

        public function setPeriodoDiRiferimentoFine($periodoDiRiferimentoFine)
        {
            $this->periodoDiRiferimentoFine = $periodoDiRiferimentoFine;
        }

        public function getImportoADebitoVersato()
        {
            return $this->importoADebitoVersato;
        }

        public function setImportoADebitoVersato($importoADebitoVersato)
        {
            $this->importoADebitoVersato = $importoADebitoVersato;
        }

        public function getImportoACreditoCompensato()
        {
            return $this->importoACreditoCompensato;
        }

        public function setImportoACreditoCompensato($importoACreditoCompensato)
        {
            $this->importoACreditoCompensato = $importoACreditoCompensato;
        }

    }

?>
