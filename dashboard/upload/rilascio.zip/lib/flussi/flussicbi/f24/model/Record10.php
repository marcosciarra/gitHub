<?php

namespace Click\Flussi\Cbi\F24;

use Click\Flussi\Utility\StringUtility;


/**
 * Description of Record10 F24 su speficifiche CBI F24 6.16
 *
 * @author  COLOMBO Claudio
 * @version 1.0
 *
 */
class Record10
{

    /** tipo record fisso */
    private $tipoRecord = "10";
    /** */
    private $progressivoDelegaF24 = "";
    /** */
    private $codiceFiscale = "";
    /** identifica se persona fisica (F) a Societa (S) */
    private $tipoSoggetto = "";
    /** */
    private $cognome = "";
    /** */
    private $ragioneSociale = "";
    /** */
    private $nome = "";
    /** */
    private $sesso = "";
    /** */
    private $comuneNascita = "";
    /** */
    private $provinciaNascita = "";
    /** */
    private $dataNascita = "";
    /** */
    private $protocolloDelegaF24 = "";

    //-------------------------
    // METODI
    //-------------------------

    function __construct()
    {
        $this->tipoRecord = "10";
        $this->crea('', '', '', '', '', '', '', '', '', '');
    }

    function crea($progressivoDelegaF24,
                  $codiceFiscale,
                  $ragioneSociale,
                  $cognome,
                  $nome,
                  $sesso,
                  $comuneNascita,
                  $provinciaNascita,
                  $dataNascita,
                  $protocolloDelegaF24)
    {
        $this->setProgressivoDelegaF24($progressivoDelegaF24);
        $this->setCodiceFiscale($codiceFiscale);
        if ($ragioneSociale != '') {
            $this->setRagioneSociale($ragioneSociale);
            $this->setCognome('');
            $this->setNome('');
            $this->setSesso('');
            $this->setComuneNascita('');
            $this->setProvinciaNascita('');
            $this->setDataNascita('');
        } else {
            $this->setRagioneSociale('');
            $this->setCognome($cognome);
            $this->setNome($nome);
            $this->setSesso($sesso);
            $this->setComuneNascita($comuneNascita);
            $this->setProvinciaNascita($provinciaNascita);
            $this->setDataNascita($dataNascita);
        }
        $this->setProtocolloDelegaF24($protocolloDelegaF24);
    }

    function creaPersonaFisica($progressivoDelegaF24,
                               $codiceFiscale,
                               $cognome,
                               $nome,
                               $sesso,
                               $comuneNascita,
                               $provinciaNascita,
                               $dataNascita,
                               $protocolloDelegaF24)
    {

        $this->crea($progressivoDelegaF24,
            $codiceFiscale,
            '',
            $cognome,
            $nome,
            $sesso,
            $comuneNascita,
            $provinciaNascita,
            $dataNascita,
            $protocolloDelegaF24
        );
    }

    function creaSocieta($progressivoDelegaF24,
                         $codiceFiscale,
                         $ragioneSociale,
                         $protocolloDelegaF24)
    {
        $this->crea($progressivoDelegaF24,
            $codiceFiscale,
            $ragioneSociale,
            '',
            '',
            '',
            '',
            '',
            '',
            $protocolloDelegaF24
        );
    }

    //-------------------------
    // GETTER & SETTER
    //-------------------------

    public function getTipoRecord()
    {
        return $this->tipoRecord;
    }

    public function getProgressivoDelegaF24()
    {
        return $this->progressivoDelegaF24;
    }

    public function setProgressivoDelegaF24($progressivoDelegaF24)
    {
        $this->progressivoDelegaF24 = StringUtility::preparaPerFlussiCon0($progressivoDelegaF24, 7);
    }

    public function getCodiceFiscale()
    {
        return $this->codiceFiscale;
    }

    public function setCodiceFiscale($codiceFiscale)
    {
        $this->codiceFiscale = StringUtility::preparaPerFlussi($codiceFiscale, 16);
    }

    public function getCognome()
    {
        return $this->cognome;
    }

    public function setCognome($cognome)
    {
        $this->cognome = StringUtility::preparaPerFlussi($cognome, 24);
    }

    public function getRagioneSociale()
    {
        return $this->ragioneSociale;
    }

    public function setRagioneSociale($ragioneSociale)
    {
        $this->ragioneSociale = StringUtility::preparaPerFlussi($ragioneSociale, 44);
    }

    public function getNome()
    {
        return $this->nome;
    }

    public function setNome($nome)
    {
        $this->nome = StringUtility::preparaPerFlussi($nome, 20);
    }

    public function getSesso()
    {
        return $this->sesso;
    }

    public function setSesso($sesso)
    {
        $this->sesso = StringUtility::preparaPerFlussi($sesso, 1);
    }

    public function getComuneNascita()
    {
        return $this->comuneNascita;
    }

    public function setComuneNascita($comuneNascita)
    {
        $this->comuneNascita = StringUtility::preparaPerFlussi($comuneNascita, 25);
    }

    public function getProvinciaNascita()
    {
        return $this->provinciaNascita;
    }

    public function setProvinciaNascita($provinciaNascita)
    {
        $this->provinciaNascita = StringUtility::preparaPerFlussi($provinciaNascita, 2);
    }

    public function getDataNascita()
    {
        return $this->dataNascita;
    }

    public function setDataNascita($dataNascita)
    {
        $this->dataNascita = StringUtility::preparaPerFlussi($dataNascita, 8);
    }

    public function getProtocolloDelegaF24()
    {
        return $this->protocolloDelegaF24;
    }

    public function setProtocolloDelegaF24($protocolloDelegaF24)
    {
        $this->protocolloDelegaF24 = StringUtility::preparaPerFlussiCon0($protocolloDelegaF24, 7);
    }

}