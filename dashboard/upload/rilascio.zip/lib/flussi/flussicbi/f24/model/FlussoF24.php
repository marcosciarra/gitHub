<?php
	namespace Click\Flussi\Cbi\F24;
	
	/**
	 * Description of Flusso F24
	 *
	 * @author COLOMBO Claudio
	 */
	class FlussoF24
	{
		
		/**
		 */
		private $recordTesta;
		/** array di dettagli */
		private $dettagli;
		/**
		 *
		 */
		private $recordCoda;
		/** path pienamente qualificato del file da scrivere */
		private $nomeFile = "";
		
		//--------------------------
		// Metodi
		//--------------------------
		
		function __construct()
		{
			$this->recordTesta = null;
			$this->dettagli = array();
			$this->recordCoda = null;
			$this->nomeFile = "";
		}
		
		/**
		 * inizializza blocco dettagli
		 *
		 * @return array
		 */
		static function nuovoBloccoDettaglio()
		{
			$arr = array();
			for ($i = 0; $i < 21; $i++) {
				$arr[] = "";
			}
			return $arr;
		}
		
		/**
		 *
		 * @param RecordF4F24 $recordTesta
		 * @param string $path path dove salvare il flusso
		 */
		function crea($recordTesta,
					  $path)
		{
			$this->recordTesta = GeneraRecordFlussiF24::generaRecordF4($recordTesta);
			$this->dettagli = array();
			$this->nomeFile = $path;
		}
		
		/**
		 *
		 * @param RecordF4F24 $recordTesta
		 * @param RecordEF $recordCoda
		 * @param string $path path dove salvare il flusso
		 */
		function creaFlussoConCoda($recordTesta,
								   $recordCoda,
								   $path)
		{
			$this->recordTesta = GeneraRecordFlussiF24::generaRecordF4($recordTesta);
			$this->dettagli = array();
			$this->recordCoda = GeneraRecordFlussiF24::generaRecordEF($recordCoda);
			$this->nomeFile = $path;
		}
		
		/**
		 *
		 * @param RecordEF $record
		 */
		function settaRecordCoda($record)
		{
			$this->recordCoda = GeneraRecordFlussiF24::generaRecordEF($record);
		}
		
		function addDettaglio($r10, $r20, $r40_1A, $r40_1B, $r40_1C,
							  $r40_02, $r50_01, $r50_02, $r50_03)
		{
			$app = array();
			$app[0] = GeneraRecordFlussiF24::generaRecord10($r10);
			$app[1] = GeneraRecordFlussiF24::generaRecord20($r20);
			$app[2] = GeneraRecordFlussiF24::generaRecord40_01($r40_1A);
			$app[3] = GeneraRecordFlussiF24::generaRecord40_01($r40_1B);
			$app[4] = GeneraRecordFlussiF24::generaRecord40_01($r40_1C);
			$app[5] = GeneraRecordFlussiF24::generaRecord40_02($r40_02);
			$app[20] = GeneraRecordFlussiF24::generaRecord50_01($r50_01);
			$app[21] = GeneraRecordFlussiF24::generaRecord50_02($r50_02);
			$app[22] = GeneraRecordFlussiF24::generaRecord50_03($r50_03);
			$this->dettagli[] = $app;
		}
		
		/**
		 *
		 * @param Record10 $record
		 */
		function addRecord10($record)
		{
			$app = $this->dettagli[0];
			$app[] = GeneraRecordFlussiF24::generaRecord10($record);
			$this->dettagli[0] = $app;
		}
		
		/**
		 *
		 * @param Record20 $record
		 */
		function addRecord20($record)
		{
			$app = $this->dettagli[1];
			$app[] = GeneraRecordFlussiF24::generaRecord20($record);
			$this->dettagli[1] = $app;
		}
		
		/**
		 *
		 * @param Record40F24_01 $record
		 */
		function addRecord40_01($record, $progressivo)
		{
			$progressivo++;
			$app = $this->dettagli[$progressivo];
			$app[] = GeneraRecordFlussiF24::generaRecord40_01($record);
			$this->dettagli[$progressivo] = $app;
		}
		
		/**
		 *
		 * @param Record40F24_02 $record
		 */
		function addRecord40_02($record)
		{
			$app = $this->dettagli[5];
			$app[] = GeneraRecordFlussiF24::generaRecord40_02($record);
			$this->dettagli[5] = $app;
		}
		
		/**
		 *
		 * @param Record40F24_03 $record
		 */
		function addRecord40_03($record)
		{
			$app = $this->dettagli[6];
			$app[] = GeneraRecordFlussiF24::generaRecord40_03($record);
			$this->dettagli[6] = $app;
		}
		
		/**
		 *
		 * @param Record50F24_01 $record
		 */
		function addRecord50_01($record)
		{
			$app = $this->dettagli[20];
			$app[] = GeneraRecordFlussiF24::generaRecord50_01($record);
			$this->dettagli[20] = $app;
		}
		
		/**
		 *
		 * @param Record50F24_02 $record
		 */
		function addRecord50_02($record)
		{
			$app = $this->dettagli[21];
			$app[] = GeneraRecordFlussiF24::generaRecord50_02($record);
			$this->dettagli[21] = $app;
		}
		
		/**
		 *
		 * @param Record50_03 $record
		 */
		function addRecord50_03($record)
		{
			$app = $this->dettagli[22];
			$app[] = GeneraRecordFlussiF24::generaRecord50_03($record);
			$this->dettagli[22] = $app;
		}
		
		/**
		 *
		 * @param Record40F24_02 $record
		 */
		function setRecord40_02($record)
		{
			$this->dettagli[5] = GeneraRecordFlussiF24::generaRecord40_02($record);
		}
		
		function setRecor50_01($record)
		{
			$this->dettagli[20] = GeneraRecordFlussiF24::generaRecord50_01($record);
		}
		
		function setRecor50_02($record)
		{
			$this->dettagli[21] = GeneraRecordFlussiF24::generaRecord50_02($record);
		}
		
		function setRecor50_03($record)
		{
			$this->dettagli[22] = GeneraRecordFlussiF24::generaRecord50_03($record);
		}
		
		//--------------------------
		// Getter & Setter
		//--------------------------
		
		public function getRecordTesta()
		{
			return $this->recordTesta;
		}
		
		public function setRecordTesta($recordTesta)
		{
			$this->recordTesta = $recordTesta;
		}
		
		public function getDettagli()
		{
			return $this->dettagli;
		}
		
		public function setDettagli($dettagli)
		{
			$this->dettagli = $dettagli;
		}
		
		public function getRecordCoda()
		{
			return $this->recordCoda;
		}
		
		public function setRecordCoda($recordCoda)
		{
			$this->recordCoda = $recordCoda;
		}
		
		public function getNomeFile()
		{
			return $this->nomeFile;
		}
		
		public function setNomeFile($nomeFile)
		{
			$this->nomeFile = $nomeFile;
		}
		
	}

?>
