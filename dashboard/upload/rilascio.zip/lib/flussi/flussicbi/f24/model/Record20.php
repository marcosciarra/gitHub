<?php
	
	namespace Click\Flussi\Cbi\F24;
	
	use Click\Flussi\Utility\StringUtility;


	/**
	 * Description of Record20 F24 su speficifiche CBI F24 6.12
	 *
	 * @author  COLOMBO Claudio
	 * @version 1.0
	 *
	 */
	class Record20
	{
		
		/** tipo record fisso */
		private $tipoRecord = "20";
		/** */
		private $progressivoDelegaF24 = "";
		/** */
		private $comune = "";
		/** */
		private $provincia = "";
		/** */
		private $indirizzo = "";
		/** */
		private $dataPagamento = "";
		/** */
		private $flagAnnoImposta = "";
		/** */
		private $secondoCodiceFiscale = "";
		/** */
		private $codiceIdentificativo = "";
		
		//-------------------------
		// METODI
		//-------------------------
		
		/**
		 *
		 */
		function __constructor()
		{
			$this->tipoRecord = "20";
			$this->crea('', '', '', '', '', '', '', '', '');
		}
		
		/**
		 * @param string $progressivoDelegaF24
		 * @param string $comune
		 * @param string $provincia
		 * @param string $indirizzo
		 * @param string $dataPagamento
		 * @param string $flagAnnoImposta
		 * @param string $secondoCodiceFiscale
		 * @param string $codiceIdentificativo
		 */
		public function crea($progressivoDelegaF24,
							 $comune,
							 $provincia,
							 $indirizzo,
							 $dataPagamento,
							 $flagAnnoImposta,
							 $secondoCodiceFiscale='',
							 $codiceIdentificativo=''
		)
		{
			$this->setProgressivoDelegaF24($progressivoDelegaF24);
			$this->setComune($comune);
			$this->setProvincia($provincia);
			$this->setIndirizzo($indirizzo);
			$this->setDataPagamento($dataPagamento);
			$this->setFlagAnnoImposta($flagAnnoImposta);
			$this->setSecondoCodiceFiscale($secondoCodiceFiscale);
			$this->setCodiceIdentificativo($codiceIdentificativo);
		}
		
		//-------------------------
		// GETTER & SETTER
		//-------------------------
		
		public function getTipoRecord()
		{
			return $this->tipoRecord;
		}
		
		public function setTipoRecord($tipoRecord)
		{
			$this->tipoRecord = $tipoRecord;
		}
		
		public function getProgressivoDelegaF24()
		{
			return $this->progressivoDelegaF24;
		}
		
		public function setProgressivoDelegaF24($progressivoDelegaF24)
		{
			$this->progressivoDelegaF24 = StringUtility::preparaPerFlussiCon0($progressivoDelegaF24, 7);
		}
		
		public function getComune()
		{
			return $this->comune;
		}
		
		public function setComune($comune)
		{
			$this->comune = StringUtility::preparaPerFlussi($comune, 25);
		}
		
		public function getProvincia()
		{
			return $this->provincia;
		}
		
		public function setProvincia($provincia)
		{
			$this->provincia = StringUtility::preparaPerFlussi($provincia, 2);
		}
		
		public function getIndirizzo()
		{
			return $this->indirizzo;
		}
		
		public function setIndirizzo($indirizzo)
		{
			$this->indirizzo = StringUtility::preparaPerFlussi($indirizzo, 35);
		}
		
		public function getDataPagamento()
		{
			return $this->dataPagamento;
		}
		
		public function setDataPagamento($dataPagamento)
		{
            $dataPagamento=str_replace('-','',$dataPagamento);
			$this->dataPagamento = StringUtility::preparaPerFlussiCon0($dataPagamento, 8);
		}
		
		public function getFlagAnnoImposta()
		{
			return $this->flagAnnoImposta;
		}
		
		public function setFlagAnnoImposta($flagAnnoImposta)
		{
			$this->flagAnnoImposta = StringUtility::ckFlag0($flagAnnoImposta, 1);
		}
		
		public function getSecondoCodiceFiscale()
		{
			return $this->secondoCodiceFiscale;
		}
		
		public function setSecondoCodiceFiscale($secondoCodiceFiscale)
		{
			$this->secondoCodiceFiscale = StringUtility::preparaPerFlussi($secondoCodiceFiscale, 16);
		}
		
		public function getCodiceIdentificativo()
		{
			return $this->codiceIdentificativo;
		}
		
		public function setCodiceIdentificativo($codiceIdentificativo)
		{
			$this->codiceIdentificativo = StringUtility::preparaPerFlussi($codiceIdentificativo, 2);
		}
		
	}