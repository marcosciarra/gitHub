<?php
	
	namespace Click\Flussi\Cbi\F24;
	
	use Click\Flussi\Utility\StringUtility;


	/**
	 * Description of Record50_01 F24 su speficifiche CBI F24 6.16
	 *
	 * @author  COLOMBO Claudio
	 * @version 1.0
	 *
	 */
	class Record50_01
	{
		
		/** tipo record fisso */
		private $tipoRecord = "50";
		/** */
		private $progressivoDelegaF24 = "";
		/** */
		private $subtipoRecord = "01";
		/** */
		private $bancaPassiva = "";
		/** */
		private $sportelloBancaPassiva = "";
		/** */
		private $contoAddebito = "";
		/** */
		private $cin = "";
		/** */
		private $saldoFinaleDelegaF24 = "";
		/** */
		private $flagFirmatario = "";
		/** */
		private $codiceFiscale = "";
		/** */
		private $titolarePagamento = "";
		/** */
		private $dataPagamento = "";
		/** */
		private $totImportiCreditoCompensati = "";
		/** */
		private $tipoCodiceIndividuale = "";
		/** */
		private $codicePaese = "";
		/** */
		private $checkDigit = "";
		
		//-------------------------
		// METODI
		//-------------------------
		
		/**
		 * Record50_01 constructor.
		 */
		function __construct()
		{
			$this->tipoRecord = "50";
			$this->subtipoRecord = "01";
			$this->tipoCodiceIndividuale= 3;
			$this->crea('', '', '', '', '', '', '', '', '',  '', '', '', '');
		}
		
		/**
		 * @param $progressivoDelegaF24
		 * @param $bancaPassiva
		 * @param $sportelloBancaPassiva
		 * @param $contoAddebito
		 * @param $cin
		 * @param $saldoFinaleDelegaF24
		 * @param $flagFirmatario
		 * @param $codiceFiscale
		 * @param $titolarePagamento
		 * @param $dataPagamento
		 * @param $totImportiCreditoCompensati
		 * @param $codicePaese
		 * @param $checkDigit
		 */
		function crea($progressivoDelegaF24,
					  $bancaPassiva,
					  $sportelloBancaPassiva,
					  $contoAddebito,
					  $cin,
					  $saldoFinaleDelegaF24,
					  $flagFirmatario,
					  $codiceFiscale,
					  $titolarePagamento,
					  $dataPagamento,
					  $totImportiCreditoCompensati,
					  $codicePaese,
					  $checkDigit)
		{
			$this->setProgressivoDelegaF24($progressivoDelegaF24);
			$this->setBancaPassiva($bancaPassiva);
			$this->setSportelloBancaPassiva($sportelloBancaPassiva);
			$this->setContoAddebito($contoAddebito);
			$this->setCin($cin);
			$this->setSaldoFinaleDelegaF24($saldoFinaleDelegaF24);
			$this->setFlagFirmatario($flagFirmatario);
			$this->setTitolarePagamento($titolarePagamento);
			$this->setCodiceFiscale($codiceFiscale);
			$this->setDataPagamento($dataPagamento);
			$this->setTotImportiCreditoCompensati($totImportiCreditoCompensati);
			$this->setCodicePaese($codicePaese);
			$this->setCheckDigit($checkDigit);
		}
		
		//-------------------------
		// GETTER & SETTER
		//-------------------------
		
		/**
		 * @return string
		 */
		public function getTipoRecord()
		{
			return $this->tipoRecord;
		}
		
		/**
		 * @return string
		 */
		public function getProgressivoDelegaF24()
		{
			return $this->progressivoDelegaF24;
		}
		
		/**
		 * @param $progressivoDelegaF24
		 */
		public function setProgressivoDelegaF24($progressivoDelegaF24)
		{
			$this->progressivoDelegaF24 = StringUtility::preparaPerFlussiCon0($progressivoDelegaF24, 7);
		}
		
		/**
		 * @return string
		 */
		public function getSubtipoRecord()
		{
			return $this->subtipoRecord;
		}
		
		/**
		 * @return string
		 */
		public function getBancaPassiva()
		{
			return $this->bancaPassiva;
		}

		/**
		 * @param $bancaPassiva
		 */
		public function setBancaPassiva($bancaPassiva)
		{
			$this->bancaPassiva = StringUtility::preparaPerFlussiCon0($bancaPassiva, 5);
		}
		
		/**
		 * @return string
		 */
		public function getSportelloBancaPassiva()
		{
			return $this->sportelloBancaPassiva;
		}
		
		/**
		 * @param $sportelloBancaPassiva
		 */
		public function setSportelloBancaPassiva($sportelloBancaPassiva)
		{
			$this->sportelloBancaPassiva = StringUtility::preparaPerFlussiCon0($sportelloBancaPassiva, 5);
		}
		
		/**
		 * @return string
		 */
		public function getContoAddebito()
		{
			return $this->contoAddebito;
		}
		
		/**
		 * @param $contoAddebito
		 */
		public function setContoAddebito($contoAddebito)
		{
			$this->contoAddebito = StringUtility::preparaPerFlussiCon0($contoAddebito, 12);
		}
		
		/**
		 * @return string
		 */
		public function getCin()
		{
			return $this->cin;
		}
		
		/**
		 * @param $cin
		 */
		public function setCin($cin)
		{
			$this->cin = StringUtility::preparaPerFlussi($cin, 1);
		}
		
		/**
		 * @return string
		 */
		public function getSaldoFinaleDelegaF24()
		{
			return $this->saldoFinaleDelegaF24;
		}
		
		/**
		 * @param $saldoFinaleDelegaF24
		 */
		public function setSaldoFinaleDelegaF24($saldoFinaleDelegaF24)
		{
			$this->saldoFinaleDelegaF24 = StringUtility::doubleToStringFlussi($saldoFinaleDelegaF24, 15);
		}
		
		/**
		 * @return string
		 */
		public function getCodiceFiscale()
		{
			return $this->codiceFiscale;
		}
		
		/**
		 * @param $codiceFiscale
		 */
		public function setCodiceFiscale($codiceFiscale)
		{
			$this->codiceFiscale = StringUtility::preparaPerFlussi($codiceFiscale, 16);
		}
		
		/**
		 * @return string
		 */
		public function getTitolarePagamento()
		{
			return $this->titolarePagamento;
		}
		
		/**
		 * @param $titolarePagamento
		 */
		public function setTitolarePagamento($titolarePagamento)
		{
			$this->titolarePagamento = StringUtility::preparaPerFlussi($titolarePagamento, 1);
		}
		
		/**
		 * @return string
		 */
		public function getDataPagamento()
		{
			return $this->dataPagamento;
		}
		
		/**
		 * @param $dataPagamento
		 */
		public function setDataPagamento($dataPagamento)
		{
            $dataPagamento=str_replace('-','',$dataPagamento);
			$this->dataPagamento = StringUtility::preparaPerFlussiCon0($dataPagamento, 8);
		}
		
		/**
		 * @return string
		 */
		public function getTotImportiCreditoCompensati()
		{
			return $this->totImportiCreditoCompensati;
		}
		
		/**
		 * @param $totImportiCreditoCompensati
		 */
		public function setTotImportiCreditoCompensati($totImportiCreditoCompensati)
		{
			$this->totImportiCreditoCompensati = StringUtility::doubleToStringFlussi($totImportiCreditoCompensati, 15);
		}
		
		/**
		 * @return string
		 */
		public function getTipoCodiceIndividuale()
		{
			return $this->tipoCodiceIndividuale;
		}
		
		/**
		 * @return string
		 */
		public function getCodicePaese()
		{
			return $this->codicePaese;
		}
		
		/**
		 * @param $codicePaese
		 */
		public function setCodicePaese($codicePaese)
		{
			$this->codicePaese = StringUtility::preparaPerFlussi($codicePaese, 2);
		}
		
		/**
		 * @return string
		 */
		public function getCheckDigit()
		{
			return $this->checkDigit;
		}
		
		/**
		 * @param $checkDigit
		 */
		public function setCheckDigit($checkDigit)
		{
			$this->checkDigit = StringUtility::preparaPerFlussi($checkDigit, 2);
		}
		
		/**
		 * @return string
		 */
		public function getFlagFirmatario()
		{
			return $this->flagFirmatario;
		}
		
		/**
		 * @param $flagFirmatario
		 */
		public function setFlagFirmatario($flagFirmatario)
		{
			$this->flagFirmatario = StringUtility::ckFlag0($flagFirmatario);
		}
		
	}