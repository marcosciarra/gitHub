<?php

require_once '../../flussi/utility/StringUtility.php';
    /**
     * Description of Record40-01 F24 su speficifiche CBI F24 6.12
     *
     * @author  COLOMBO Claudio
     * @version 1.0
     *
     */
    class Record40F24_01
    {

        /** tipo record fisso */
        private $tipoRecord = "40";
        /** */
        private $progressivoDelegaF24 = "";
        /** */
        private $subtipoRecord = "01";
        /** */
        private $progressivoTributo = "";
        /** */
        private $codiceTributo = "";
        /** */
        private $riferimentiTributo = "";
        /** */
        private $importoADebitoVersato = "";
        /** */
        private $importoACreditoCompensato = "";
        /** */
        private $codiceUfficio = "";
        /** */
        private $codiceAtto = "";

        //-------------------------
        // METODI
        //-------------------------

        /**
         *
         */
        function __construct()
        {
            $this->tipoRecord = "40";
            $this->subtipoRecord = "01";
            $this->progressivoDelegaF24 = StringUtility::preparaPerFlussiCon0(0,
                                                                              7);

            $this->progressivoTributo = StringUtility::preparaPerFlussiCon0(0,
                                                                            2);

            $this->codiceTributo = StringUtility::preparaPerFlussi("",
                                                                   4);
            $this->riferimentiTributo = StringUtility::preparaPerFlussi("",
                                                                        8);
            $this->importoADebitoVersato = StringUtility::doubleToStringFlussi(0,
                                                                               15);
            $this->importoACreditoCompensato = StringUtility::doubleToStringFlussi(0,
                                                                                   15);
            $this->codiceUfficio = StringUtility::preparaPerFlussi("",
                                                                   2);
            $this->codiceAtto = StringUtility::preparaPerFlussi("",
                                                                11);
        }

        /**
         *
         * @param int $progressivoDelegaF24
         * @param int $progressivoTributo
         * @param string $codiceTributo
         * @param string $riferimentiTributo
         * @param float $importoADebitoVersato
         * @param float $importoACreditoCompensato
         * @param string $codiceUfficio
         * @param string $codiceAtto
         */
        function crea($progressivoDelegaF24,
                      $progressivoTributo,
                      $codiceTributo,
                      $riferimentiTributo,
                      $importoADebitoVersato,
                      $importoACreditoCompensato,
                      $codiceUfficio,
                      $codiceAtto)
        {
            $this->progressivoDelegaF24 = StringUtility::preparaPerFlussiCon0($progressivoDelegaF24,
                                                                              7);

            $this->progressivoTributo = StringUtility::preparaPerFlussiCon0($progressivoTributo,
                                                                            2);

            $this->codiceTributo = StringUtility::preparaPerFlussi($codiceTributo,
                                                                   4);
            $this->riferimentiTributo = StringUtility::preparaPerFlussi($riferimentiTributo,
                                                                        8);
            $this->importoADebitoVersato = StringUtility::doubleToStringFlussi($importoADebitoVersato,
                                                                               15);
            $this->importoACreditoCompensato = StringUtility::doubleToStringFlussi($importoACreditoCompensato,
                                                                                   15);
            $this->codiceUfficio = StringUtility::preparaPerFlussi($codiceUfficio,
                                                                   2);
            $this->codiceAtto = StringUtility::preparaPerFlussi($codiceAtto,
                                                                11);
        }

        //-------------------------
        // GETTER & SETTER
        //-------------------------

        public function getTipoRecord()
        {
            return $this->tipoRecord;
        }

        public function setTipoRecord($tipoRecord)
        {
            $this->tipoRecord = $tipoRecord;
        }

        public function getProgressivoDelegaF24()
        {
            return $this->progressivoDelegaF24;
        }

        public function setProgressivoDelegaF24($progressivoDelegaF24)
        {
            $this->progressivoDelegaF24 = $progressivoDelegaF24;
        }

        public function getSubtipoRecord()
        {
            return $this->subtipoRecord;
        }

        public function setSubtipoRecord($subtipoRecord)
        {
            $this->subtipoRecord = $subtipoRecord;
        }

        public function getProgressivoTributo()
        {
            return $this->progressivoTributo;
        }

        public function setProgressivoTributo($progressivoTributo)
        {
            $this->progressivoTributo = $progressivoTributo;
        }

        public function getCodiceTributo()
        {
            return $this->codiceTributo;
        }

        public function setCodiceTributo($codiceTributo)
        {
            $this->codiceTributo = $codiceTributo;
        }

        public function getRiferimentiTributo()
        {
            return $this->riferimentiTributo;
        }

        public function setRiferimentiTributo($riferimentiTributo)
        {
            $this->riferimentiTributo = $riferimentiTributo;
        }

        public function getImportoADebitoVersato()
        {
            return $this->importoADebitoVersato;
        }

        public function setImportoADebitoVersato($importoADebitoVersato)
        {
            $this->importoADebitoVersato = $importoADebitoVersato;
        }

        public function getImportoACreditoCompensato()
        {
            return $this->importoACreditoCompensato;
        }

        public function setImportoACreditoCompensato($importoACreditoCompensato)
        {
            $this->importoACreditoCompensato = $importoACreditoCompensato;
        }

        public function getCodiceUfficio()
        {
            return $this->codiceUfficio;
        }

        public function setCodiceUfficio($codiceUfficio)
        {
            $this->codiceUfficio = $codiceUfficio;
        }

        public function getCodiceAtto()
        {
            return $this->codiceAtto;
        }

        public function setCodiceAtto($codiceAtto)
        {
            $this->codiceAtto = $codiceAtto;
        }

    }

?>
