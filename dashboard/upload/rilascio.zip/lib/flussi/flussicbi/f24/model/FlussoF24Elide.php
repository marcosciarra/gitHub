<?php
namespace Click\Flussi\Cbi\F24;

/**
 * Description of Flusso F24 Elide
 *
 * @author COLOMBO Claudio
 */
/**
 * Class FlussoF24
 *
 * @package Click\Flussi\Cbi\F24
 */
class FlussoF24Elide
{

    /**@var RecordF4 */
    private $recordTesta;
    /**@var array stack di dettagli */
    private $dettagli;
    /**@var RecordEF */
    private $recordCoda;
    /** path pienamente qualificato del file da scrivere */
    private $nomeFile = "";

    //--------------------------
    // Metodi
    //--------------------------

    /**
     * FlussoF24 constructor.
     */
    function __construct()
    {
        $this->recordTesta = null;
        $this->dettagli = array();
        $this->recordCoda = null;
        $this->nomeFile = "";
    }

    /**
     * inizializza blocco dettagli
     *
     * @return array
     */
    static function nuovoBloccoDettaglio()
    {
        $arr = array();
        for ($i = 0; $i < 21; $i++) {
            $arr[] = "";
        }
        return $arr;
    }

    /**
     *
     * @param RecordF4 $recordTesta
     * @param string $path path dove salvare il flusso
     */
    function crea($recordTesta, $path)
    {
        $this->recordTesta = GeneraRecordFlussiF24::generaRecordF4($recordTesta);
        $this->dettagli = array();
        $this->nomeFile = $path;
    }

    /**
     *
     * @param RecordF4 $recordTesta
     * @param RecordEF $recordCoda
     * @param string $path path dove salvare il flusso
     */
    function creaFlussoConCoda($recordTesta, $recordCoda, $path)
    {
        $this->recordTesta = GeneraRecordFlussiF24::generaRecordF4($recordTesta);
        $this->recordCoda = GeneraRecordFlussiF24::generaRecordEF($recordCoda);
        $this->nomeFile = $path;
    }

    /**
     *
     * @param RecordEF $record
     */
    function settaRecordCoda($record)
    {
        $this->recordCoda = GeneraRecordFlussiF24::generaRecordEF($record);
    }


    /**
     * @param Record10 $r10
     * @param Record20 $r20
     * @param Record40_17[] $r40_17
     * @param Record40_18 $r40_18
     * @param Record50_01 $r50_01
     * @param Record50_02 $r50_02
     * @param Record50_03 $r50_03
     */
    function addDettaglio($r10, $r20, $r40_17, $r40_18, $r50_01, $r50_02, $r50_03 = null)
    {
        $app = array();
        $app[0] = GeneraRecordFlussiF24::generaRecord10($r10);
        $app[1] = GeneraRecordFlussiF24::generaRecord20($r20);
        foreach ($r40_17 as $r) {
            $app[] = GeneraRecordFlussiF24::generaRecord40_17($r);
        }
        $app[19] = GeneraRecordFlussiF24::generaRecord40_18($r40_18);

        $app[20] = GeneraRecordFlussiF24::generaRecord50_01($r50_01);
        $app[21] = GeneraRecordFlussiF24::generaRecord50_02($r50_02);
        if (!is_null($r50_03))
            $app[22] = GeneraRecordFlussiF24::generaRecord50_03($r50_03);

        $this->dettagli[] = $app;
    }

    //--------------------------
    // Getter & Setter
    //--------------------------

    /**
     * @return RecordF4|null
     */
    public function getRecordTesta()
    {
        return $this->recordTesta;
    }

    /**
     * @param $recordTesta
     */
    public function setRecordTesta($recordTesta)
    {
        $this->recordTesta = $recordTesta;
    }

    /**
     * @return array
     */
    public function getDettagli()
    {
        return $this->dettagli;
    }

    /**
     * @param $dettagli
     */
    public function setDettagli($dettagli)
    {
        $this->dettagli = $dettagli;
    }

    /**
     * @return RecordEF|null
     */
    public function getRecordCoda()
    {
        return $this->recordCoda;
    }

    /**
     * @param $recordCoda
     */
    public function setRecordCoda($recordCoda)
    {
        $this->recordCoda = $recordCoda;
    }

    /**
     * @return string
     */
    public function getNomeFile()
    {
        return $this->nomeFile;
    }

    /**
     * @param $nomeFile
     */
    public function setNomeFile($nomeFile)
    {
        $this->nomeFile = $nomeFile;
    }

}

