<?php
require_once '../../flussi/utility/StringUtility.php';
    /**
     * Description of Record40-09 F24 su speficifiche CBI F24 6.12
     *
     * @author  COLOMBO Claudio
     * @version 1.0
     *
     */
    class Record40F24_09
    {

        /** tipo record fisso */
        private $tipoRecord = "40";
        /** */
        private $progressivoDelegaF24 = "";
        /** */
        private $subtipoRecord = "09";

        //-------------------------
        // METODI
        //-------------------------


        //-------------------------
        // GETTER & SETTER
        //-------------------------
    }

?>
