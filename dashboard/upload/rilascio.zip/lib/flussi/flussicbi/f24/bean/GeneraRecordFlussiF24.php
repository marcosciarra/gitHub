<?php
	
	namespace Click\Flussi\Cbi\F24;
	
	use Click\Flussi\Utility\StringUtility;
	use Click\Flussi\Utility\GestioneFlussi;

	/**
	 * Funzioni per la generazione dei flussi su speficifiche CBI F24 6.16
	 *
	 * @author  COLOMBO Claudio
	 * @version 1.0
	 */
	class GeneraRecordFlussiF24
	{
		
		/**
		 *
		 * funzione per la generazione formale del record F4
		 *
		 * @param RecordF4 $record Description
		 *
		 * @return string record F4
		 */
		public static function generaRecordF4($record)
		{
			
			if (isset($record)) {
				$r = " ";
				$r .= $record->getTipoRecord();
				$r .= $record->getMittente();
				$r .= $record->getRicevente();
				$r .= $record->getDataCreazione();
				$r .= $record->getNomeSupporto();
				$r .= $record->getRiferimentiMittente();
				
				//filler di 59 caratteri (46-104)
				$r .= StringUtility::creaFiller(59);
				
				
				$r .= $record->getTipoFlusso();
				$r .= $record->getQualificatoreFlusso();
				$r .= $record->getSoggettoVeicolatore();
//filler 2 caratteri (112-113)
				$r .= "  ";
				$r .= $record->getCodiceDivisa();
//filler 115
				$r .= " ";
//campo non utilizzabile di 5 caratteri (116-120)
				$r .= StringUtility::creaFiller(5);
				
				
				GestioneFlussi::ckRecord("RecordPC",
										 $r,
										 false
				);
			}
			else {
				return "";
			}
			return $r;
		}
		
		/**
		 *
		 * funzione per la generazione formale del record EF
		 *
		 * @param RecordEF $record
		 *
		 * @return string record EF
		 */
		public static function generaRecordEF($record)
		{
			if (isset($record)) {
				$r = " ";
				$r .= $record->getTipoRecord();
				$r .= $record->getMittente();
				$r .= $record->getRicevente();
				$r .= $record->getDataCreazione();
				$r .= $record->getNomeSupporto();
				$r .= $record->getRiferimentiMittente();
				$r .= $record->getNumeroDisposizioni();
				$r .= $record->getImportiPositivi();
				$r .= $record->getImportiNegativi();
				$r .= $record->getNumeroRecord();
//filler di 24 caratteri (90-113)
				$r .= StringUtility::creaFiller(24);
				
				$r .= $record->getCodiceDivisa();
//campo non utilizzabile di 5 caratteri (115-120)
				$r .= StringUtility::creaFiller(6);
				
				GestioneFlussi::ckRecord("RecordEF",
										 $r,
										 false
				);
				return $r;
			}
			else {
				return "";
			}
		}
		
		/**
		 *
		 * funzione per la generazione formale del record 10
		 *
		 * @param Record10 $record
		 *
		 * @return string record 10
		 */
		public static function generaRecord10($record)
		{
			
			if (isset($record)) {
				$r = " ";
				$r .= $record->getTipoRecord();
				$r .= $record->getProgressivoDelegaF24();
				$r .= $record->getCodiceFiscale();

//genero record x ditta o PF
				if(trim($record->getCognome())!='') {
                    $r .= $record->getCognome();
                    $r .= $record->getNome();
                }
				else {
					$r .= $record->getRagioneSociale();
				}

					$r .= $record->getSesso();
					$r .= $record->getComuneNascita();
					$r .= $record->getProvinciaNascita();
					$r .= $record->getDataNascita();

				$r .= $record->getProtocolloDelegaF24();
				
				//campo non utilizzabile di 7 caratteri (117-120)
				$r .= StringUtility::creaFiller(7);
				
				
				return $r;
			}
			else {
				return "";
			}
		}
		
		/**
		 *
		 * funzione per la generazione formale del record 20
		 *
		 * @param Record20 $record
		 *
		 * @return string record 10
		 */
		public static function generaRecord20($record)
		{
			
			if (isset($record)) {
				$r = " ";
				$r .= $record->getTipoRecord();
				$r .= $record->getProgressivoDelegaF24();
				$r .= $record->getComune();
				$r .= $record->getProvincia();
				$r .= $record->getIndirizzo();
				$r .= $record->getDataPagamento();
				$r .= $record->getFlagAnnoImposta();
				$r .= $record->getSecondoCodiceFiscale();
				$r .= $record->getCodiceIdentificativo();
				
				
				//campo non utilizzabile di 20 caratteri (100-120)
				$r .= StringUtility::creaFiller(21);
				
				
				return $r;
			}
			else {
				return "";
			}
		}
		
		/**
		 *
		 * funzione per la generazione formale del record 40-01
		 *
		 * @param Record40_01 $record
		 *
		 * @return string record 10
		 */
		public static function generaRecord40_01($record)
		{
			
			if (isset($record)) {
				$r = " ";
				$r .= $record->getTipoRecord();
				$r .= $record->getProgressivoDelegaF24();
				$r .= $record->getSubtipoRecord();
				$r .= $record->getProgressivoTributo();
				$r .= $record->getCodiceTributo();
				$r .= $record->getRiferimentiTributo();
				$r .= $record->getImportoADebitoVersato();
				$r .= $record->getImportoACreditoCompensato();
				$r .= $record->getCodiceUfficio();
				$r .= $record->getCodiceAtto();
				
				//campo non utilizzabile di 50 caratteri (71-120)
				$r .= StringUtility::creaFiller(50);
				
				
				return $r;
			}
			else {
				return "";
			}
		}
		
		/**
		 *
		 * funzione per la generazione formale del record 40-02
		 *
		 * @param Record40_02 $record
		 *
		 * @return string record 10
		 */
		public static function generaRecord40_02($record)
		{
			
			if (isset($record)) {
				$r = " ";
				$r .= $record->getTipoRecord();
				$r .= $record->getProgressivoDelegaF24();
				$r .= $record->getSubtipoRecord();
				$r .= $record->getTotaleImportoADebitoVersato();
				$r .= $record->getTotaleImportoACreditoCompensato();
				$r .= $record->getSegnoSezione();
				$r .= $record->getSaldoSezione();
				
				//campo non utilizzabile di 62 caratteri (59-120)
				$r .= StringUtility::creaFiller(62);
				
				
				return $r;
			}
			else {
				return "";
			}
		}
		
		/**
		 *
		 * funzione per la generazione formale del record 40-03
		 *
		 * @param Record40_03 $record
		 *
		 * @return string record 10
		 */
		public static function generaRecord40_03($record)
		{
			
			if (isset($record)) {
				$r = " ";
				$r .= $record->getTipoRecord();
				$r .= $record->getProgressivoDelegaF24();
				$r .= $record->getSubtipoRecord();
				$r .= $record->getProgressivoContributo();
				$r .= $record->getCodiceSede();
				$r .= $record->getCausaleContributo();
				$r .= $record->getInps();
				$r .= $record->getPeriodoDiRiferimentoInizio();
				$r .= $record->getPeriodoDiRiferimentoFine();
				$r .= $record->getImportoADebitoVersato();
				$r .= $record->getImportoACreditoCompensato();
				//campo non utilizzabile di 39 caratteri (82-120)
				$r .= StringUtility::creaFiller(39);
				
				
				return $r;
			}
			else {
				return "";
			}
		}
		
		
		/**
		 *
		 * funzione per la generazione formale del record 40-17
		 *
		 * @param Record40_17 $record
		 *
		 * @return string
		 */
		public static function generaRecord40_17($record)
		{
			
			if (isset($record)) {
				$r = StringUtility::creaFiller(1);
				$r .= $record->getTipoRecord();
				$r .= $record->getProgressivoDelegaF24();
				$r .= $record->getSubtipoRecord();
				$r .= $record->getProgressivoTributo();
                $r .= $record->getTipo();
				$r .= $record->getElementiIdentificativi();
				$r .= $record->getCodice();
				$r .= $record->getAnnoRiferimento();
				$r .= $record->getImportoDebitoVersato();
				$r .= $record->getImportoCreditoCompensato();
				$r .= $record->getCodiceUfficio();
				$r .= $record->getCodiceAtto();
				$r .= StringUtility::creaFiller(36);
				return $r;
			}
			else {
				return "";
			}
		}
		
		/**
		 *
		 * funzione per la generazione formale del record 40-18
		 *
		 * @param Record40_18 $record
		 *
		 * @return string
		 */
		public static function generaRecord40_18($record)
		{
			
			if (isset($record)) {
				$r = StringUtility::creaFiller(1);
				$r .= $record->getTipoRecord();
				$r .= $record->getProgressivoDelegaF24();
				$r .= $record->getSubtipoRecord();
				$r .= StringUtility::creaFiller(30);
				$r .= $record->getSegnoSaldo();
				$r .= $record->getSaldoSezione();
				$r .= StringUtility::creaFiller(62);
				return $r;
			}
			else {
				return "";
			}
		}
		
		/**
		 *
		 * funzione per la generazione formale del record 50_01
		 *
		 * @param Record50F24_01 $record
		 *
		 * @return string record 50_01
		 */
		public static function generaRecord50_01($record)
		{
			
			if (isset($record)) {
				$r = " ";
				$r .= $record->getTipoRecord();
				$r .= $record->getProgressivoDelegaF24();
				$r .= $record->getSubtipoRecord();
				$r .= $record->getBancaPassiva();
				$r .= $record->getSportelloBancaPassiva();
				$r .= $record->getContoAddebito();
				$r .= $record->getCin();
				$r .= $record->getSaldoFinaleDelegaF24();
				$r .= $record->getFlagFirmatario();
				//filler 2 caratteri (52-53)
				$r .= StringUtility::creaFiller(2);
				$r .= $record->getCodiceFiscale();
				$r .= $record->getTitolarePagamento();
				$r .= $record->getDataPagamento();
				$r .= $record->getTotImportiCreditoCompensati();
				//filler 2 caratteri (94-95)
				$r .= StringUtility::creaFiller(2);
				$r .= $record->getTipoCodiceIndividuale();
				$r .= $record->getCodicePaese();
				$r .= $record->getCheckDigit();
				//campo non utilizzabile di 20 caratteri (101-120)
				$r .= StringUtility::creaFiller(20);
				
				
				return $r;
			}
			else {
				return "";
			}
		}
		
		/**
		 *
		 * funzione per la generazione formale del record 50_02
		 *
		 * @param Record50F24_02 $record
		 *
		 * @return string record 50_02
		 */
		public static function generaRecord50_02($record)
		{
			
			if (isset($record)) {
				$r = " ";
				$r .= $record->getTipoRecord();
				$r .= $record->getProgressivoDelegaF24();
				$r .= $record->getSubtipoRecord();
				$r .= $record->getCodiceMittente();
				//filler 4 coarattiri (29-32)
				$r .= StringUtility::creaFiller(4);
				
				$r .= $record->getAbi();
				$r .= $record->getCab();
				$r .= $record->getCodiceCliente();
				$r .= $record->getDestinatarioStampa();
				$r .= $record->getDenominazioneDestinatarioStampa();
				//campo non utilizzabile di 12 caratteri (109-120)
				$r .= StringUtility::creaFiller(12);
				
				
				return $r;
			}
			else {
				return "";
			}
		}
		
		/**
		 *
		 * funzione per la generazione formale del record 50_03
		 *
		 * @param Record50_03 $record
		 *
		 * @return string record 50_03
		 */
		public static function generaRecord50_03($record)
		{
			
			if (isset($record)) {
				$r = " ";
				$r .= $record->getTipoRecord();
				$r .= $record->getProgressivoDelegaF24();
				$r .= $record->getSubtipoRecord();
				$r .= $record->getCap();
				$r .= $record->getComune();
				$r .= $record->getProvincia();
				$r .= $record->getIndirizzo();
				//campo non utilizzabile di 42 caratteri (79-120)
				$r .= StringUtility::creaFiller(42);
				return $r;
			}
			else {
				return "";
			}
		}
		
	}

?>
