<?php
	/**
	 * Created by PhpStorm.
	 * User: claudio
	 * Date: 05/10/18
	 * Time: 11.30
	 */
	
	namespace Click\FattureB2B;
	
	require_once 'Header.php';
	require_once 'Body.php';
	require_once 'Config.php';

	class Fattura
	{
		/** @var \stdClass */
		public $dati;
		/** @var \stdClass */
		public $config;

		/**
		 * Fattura constructor.
		 *
		 * @param Header $header
		 * @param Body $body
		 */
		public function __construct($header = null, $body = null, $config = null)
		{
		    $this->dati = new \stdClass();

		    $this->dati->body = new Body();
			$this->dati->header = new Header();

			if (!is_null($body)) $this->dati->body = $body;
			if (!is_null($header)) $this->dati->header = $header;

			$this->config = new \stdClass();

			if (!is_null($config)) $this->config = $config;
		}

		/**
		 * @param Body $body
		 */
		public function setBody($body)
		{
			$this->dati->body = $body;
		}
		
		/**
		 * @param Header $header
		 */
		public function setHeader($header)
		{
			$this->dati->header = $header;
		}

        /**
         * @param \stdClass $config
         */
        public function setConfig($config)
        {
            $this->config = $config;
        }


        ///////////////////////////////
        ///      Cast
        ////////////////////////////////
		public function toArray()
		{
			return (array)$this;
		}
		
		public function toJson()
		{
			return json_encode($this->toArray());
		}

	}