<?php
	/**
	 * Created by PhpStorm.
	 * User: claudio
	 * Date: 05/10/18
	 * Time: 11.32
	 */
	
	namespace Click\FattureB2B;
	
	
	class Body
	{
		/** @var \stdClass */
		public $DatiGenerali;
		/** @var \stdClass */
		public $DatiBeniServizi;
		/** @var \stdClass */
		public $DatiPagamento;
		
		/**
		 * Body constructor.
		 */
		public function __construct()
		{
			$this->DatiGenerali = new \stdClass();
			
			$this->DatiBeniServizi = new \stdClass();
			$this->DatiBeniServizi->DettaglioLinee = array();
			$this->DatiBeniServizi->DatiRiepilogo = array();

			$this->DatiPagamento = new \stdClass();
		}

        ////////////////////////////////////////////////////------------------------------------------------------------
        //DATI GENERALI
        ////////////////////////////////////////////////////------------------------------------------------------------

        /** GENERALI
		 * @param $data
		 * @param $numero
		 * @param string $divisa
		 * @param string $tipoDocumento
		 */
		public function creaDatiGeneraliDocumento($data,
												  $numero,
												  $divisa = 'EUR',
												  $tipoDocumento = 'TD01')
		{
			$this->DatiGenerali->DatiGeneraliDocumento = new \stdClass();
			$this->DatiGenerali->DatiGeneraliDocumento->TipoDocumento = $tipoDocumento;
			$this->DatiGenerali->DatiGeneraliDocumento->Divisa = $divisa;
			$this->DatiGenerali->DatiGeneraliDocumento->Data = $data;
			$this->DatiGenerali->DatiGeneraliDocumento->Numero = $numero;
		}
        
        /**
         * @param null   $causale
         * @param null   $importoTotaleDocumento
         * @param null   $arrotondamento
         * @param string $divisa
         * @param string $tipoDocumento
         * @param string $art37
         */
        public function creaDatiGeneraliFattura(
            $causale = null,
            $importoTotaleDocumento = null,
            $arrotondamento = null,
            $art37=null) {
            if(!is_null($importoTotaleDocumento))
			    $this->DatiGenerali->DatiGeneraliDocumento->ImportoTotaleDocumento = $importoTotaleDocumento;
            if(!is_null($arrotondamento))
                $this->DatiGenerali->DatiGeneraliDocumento->Arrotondamento = $arrotondamento;
            if(!is_null($causale))
			    $this->DatiGenerali->DatiGeneraliDocumento->causale = $causale;
            if(!is_null($art37))
			    $this->DatiGenerali->DatiGeneraliDocumento->Art73 = $art37;
		}
		
		
		/** DATI RITENUTA
         *
		 * @param $tipoRitenuta
		 * @param $importoRitenuta
		 * @param $aliquotaRitenuta
		 * @param $causalePagamento
		 */
		public function creaDatiGeneraliRitenuta($tipoRitenuta,
												 $importoRitenuta,
												 $aliquotaRitenuta,
												 $causalePagamento)
		{
			$this->DatiGenerali->DatiGeneraliDocumento->DatiRitenuta = new \stdClass();
			$this->DatiGenerali->DatiGeneraliDocumento->DatiRitenuta->TipoRitenuta = $tipoRitenuta;
			$this->DatiGenerali->DatiGeneraliDocumento->DatiRitenuta->ImportoRitenuta = $importoRitenuta;
			$this->DatiGenerali->DatiGeneraliDocumento->DatiRitenuta->AliquotaRitenuta = $aliquotaRitenuta;
			$this->DatiGenerali->DatiGeneraliDocumento->DatiRitenuta->CausalePagamento = $causalePagamento;
		}

		/** DATI BOLLO (NON OBBLIGATORIO)
         *
		 * @param $bolloVirtuale
		 * @param $importoBollo
		 */
		public function creaDatiGeneraliBollo($bolloVirtuale,
                                             $importoBollo)
		{
			$this->DatiGenerali->DatiGeneraliDocumento->DatiBollo = new \stdClass();
			$this->DatiGenerali->DatiGeneraliDocumento->DatiBollo->BolloVirtuale = $bolloVirtuale;
			$this->DatiGenerali->DatiGeneraliDocumento->DatiBollo->ImportoBollo = $importoBollo;
		}

        /** DATI CASSA PREVIDENZIALE (NON OBBLIGATORIO)
         *
         * @param $tipoCassa
         * @param $AlCassa
         * @param $importoContributoCassa
         * @param $aliquotaIVA
         * @param null $imponibileCassa
         * @param null $ritenuta
         * @param null $natura
         * @param null $riferimentoAmministrazione
         */
        public function creaDatiCassaPrevidenziale($tipoCassa,
                                                   $AlCassa,
                                                   $importoContributoCassa,
                                                   $aliquotaIVA,
                                                   $imponibileCassa = null,
                                                   $ritenuta = null,
                                                   $natura = null,
                                                   $riferimentoAmministrazione = null)
        {
            $this->DatiGenerali->DatiGeneraliDocumento->DatiCassaPrevidenziale = new \stdClass();
            $this->DatiGenerali->DatiGeneraliDocumento->DatiCassaPrevidenziale->TipoCassa = $tipoCassa;
            $this->DatiGenerali->DatiGeneraliDocumento->DatiCassaPrevidenziale->AlCassa = $AlCassa;
            $this->DatiGenerali->DatiGeneraliDocumento->DatiCassaPrevidenziale->ImportoContributoCassa = $importoContributoCassa;
            $this->DatiGenerali->DatiGeneraliDocumento->DatiCassaPrevidenziale->AliquotaIVA = $aliquotaIVA;
            if(!is_null($imponibileCassa))
                $this->DatiGenerali->DatiGeneraliDocumento->DatiCassaPrevidenziale->ImponibileCassa = $imponibileCassa;
            if(!is_null($ritenuta))
                $this->DatiGenerali->DatiGeneraliDocumento->DatiCassaPrevidenziale->Ritenuta = $ritenuta;
            if(!is_null($natura))
                $this->DatiGenerali->DatiGeneraliDocumento->DatiCassaPrevidenziale->Natura = $natura;
            if(!is_null($riferimentoAmministrazione))
                $this->DatiGenerali->DatiGeneraliDocumento->DatiCassaPrevidenziale->RiferimentoAmministrazione = $riferimentoAmministrazione;
        }

		/**DATI CONTRATTO (NON OBBLIGATORIO)
         *
		 * @param $idDocumento
		 * @param $riferimentoNumeroLinea
		 * @param $data
		 * @param $numItem
		 * @param $codiceCommessaConvenzione
		 * @param $codiceCUP
		 * @param $codiceCIG
		 */
		public function creaDatiGeneraliContratto($idDocumento,
                                                  $riferimentoNumeroLinea = null,
                                                  $data = null,
                                                  $numItem = null,
                                                  $codiceCommessaConvenzione = null,
                                                  $codiceCUP = null,
                                                  $codiceCIG = null)
		{
			$this->DatiGenerali->DatiContratto = new \stdClass();
            $this->DatiGenerali->DatiContratto->IdDocumento = $idDocumento;
            if(!is_null($riferimentoNumeroLinea))
			    $this->DatiGenerali->DatiContratto->RiferimentoNumeroLinea = $riferimentoNumeroLinea;
            if(!is_null($data))
			    $this->DatiGenerali->DatiContratto->Data = $data;
            if(!is_null($numItem))
                $this->DatiGenerali->DatiContratto->NumItem = $numItem;
            if(!is_null($codiceCommessaConvenzione))
                $this->DatiGenerali->DatiContratto->CodiceCommessaConvenzione = $codiceCommessaConvenzione;
            if(!is_null($codiceCUP))
                $this->DatiGenerali->DatiContratto->CodiceCUP = $codiceCUP;
            if(!is_null($codiceCIG))
                $this->DatiGenerali->DatiContratto->CodiceCIG = $codiceCIG;
		}

		/**DATI FATTURE COLLEGATE (NON OBBLIGATORIO)
         *
		 * @param $idDocumento
		 * @param $riferimentoNumeroLinea
		 * @param $data
		 * @param $numItem
		 * @param $codiceCommessaConvenzione
		 * @param $codiceCUP
		 * @param $codiceCIG
		 */
		public function creaDatiGeneraliFattureCollegate($idDocumento,
                                                         $riferimentoNumeroLinea = null,
                                                         $data = null,
                                                         $numItem = null,
                                                         $codiceCommessaConvenzione = null,
                                                         $codiceCUP = null,
                                                         $codiceCIG = null)
		{
			$this->DatiGenerali->DatiFattureCollegate = new \stdClass();
            $this->DatiGenerali->DatiFattureCollegate->IdDocumento = $idDocumento;
            if(!is_null($riferimentoNumeroLinea))
			    $this->DatiGenerali->DatiFattureCollegate->RiferimentoNumeroLinea = $riferimentoNumeroLinea;
            if(!is_null($data))
			    $this->DatiGenerali->DatiFattureCollegate->Data = $data;
            if(!is_null($numItem))
			    $this->DatiGenerali->DatiFattureCollegate->NumItem = $numItem;
            if(!is_null($codiceCommessaConvenzione))
			    $this->DatiGenerali->DatiFattureCollegate->CodiceCommessaConvenzione = $codiceCommessaConvenzione;
            if(!is_null($codiceCUP))
			    $this->DatiGenerali->DatiFattureCollegate->CodiceCUP = $codiceCUP;
            if(!is_null($codiceCIG))
			    $this->DatiGenerali->DatiFattureCollegate->CodiceCIG = $codiceCIG;
		}

        ////////////////////////////////////////////////////------------------------------------------------------------
        //DATI BENI E SERVIZI
        ////////////////////////////////////////////////////------------------------------------------------------------
		
		/**
		 * @param $numeroLinea
		 * @param $descrizione
		 * @param $prezzoUnitario
		 * @param $aliquotaIVA
         * @param $quantita
         * @param $natura
		 */
		public function addDatiBeniServiziDettaglioLinee($numeroLinea,
														 $descrizione,
														 $prezzoUnitario,
														 $aliquotaIVA,
                                                         $quantita = null,
                                                         $natura = null)
		{
			$dettaglio = new \stdClass();
			$dettaglio->NumeroLinea = $numeroLinea;
			$dettaglio->Descrizione = $descrizione;
			$dettaglio->PrezzoUnitario = $prezzoUnitario;
            if(!is_null($quantita))
                $dettaglio->PrezzoTotale = $prezzoUnitario * $quantita;
            else
                $dettaglio->PrezzoTotale = $prezzoUnitario;
			$dettaglio->AliquotaIVA = $aliquotaIVA;
            if(!is_null($quantita))
                $dettaglio->Quantita = $quantita;
            if(!is_null($natura))
                $dettaglio->Natura = $natura;
            $this->DatiBeniServizi->DettaglioLinee[] = $dettaglio;
		}
		
		/**
		 * @param $aliquotaIVA
		 * @param $imponibileImporto
		 * @param $imposta
		 * @param $esigibilitaIVA
		 */
        public function addDatiBeniServiziDatiRiepilogo($aliquotaIVA,
                                                        $imponibileImporto,
                                                        $imposta,
                                                        $natura = null,
                                                        $riferimentoNormativo = null,
                                                        $esigibilitaIVA = null)
        {
            $dettaglio = new \stdClass();
            $dettaglio->AliquotaIVA = $aliquotaIVA;
            $dettaglio->ImponibileImporto = $imponibileImporto;
            $dettaglio->Imposta = $imposta;
            if (!is_null($natura))
                $dettaglio->Natura = $natura;
            if (!is_null($riferimentoNormativo))
                $dettaglio->RiferimentoNormativo = $riferimentoNormativo;
            if (!is_null($esigibilitaIVA))
                $dettaglio->EsigibilitaIVA = $esigibilitaIVA;

            $this->DatiBeniServizi->DatiRiepilogo[] = $dettaglio;
        }



        ////////////////////////////////////////////////////------------------------------------------------------------
        //DATI PAGAMENTO (NON OBBLIGATORIO)
        ////////////////////////////////////////////////////------------------------------------------------------------
		
		/**
		 * @param $condizioniPagamento
		 * @param $modalitaPagamento
		 * @param $dataScadenzaPagamento
		 * @param $importoPagamento
		 */
		public function creaDatiPagamento($condizioniPagamento,
										  $modalitaPagamento,
                                          $importoPagamento,
										  $dataScadenzaPagamento = null)
		{
			$this->DatiPagamento->CondizioniPagamento = $condizioniPagamento;
			$this->DatiPagamento->modalitaPagamento = $modalitaPagamento;
            $this->DatiPagamento->importoPagamento = $importoPagamento;
            if(!is_null($dataScadenzaPagamento))
			    $this->DatiPagamento->dataScadenzaPagamento = $dataScadenzaPagamento;
		}
		
	}
	
	
	
	
	