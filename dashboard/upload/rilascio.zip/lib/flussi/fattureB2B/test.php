<?php
	/**
	 * Created by PhpStorm.
	 * User: claudio
	 * Date: 05/10/18
	 * Time: 12.47
	 */

    require_once 'Fattura.php';
	require_once 'WS.php';


	//HEADER
	$h = new \Click\FattureB2B\Header();
	//dati trasmissione
	$h->creaDatiTrasmissione('IT01234567890', 1, 12345, 333123456, null, 'prova@pec.it');
    //cedente prestatore
	$h->creaCedentePrestatoreDenominazione('IT01234567890', 'PPPPLT80R10M082K', 'SOCIETA ALPHA SRL', 'RF01', 'VIALE ROMA 543', '07100', 'SASSARI', 'SS', 'IT', null, null);
	$h->setCedentePrestatoreRegimeFiscale('regime fiscale');
	$h->setCedentePrestatoreRiferimentoAmministrazione('riferimento amministrazione');
	$h->setCedentePrestatoreIscrizioneREA('ufficio', 123, 'capitale sociale', 'socio unico', 'stato liquidazione');
	$h->setCedentePrestatoreContatti(123456, 987654, 'prova@email.it');
	$h->setCedentePrestatoreAlboProfessionale('albo professionale', 'MI', 1010, '2015-10-03');
	//cessionario committente
	$h->creaCessionarioCommittenteDenominzaione('09876543210',null, 'BETA GAMMA', 'VIA TORINO 38-B', '00145', 'ROMA', 'RM', 'IT', null, null);
	//rappresentante fiscale
    $h->creaRappresentanteFiscaleDenominazione('12345678901', null, 'rappresentante fiscale', null, null);
    //soggetto emittente
    $h->creaTerzoIntermediarioSoggettoEmittenteDenominazione('12345678901', null, 'soggetto emittente', null, null);


	//BODY
	$b = new \Click\FattureB2B\Body();
	//dati generali
	$b->creaDatiGeneraliDocumento('2014-12-18','123', 'LA FATTURA FA RIFERIMENTO AD UNA OPERAZIONE AAAA BBBBBBBBBBBBBBBBBB CCC DDDDDDDDDDDDDDD E FFFFFFFFFFFFFFFFFFFF GGGGGGGGGG HHHHHHH II LLLLLLLLLLLLLLLLL MMM NNNNN OO PPPPPPPPPPP QQQQ RRRR SSSSSSSSSSSSSS SEGUE DESCRIZIONE CAUSALE NEL CASO IN CUI NON SIANO STATI SUFFICIENTI 200 CARATTERI AAAAAAAAAAA BBBBBBBBBBBBBBBBB', 'EUR', 'TD01');
    $b->creaDatiGeneraliRitenuta('RT01', 359.02,  20.00, 'A');
    $b->creaDatiGeneraliBollo('bollo', 100);
    $b->creaDatiCassaPrevidenziale('tipo', 4.00, 1000, 21.00, 2000, null, null, null);
    //$b->creaDatiGeneraliContratto();
    $b->creaDatiGeneraliFattureCollegate(1, 1, '20-10-2018', 10, 'ABC123', null, null);
    //beni e servizi
	$b->addDatiBeniServiziDettaglioLinee(1, 'descrizione prova1', 1, 5, 22);
	$b->addDatiBeniServiziDettaglioLinee(1, 'descrizione prova2', 10, 54, 4);
	$b->addDatiBeniServiziDatiRiepilogo('22.00', '25.00', '5.50', 'D');
	//dati pagamento
	$b->creaDatiPagamento('TP01', 'MP01', '2015-01-30', '30.50');


	//CONFIG
    $c = new \Click\FattureB2B\Config(false);


	//FATTURA
	$f = new Click\FattureB2B\Fattura($h, $b, $c);
	//var_dump($f->toJson());


	//WS
    $ws = new \Click\FattureB2B\WS();

    //CREAZIONE XML DA JSON

    //ritorno xml
    //$xml = $ws->creaXML($f->toJson());
    //echo '<br>XML<br>';
    //echo $xml;

    //ritorno path xml
    echo '<br>PATH<br>';
    $xmlPath = $ws->creaXMLgetPath($f->toJson());
    echo $xmlPath;
    echo '<br><br>XML AS STRING<br>';
    $stringXML = $ws->getStringXMLbyPath($xmlPath);
    echo $stringXML;
    echo '<br><br>VERIFICA XML<br>';
    echo $ws->verificaXML($xmlPath, true);
    echo '<br><br>INVIA XML<br>';
    echo $ws->inviaXML($xmlPath, true);

