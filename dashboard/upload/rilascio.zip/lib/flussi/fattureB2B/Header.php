<?php
	/**
	 * Created by PhpStorm.
	 * User: claudio
	 * Date: 05/10/18
	 * Time: 11.31
	 */
	
	namespace Click\FattureB2B;
	
	
	class Header
	{
		
		/** @var \stdClass */
		public $DatiTrasmissione;
		/** @var \stdClass */
		public $CedentePrestatore;
		/** @var \stdClass */
		public $RappresentanteFiscale;
		/** @var \stdClass */
		public $CessionarioCommittente;
		/** @var \stdClass */
		public $TerzoIntermediarioSoggettoEmittente;
		
		/**
		 * Header constructor.
		 */
		public function __construct()
		{
			$this->DatiTrasmissione = new \stdClass();
			$this->CedentePrestatore = new \stdClass();
			$this->RappresentanteFiscale = new \stdClass();
			$this->CessionarioCommittente = new \stdClass();
			$this->TerzoIntermediarioSoggettoEmittente = new \stdClass();
		}
		
		////////////////////////////////////////////////////------------------------------------------------------------
		//DATI TRASMISSIONE
		////////////////////////////////////////////////////------------------------------------------------------------
		
		/**
		 * @param $partitaIva
		 * @param $progressivoInvio
		 * @param $codiceDestinatario
         * @param $pecDestinatario
		 * @param $telefono
		 * @param $email
		 */
		public function creaDatiTrasmissione($partitaIva,
                                             $progressivoInvio,
                                             $codiceDestinatario,
                                             $pecDestinatario = null,
                                             $telefono = null,
                                             $email = null)
		{
			$this->DatiTrasmissione->partitaIva = $partitaIva;
			$this->DatiTrasmissione->ProgressivoInvio = $progressivoInvio;
			$this->DatiTrasmissione->CodiceDestinatario = $codiceDestinatario;
			if (!is_null($telefono))
				$this->DatiTrasmissione->telefono = $telefono;
			if (!is_null($email))
				$this->DatiTrasmissione->email = $email;
			if (!is_null($pecDestinatario))
				$this->DatiTrasmissione->PECDestinatario = $pecDestinatario;
		}
		
		////////////////////////////////////////////////////------------------------------------------------------------
		//CEDENTE PRESTATORE
		////////////////////////////////////////////////////------------------------------------------------------------
		
		/**
		 * OBBLIGATORIO
		 *
		 *
		 * @param $partitaIva
		 * @param $codiceFiscale
		 * @param $denominazione
		 * @param $regimeFiscale
		 * @param $indirizzo //indirizzo sede
		 * @param $cap       //cap sede
		 * @param $comune    //comune sede
		 * @param $provincia //provincia sede
		 * @param $nazione   //nazione sede, default IT
		 * @param $titoloOnorifico
		 * @param $codEori
		 */
		public function creaCedentePrestatoreDenominazione($partitaIva,
														   $codiceFiscale,
														   $denominazione,
														   $regimeFiscale,
														   $indirizzo, $cap, $comune, $provincia, $nazione = 'IT',
														   $titoloOnorifico = null,
														   $codEori = null)
		{
			$this->CedentePrestatore->partitaIva = $partitaIva;
			if (!is_null($codiceFiscale))
				$this->CedentePrestatore->codiceFiscale = $codiceFiscale;
			$this->CedentePrestatore->denominazione = $denominazione;
			//regime fiscale
			$this->CedentePrestatore->RegimeFiscale = $regimeFiscale;
			//dati sede
			$this->CedentePrestatore->indirizzo = $indirizzo;
			$this->CedentePrestatore->cap = $cap;
			$this->CedentePrestatore->comune = $comune;
			if (!is_null($provincia))
				$this->CedentePrestatore->provincia = $provincia;
			$this->CedentePrestatore->nazione = $nazione;
			//titolo onorifico - codEORI
			if (!is_null($titoloOnorifico))
				$this->CedentePrestatore->titolo = $titoloOnorifico;
			if (!is_null($codEori))
				$this->CedentePrestatore->codEORI = $codEori;
		}
		
		/**
		 * OBBLIGATORIO
		 *
		 *
		 * @param $partitaIva
		 * @param $codiceFiscale
		 * @param $nome
		 * @param $cognome
		 * @param $regimeFiscale
		 * @param $indirizzo //indirizzo sede
		 * @param $cap       //cap sede
		 * @param $comune    //comune sede
		 * @param $provincia //provincia sede
		 * @param $nazione   //nazione sede, default IT
		 * @param $titoloOnorifico
		 * @param $codEori
		 */
		public function creaCedentePrestatoreNomeCognome($partitaIva,
														 $codiceFiscale,
														 $nome,
														 $cognome,
														 $regimeFiscale,
														 $indirizzo, $cap, $comune, $provincia, $nazione = 'IT',
														 $titoloOnorifico = null,
														 $codEori = null)
		{
			$this->CedentePrestatore->partitaIva = $partitaIva;
			if (!is_null($codiceFiscale))
				$this->CedentePrestatore->codiceFiscale = $codiceFiscale;
			$this->CedentePrestatore->Nome = $nome;
			$this->CedentePrestatore->Cognome = $cognome;
			//regime fiscale
			$this->CedentePrestatore->RegimeFiscale = $regimeFiscale;
			//dati sede
			$this->CedentePrestatore->indirizzo = $indirizzo;
			$this->CedentePrestatore->cap = $cap;
			$this->CedentePrestatore->comune = $comune;
			if (!is_null($provincia))
				$this->CedentePrestatore->provincia = $provincia;
			$this->CedentePrestatore->nazione = $nazione;
			//titolo onorifico - codEORI
			if (!is_null($titoloOnorifico))
				$this->CedentePrestatore->titolo = $titoloOnorifico;
			if (!is_null($codEori))
				$this->CedentePrestatore->codEORI = $codEori;
		}
		
		/**
		 * NON OBBLIGATORIO
		 *
		 * @param $regimeFiscale
		 */
		public function setCedentePrestatoreRegimeFiscale($regimeFiscale)
		{
			$this->CedentePrestatore->RegimeFiscale = $regimeFiscale;
		}
		
		/**
		 * NON OBBLIGATORIO
		 *
		 * @param $riferimento
		 */
		public function setCedentePrestatoreRiferimentoAmministrazione($riferimento)
		{
			$this->CedentePrestatore->RiferimentoAmministrazione = $riferimento;
		}
		
		/**
		 * NON OBBLIGATORIO
		 *
		 * @param $ufficio
		 * @param $numeroRea
		 * @param $capitaleSociale
		 * @param $socioUnico
		 * @param $statoLiquidazione
		 */
		public function setCedentePrestatoreIscrizioneREA($ufficio, $numeroRea, $capitaleSociale, $socioUnico, $statoLiquidazione)
		{
			$this->CedentePrestatore->IscrizioneREA = new \stdClass();
			$this->CedentePrestatore->IscrizioneREA->Ufficio = $ufficio;
			$this->CedentePrestatore->IscrizioneREA->NumeroREA = $numeroRea;
			$this->CedentePrestatore->IscrizioneREA->CapitaleSociale = $capitaleSociale;
			$this->CedentePrestatore->IscrizioneREA->SocioUnico = $socioUnico;
			$this->CedentePrestatore->IscrizioneREA->StatoLiquidazione = $statoLiquidazione;
		}
		
		/**
		 * NON OBBLIGATORIO
		 *
		 * @param string $telefono
		 * @param string $fax
		 * @param string $email
		 */
		public function setCedentePrestatoreContatti($telefono = '', $fax = '', $email = '')
		{
			$this->CedentePrestatore->Contatti = new \stdClass();
			$this->CedentePrestatore->Contatti->Telefono = $telefono;
			$this->CedentePrestatore->Contatti->Fax = $fax;
			$this->CedentePrestatore->Contatti->Email = $email;
			
		}
		
		/**
		 * NON OBBLIGATORIO
		 *
		 * @param $alboProfessionale
		 * @param $provinciaAlbo
		 * @param $numeroIscrizioneAlbo
		 * @param $dataIscrizioneAlbo
		 */
		public function setCedentePrestatoreAlboProfessionale($alboProfessionale, $provinciaAlbo, $numeroIscrizioneAlbo, $dataIscrizioneAlbo)
		{
			$this->CedentePrestatore->AlboProfessionale = $alboProfessionale;
			$this->CedentePrestatore->ProvinciaAlbo = $provinciaAlbo;
			$this->CedentePrestatore->NumeroIscrizioneAlbo = $numeroIscrizioneAlbo;
			$this->CedentePrestatore->DataIscrizioneAlbo = $dataIscrizioneAlbo;
		}
		
		
		////////////////////////////////////////////////////------------------------------------------------------------
		//RAPPRESENTANTE FISCALE
		////////////////////////////////////////////////////------------------------------------------------------------
		
		/**
		 * NON OBBLIGATORIO
		 *
		 * @param $partitaIva
		 * @param $codiceFiscale
		 * @param $denominazione
		 * @param $titoloOnorifico
		 * @param $codEORI
		 */
		public function creaRappresentanteFiscaleDenominazione($partitaIva,
															   $codiceFiscale,
															   $denominazione,
															   $titoloOnorifico = null,
															   $codEORI = null)
		{
			$this->RappresentanteFiscale->partitaIva = $partitaIva;
			if (!is_null($codiceFiscale))
				$this->RappresentanteFiscale->codiceFiscale = $codiceFiscale;
			$this->RappresentanteFiscale->denominazione = $denominazione;
			//titolo onorifico - codEORI
			if (!is_null($titoloOnorifico))
				$this->RappresentanteFiscale->titolo = $titoloOnorifico;
			if (!is_null($codEORI))
				$this->RappresentanteFiscale->codEORI = $codEORI;
		}
		
		/**
		 * NON OBBLIGATORIO
		 *
		 * @param $partitaIva
		 * @param $codiceFiscale
		 * @param $nome
		 * @param $cognome
		 * @param $titoloOnorifico
		 * @param $codEORI
		 */
		public function creaRappresentanteFiscaleNomeCognome($partitaIva,
															 $codiceFiscale,
															 $nome,
															 $cognome,
															 $titoloOnorifico = null,
															 $codEORI = null)
		{
			$this->RappresentanteFiscale->partitaIva = $partitaIva;
			if (!is_null($codiceFiscale))
				$this->RappresentanteFiscale->codiceFiscale = $codiceFiscale;
			$this->RappresentanteFiscale->Nome = $nome;
			$this->RappresentanteFiscale->Cognome = $cognome;
			//titolo onorifico - codEORI
			if (!is_null($titoloOnorifico))
				$this->RappresentanteFiscale->titolo = $titoloOnorifico;
			if (!is_null($codEORI))
				$this->RappresentanteFiscale->codEORI = $codEORI;
		}
		
		
		////////////////////////////////////////////////////------------------------------------------------------------
		//CESSIONARIO COMMITTENTE
		////////////////////////////////////////////////////------------------------------------------------------------
		
		/**
		 * OBBLIGATORIO
		 *
		 * @param $partitaIva
		 * @param $codiceFiscale
		 * @param $denominazione
		 * @param $indirizzo
		 * @param $cap
		 * @param $comune
		 * @param $provincia
		 * @param string $nazione
		 * @param $titoloOnorifico
		 * @param $codEORI
		 */
		public function creaCessionarioCommittenteDenominzaione($partitaIva,
																$codiceFiscale,
																$denominazione,
																$indirizzo, $cap, $comune, $provincia, $nazione = 'IT',
																$titoloOnorifico = null,
																$codEORI = null)
		{
            if (!is_null($partitaIva))
			    $this->CessionarioCommittente->partitaIva = $partitaIva;
			if (!is_null($codiceFiscale))
				$this->CessionarioCommittente->codiceFiscale = $codiceFiscale;
			$this->CessionarioCommittente->denominazione = $denominazione;
			//dati sede
			$this->CessionarioCommittente->indirizzo = $indirizzo;
			$this->CessionarioCommittente->cap = $cap;
			$this->CessionarioCommittente->comune = $comune;
			if (!is_null($provincia))
				$this->CessionarioCommittente->provincia = $provincia;
			$this->CessionarioCommittente->nazione = $nazione;
			//titolo onorifico - codEORI
			if (!is_null($titoloOnorifico))
				$this->CessionarioCommittente->titolo = $titoloOnorifico;
			if (!is_null($codEORI))
				$this->CessionarioCommittente->codEORI = $codEORI;
		}
		
		/**
		 * OBBLIGATORIO
		 *
		 * @param $partitaIva
		 * @param $codiceFiscale
		 * @param $nome
		 * @param $cognome
		 * @param $indirizzo
		 * @param $cap
		 * @param $comune
		 * @param $provincia
		 * @param string $nazione
		 * @param $titoloOnorifico
		 * @param $codEORI
		 */
		public function creaCessionarioCommittenteNomeCognome($partitaIva,
															  $codiceFiscale,
															  $nome,
															  $cognome,
															  $indirizzo, $cap, $comune, $provincia, $nazione = 'IT',
															  $titoloOnorifico = null,
															  $codEORI = null)
		{
			$this->CessionarioCommittente->partitaIva = $partitaIva;
			if (!is_null($codiceFiscale))
				$this->CessionarioCommittente->codiceFiscale = $codiceFiscale;
			$this->CessionarioCommittente->Nome = $nome;
			$this->CessionarioCommittente->Cognome = $cognome;
			//dati sede
			$this->CessionarioCommittente->indirizzo = $indirizzo;
			$this->CessionarioCommittente->cap = $cap;
			$this->CessionarioCommittente->comune = $comune;
			if (!is_null($provincia))
				$this->CessionarioCommittente->provincia = $provincia;
			$this->CessionarioCommittente->nazione = $nazione;
			//titolo onorifico - codEORI
			if (!is_null($titoloOnorifico))
				$this->CessionarioCommittente->titolo = $titoloOnorifico;
			if (!is_null($codEORI))
				$this->CessionarioCommittente->codEORI = $codEORI;
		}
		
		
		////////////////////////////////////////////////////------------------------------------------------------------
		//TERZO INTERMEDIARIO SOGGETTO EMITTENTE
		////////////////////////////////////////////////////------------------------------------------------------------
		
		/**
		 * NON OBBLIGATORIO
		 *
		 * @param $partitaIva
		 * @param $codiceFiscale
		 * @param $denominazione
		 * @param $titoloOnorifico
		 * @param $codEORI
		 */
		public function creaTerzoIntermediarioSoggettoEmittenteDenominazione($partitaIva,
																			 $codiceFiscale,
																			 $denominazione,
																			 $titoloOnorifico = null,
																			 $codEORI = null)
		{
			$this->TerzoIntermediarioSoggettoEmittente->partitaIva = $partitaIva;
			if (!is_null($codiceFiscale))
				$this->TerzoIntermediarioSoggettoEmittente->codiceFiscale = $codiceFiscale;
			$this->TerzoIntermediarioSoggettoEmittente->denominazione = $denominazione;
			if (!is_null($titoloOnorifico))
				$this->TerzoIntermediarioSoggettoEmittente->titolo = $titoloOnorifico;
			if (!is_null($codEORI))
				$this->TerzoIntermediarioSoggettoEmittente->codEORI = $codEORI;
		}
		
		/**
		 * NON OBBLIGATORIO
		 *
		 * @param $partitaIva
		 * @param $codiceFiscale
		 * @param $nome
		 * @param $cognome
		 * @param $titoloOnorifico
		 * @param $codEORI
		 */
		public function creaTerzoIntermediarioSoggettoEmittenteNomeCognome($partitaIva,
																		   $codiceFiscale,
																		   $nome,
																		   $cognome,
																		   $titoloOnorifico = null,
																		   $codEORI = null)
		{
			$this->TerzoIntermediarioSoggettoEmittente->partitaIva = $partitaIva;
			if (!is_null($codiceFiscale))
				$this->TerzoIntermediarioSoggettoEmittente->codiceFiscale = $codiceFiscale;
			$this->TerzoIntermediarioSoggettoEmittente->Nome = $nome;
			$this->TerzoIntermediarioSoggettoEmittente->Cognome = $cognome;
			if (!is_null($titoloOnorifico))
				$this->TerzoIntermediarioSoggettoEmittente->titolo = $titoloOnorifico;
			if (!is_null($codEORI))
				$this->TerzoIntermediarioSoggettoEmittente->codEORI = $codEORI;
		}
		
	}