<?php
/**
 * Created by PhpStorm.
 * User: alessandro
 * Date: 12/10/18
 * Time: 12.42
 */

namespace Click\FattureB2B;


class Config extends \stdClass
{

    /** @var boolean */
    public $pretty;

    /**
     * Config constructor.
     */
    public function __construct($pretty = false)
    {
        $this->pretty = $pretty;
    }

}