<?php
/**
 * Created by PhpStorm.
 * User: alessandro
 * Date: 20/11/18
 * Time: 12.40
 */

namespace Click\FattureB2B;

require_once 'Fattura.php';

class WS
{
    /** @var  Fattura */
    private $fattura;

    //199
//    private $urlIntermediari = "http://172.16.0.199:5002/Intermediari/";
//    private $urlClick = "http://172.16.0.199:5002/Click/";
//    private $port = "5002";
    //pc ale
//    private $urlIntermediari = "http://192.168.8.138:5002/Intermediari/";
//    private $urlClick = "http://192.168.8.138:5002/Click/";
//    private $port = "5002";
    //dns test

//    private $urlIntermediari = "http://ws.62.94.243.83.xip.io/Intermediari/";
//    private $urlClick = "http://ws.62.94.243.83.xip.io/Click/";
    private $urlIntermediari = "http://ws.172.16.0.171.xip.io/Intermediari/";
    private $urlClick = "http://ws.172.16.0.171.xip.io/Click/";
//    private $urlIntermediari = "http://wsfatturee.dscsrl.it/Intermediari/";
//    private $urlClick = "http://wsfatturee.dscsrl.it/Click/";
    private $port = "80";

    private $cache = "no-cache";

    //autenticazione click
    private $user = "APIREST_wt00012683@wt00012683";
    private $password = "FUS21AJS";
    private $token = "xxxx";

    /**
     * WS constructor.
     */
    public function __construct()
    {
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///       Getter & Setter
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    /**
     * @return Fattura
     */
    public function getFattura()
    {
        return $this->fattura;
    }

    /**
     * @param Fattura $fattura
     */
    public function setFattura($fattura)
    {
        $this->fattura = $fattura;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///       Interfaccia WS
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    //INTERMEDIARI =====================================================================================================

    //FATTURE ATTIVE ---------------------------------------------------------------------------------------------------


    /**Verifica se tutti i dati richiesti dalla normativa sono contenuti nell'xml in questione
     *
     * @param $xml -> xml in binario
     */
    public function verificaXML($xml, $path=true){

        if($path)
            $j = json_encode(array('fileXml' => $xml));
        else
            $j = json_encode(array('xml' => $xml));

        $curl = curl_init();

        curl_setopt_array($curl, $this->writeCurlSettingsPA($this->urlIntermediari.'FatturaAttiva/VerificaXml', $j, $this->cache, $this->user, $this->password, $this->token));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            return "cURL Error #:" . $err;
        } else {
            return $response;
        }
    }

    /**Invia xml
     *
     * @param $xml -> xml in binario
     *
     * @param $xml -> xml in binario
     */
    public function inviaXML($xml, $path=true){

        if($path)
            $j = json_encode(array('fileXml' => $xml));
        else
            $j = json_encode(array('xml' => $xml));

        $curl = curl_init();

        curl_setopt_array($curl, $this->writeCurlSettingsPA($this->urlIntermediari.'FatturaAttiva/InviaXml', $j, $this->cache, $this->user, $this->password, $this->token));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            return "cURL Error #:" . $err;
        } else {
            return $response;
        }
    }

    /** Elimina una fattura in coda se possibile
     *
     * @param $id -> Identificativo fattura in coda
     */
    public function cancellaFatturaInCoda($id){

        $j = json_encode(array('id' => $id));

        $curl = curl_init();

        curl_setopt_array($curl, $this->writeCurlSettingsPA($this->urlIntermediari.'FatturaAttiva/cancellaFatturaInCoda', $j, $this->cache, $this->user, $this->password, $this->token));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        } else {
            echo $response;
        }
    }

    /** Ricerca Fatture attive (risultato filtrato dai parametri passati)
     *
     * @param null $invioDataDa
     * @param null $invioDataA
     * @param null $cessionarioCfPiva
     * @param null $cessionarioDenominazione
     * @param null $cedenteCfPiva
     * @param null $cedenteDenominazione
     * @param null $fatturaDataDa
     * @param null $fatturaDataA
     * @param null $fatturaData
     * @param null $fatturaNumero
     * @param null $risultatiLimite
     * @param null $risultatiOffset
     */
    public function ricercaFattureAttive($invioDataDa=null,
                                         $invioDataA=null,
                                         $cessionarioCfPiva=null,
                                         $cessionarioDenominazione=null,
                                         $cedenteCfPiva=null,
                                         $cedenteDenominazione=null,
                                         $fatturaDataDa=null,
                                         $fatturaDataA=null,
                                         $fatturaData=null,
                                         $fatturaNumero=null,
                                         $risultatiLimite=null,
                                         $risultatiOffset=null){
        $ricerca = [];
        if(!is_null($invioDataDa))
            $ricerca['invioDataDa'] = $invioDataDa;
        if(!is_null($invioDataA))
            $ricerca['invioDataA'] = $invioDataA;
        if(!is_null($cessionarioCfPiva))
            $ricerca['cessionarioCfPiva'] = $cessionarioCfPiva;
        if(!is_null($cessionarioDenominazione))
            $ricerca['cessionarioDenominazione'] = $cessionarioDenominazione;
        if(!is_null($cedenteCfPiva))
            $ricerca['cedenteCfPiva'] = $cedenteCfPiva;
        if(!is_null($cedenteDenominazione))
            $ricerca['cedenteDenominazione'] = $cedenteDenominazione;
        if(!is_null($fatturaDataDa))
            $ricerca['fatturaDataDa'] = $fatturaDataDa;
        if(!is_null($fatturaDataA))
            $ricerca['fatturaDataA'] = $fatturaDataA;
        if(!is_null($fatturaData))
            $ricerca['fatturaData'] = $fatturaData;
        if(!is_null($fatturaNumero))
            $ricerca['fatturaNumero'] = $fatturaNumero;
        if(!is_null($risultatiLimite))
            $ricerca['risultatiLimite'] = $risultatiLimite;
        if(!is_null($risultatiOffset))
            $ricerca['risultatiOffset'] = $risultatiOffset;

        $j = json_encode($ricerca);

        $curl = curl_init();

        curl_setopt_array($curl, $this->writeCurlSettingsPA($this->urlIntermediari.'FatturaAttiva/RicercaFatture', $j, $this->cache, $this->user, $this->password, $this->token));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        } else {
            echo $response;
        }
    }



    //FATTURE PASSIVE --------------------------------------------------------------------------------------------------


    /**Ricerca Fatture passive (risultato filtrato dai parametri passati)
     *
     * @param int $codiceStatoGestionale -> codice fatture passive da ricercare:
     *                                      -1: da gestire
     *                                       1: in gestione
     *                                       2: respinta
     *                                       3: da trasferire
     *                                       4: trasferita
     * @param null $invioDataDa
     * @param null $invioDataA
     * @param null $cessionarioCfPiva
     * @param null $cessionarioDenominazione
     * @param null $cedenteCfPiva
     * @param null $cedenteDenominazione
     * @param null $fatturaDataDa
     * @param null $fatturaDataA
     * @param null $fatturaData
     * @param null $fatturaNumero
     * @param null $risultatiLimite
     * @param null $risultatiOffset
     * @return mixed|string
     */
    public function ricercaFatturePassive($codiceStatoGestionale=-1,
                                          $invioDataDa=null,
                                          $invioDataA=null,
                                          $cessionarioCfPiva=null,
                                          $cessionarioDenominazione=null,
                                          $cedenteCfPiva=null,
                                          $cedenteDenominazione=null,
                                          $fatturaDataDa=null,
                                          $fatturaDataA=null,
                                          $fatturaData=null,
                                          $fatturaNumero=null,
                                          $risultatiLimite=null,
                                          $risultatiOffset=null){
        $ricerca = [];
        if(!is_null($codiceStatoGestionale))
            $ricerca['codiceStatoGestionale'] = $codiceStatoGestionale;
        if(!is_null($invioDataDa))
            $ricerca['invioDataDa'] = $invioDataDa;
        if(!is_null($invioDataA))
            $ricerca['invioDataA'] = $invioDataA;
        if(!is_null($cessionarioCfPiva))
            $ricerca['cessionarioCfPiva'] = $cessionarioCfPiva;
        if(!is_null($cessionarioDenominazione))
            $ricerca['cessionarioDenominazione'] = $cessionarioDenominazione;
        if(!is_null($cedenteCfPiva))
            $ricerca['cedenteCfPiva'] = $cedenteCfPiva;
        if(!is_null($cedenteDenominazione))
            $ricerca['cedenteDenominazione'] = $cedenteDenominazione;
        if(!is_null($fatturaDataDa))
            $ricerca['fatturaDataDa'] = $fatturaDataDa;
        if(!is_null($fatturaDataA))
            $ricerca['fatturaDataA'] = $fatturaDataA;
        if(!is_null($fatturaData))
            $ricerca['fatturaData'] = $fatturaData;
        if(!is_null($fatturaNumero))
            $ricerca['fatturaNumero'] = $fatturaNumero;
        if(!is_null($risultatiLimite))
            $ricerca['risultatiLimite'] = $risultatiLimite;
        if(!is_null($risultatiOffset))
            $ricerca['risultatiOffset'] = $risultatiOffset;

        $j = json_encode($ricerca);


        $curl = curl_init();

        curl_setopt_array($curl, $this->writeCurlSettingsPA($this->urlIntermediari.'FatturaPassiva/RicercaFatture', $j, $this->cache, $this->user, $this->password, $this->token));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            return "cURL Error #:" . $err;
        } else {
            return $response;
        }
    }

    /**Find fatture passive
     *
     * @param $idFattura -> identificativo della fattura di cui aggiornare lo stato
     * @param $codice -> valore codice stato
     *      -1: da gestire
     *      1: in gestione
     *      2: respinta
     *      3: da trasferire
     *      4: trasferita
     */
    public function aggiornaStato($idFattura, $codice=-1){

        $j = json_encode(array('idcoda' => $idFattura , 'CodiceStato' => $codice));

        $curl = curl_init();

        curl_setopt_array($curl, $this->writeCurlSettingsPA($this->urlIntermediari.'FatturaPassiva/AggiornaStato', $j, $this->cache, $this->user, $this->password, $this->token));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            return "cURL Error #:" . $err;
        } else {
            return $response;
        }
    }


    //CHIAMATE GENERICHE -----------------------------------------------------------------------------------------------


    /** Recupera i dati riguardanti una fattura in coda
     *
     * @param $id -> Identificativo fattura in coda
     */
    public function getStatoById($id){

        $j = json_encode(array('id' => $id));

        $curl = curl_init();

        curl_setopt_array($curl, $this->writeCurlSettingsPA($this->urlIntermediari.'GetStatoById', $j, $this->cache, $this->user, $this->password, $this->token));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            return "cURL Error #:" . $err;
        } else {
            return $response;
        }
    }

    /** write file xml by id
     *
     * @param $id -> identificativo file xml
     * @param $pathOutput -> where write file xml
     */
    public function GetFileXmlById($id, $pathOutput){

        $j = json_encode(array('id' => $id, 'tipoFile' => 'base64'));

        $curl = curl_init();

        curl_setopt_array($curl, $this->writeCurlSettingsPA($this->urlIntermediari.'GetFileXmlById', $j, $this->cache, $this->user, $this->password, $this->token));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            return "cURL Error #:" . $err;
        } else {
            $response = json_decode($response);
            $file = base64_decode($response->result->FileBase64);
            $name = $response->result->NomeFileBase64;

            $f = fopen($pathOutput.$name, 'w');
            fwrite($f, $file);
            fclose($f);
            return $name; //ritorno il nome dell'XML generato per elaborarlo
        }
    }


    //CLICK ============================================================================================================


    /** crea xml da json
     *
     * @param $j -> json click
     */
    public function creaXML($j){

        $curl = curl_init();

        curl_setopt_array($curl, $this->writeCurlSettingsClick($this->urlClick.'creaXML', $j, $this->cache));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            return "cURL Error #:" . $err;
        } else {
            return $response;
        }
    }

    /** crea xml da json
     *
     * @param $j -> json click
     */
    public function creaXMLgetPath($j){

        $curl = curl_init();

        curl_setopt_array($curl, $this->writeCurlSettingsClick($this->urlClick.'creaXMLgetPath', $j, $this->cache));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            return "cURL Error #:" . $err;
        } else {
            return str_replace('"','',trim(str_replace("\r\n","",$response)));
        }
    }

    /** get xml as string from path
     *
     * @param $path
     */
    public function getStringXMLbyPath($path){

        $curl = curl_init();

        $j = json_encode(array('path' => $path));

        curl_setopt_array($curl, $this->writeCurlSettingsClick($this->urlClick.'getStringXMLbyPath', $j, $this->cache));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            return "cURL Error #:" . $err;
        } else {
            return $response;
        }
    }
    

    //TODO: chiamata ws curl Click/inviaJson



    //==================================================================================================================
    // UTILITY
    //==================================================================================================================

    private function writeCurlSettingsPA($url, $json, $cache, $user, $password, $token){

        return array(
            CURLOPT_PORT => $this->port,
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $json,
            CURLOPT_HTTPHEADER => array(
                "Cache-Control: $cache",
                "Content-Type: application/json",
                "Postman-Token: 05b7195b-2ff4-6a5f-8104-8d588d8ff5d7",
                "password: $password",
                "token: $token",
                "user: $user"
            ),
        );
    }

    private function writeCurlSettingsClick($url, $json, $cache){

        return array(
            CURLOPT_PORT => $this->port,
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $json,
            CURLOPT_HTTPHEADER => array(
                "Cache-Control: $cache",
                "Content-Type: application/json",
                "Postman-Token: 74e79716-c45e-ff79-4d55-58bd68ddde60"
            ),
        );
    }
    //==================================================================================================================
    //                  SETTER PER PARAMETRI CONNESSIONE
    //==================================================================================================================
    
    /**
     * @param string $user
     */
    public function setUser($user) {
        $this->user = $user;
    }
    
    /**
     * @param string $password
     */
    public function setPassword($password) {
        $this->password = $password;
    }
}
