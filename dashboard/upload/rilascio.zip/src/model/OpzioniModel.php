<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-15
* Time: 11:42:47.671706
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class OpzioniModel extends PdaAbstractModel {
/** @var integer */
protected $id;
/** @var string */
protected $descrizione;
/** @var integer */
protected $valore=0;
/** @var string (enum) S = STAMPE\\nI= IMPOSTE\\nA= AGGIORNAMENTO ISTAT\nC= CONTRATTO*/
protected $categoria;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='opzioni';$this->tableName='opzioni';}

/**
 * find by tables' Primary Key: 
 * @return Opzioni|array|string|null
 */
public function findByPk($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($id), $typeResult);}
/**
 * delete by tables' Primary Key: 
 */
public function deleteByPk($id){$query = "DELETE FROM $this->tableName  WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($id));}
/**
 * Find all record of table
 * @return Opzioni[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * find by id
 * @return Opzioni[]
 */
public function findById($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($id), $typeResult);}


/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->id))$arrayValue['id']=$this->id;if(isset($this->descrizione))$arrayValue['descrizione']=($this->descrizione==self::NULL_VALUE)?null:$this->descrizione;if(isset($this->valore))$arrayValue['valore']=$this->valore;if(isset($this->categoria))$arrayValue['categoria']=($this->categoria==self::NULL_VALUE)?null:$this->categoria;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['id'])) || (isset($keyArray['opzioni_id']))) {$this->setId(isset($keyArray['id'])?$keyArray['id']:$keyArray['opzioni_id']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['descrizione'])) || (isset($keyArray['opzioni_descrizione']))) {$this->setDescrizione(isset($keyArray['descrizione'])?$keyArray['descrizione']:$keyArray['opzioni_descrizione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['valore'])) || (isset($keyArray['opzioni_valore']))) {$this->setValore(isset($keyArray['valore'])?$keyArray['valore']:$keyArray['opzioni_valore']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['categoria'])) || (isset($keyArray['opzioni_categoria']))) {$this->setCategoria(isset($keyArray['categoria'])?$keyArray['categoria']:$keyArray['opzioni_categoria']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['id'] =$positionalArray[0];$values['descrizione'] =($positionalArray[1]==self::NULL_VALUE)?null:$positionalArray[1];$values['valore'] =$positionalArray[2];$values['categoria'] =($positionalArray[3]==self::NULL_VALUE)?null:$positionalArray[3];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['id'] = null;$values['descrizione'] = null;$values['valore'] = 0;$values['categoria'] = null;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'opzioni.id as opzioni_id,opzioni.descrizione as opzioni_descrizione,opzioni.valore as opzioni_valore,opzioni.categoria as opzioni_categoria';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `opzioni` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descrizione` varchar(250) DEFAULT NULL,
  `valore` tinyint(1) NOT NULL DEFAULT '0',
  `categoria` enum('S','I','A','C') DEFAULT NULL COMMENT 'S = STAMPE\\\\nI= IMPOSTE\\\\nA= AGGIORNAMENTO ISTAT\\nC= CONTRATTO',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ");}
/**
 * @return integer
 */
public function getId(){return $this->id;}
/**
 * @param integer $id Id
 */
public function setId($id){$this->id=$id;}
/**
 * @return string
 */
public function getDescrizione(){return $this->descrizione;}
/**
 * @param string $descrizione Descrizione
 * @param int $encodeType
 */
public function setDescrizione($descrizione,$encodeType = self::STR_DEFAULT){$this->descrizione=$this->decodeString($descrizione,$encodeType);}
/**
 * @return integer
 */
public function getValore(){return $this->valore;}
/**
 * @param integer $valore Valore
 */
public function setValore($valore){$this->valore=$valore;}
/**
 * @param bool $decode if true return decode value * @return string
 */
public function getCategoria($decode=false){return ($decode)?$this->getCategoriaValuesList()[$this->categoria]:$this->categoria;}
/**
 * @param bool $json if true return value json's array else return array values * @return array|string
 */
public function getCategoriaValuesList($json=false){$kv=[];return ($json)?$this->createJsonKeyValArray($kv):$kv;}
/**
 * @param string (enum) $categoria Categoria
 */
public function setCategoria($categoria){$this->categoria=$categoria;}
}