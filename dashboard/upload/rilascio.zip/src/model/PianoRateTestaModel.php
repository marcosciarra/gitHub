<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-15
* Time: 11:42:47.711051
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class PianoRateTestaModel extends PdaAbstractModel {
/** @var integer */
protected $id;
/** @var integer */
protected $idGestione;
/** @var integer */
protected $idCanoniOneri;
/** @var string */
protected $descrizione;
/** @var integer */
protected $idTipoIva;
/** @var double */
protected $imponibile=0;
/** @var double */
protected $importo=0;
/** @var double */
protected $conguaglio;
/** @var double */
protected $percentualeIstat;
/** @var string (enum) */
protected $tipoSpesa;
/** @var string (enum) */
protected $tipoSaldo;
/** @var string */
protected $dataAggiornamentoIstat;
/** @var string */
protected $dataAggiornamentoConguaglio;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='piano_rate_testa';$this->tableName='piano_rate_testa';}

/**
 * find by tables' Primary Key: 
 * @return PianoRateTesta|array|string|null
 */
public function findByPk($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($id), $typeResult);}
/**
 * delete by tables' Primary Key: 
 */
public function deleteByPk($id){$query = "DELETE FROM $this->tableName  WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($id));}
/**
 * Find all record of table
 * @return PianoRateTesta[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * find by tables' Key idx_id_gestione: 
 * @return PianoRateTesta[]|array|string
 */
public function findByIdxIdGestione($idGestione,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_id_gestione) WHERE id_gestione=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($idGestione), $typeResult);}

/**
 * find by tables' Key idx_id_canoni_oneri: 
 * @return PianoRateTesta[]|array|string
 */
public function findByIdxIdCanoniOneri($idCanoniOneri,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_id_canoni_oneri) WHERE id_canoni_oneri=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($idCanoniOneri), $typeResult);}

/**
 * find by tables' Key idx_id_tipi_iva: 
 * @return PianoRateTesta[]|array|string
 */
public function findByIdxIdTipiIva($idTipoIva,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_id_tipi_iva) WHERE id_tipo_iva=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($idTipoIva), $typeResult);}

/**
 * delete by tables' Key idx_id_gestione: 
 * @return boolean
 */
public function deleteByIdxIdGestione($idGestione,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_gestione=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idGestione));}
/**
 * delete by tables' Key idx_id_canoni_oneri: 
 * @return boolean
 */
public function deleteByIdxIdCanoniOneri($idCanoniOneri,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_canoni_oneri=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idCanoniOneri));}
/**
 * delete by tables' Key idx_id_tipi_iva: 
 * @return boolean
 */
public function deleteByIdxIdTipiIva($idTipoIva,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_tipo_iva=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idTipoIva));}
/**
 * find by id
 * @return PianoRateTesta[]
 */
public function findById($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($id), $typeResult);}


/**
 * find by id_gestione
 * @return PianoRateTesta[]
 */
public function findByIdGestione($idGestione,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id_gestione=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($idGestione), $typeResult);}


/**
 * find by id_canoni_oneri
 * @return PianoRateTesta[]
 */
public function findByIdCanoniOneri($idCanoniOneri,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id_canoni_oneri=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($idCanoniOneri), $typeResult);}


/**
 * find by id_tipo_iva
 * @return PianoRateTesta[]
 */
public function findByIdTipoIva($idTipoIva,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id_tipo_iva=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($idTipoIva), $typeResult);}


/**
 * delete by id_gestione
 * @return boolean
 */
public function deleteByIdGestione($idGestione){$query = "DELETE FROM $this->tableName WHERE id_gestione=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idGestione));}

/**
 * delete by id_canoni_oneri
 * @return boolean
 */
public function deleteByIdCanoniOneri($idCanoniOneri){$query = "DELETE FROM $this->tableName WHERE id_canoni_oneri=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idCanoniOneri));}

/**
 * delete by id_tipo_iva
 * @return boolean
 */
public function deleteByIdTipoIva($idTipoIva){$query = "DELETE FROM $this->tableName WHERE id_tipo_iva=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idTipoIva));}

/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->id))$arrayValue['id']=$this->id;if(isset($this->idGestione))$arrayValue['id_gestione']=$this->idGestione;if(isset($this->idCanoniOneri))$arrayValue['id_canoni_oneri']=$this->idCanoniOneri;if(isset($this->descrizione))$arrayValue['descrizione']=($this->descrizione==self::NULL_VALUE)?null:$this->descrizione;if(isset($this->idTipoIva))$arrayValue['id_tipo_iva']=$this->idTipoIva;if(isset($this->imponibile))$arrayValue['imponibile']=$this->imponibile;if(isset($this->importo))$arrayValue['importo']=$this->importo;if(isset($this->conguaglio))$arrayValue['conguaglio']=($this->conguaglio==self::NULL_VALUE)?null:$this->conguaglio;if(isset($this->percentualeIstat))$arrayValue['percentuale_istat']=($this->percentualeIstat==self::NULL_VALUE)?null:$this->percentualeIstat;if(isset($this->tipoSpesa))$arrayValue['tipo_spesa']=$this->tipoSpesa;if(isset($this->tipoSaldo))$arrayValue['tipo_saldo']=$this->tipoSaldo;if(isset($this->dataAggiornamentoIstat))$arrayValue['data_aggiornamento_istat']=($this->dataAggiornamentoIstat==self::NULL_VALUE)?null:$this->dataAggiornamentoIstat;if(isset($this->dataAggiornamentoConguaglio))$arrayValue['data_aggiornamento_conguaglio']=($this->dataAggiornamentoConguaglio==self::NULL_VALUE)?null:$this->dataAggiornamentoConguaglio;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['id'])) || (isset($keyArray['piano_rate_testa_id']))) {$this->setId(isset($keyArray['id'])?$keyArray['id']:$keyArray['piano_rate_testa_id']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_gestione'])) || (isset($keyArray['piano_rate_testa_id_gestione']))) {$this->setIdgestione(isset($keyArray['id_gestione'])?$keyArray['id_gestione']:$keyArray['piano_rate_testa_id_gestione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_canoni_oneri'])) || (isset($keyArray['piano_rate_testa_id_canoni_oneri']))) {$this->setIdcanonioneri(isset($keyArray['id_canoni_oneri'])?$keyArray['id_canoni_oneri']:$keyArray['piano_rate_testa_id_canoni_oneri']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['descrizione'])) || (isset($keyArray['piano_rate_testa_descrizione']))) {$this->setDescrizione(isset($keyArray['descrizione'])?$keyArray['descrizione']:$keyArray['piano_rate_testa_descrizione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_tipo_iva'])) || (isset($keyArray['piano_rate_testa_id_tipo_iva']))) {$this->setIdtipoiva(isset($keyArray['id_tipo_iva'])?$keyArray['id_tipo_iva']:$keyArray['piano_rate_testa_id_tipo_iva']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['imponibile'])) || (isset($keyArray['piano_rate_testa_imponibile']))) {$this->setImponibile(isset($keyArray['imponibile'])?$keyArray['imponibile']:$keyArray['piano_rate_testa_imponibile']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['importo'])) || (isset($keyArray['piano_rate_testa_importo']))) {$this->setImporto(isset($keyArray['importo'])?$keyArray['importo']:$keyArray['piano_rate_testa_importo']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['conguaglio'])) || (isset($keyArray['piano_rate_testa_conguaglio']))) {$this->setConguaglio(isset($keyArray['conguaglio'])?$keyArray['conguaglio']:$keyArray['piano_rate_testa_conguaglio']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['percentuale_istat'])) || (isset($keyArray['piano_rate_testa_percentuale_istat']))) {$this->setPercentualeistat(isset($keyArray['percentuale_istat'])?$keyArray['percentuale_istat']:$keyArray['piano_rate_testa_percentuale_istat']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['tipo_spesa'])) || (isset($keyArray['piano_rate_testa_tipo_spesa']))) {$this->setTipospesa(isset($keyArray['tipo_spesa'])?$keyArray['tipo_spesa']:$keyArray['piano_rate_testa_tipo_spesa']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['tipo_saldo'])) || (isset($keyArray['piano_rate_testa_tipo_saldo']))) {$this->setTiposaldo(isset($keyArray['tipo_saldo'])?$keyArray['tipo_saldo']:$keyArray['piano_rate_testa_tipo_saldo']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['data_aggiornamento_istat'])) || (isset($keyArray['piano_rate_testa_data_aggiornamento_istat']))) {$this->setDataaggiornamentoistat(isset($keyArray['data_aggiornamento_istat'])?$keyArray['data_aggiornamento_istat']:$keyArray['piano_rate_testa_data_aggiornamento_istat']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['data_aggiornamento_conguaglio'])) || (isset($keyArray['piano_rate_testa_data_aggiornamento_conguaglio']))) {$this->setDataaggiornamentoconguaglio(isset($keyArray['data_aggiornamento_conguaglio'])?$keyArray['data_aggiornamento_conguaglio']:$keyArray['piano_rate_testa_data_aggiornamento_conguaglio']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['id'] =$positionalArray[0];$values['id_gestione'] =$positionalArray[1];$values['id_canoni_oneri'] =$positionalArray[2];$values['descrizione'] =($positionalArray[3]==self::NULL_VALUE)?null:$positionalArray[3];$values['id_tipo_iva'] =$positionalArray[4];$values['imponibile'] =$positionalArray[5];$values['importo'] =$positionalArray[6];$values['conguaglio'] =($positionalArray[7]==self::NULL_VALUE)?null:$positionalArray[7];$values['percentuale_istat'] =($positionalArray[8]==self::NULL_VALUE)?null:$positionalArray[8];$values['tipo_spesa'] =$positionalArray[9];$values['tipo_saldo'] =$positionalArray[10];$values['data_aggiornamento_istat'] =($positionalArray[11]==self::NULL_VALUE)?null:$positionalArray[11];$values['data_aggiornamento_conguaglio'] =($positionalArray[12]==self::NULL_VALUE)?null:$positionalArray[12];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['id'] = null;$values['id_gestione'] = null;$values['id_canoni_oneri'] = null;$values['descrizione'] = null;$values['id_tipo_iva'] = null;$values['imponibile'] = 0;$values['importo'] = 0;$values['conguaglio'] = null;$values['percentuale_istat'] = null;$values['tipo_spesa'] = null;$values['tipo_saldo'] = null;$values['data_aggiornamento_istat'] = null;$values['data_aggiornamento_conguaglio'] = null;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'piano_rate_testa.id as piano_rate_testa_id,piano_rate_testa.id_gestione as piano_rate_testa_id_gestione,piano_rate_testa.id_canoni_oneri as piano_rate_testa_id_canoni_oneri,piano_rate_testa.descrizione as piano_rate_testa_descrizione,piano_rate_testa.id_tipo_iva as piano_rate_testa_id_tipo_iva,piano_rate_testa.imponibile as piano_rate_testa_imponibile,piano_rate_testa.importo as piano_rate_testa_importo,piano_rate_testa.conguaglio as piano_rate_testa_conguaglio,piano_rate_testa.percentuale_istat as piano_rate_testa_percentuale_istat,piano_rate_testa.tipo_spesa as piano_rate_testa_tipo_spesa,piano_rate_testa.tipo_saldo as piano_rate_testa_tipo_saldo,piano_rate_testa.data_aggiornamento_istat as piano_rate_testa_data_aggiornamento_istat,piano_rate_testa.data_aggiornamento_conguaglio as piano_rate_testa_data_aggiornamento_conguaglio';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `piano_rate_testa` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_gestione` int(10) unsigned NOT NULL,
  `id_canoni_oneri` int(11) unsigned NOT NULL,
  `descrizione` varchar(45) DEFAULT NULL,
  `id_tipo_iva` int(10) unsigned NOT NULL,
  `imponibile` double NOT NULL DEFAULT '0',
  `importo` double NOT NULL DEFAULT '0',
  `conguaglio` double DEFAULT NULL,
  `percentuale_istat` decimal(6,4) DEFAULT NULL,
  `tipo_spesa` enum('C','O') NOT NULL,
  `tipo_saldo` enum('C','F') NOT NULL,
  `data_aggiornamento_istat` datetime DEFAULT NULL,
  `data_aggiornamento_conguaglio` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_id_gestione` (`id_gestione`),
  KEY `idx_id_canoni_oneri` (`id_canoni_oneri`),
  KEY `idx_id_tipi_iva` (`id_tipo_iva`)
) ENGINE=InnoDB AUTO_INCREMENT=996 DEFAULT CHARSET=latin1 ");}
/**
 * @return integer
 */
public function getId(){return $this->id;}
/**
 * @param integer $id Id
 */
public function setId($id){$this->id=$id;}
/**
 * @return integer
 */
public function getIdGestione(){return $this->idGestione;}
/**
 * @param integer $idGestione IdGestione
 */
public function setIdGestione($idGestione){$this->idGestione=$idGestione;}
/**
 * @return integer
 */
public function getIdCanoniOneri(){return $this->idCanoniOneri;}
/**
 * @param integer $idCanoniOneri IdCanoniOneri
 */
public function setIdCanoniOneri($idCanoniOneri){$this->idCanoniOneri=$idCanoniOneri;}
/**
 * @return string
 */
public function getDescrizione(){return $this->descrizione;}
/**
 * @param string $descrizione Descrizione
 * @param int $encodeType
 */
public function setDescrizione($descrizione,$encodeType = self::STR_DEFAULT){$this->descrizione=$this->decodeString($descrizione,$encodeType);}
/**
 * @return integer
 */
public function getIdTipoIva(){return $this->idTipoIva;}
/**
 * @param integer $idTipoIva IdTipoIva
 */
public function setIdTipoIva($idTipoIva){$this->idTipoIva=$idTipoIva;}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getImponibile($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->imponibile:number_format($this->imponibile,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $imponibile Imponibile
 */
public function setImponibile($imponibile){$this->imponibile=$imponibile;}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getImporto($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->importo:number_format($this->importo,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $importo Importo
 */
public function setImporto($importo){$this->importo=$importo;}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getConguaglio($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->conguaglio:number_format($this->conguaglio,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $conguaglio Conguaglio
 */
public function setConguaglio($conguaglio){$this->conguaglio=$conguaglio;}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getPercentualeIstat($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->percentualeIstat:number_format($this->percentualeIstat,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $percentualeIstat PercentualeIstat
 */
public function setPercentualeIstat($percentualeIstat){$this->percentualeIstat=$percentualeIstat;}
/**
 * @param bool $decode if true return decode value * @return string
 */
public function getTipoSpesa($decode=false){return ($decode)?$this->getTipoSpesaValuesList()[$this->tipoSpesa]:$this->tipoSpesa;}
/**
 * @param bool $json if true return value json's array else return array values * @return array|string
 */
public function getTipoSpesaValuesList($json=false){$kv=[];return ($json)?$this->createJsonKeyValArray($kv):$kv;}
/**
 * @param string (enum) $tipoSpesa TipoSpesa
 */
public function setTipoSpesa($tipoSpesa){$this->tipoSpesa=$tipoSpesa;}
/**
 * @param bool $decode if true return decode value * @return string
 */
public function getTipoSaldo($decode=false){return ($decode)?$this->getTipoSaldoValuesList()[$this->tipoSaldo]:$this->tipoSaldo;}
/**
 * @param bool $json if true return value json's array else return array values * @return array|string
 */
public function getTipoSaldoValuesList($json=false){$kv=[];return ($json)?$this->createJsonKeyValArray($kv):$kv;}
/**
 * @param string (enum) $tipoSaldo TipoSaldo
 */
public function setTipoSaldo($tipoSaldo){$this->tipoSaldo=$tipoSaldo;}
/**
 * @return string
 */
public function getDataAggiornamentoIstat(){return $this->dataAggiornamentoIstat;}
/**
 * @param string $dataAggiornamentoIstat DataAggiornamentoIstat
 * @param int $encodeType
 */
public function setDataAggiornamentoIstat($dataAggiornamentoIstat,$encodeType = self::STR_DEFAULT){$this->dataAggiornamentoIstat=$this->decodeString($dataAggiornamentoIstat,$encodeType);}
/**
 * @return string
 */
public function getDataAggiornamentoConguaglio(){return $this->dataAggiornamentoConguaglio;}
/**
 * @param string $dataAggiornamentoConguaglio DataAggiornamentoConguaglio
 * @param int $encodeType
 */
public function setDataAggiornamentoConguaglio($dataAggiornamentoConguaglio,$encodeType = self::STR_DEFAULT){$this->dataAggiornamentoConguaglio=$this->decodeString($dataAggiornamentoConguaglio,$encodeType);}
}