<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-15
* Time: 11:42:47.452023
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class ContrattiPreferenzeModel extends PdaAbstractModel {
/** @var integer */
protected $id;
/** @var integer Indica la percentuale di divisione della tassa di registro: di default � 50% al locatore e di conseguenza 50% al conduttore. Se impostata a 100 sar� tutto a carico del locatore, se impostata a 0 sar� tutto a carico del conduttore.*/
protected $impostaRegistroPercLocatore=50;
/** @var string (enum) --Modalit� richiesta imposta di registro:<br/>A= Anticipata (Default)<br/>P= Posticipata*/
protected $impostaRegistroTipoRichiesta='P';
/** @var string */
protected $dataPrimaScadenza;
/** @var string */
protected $dataScadenzaRaccordo;
/** @var integer */
protected $tipoScadenza;
/** @var string (enum) MP02=Assegno<br/>MP05=Bonifico<br/>MP01=Contanti<br/>MP13=MAV*/
protected $tipoPagamento;
/** @var objext (string) */
protected $divisioneConduttori;
/** @var objext (string) */
protected $divisioneLocatori;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='contratti_preferenze';$this->tableName='contratti_preferenze';}

/**
 * find by tables' Primary Key: 
 * @return ContrattiPreferenze|array|string|null
 */
public function findByPk($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($id), $typeResult);}
/**
 * delete by tables' Primary Key: 
 */
public function deleteByPk($id){$query = "DELETE FROM $this->tableName  WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($id));}
/**
 * Find all record of table
 * @return ContrattiPreferenze[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * find by id
 * @return ContrattiPreferenze[]
 */
public function findById($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($id), $typeResult);}


/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->id))$arrayValue['id']=$this->id;if(isset($this->impostaRegistroPercLocatore))$arrayValue['imposta_registro_perc_locatore']=$this->impostaRegistroPercLocatore;if(isset($this->impostaRegistroTipoRichiesta))$arrayValue['imposta_registro_tipo_richiesta']=$this->impostaRegistroTipoRichiesta;if(isset($this->dataPrimaScadenza))$arrayValue['data_prima_scadenza']=($this->dataPrimaScadenza==self::NULL_VALUE)?null:$this->dataPrimaScadenza;if(isset($this->dataScadenzaRaccordo))$arrayValue['data_scadenza_raccordo']=($this->dataScadenzaRaccordo==self::NULL_VALUE)?null:$this->dataScadenzaRaccordo;if(isset($this->tipoScadenza))$arrayValue['tipo_scadenza']=($this->tipoScadenza==self::NULL_VALUE)?null:$this->tipoScadenza;if(isset($this->tipoPagamento))$arrayValue['tipo_pagamento']=($this->tipoPagamento==self::NULL_VALUE)?null:$this->tipoPagamento;if(isset($this->divisioneConduttori))$arrayValue['divisione_conduttori']=$this->jsonEncode($this->divisioneConduttori);if(isset($this->divisioneLocatori))$arrayValue['divisione_locatori']=$this->jsonEncode($this->divisioneLocatori);return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['id'])) || (isset($keyArray['contratti_preferenze_id']))) {$this->setId(isset($keyArray['id'])?$keyArray['id']:$keyArray['contratti_preferenze_id']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['imposta_registro_perc_locatore'])) || (isset($keyArray['contratti_preferenze_imposta_registro_perc_locatore']))) {$this->setImpostaregistroperclocatore(isset($keyArray['imposta_registro_perc_locatore'])?$keyArray['imposta_registro_perc_locatore']:$keyArray['contratti_preferenze_imposta_registro_perc_locatore']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['imposta_registro_tipo_richiesta'])) || (isset($keyArray['contratti_preferenze_imposta_registro_tipo_richiesta']))) {$this->setImpostaregistrotiporichiesta(isset($keyArray['imposta_registro_tipo_richiesta'])?$keyArray['imposta_registro_tipo_richiesta']:$keyArray['contratti_preferenze_imposta_registro_tipo_richiesta']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['data_prima_scadenza'])) || (isset($keyArray['contratti_preferenze_data_prima_scadenza']))) {$this->setDataprimascadenza(isset($keyArray['data_prima_scadenza'])?$keyArray['data_prima_scadenza']:$keyArray['contratti_preferenze_data_prima_scadenza']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['data_scadenza_raccordo'])) || (isset($keyArray['contratti_preferenze_data_scadenza_raccordo']))) {$this->setDatascadenzaraccordo(isset($keyArray['data_scadenza_raccordo'])?$keyArray['data_scadenza_raccordo']:$keyArray['contratti_preferenze_data_scadenza_raccordo']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['tipo_scadenza'])) || (isset($keyArray['contratti_preferenze_tipo_scadenza']))) {$this->setTiposcadenza(isset($keyArray['tipo_scadenza'])?$keyArray['tipo_scadenza']:$keyArray['contratti_preferenze_tipo_scadenza']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['tipo_pagamento'])) || (isset($keyArray['contratti_preferenze_tipo_pagamento']))) {$this->setTipopagamento(isset($keyArray['tipo_pagamento'])?$keyArray['tipo_pagamento']:$keyArray['contratti_preferenze_tipo_pagamento']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['divisione_conduttori'])) || (isset($keyArray['contratti_preferenze_divisione_conduttori']))) {$this->setDivisioneconduttori(isset($keyArray['divisione_conduttori'])?$keyArray['divisione_conduttori']:$keyArray['contratti_preferenze_divisione_conduttori']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['divisione_locatori'])) || (isset($keyArray['contratti_preferenze_divisione_locatori']))) {$this->setDivisionelocatori(isset($keyArray['divisione_locatori'])?$keyArray['divisione_locatori']:$keyArray['contratti_preferenze_divisione_locatori']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['id'] =$positionalArray[0];$values['imposta_registro_perc_locatore'] =$positionalArray[1];$values['imposta_registro_tipo_richiesta'] =$positionalArray[2];$values['data_prima_scadenza'] =($positionalArray[3]==self::NULL_VALUE)?null:$positionalArray[3];$values['data_scadenza_raccordo'] =($positionalArray[4]==self::NULL_VALUE)?null:$positionalArray[4];$values['tipo_scadenza'] =($positionalArray[5]==self::NULL_VALUE)?null:$positionalArray[5];$values['tipo_pagamento'] =($positionalArray[6]==self::NULL_VALUE)?null:$positionalArray[6];$values['divisione_conduttori'] =($positionalArray[7]==self::NULL_VALUE)?null:$positionalArray[7];$values['divisione_locatori'] =($positionalArray[8]==self::NULL_VALUE)?null:$positionalArray[8];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['id'] = null;$values['imposta_registro_perc_locatore'] = 50;$values['imposta_registro_tipo_richiesta'] = 'P';$values['data_prima_scadenza'] = null;$values['data_scadenza_raccordo'] = null;$values['tipo_scadenza'] = null;$values['tipo_pagamento'] = null;$values['divisione_conduttori'] = null;$values['divisione_locatori'] = null;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'contratti_preferenze.id as contratti_preferenze_id,contratti_preferenze.imposta_registro_perc_locatore as contratti_preferenze_imposta_registro_perc_locatore,contratti_preferenze.imposta_registro_tipo_richiesta as contratti_preferenze_imposta_registro_tipo_richiesta,contratti_preferenze.data_prima_scadenza as contratti_preferenze_data_prima_scadenza,contratti_preferenze.data_scadenza_raccordo as contratti_preferenze_data_scadenza_raccordo,contratti_preferenze.tipo_scadenza as contratti_preferenze_tipo_scadenza,contratti_preferenze.tipo_pagamento as contratti_preferenze_tipo_pagamento,contratti_preferenze.divisione_conduttori as contratti_preferenze_divisione_conduttori,contratti_preferenze.divisione_locatori as contratti_preferenze_divisione_locatori';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `contratti_preferenze` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `imposta_registro_perc_locatore` tinyint(3) unsigned NOT NULL DEFAULT '50' COMMENT 'Indica la percentuale di divisione della tassa di registro: di default � 50% al locatore e di conseguenza 50% al conduttore. Se impostata a 100 sar� tutto a carico del locatore, se impostata a 0 sar� tutto a carico del conduttore.',
  `imposta_registro_tipo_richiesta` enum('A','P') NOT NULL DEFAULT 'P' COMMENT '--Modalit� richiesta imposta di registro:\nA= Anticipata (Default)\nP= Posticipata',
  `data_prima_scadenza` date DEFAULT NULL,
  `data_scadenza_raccordo` date DEFAULT NULL,
  `tipo_scadenza` int(11) DEFAULT NULL,
  `tipo_pagamento` enum('MP01','MP02','MP05','MP13') DEFAULT NULL COMMENT 'MP02=Assegno\nMP05=Bonifico\nMP01=Contanti\nMP13=MAV',
  `divisione_conduttori` json DEFAULT NULL,
  `divisione_locatori` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=latin1 ");}
/**
 * @return integer
 */
public function getId(){return $this->id;}
/**
 * @param integer $id Id
 */
public function setId($id){$this->id=$id;}
/**
 * @return integer
 */
public function getImpostaRegistroPercLocatore(){return $this->impostaRegistroPercLocatore;}
/**
 * @param integer $impostaRegistroPercLocatore ImpostaRegistroPercLocatore
 */
public function setImpostaRegistroPercLocatore($impostaRegistroPercLocatore){$this->impostaRegistroPercLocatore=$impostaRegistroPercLocatore;}
/**
 * @param bool $decode if true return decode value * @return string
 */
public function getImpostaRegistroTipoRichiesta($decode=false){return ($decode)?$this->getImpostaRegistroTipoRichiestaValuesList()[$this->impostaRegistroTipoRichiesta]:$this->impostaRegistroTipoRichiesta;}
/**
 * @param bool $json if true return value json's array else return array values * @return array|string
 */
public function getImpostaRegistroTipoRichiestaValuesList($json=false){$kv=['A'=>'Anticipata (Default)','P'=>'Posticipata'];return ($json)?$this->createJsonKeyValArray($kv):$kv;}
/**
 * @param string (enum) $impostaRegistroTipoRichiesta ImpostaRegistroTipoRichiesta
 */
public function setImpostaRegistroTipoRichiesta($impostaRegistroTipoRichiesta){$this->impostaRegistroTipoRichiesta=$impostaRegistroTipoRichiesta;}
/**
 * @return string
 */
public function getDataPrimaScadenza(){return $this->dataPrimaScadenza;}
/**
 * @param string $dataPrimaScadenza DataPrimaScadenza
 * @param int $encodeType
 */
public function setDataPrimaScadenza($dataPrimaScadenza,$encodeType = self::STR_DEFAULT){$this->dataPrimaScadenza=$this->decodeString($dataPrimaScadenza,$encodeType);}
/**
 * @return string
 */
public function getDataScadenzaRaccordo(){return $this->dataScadenzaRaccordo;}
/**
 * @param string $dataScadenzaRaccordo DataScadenzaRaccordo
 * @param int $encodeType
 */
public function setDataScadenzaRaccordo($dataScadenzaRaccordo,$encodeType = self::STR_DEFAULT){$this->dataScadenzaRaccordo=$this->decodeString($dataScadenzaRaccordo,$encodeType);}
/**
 * @return integer
 */
public function getTipoScadenza(){return $this->tipoScadenza;}
/**
 * @param integer $tipoScadenza TipoScadenza
 */
public function setTipoScadenza($tipoScadenza){$this->tipoScadenza=$tipoScadenza;}
/**
 * @param bool $decode if true return decode value * @return string
 */
public function getTipoPagamento($decode=false){return ($decode)?$this->getTipoPagamentoValuesList()[$this->tipoPagamento]:$this->tipoPagamento;}
/**
 * @param bool $json if true return value json's array else return array values * @return array|string
 */
public function getTipoPagamentoValuesList($json=false){$kv=['MP02'=>'Assegno','MP05'=>'Bonifico','MP01'=>'Contanti','MP13'=>'MAV'];return ($json)?$this->createJsonKeyValArray($kv):$kv;}
/**
 * @param string (enum) $tipoPagamento TipoPagamento
 */
public function setTipoPagamento($tipoPagamento){$this->tipoPagamento=$tipoPagamento;}
/**
 * @return objext (string)
 */
public function getDivisioneConduttori(){return $this->divisioneConduttori;}
/**
 * @param objext (string) $divisioneConduttori DivisioneConduttori
 */
public function setDivisioneConduttori($divisioneConduttori){$this->divisioneConduttori=$divisioneConduttori;}
/**
 * @return objext (string)
 */
public function getDivisioneLocatori(){return $this->divisioneLocatori;}
/**
 * @param objext (string) $divisioneLocatori DivisioneLocatori
 */
public function setDivisioneLocatori($divisioneLocatori){$this->divisioneLocatori=$divisioneLocatori;}
}