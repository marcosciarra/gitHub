<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-15
* Time: 11:42:47.332197
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class CanoniOneriModel extends PdaAbstractModel {
/** @var integer */
protected $id;
/** @var integer */
protected $idContratto;
/** @var integer */
protected $idTipiIva;
/** @var integer */
protected $idUnitaImmobiliari;
/** @var string (enum) C = Canone<br/>O = Onere*/
protected $tipoSpesa;
/** @var string (enum) F = Forfettario<br/>C = A Conguaglio*/
protected $tipoSaldo;
/** @var string */
protected $descrizione;
/** @var double */
protected $imponibile=0;
/** @var double */
protected $importo=0;
/** @var integer */
protected $numeroRate;
/** @var string */
protected $dataInizio;
/** @var string */
protected $dataFine;
/** @var objext (string) */
protected $rateizzazione;
/** @var integer */
protected $inserimentoSuccessivo=0;
/** @var integer */
protected $cestino=0;
/** @var integer */
protected $giornoConguaglio=0;
/** @var integer */
protected $meseConguaglio=0;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='canoni_oneri';$this->tableName='canoni_oneri';}

/**
 * find by tables' Primary Key: 
 * @return CanoniOneri|array|string|null
 */
public function findByPk($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($id), $typeResult);}
/**
 * delete by tables' Primary Key: 
 */
public function deleteByPk($id){$query = "DELETE FROM $this->tableName  WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($id));}
/**
 * Find all record of table
 * @return CanoniOneri[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * find by tables' Key idx_id_contratto: 
 * @return CanoniOneri[]|array|string
 */
public function findByIdxIdContratto($idContratto,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_id_contratto) WHERE id_contratto=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($idContratto), $typeResult);}

/**
 * find by tables' Key idx_id_tipi_iva: 
 * @return CanoniOneri[]|array|string
 */
public function findByIdxIdTipiIva($idTipiIva,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_id_tipi_iva) WHERE id_tipi_iva=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($idTipiIva), $typeResult);}

/**
 * delete by tables' Key idx_id_contratto: 
 * @return boolean
 */
public function deleteByIdxIdContratto($idContratto,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_contratto=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idContratto));}
/**
 * delete by tables' Key idx_id_tipi_iva: 
 * @return boolean
 */
public function deleteByIdxIdTipiIva($idTipiIva,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_tipi_iva=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idTipiIva));}
/**
 * find by id
 * @return CanoniOneri[]
 */
public function findById($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($id), $typeResult);}


/**
 * find by id_contratto
 * @return CanoniOneri[]
 */
public function findByIdContratto($idContratto,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id_contratto=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($idContratto), $typeResult);}


/**
 * find by id_tipi_iva
 * @return CanoniOneri[]
 */
public function findByIdTipiIva($idTipiIva,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id_tipi_iva=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($idTipiIva), $typeResult);}


/**
 * delete by id_contratto
 * @return boolean
 */
public function deleteByIdContratto($idContratto){$query = "DELETE FROM $this->tableName WHERE id_contratto=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idContratto));}

/**
 * delete by id_tipi_iva
 * @return boolean
 */
public function deleteByIdTipiIva($idTipiIva){$query = "DELETE FROM $this->tableName WHERE id_tipi_iva=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idTipiIva));}

/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->id))$arrayValue['id']=$this->id;if(isset($this->idContratto))$arrayValue['id_contratto']=$this->idContratto;if(isset($this->idTipiIva))$arrayValue['id_tipi_iva']=($this->idTipiIva==self::NULL_VALUE)?null:$this->idTipiIva;if(isset($this->idUnitaImmobiliari))$arrayValue['id_unita_immobiliari']=($this->idUnitaImmobiliari==self::NULL_VALUE)?null:$this->idUnitaImmobiliari;if(isset($this->tipoSpesa))$arrayValue['tipo_spesa']=$this->tipoSpesa;if(isset($this->tipoSaldo))$arrayValue['tipo_saldo']=$this->tipoSaldo;if(isset($this->descrizione))$arrayValue['descrizione']=($this->descrizione==self::NULL_VALUE)?null:$this->descrizione;if(isset($this->imponibile))$arrayValue['imponibile']=$this->imponibile;if(isset($this->importo))$arrayValue['importo']=$this->importo;if(isset($this->numeroRate))$arrayValue['numero_rate']=$this->numeroRate;if(isset($this->dataInizio))$arrayValue['data_inizio']=($this->dataInizio==self::NULL_VALUE)?null:$this->dataInizio;if(isset($this->dataFine))$arrayValue['data_fine']=($this->dataFine==self::NULL_VALUE)?null:$this->dataFine;if(isset($this->rateizzazione))$arrayValue['rateizzazione']=$this->jsonEncode($this->rateizzazione);if(isset($this->inserimentoSuccessivo))$arrayValue['inserimento_successivo']=$this->inserimentoSuccessivo;if(isset($this->cestino))$arrayValue['cestino']=$this->cestino;if(isset($this->giornoConguaglio))$arrayValue['giorno_conguaglio']=($this->giornoConguaglio==self::NULL_VALUE)?null:$this->giornoConguaglio;if(isset($this->meseConguaglio))$arrayValue['mese_conguaglio']=($this->meseConguaglio==self::NULL_VALUE)?null:$this->meseConguaglio;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['id'])) || (isset($keyArray['canoni_oneri_id']))) {$this->setId(isset($keyArray['id'])?$keyArray['id']:$keyArray['canoni_oneri_id']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_contratto'])) || (isset($keyArray['canoni_oneri_id_contratto']))) {$this->setIdcontratto(isset($keyArray['id_contratto'])?$keyArray['id_contratto']:$keyArray['canoni_oneri_id_contratto']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_tipi_iva'])) || (isset($keyArray['canoni_oneri_id_tipi_iva']))) {$this->setIdtipiiva(isset($keyArray['id_tipi_iva'])?$keyArray['id_tipi_iva']:$keyArray['canoni_oneri_id_tipi_iva']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_unita_immobiliari'])) || (isset($keyArray['canoni_oneri_id_unita_immobiliari']))) {$this->setIdunitaimmobiliari(isset($keyArray['id_unita_immobiliari'])?$keyArray['id_unita_immobiliari']:$keyArray['canoni_oneri_id_unita_immobiliari']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['tipo_spesa'])) || (isset($keyArray['canoni_oneri_tipo_spesa']))) {$this->setTipospesa(isset($keyArray['tipo_spesa'])?$keyArray['tipo_spesa']:$keyArray['canoni_oneri_tipo_spesa']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['tipo_saldo'])) || (isset($keyArray['canoni_oneri_tipo_saldo']))) {$this->setTiposaldo(isset($keyArray['tipo_saldo'])?$keyArray['tipo_saldo']:$keyArray['canoni_oneri_tipo_saldo']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['descrizione'])) || (isset($keyArray['canoni_oneri_descrizione']))) {$this->setDescrizione(isset($keyArray['descrizione'])?$keyArray['descrizione']:$keyArray['canoni_oneri_descrizione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['imponibile'])) || (isset($keyArray['canoni_oneri_imponibile']))) {$this->setImponibile(isset($keyArray['imponibile'])?$keyArray['imponibile']:$keyArray['canoni_oneri_imponibile']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['importo'])) || (isset($keyArray['canoni_oneri_importo']))) {$this->setImporto(isset($keyArray['importo'])?$keyArray['importo']:$keyArray['canoni_oneri_importo']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['numero_rate'])) || (isset($keyArray['canoni_oneri_numero_rate']))) {$this->setNumerorate(isset($keyArray['numero_rate'])?$keyArray['numero_rate']:$keyArray['canoni_oneri_numero_rate']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['data_inizio'])) || (isset($keyArray['canoni_oneri_data_inizio']))) {$this->setDatainizio(isset($keyArray['data_inizio'])?$keyArray['data_inizio']:$keyArray['canoni_oneri_data_inizio']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['data_fine'])) || (isset($keyArray['canoni_oneri_data_fine']))) {$this->setDatafine(isset($keyArray['data_fine'])?$keyArray['data_fine']:$keyArray['canoni_oneri_data_fine']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['rateizzazione'])) || (isset($keyArray['canoni_oneri_rateizzazione']))) {$this->setRateizzazione(isset($keyArray['rateizzazione'])?$keyArray['rateizzazione']:$keyArray['canoni_oneri_rateizzazione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['inserimento_successivo'])) || (isset($keyArray['canoni_oneri_inserimento_successivo']))) {$this->setInserimentosuccessivo(isset($keyArray['inserimento_successivo'])?$keyArray['inserimento_successivo']:$keyArray['canoni_oneri_inserimento_successivo']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['cestino'])) || (isset($keyArray['canoni_oneri_cestino']))) {$this->setCestino(isset($keyArray['cestino'])?$keyArray['cestino']:$keyArray['canoni_oneri_cestino']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['giorno_conguaglio'])) || (isset($keyArray['canoni_oneri_giorno_conguaglio']))) {$this->setGiornoconguaglio(isset($keyArray['giorno_conguaglio'])?$keyArray['giorno_conguaglio']:$keyArray['canoni_oneri_giorno_conguaglio']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['mese_conguaglio'])) || (isset($keyArray['canoni_oneri_mese_conguaglio']))) {$this->setMeseconguaglio(isset($keyArray['mese_conguaglio'])?$keyArray['mese_conguaglio']:$keyArray['canoni_oneri_mese_conguaglio']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['id'] =$positionalArray[0];$values['id_contratto'] =$positionalArray[1];$values['id_tipi_iva'] =($positionalArray[2]==self::NULL_VALUE)?null:$positionalArray[2];$values['id_unita_immobiliari'] =($positionalArray[3]==self::NULL_VALUE)?null:$positionalArray[3];$values['tipo_spesa'] =$positionalArray[4];$values['tipo_saldo'] =$positionalArray[5];$values['descrizione'] =($positionalArray[6]==self::NULL_VALUE)?null:$positionalArray[6];$values['imponibile'] =$positionalArray[7];$values['importo'] =$positionalArray[8];$values['numero_rate'] =$positionalArray[9];$values['data_inizio'] =($positionalArray[10]==self::NULL_VALUE)?null:$positionalArray[10];$values['data_fine'] =($positionalArray[11]==self::NULL_VALUE)?null:$positionalArray[11];$values['rateizzazione'] =($positionalArray[12]==self::NULL_VALUE)?null:$positionalArray[12];$values['inserimento_successivo'] =$positionalArray[13];$values['cestino'] =$positionalArray[14];$values['giorno_conguaglio'] =($positionalArray[15]==self::NULL_VALUE)?null:$positionalArray[15];$values['mese_conguaglio'] =($positionalArray[16]==self::NULL_VALUE)?null:$positionalArray[16];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['id'] = null;$values['id_contratto'] = null;$values['id_tipi_iva'] = null;$values['id_unita_immobiliari'] = null;$values['tipo_spesa'] = null;$values['tipo_saldo'] = null;$values['descrizione'] = null;$values['imponibile'] = 0;$values['importo'] = 0;$values['numero_rate'] = null;$values['data_inizio'] = null;$values['data_fine'] = null;$values['rateizzazione'] = null;$values['inserimento_successivo'] = 0;$values['cestino'] = 0;$values['giorno_conguaglio'] = 0;$values['mese_conguaglio'] = 0;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'canoni_oneri.id as canoni_oneri_id,canoni_oneri.id_contratto as canoni_oneri_id_contratto,canoni_oneri.id_tipi_iva as canoni_oneri_id_tipi_iva,canoni_oneri.id_unita_immobiliari as canoni_oneri_id_unita_immobiliari,canoni_oneri.tipo_spesa as canoni_oneri_tipo_spesa,canoni_oneri.tipo_saldo as canoni_oneri_tipo_saldo,canoni_oneri.descrizione as canoni_oneri_descrizione,canoni_oneri.imponibile as canoni_oneri_imponibile,canoni_oneri.importo as canoni_oneri_importo,canoni_oneri.numero_rate as canoni_oneri_numero_rate,canoni_oneri.data_inizio as canoni_oneri_data_inizio,canoni_oneri.data_fine as canoni_oneri_data_fine,canoni_oneri.rateizzazione as canoni_oneri_rateizzazione,canoni_oneri.inserimento_successivo as canoni_oneri_inserimento_successivo,canoni_oneri.cestino as canoni_oneri_cestino,canoni_oneri.giorno_conguaglio as canoni_oneri_giorno_conguaglio,canoni_oneri.mese_conguaglio as canoni_oneri_mese_conguaglio';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `canoni_oneri` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_contratto` int(10) unsigned NOT NULL,
  `id_tipi_iva` int(10) unsigned DEFAULT NULL,
  `id_unita_immobiliari` int(10) unsigned DEFAULT NULL,
  `tipo_spesa` enum('C','O') NOT NULL COMMENT 'C = Canone\nO = Onere',
  `tipo_saldo` enum('F','C') NOT NULL COMMENT 'F = Forfettario\nC = A Conguaglio',
  `descrizione` varchar(45) DEFAULT NULL,
  `imponibile` double NOT NULL DEFAULT '0',
  `importo` double NOT NULL DEFAULT '0',
  `numero_rate` int(10) unsigned NOT NULL,
  `data_inizio` date DEFAULT NULL,
  `data_fine` date DEFAULT NULL,
  `rateizzazione` json DEFAULT NULL,
  `inserimento_successivo` tinyint(1) NOT NULL DEFAULT '0',
  `cestino` tinyint(1) NOT NULL DEFAULT '0',
  `giorno_conguaglio` tinyint(2) unsigned DEFAULT '0',
  `mese_conguaglio` tinyint(2) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_id_contratto` (`id_contratto`),
  KEY `idx_id_tipi_iva` (`id_tipi_iva`),
  CONSTRAINT `fk_canoni_oneri_1` FOREIGN KEY (`id_contratto`) REFERENCES `contratti` (`id`),
  CONSTRAINT `fk_canoni_oneri_tipi_iva1` FOREIGN KEY (`id_tipi_iva`) REFERENCES `tipi_iva` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `idx_id_contratto` FOREIGN KEY (`id_contratto`) REFERENCES `contratti` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=latin1 ");}
/**
 * @return integer
 */
public function getId(){return $this->id;}
/**
 * @param integer $id Id
 */
public function setId($id){$this->id=$id;}
/**
 * @return integer
 */
public function getIdContratto(){return $this->idContratto;}
/**
 * @param integer $idContratto IdContratto
 */
public function setIdContratto($idContratto){$this->idContratto=$idContratto;}
/**
 * @return integer
 */
public function getIdTipiIva(){return $this->idTipiIva;}
/**
 * @param integer $idTipiIva IdTipiIva
 */
public function setIdTipiIva($idTipiIva){$this->idTipiIva=$idTipiIva;}
/**
 * @return integer
 */
public function getIdUnitaImmobiliari(){return $this->idUnitaImmobiliari;}
/**
 * @param integer $idUnitaImmobiliari IdUnitaImmobiliari
 */
public function setIdUnitaImmobiliari($idUnitaImmobiliari){$this->idUnitaImmobiliari=$idUnitaImmobiliari;}
/**
 * @param bool $decode if true return decode value * @return string
 */
public function getTipoSpesa($decode=false){return ($decode)?$this->getTipoSpesaValuesList()[$this->tipoSpesa]:$this->tipoSpesa;}
/**
 * @param bool $json if true return value json's array else return array values * @return array|string
 */
public function getTipoSpesaValuesList($json=false){$kv=['C'=>'Canone','O'=>'Onere'];return ($json)?$this->createJsonKeyValArray($kv):$kv;}
/**
 * @param string (enum) $tipoSpesa TipoSpesa
 */
public function setTipoSpesa($tipoSpesa){$this->tipoSpesa=$tipoSpesa;}
/**
 * @param bool $decode if true return decode value * @return string
 */
public function getTipoSaldo($decode=false){return ($decode)?$this->getTipoSaldoValuesList()[$this->tipoSaldo]:$this->tipoSaldo;}
/**
 * @param bool $json if true return value json's array else return array values * @return array|string
 */
public function getTipoSaldoValuesList($json=false){$kv=['F'=>'Forfettario','C'=>'A Conguaglio'];return ($json)?$this->createJsonKeyValArray($kv):$kv;}
/**
 * @param string (enum) $tipoSaldo TipoSaldo
 */
public function setTipoSaldo($tipoSaldo){$this->tipoSaldo=$tipoSaldo;}
/**
 * @return string
 */
public function getDescrizione(){return $this->descrizione;}
/**
 * @param string $descrizione Descrizione
 * @param int $encodeType
 */
public function setDescrizione($descrizione,$encodeType = self::STR_DEFAULT){$this->descrizione=$this->decodeString($descrizione,$encodeType);}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getImponibile($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->imponibile:number_format($this->imponibile,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $imponibile Imponibile
 */
public function setImponibile($imponibile){$this->imponibile=$imponibile;}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getImporto($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->importo:number_format($this->importo,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $importo Importo
 */
public function setImporto($importo){$this->importo=$importo;}
/**
 * @return integer
 */
public function getNumeroRate(){return $this->numeroRate;}
/**
 * @param integer $numeroRate NumeroRate
 */
public function setNumeroRate($numeroRate){$this->numeroRate=$numeroRate;}
/**
 * @return string
 */
public function getDataInizio(){return $this->dataInizio;}
/**
 * @param string $dataInizio DataInizio
 * @param int $encodeType
 */
public function setDataInizio($dataInizio,$encodeType = self::STR_DEFAULT){$this->dataInizio=$this->decodeString($dataInizio,$encodeType);}
/**
 * @return string
 */
public function getDataFine(){return $this->dataFine;}
/**
 * @param string $dataFine DataFine
 * @param int $encodeType
 */
public function setDataFine($dataFine,$encodeType = self::STR_DEFAULT){$this->dataFine=$this->decodeString($dataFine,$encodeType);}
/**
 * @return objext (string)
 */
public function getRateizzazione(){return $this->rateizzazione;}
/**
 * @param objext (string) $rateizzazione Rateizzazione
 */
public function setRateizzazione($rateizzazione){$this->rateizzazione=$rateizzazione;}
/**
 * @return integer
 */
public function getInserimentoSuccessivo(){return $this->inserimentoSuccessivo;}
/**
 * @param integer $inserimentoSuccessivo InserimentoSuccessivo
 */
public function setInserimentoSuccessivo($inserimentoSuccessivo){$this->inserimentoSuccessivo=$inserimentoSuccessivo;}
/**
 * @return integer
 */
public function getCestino(){return $this->cestino;}
/**
 * @param integer $cestino Cestino
 */
public function setCestino($cestino){$this->cestino=$cestino;}
/**
 * @return integer
 */
public function getGiornoConguaglio(){return $this->giornoConguaglio;}
/**
 * @param integer $giornoConguaglio GiornoConguaglio
 */
public function setGiornoConguaglio($giornoConguaglio){$this->giornoConguaglio=$giornoConguaglio;}
/**
 * @return integer
 */
public function getMeseConguaglio(){return $this->meseConguaglio;}
/**
 * @param integer $meseConguaglio MeseConguaglio
 */
public function setMeseConguaglio($meseConguaglio){$this->meseConguaglio=$meseConguaglio;}
}