<?php
/**
 * Created by Drakkar vers. 0.0.24(Hjortspring)
 * User: P.D.A. Srl
 * Date: 2018-01-12
 * Time: 17:43:07.651449
 */

namespace Click\Affitti\TblBase;
require_once 'CategorieCatastaliModel.php';

use Click\Affitti\TblBase\CategorieCatastaliModel;

class  CategorieCatastali extends CategorieCatastaliModel
{
    function __construct($pdo)
    {
        parent::__construct($pdo);
    }

    /**
     * Find all record of table
     * @return CategorieCatastali[]|array|string
     */
    public function findAllPerSelect($distinct = false, $typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $distinctStr = ($distinct) ? 'DISTINCT' : '';
        $query = "SELECT $distinctStr *,CONCAT_WS(' - ',codice,descrizione) AS descrizione FROM $this->tableName ";
        if ($this->whereBase) $query .= " WHERE $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        $query .= $this->createLimitQuery($limit, $offset);
        return $this->createResultArray($query, null, $typeResult);
    }
}