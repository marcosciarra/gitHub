<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-15
* Time: 11:42:56.143492
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class NazioniModel extends PdaAbstractModel {
/** @var integer */
protected $id;
/** @var string */
protected $descrizione;
/** @var string */
protected $descrizioneInglese;
/** @var string */
protected $alpha2;
/** @var string */
protected $alpha3;
/** @var integer */
protected $countryCode;
/** @var string */
protected $iso31662;
/** @var string */
protected $regione;
/** @var string */
protected $subRegione;
/** @var string */
protected $codiceRegione;
/** @var string */
protected $codiceSubRegione;
/** @var integer */
protected $prefissoTelefonico;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='nazioni';$this->tableName='nazioni';}

/**
 * find by tables' Primary Key: 
 * @return Nazioni|array|string|null
 */
public function findByPk($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($id), $typeResult);}
/**
 * delete by tables' Primary Key: 
 */
public function deleteByPk($id){$query = "DELETE FROM $this->tableName  WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($id));}
/**
 * Find all record of table
 * @return Nazioni[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * find by id
 * @return Nazioni[]
 */
public function findById($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($id), $typeResult);}


/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->id))$arrayValue['id']=$this->id;if(isset($this->descrizione))$arrayValue['descrizione']=$this->descrizione;if(isset($this->descrizioneInglese))$arrayValue['descrizione_inglese']=$this->descrizioneInglese;if(isset($this->alpha2))$arrayValue['alpha2']=$this->alpha2;if(isset($this->alpha3))$arrayValue['alpha3']=$this->alpha3;if(isset($this->countryCode))$arrayValue['country_code']=$this->countryCode;if(isset($this->iso31662))$arrayValue['iso_3166_2']=$this->iso31662;if(isset($this->regione))$arrayValue['regione']=$this->regione;if(isset($this->subRegione))$arrayValue['sub_regione']=$this->subRegione;if(isset($this->codiceRegione))$arrayValue['codice_regione']=$this->codiceRegione;if(isset($this->codiceSubRegione))$arrayValue['codice_sub_regione']=$this->codiceSubRegione;if(isset($this->prefissoTelefonico))$arrayValue['prefisso_telefonico']=($this->prefissoTelefonico==self::NULL_VALUE)?null:$this->prefissoTelefonico;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['id'])) || (isset($keyArray['nazioni_id']))) {$this->setId(isset($keyArray['id'])?$keyArray['id']:$keyArray['nazioni_id']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['descrizione'])) || (isset($keyArray['nazioni_descrizione']))) {$this->setDescrizione(isset($keyArray['descrizione'])?$keyArray['descrizione']:$keyArray['nazioni_descrizione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['descrizione_inglese'])) || (isset($keyArray['nazioni_descrizione_inglese']))) {$this->setDescrizioneinglese(isset($keyArray['descrizione_inglese'])?$keyArray['descrizione_inglese']:$keyArray['nazioni_descrizione_inglese']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['alpha2'])) || (isset($keyArray['nazioni_alpha2']))) {$this->setAlpha2(isset($keyArray['alpha2'])?$keyArray['alpha2']:$keyArray['nazioni_alpha2']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['alpha3'])) || (isset($keyArray['nazioni_alpha3']))) {$this->setAlpha3(isset($keyArray['alpha3'])?$keyArray['alpha3']:$keyArray['nazioni_alpha3']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['country_code'])) || (isset($keyArray['nazioni_country_code']))) {$this->setCountrycode(isset($keyArray['country_code'])?$keyArray['country_code']:$keyArray['nazioni_country_code']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['iso_3166_2'])) || (isset($keyArray['nazioni_iso_3166_2']))) {$this->setIso31662(isset($keyArray['iso_3166_2'])?$keyArray['iso_3166_2']:$keyArray['nazioni_iso_3166_2']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['regione'])) || (isset($keyArray['nazioni_regione']))) {$this->setRegione(isset($keyArray['regione'])?$keyArray['regione']:$keyArray['nazioni_regione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['sub_regione'])) || (isset($keyArray['nazioni_sub_regione']))) {$this->setSubregione(isset($keyArray['sub_regione'])?$keyArray['sub_regione']:$keyArray['nazioni_sub_regione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['codice_regione'])) || (isset($keyArray['nazioni_codice_regione']))) {$this->setCodiceregione(isset($keyArray['codice_regione'])?$keyArray['codice_regione']:$keyArray['nazioni_codice_regione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['codice_sub_regione'])) || (isset($keyArray['nazioni_codice_sub_regione']))) {$this->setCodicesubregione(isset($keyArray['codice_sub_regione'])?$keyArray['codice_sub_regione']:$keyArray['nazioni_codice_sub_regione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['prefisso_telefonico'])) || (isset($keyArray['nazioni_prefisso_telefonico']))) {$this->setPrefissotelefonico(isset($keyArray['prefisso_telefonico'])?$keyArray['prefisso_telefonico']:$keyArray['nazioni_prefisso_telefonico']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['id'] =$positionalArray[0];$values['descrizione'] =$positionalArray[1];$values['descrizione_inglese'] =$positionalArray[2];$values['alpha2'] =$positionalArray[3];$values['alpha3'] =$positionalArray[4];$values['country_code'] =$positionalArray[5];$values['iso_3166_2'] =$positionalArray[6];$values['regione'] =$positionalArray[7];$values['sub_regione'] =$positionalArray[8];$values['codice_regione'] =$positionalArray[9];$values['codice_sub_regione'] =$positionalArray[10];$values['prefisso_telefonico'] =($positionalArray[11]==self::NULL_VALUE)?null:$positionalArray[11];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['id'] = null;$values['descrizione'] = null;$values['descrizione_inglese'] = null;$values['alpha2'] = null;$values['alpha3'] = null;$values['country_code'] = null;$values['iso_3166_2'] = null;$values['regione'] = null;$values['sub_regione'] = null;$values['codice_regione'] = null;$values['codice_sub_regione'] = null;$values['prefisso_telefonico'] = null;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'nazioni.id as nazioni_id,nazioni.descrizione as nazioni_descrizione,nazioni.descrizione_inglese as nazioni_descrizione_inglese,nazioni.alpha2 as nazioni_alpha2,nazioni.alpha3 as nazioni_alpha3,nazioni.country_code as nazioni_country_code,nazioni.iso_3166_2 as nazioni_iso_3166_2,nazioni.regione as nazioni_regione,nazioni.sub_regione as nazioni_sub_regione,nazioni.codice_regione as nazioni_codice_regione,nazioni.codice_sub_regione as nazioni_codice_sub_regione,nazioni.prefisso_telefonico as nazioni_prefisso_telefonico';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `nazioni` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descrizione` varchar(255) NOT NULL,
  `descrizione_inglese` varchar(255) NOT NULL,
  `alpha2` varchar(2) NOT NULL,
  `alpha3` varchar(3) NOT NULL,
  `country_code` int(11) NOT NULL,
  `iso_3166_2` varchar(20) NOT NULL,
  `regione` varchar(255) NOT NULL,
  `sub_regione` varchar(255) NOT NULL,
  `codice_regione` varchar(10) NOT NULL,
  `codice_sub_regione` varchar(10) NOT NULL,
  `prefisso_telefonico` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=250 DEFAULT CHARSET=latin1 ");}
/**
 * @return integer
 */
public function getId(){return $this->id;}
/**
 * @param integer $id Id
 */
public function setId($id){$this->id=$id;}
/**
 * @return string
 */
public function getDescrizione(){return $this->descrizione;}
/**
 * @param string $descrizione Descrizione
 * @param int $encodeType
 */
public function setDescrizione($descrizione,$encodeType = self::STR_DEFAULT){$this->descrizione=$this->decodeString($descrizione,$encodeType);}
/**
 * @return string
 */
public function getDescrizioneInglese(){return $this->descrizioneInglese;}
/**
 * @param string $descrizioneInglese DescrizioneInglese
 * @param int $encodeType
 */
public function setDescrizioneInglese($descrizioneInglese,$encodeType = self::STR_DEFAULT){$this->descrizioneInglese=$this->decodeString($descrizioneInglese,$encodeType);}
/**
 * @return string
 */
public function getAlpha2(){return $this->alpha2;}
/**
 * @param string $alpha2 Alpha2
 * @param int $encodeType
 */
public function setAlpha2($alpha2,$encodeType = self::STR_DEFAULT){$this->alpha2=$this->decodeString($alpha2,$encodeType);}
/**
 * @return string
 */
public function getAlpha3(){return $this->alpha3;}
/**
 * @param string $alpha3 Alpha3
 * @param int $encodeType
 */
public function setAlpha3($alpha3,$encodeType = self::STR_DEFAULT){$this->alpha3=$this->decodeString($alpha3,$encodeType);}
/**
 * @return integer
 */
public function getCountryCode(){return $this->countryCode;}
/**
 * @param integer $countryCode CountryCode
 */
public function setCountryCode($countryCode){$this->countryCode=$countryCode;}
/**
 * @return string
 */
public function getIso31662(){return $this->iso31662;}
/**
 * @param string $iso31662 Iso31662
 * @param int $encodeType
 */
public function setIso31662($iso31662,$encodeType = self::STR_DEFAULT){$this->iso31662=$this->decodeString($iso31662,$encodeType);}
/**
 * @return string
 */
public function getRegione(){return $this->regione;}
/**
 * @param string $regione Regione
 * @param int $encodeType
 */
public function setRegione($regione,$encodeType = self::STR_DEFAULT){$this->regione=$this->decodeString($regione,$encodeType);}
/**
 * @return string
 */
public function getSubRegione(){return $this->subRegione;}
/**
 * @param string $subRegione SubRegione
 * @param int $encodeType
 */
public function setSubRegione($subRegione,$encodeType = self::STR_DEFAULT){$this->subRegione=$this->decodeString($subRegione,$encodeType);}
/**
 * @return string
 */
public function getCodiceRegione(){return $this->codiceRegione;}
/**
 * @param string $codiceRegione CodiceRegione
 * @param int $encodeType
 */
public function setCodiceRegione($codiceRegione,$encodeType = self::STR_DEFAULT){$this->codiceRegione=$this->decodeString($codiceRegione,$encodeType);}
/**
 * @return string
 */
public function getCodiceSubRegione(){return $this->codiceSubRegione;}
/**
 * @param string $codiceSubRegione CodiceSubRegione
 * @param int $encodeType
 */
public function setCodiceSubRegione($codiceSubRegione,$encodeType = self::STR_DEFAULT){$this->codiceSubRegione=$this->decodeString($codiceSubRegione,$encodeType);}
/**
 * @return integer
 */
public function getPrefissoTelefonico(){return $this->prefissoTelefonico;}
/**
 * @param integer $prefissoTelefonico PrefissoTelefonico
 */
public function setPrefissoTelefonico($prefissoTelefonico){$this->prefissoTelefonico=$prefissoTelefonico;}
}