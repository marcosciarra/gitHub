<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-15
* Time: 11:42:56.152088
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class NewsModel extends PdaAbstractModel {
/** @var integer */
protected $id;
/** @var string */
protected $data;
/** @var string */
protected $titolo;
/** @var string */
protected $descrizione;
/** @var string */
protected $link;
/** @var integer */
protected $cestino=0;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='news';$this->tableName='news';}

/**
 * find by tables' Primary Key: 
 * @return News|array|string|null
 */
public function findByPk($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($id), $typeResult);}
/**
 * delete by tables' Primary Key: 
 */
public function deleteByPk($id){$query = "DELETE FROM $this->tableName  WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($id));}
/**
 * Find all record of table
 * @return News[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * find by id
 * @return News[]
 */
public function findById($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($id), $typeResult);}


/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->id))$arrayValue['id']=$this->id;if(isset($this->data))$arrayValue['data']=($this->data==self::NULL_VALUE)?null:$this->data;if(isset($this->titolo))$arrayValue['titolo']=($this->titolo==self::NULL_VALUE)?null:$this->titolo;if(isset($this->descrizione))$arrayValue['descrizione']=($this->descrizione==self::NULL_VALUE)?null:$this->descrizione;if(isset($this->link))$arrayValue['link']=($this->link==self::NULL_VALUE)?null:$this->link;if(isset($this->cestino))$arrayValue['cestino']=($this->cestino==self::NULL_VALUE)?null:$this->cestino;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['id'])) || (isset($keyArray['news_id']))) {$this->setId(isset($keyArray['id'])?$keyArray['id']:$keyArray['news_id']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['data'])) || (isset($keyArray['news_data']))) {$this->setData(isset($keyArray['data'])?$keyArray['data']:$keyArray['news_data']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['titolo'])) || (isset($keyArray['news_titolo']))) {$this->setTitolo(isset($keyArray['titolo'])?$keyArray['titolo']:$keyArray['news_titolo']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['descrizione'])) || (isset($keyArray['news_descrizione']))) {$this->setDescrizione(isset($keyArray['descrizione'])?$keyArray['descrizione']:$keyArray['news_descrizione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['link'])) || (isset($keyArray['news_link']))) {$this->setLink(isset($keyArray['link'])?$keyArray['link']:$keyArray['news_link']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['cestino'])) || (isset($keyArray['news_cestino']))) {$this->setCestino(isset($keyArray['cestino'])?$keyArray['cestino']:$keyArray['news_cestino']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['id'] =$positionalArray[0];$values['data'] =($positionalArray[1]==self::NULL_VALUE)?null:$positionalArray[1];$values['titolo'] =($positionalArray[2]==self::NULL_VALUE)?null:$positionalArray[2];$values['descrizione'] =($positionalArray[3]==self::NULL_VALUE)?null:$positionalArray[3];$values['link'] =($positionalArray[4]==self::NULL_VALUE)?null:$positionalArray[4];$values['cestino'] =($positionalArray[5]==self::NULL_VALUE)?null:$positionalArray[5];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['id'] = null;$values['data'] = null;$values['titolo'] = null;$values['descrizione'] = null;$values['link'] = null;$values['cestino'] = 0;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'news.id as news_id,news.data as news_data,news.titolo as news_titolo,news.descrizione as news_descrizione,news.link as news_link,news.cestino as news_cestino';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data` date DEFAULT NULL,
  `titolo` varchar(250) DEFAULT NULL,
  `descrizione` longtext,
  `link` varchar(250) DEFAULT NULL,
  `cestino` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ");}
/**
 * @return integer
 */
public function getId(){return $this->id;}
/**
 * @param integer $id Id
 */
public function setId($id){$this->id=$id;}
/**
 * @return string
 */
public function getData(){return $this->data;}
/**
 * @param string $data Data
 * @param int $encodeType
 */
public function setData($data,$encodeType = self::STR_DEFAULT){$this->data=$this->decodeString($data,$encodeType);}
/**
 * @return string
 */
public function getTitolo(){return $this->titolo;}
/**
 * @param string $titolo Titolo
 * @param int $encodeType
 */
public function setTitolo($titolo,$encodeType = self::STR_DEFAULT){$this->titolo=$this->decodeString($titolo,$encodeType);}
/**
 * @return string
 */
public function getDescrizione(){return $this->descrizione;}
/**
 * @param string $descrizione Descrizione
 * @param int $encodeType
 */
public function setDescrizione($descrizione,$encodeType = self::STR_DEFAULT){$this->descrizione=$this->decodeString($descrizione,$encodeType);}
/**
 * @return string
 */
public function getLink(){return $this->link;}
/**
 * @param string $link Link
 * @param int $encodeType
 */
public function setLink($link,$encodeType = self::STR_DEFAULT){$this->link=$this->decodeString($link,$encodeType);}
/**
 * @return integer
 */
public function getCestino(){return $this->cestino;}
/**
 * @param integer $cestino Cestino
 */
public function setCestino($cestino){$this->cestino=$cestino;}
}