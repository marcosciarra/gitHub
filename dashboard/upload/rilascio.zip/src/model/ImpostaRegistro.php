<?php
/**
 * Created by Drakkar vers. 0.1.0(Hjortspring)
 * User: P.D.A. Srl
 * Date: 2018-04-04
 * Time: 17:19:13.557922
 */

namespace Click\Affitti\TblBase;
require_once 'ImpostaRegistroModel.php';
require_once 'Rli.php';

use Click\Affitti\TblBase\ImpostaRegistroModel;
use Click\Affitti\TblBase\Rli;

class  ImpostaRegistro extends ImpostaRegistroModel
{
    function __construct($pdo)
    {
        parent::__construct($pdo);
    }


    //FIXME:: Da cancellare successivamente
    public static function getListColumnsStatic()
    {
        $app = new self(null);
        return $app->getListColumns();
    }

    /**
     * find by tables' Primary Key:
     * @return ImpostaRegistro|array|string|null
     */
    public function findImposteRegistroDaIdContratto($idContratto, $idGestione, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT imposta_registro.*,rate.id_gestione as idGestioneRate, rate.id AS idRata FROM imposta_registro
inner join rate_dettagli on rate_dettagli.id_imposta_registro=imposta_registro.id
inner join rate on rate_dettagli.id_rata=rate.id
inner join gestioni on rate.id_gestione=gestioni.id
inner join periodi_contrattuali on gestioni.id_periodo_contrattuale=periodi_contrattuali.id 
WHERE periodi_contrattuali.id_contratto=? AND imposta_registro.id_gestione=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultArray($query, array($idContratto, $idGestione), $typeResult);
    }

    /**
     * @param $dataInizio
     * @param $dataFine
     * @param int $typeResult
     * @return ImpostaRegistro[]|string
     */
    public function findProrogheByPeriodo($dataInizio, $dataFine, $typeResult = self::FETCH_OBJ)
    {
        $query =
            "
            SELECT 
                imposta_registro.*,
                contratti.id as id_contratto
            FROM
                imposta_registro
                INNER JOIN rli ON imposta_registro.id_rli=rli.id
                INNER JOIN contratti ON rli.id_contratto=contratti.id
            WHERE
                data_scadenza BETWEEN ? AND ?
                    AND data_versamento IS NULL
                    AND contratti.cestino=0
                    AND contratti.elaborato=1
                    AND rli.codice_identificativo IS NOT NULL
                    AND imposta_registro.importo_totale > 0
                    AND rli.id_contribuente > 0
                    AND rli.id_coobbligato > 0
            ORDER BY data_scadenza ASC
            ";
        return $this->createResultArray($query, array($dataInizio, $dataFine), $typeResult);
    }

    /**
     * @param $oggi
     * @return ImpostaRegistro[]|string
     */
    public function findProrogheArretrate($oggi, $typeResult = self::FETCH_OBJ)
    {
        $query = "
                    SELECT
                      imposta_registro.*,contratti.id as id_contratto
                    FROM
                        imposta_registro
                        INNER JOIN rli ON imposta_registro.id_rli=rli.id
                        INNER JOIN contratti ON rli.id_contratto=contratti.id
                    WHERE
                        data_scadenza < ?
                        AND data_versamento IS NULL
                        AND contratti.cestino=0
                        AND contratti.elaborato=1
                        AND rli.codice_identificativo IS NOT NULL
                        AND imposta_registro.importo_totale > 0
                        AND rli.id_contribuente > 0
                        AND rli.id_coobbligato > 0
                    ORDER BY data_scadenza ASC
                    ";


        return $this->createResultArray($query, array($oggi), $typeResult);
    }

    /*
     * FIXME::Modificare la chiamata per aggiornare l'imposta di registro
     */
    public function calcolaCanonePerImpostaDiRegistro($idGestione)
    {
        $query = "
        SELECT 
          SUM(importo) as importo 
        FROM 
          piano_rate_testa 
        where 
          tipo_spesa='C'
          AND tipo_saldo='F'
          AND id_gestione=?
        ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        return $this->createResultValue($query, array($idGestione));
    }

    /**
     * @return int
     */
    public function getIdContratto()
    {
        $query = "SELECT rli.id_contratto 
                    FROM imposta_registro
                    INNER JOIN rli 
                    ON imposta_registro.id_rli=rli.id
                    WHERE imposta_registro.id=?";
        return $this->createResultValue($query, array($this->id));
    }


    public function findByIdContrattoVersati($idContratto, $typeResult = self::FETCH_OBJ)
    {
        $query =
            "
            SELECT 
                imposta_registro.*
            FROM
                imposta_registro
                    INNER JOIN
                rli ON imposta_registro.id_rli = rli.id
            WHERE
                imposta_registro.data_versamento IS NOT NULL
                    AND rli.id_contratto = ?
            ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        return $this->createResultArray($query, array($idContratto), $typeResult);
    }


    public function findByIdContrattoNonVersati($idContratto, $typeResult = self::FETCH_OBJ)
    {
        $query =
            "
            SELECT 
                imposta_registro.*
            FROM
                imposta_registro
                    INNER JOIN
                rli ON imposta_registro.id_rli = rli.id
            WHERE
                imposta_registro.data_versamento IS NULL
                    AND rli.id_contratto = ?
            ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        return $this->createResultArray($query, array($idContratto), $typeResult);
    }


    public function getElencoAbiById($ids)
    {
        $query =
            "
            SELECT DISTINCT
                conti_correnti.abi
            FROM
                imposta_registro
                INNER JOIN rli ON imposta_registro.id_rli=rli.id
                INNER JOIN conti_correnti ON rli.id_conto_corrente=conti_correnti.id
                where imposta_registro.id IN (" . implode(',', $ids) . ")
            ";
//        if ($this->whereBase) $query .= " WHERE $this->whereBase";
//        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        return $this->createResultArray($query, array(), ImpostaRegistro::FETCH_KEYARRAY);
    }


    public function findByIdContratto($idContratto, $typeResult = self::FETCH_OBJ)
    {
        $query =
            "
            SELECT 
                imposta_registro.*
            FROM
                imposta_registro
                    INNER JOIN
                rli ON imposta_registro.id_rli = rli.id
            WHERE
                rli.id_contratto = ?
            ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        return $this->createResultArray($query, array($idContratto), $typeResult);
    }


}