<?php
/**
 * Created by Drakkar vers. 0.0.22(Hjortspring)
 * User: P.D.A. Srl
 * Date: 2017-11-27
 * Time: 18:25:51.896747
 */

namespace Click\Affitti\TblBase;
require_once 'CanoniOneriModel.php';

use Click\Affitti\TblBase\CanoniOneriModel;

class  CanoniOneri extends CanoniOneriModel
{
    function __construct($pdo)
    {
        parent::__construct($pdo);
    }

    public function getTipoSpesa($decode = false)
    {
        if ($decode) {
            return $this->getElencoTipoSpesa()[parent::getTipoSpesa()];
        } else {
            return parent::getTipoSpesa();
        }
    }


    public function getElencoTipoSpesa($json = false)
    {
        $appoggio = $this->getTipoSpesaValuesList();
        if ($json == false) {
            return $appoggio;
        } else {
            return $this->createJsonKeyValArray($appoggio, 'id', 'descrizione');
        }

    }


    public function getTipoSaldo($decode = false)
    {
        if ($decode) {
            return $this->getElencotipoSaldo()[parent::getTipoSaldo()];
        } else {
            return parent::getTipoSaldo();
        }
    }


    public function getElencotipoSaldo($json = false)
    {
        $appoggio = $this->gettipoSaldoValuesList();
        if ($json == false) {
            return $appoggio;
        } else {
            return $this->createJsonKeyValArray($appoggio, 'id', 'descrizione');
        }
    }

    public function findByIdPianoRateTesta($idPianoRateTesta, $typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $query = "SELECT canoni_oneri.* FROM canoni_oneri 
                  INNER JOIN piano_rate_testa ON canoni_oneri.id=piano_rate_testa.id_canoni_oneri
                  WHERE piano_rate_testa.id=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResult($query, array($idPianoRateTesta), $typeResult);
    }

}