<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-15
* Time: 11:42:47.779932
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class RateDettagliModel extends PdaAbstractModel {
/** @var integer */
protected $id;
/** @var integer */
protected $idRata;
/** @var integer */
protected $idTipoIva;
/** @var string A = AFFITTO<br/>B = BOLLO<br/>C = CONGUAGLIO<br/>E = ESTEMPORANEA<br/>F = SPESA FORFETTARIA<br/>I = IVA<br/>R = IMPOSTA REGISTRO<br/>S = SPESA<br/>T = ISTAT*/
protected $idCategoriaSpesa;
/** @var string (enum) E = Estemporanea<br/>C = Canone<br/>O = Onere<br/>I = Imposte<br/>*/
protected $tipoSpesa;
/** @var string (enum) F = Forfettario<br/>C = A Conguaglio*/
protected $tipoSaldo;
/** @var string */
protected $descrizione;
/** @var double */
protected $imponibile=0;
/** @var double */
protected $importo=0;
/** @var integer */
protected $idPianoRateDettagli;
/** @var integer */
protected $idImpostaRegistro;
/** @var integer */
protected $idConduttoreAssociato;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='rate_dettagli';$this->tableName='rate_dettagli';}

/**
 * find by tables' Primary Key: 
 * @return RateDettagli|array|string|null
 */
public function findByPk($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($id), $typeResult);}
/**
 * delete by tables' Primary Key: 
 */
public function deleteByPk($id){$query = "DELETE FROM $this->tableName  WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($id));}
/**
 * Find all record of table
 * @return RateDettagli[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * find by tables' Key idx_id_imposta_registro: 
 * @return RateDettagli|array|string
 */
public function findByIdxIdImpostaRegistro($idImpostaRegistro,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(idx_id_imposta_registro) WHERE id_imposta_registro=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($idImpostaRegistro), $typeResult);}

/**
 * find by tables' Key idx_id_rata: 
 * @return RateDettagli[]|array|string
 */
public function findByIdxIdRata($idRata,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_id_rata) WHERE id_rata=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($idRata), $typeResult);}

/**
 * find by tables' Key idx_id_tipo_iva: 
 * @return RateDettagli[]|array|string
 */
public function findByIdxIdTipoIva($idTipoIva,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_id_tipo_iva) WHERE id_tipo_iva=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($idTipoIva), $typeResult);}

/**
 * find by tables' Key idx_id_piano_rate_dettagli: 
 * @return RateDettagli[]|array|string
 */
public function findByIdxIdPianoRateDettagli($idPianoRateDettagli,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_id_piano_rate_dettagli) WHERE id_piano_rate_dettagli=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($idPianoRateDettagli), $typeResult);}

/**
 * delete by tables' Key idx_id_imposta_registro: 
 * @return boolean
 */
public function deleteByIdxIdImpostaRegistro($idImpostaRegistro,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_imposta_registro=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idImpostaRegistro));}
/**
 * delete by tables' Key idx_id_rata: 
 * @return boolean
 */
public function deleteByIdxIdRata($idRata,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_rata=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idRata));}
/**
 * delete by tables' Key idx_id_tipo_iva: 
 * @return boolean
 */
public function deleteByIdxIdTipoIva($idTipoIva,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_tipo_iva=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idTipoIva));}
/**
 * delete by tables' Key idx_id_piano_rate_dettagli: 
 * @return boolean
 */
public function deleteByIdxIdPianoRateDettagli($idPianoRateDettagli,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_piano_rate_dettagli=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idPianoRateDettagli));}
/**
 * find by id
 * @return RateDettagli[]
 */
public function findById($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($id), $typeResult);}


/**
 * find by id_rata
 * @return RateDettagli[]
 */
public function findByIdRata($idRata,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id_rata=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($idRata), $typeResult);}


/**
 * find by id_tipo_iva
 * @return RateDettagli[]
 */
public function findByIdTipoIva($idTipoIva,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id_tipo_iva=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($idTipoIva), $typeResult);}


/**
 * find by id_piano_rate_dettagli
 * @return RateDettagli[]
 */
public function findByIdPianoRateDettagli($idPianoRateDettagli,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id_piano_rate_dettagli=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($idPianoRateDettagli), $typeResult);}


/**
 * find by id_imposta_registro
 * @return RateDettagli
 */
public function findByIdImpostaRegistro($idImpostaRegistro,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id_imposta_registro=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResult($query, array($idImpostaRegistro), $typeResult);}


/**
 * delete by id_rata
 * @return boolean
 */
public function deleteByIdRata($idRata){$query = "DELETE FROM $this->tableName WHERE id_rata=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idRata));}

/**
 * delete by id_tipo_iva
 * @return boolean
 */
public function deleteByIdTipoIva($idTipoIva){$query = "DELETE FROM $this->tableName WHERE id_tipo_iva=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idTipoIva));}

/**
 * delete by id_piano_rate_dettagli
 * @return boolean
 */
public function deleteByIdPianoRateDettagli($idPianoRateDettagli){$query = "DELETE FROM $this->tableName WHERE id_piano_rate_dettagli=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idPianoRateDettagli));}

/**
 * delete by id_imposta_registro
 * @return boolean
 */
public function deleteByIdImpostaRegistro($idImpostaRegistro){$query = "DELETE FROM $this->tableName WHERE id_imposta_registro=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idImpostaRegistro));}

/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->id))$arrayValue['id']=$this->id;if(isset($this->idRata))$arrayValue['id_rata']=$this->idRata;if(isset($this->idTipoIva))$arrayValue['id_tipo_iva']=$this->idTipoIva;if(isset($this->idCategoriaSpesa))$arrayValue['id_categoria_spesa']=($this->idCategoriaSpesa==self::NULL_VALUE)?null:$this->idCategoriaSpesa;if(isset($this->tipoSpesa))$arrayValue['tipo_spesa']=$this->tipoSpesa;if(isset($this->tipoSaldo))$arrayValue['tipo_saldo']=$this->tipoSaldo;if(isset($this->descrizione))$arrayValue['descrizione']=$this->descrizione;if(isset($this->imponibile))$arrayValue['imponibile']=$this->imponibile;if(isset($this->importo))$arrayValue['importo']=$this->importo;if(isset($this->idPianoRateDettagli))$arrayValue['id_piano_rate_dettagli']=($this->idPianoRateDettagli==self::NULL_VALUE)?null:$this->idPianoRateDettagli;if(isset($this->idImpostaRegistro))$arrayValue['id_imposta_registro']=($this->idImpostaRegistro==self::NULL_VALUE)?null:$this->idImpostaRegistro;if(isset($this->idConduttoreAssociato))$arrayValue['id_conduttore_associato']=($this->idConduttoreAssociato==self::NULL_VALUE)?null:$this->idConduttoreAssociato;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['id'])) || (isset($keyArray['rate_dettagli_id']))) {$this->setId(isset($keyArray['id'])?$keyArray['id']:$keyArray['rate_dettagli_id']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_rata'])) || (isset($keyArray['rate_dettagli_id_rata']))) {$this->setIdrata(isset($keyArray['id_rata'])?$keyArray['id_rata']:$keyArray['rate_dettagli_id_rata']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_tipo_iva'])) || (isset($keyArray['rate_dettagli_id_tipo_iva']))) {$this->setIdtipoiva(isset($keyArray['id_tipo_iva'])?$keyArray['id_tipo_iva']:$keyArray['rate_dettagli_id_tipo_iva']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_categoria_spesa'])) || (isset($keyArray['rate_dettagli_id_categoria_spesa']))) {$this->setIdcategoriaspesa(isset($keyArray['id_categoria_spesa'])?$keyArray['id_categoria_spesa']:$keyArray['rate_dettagli_id_categoria_spesa']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['tipo_spesa'])) || (isset($keyArray['rate_dettagli_tipo_spesa']))) {$this->setTipospesa(isset($keyArray['tipo_spesa'])?$keyArray['tipo_spesa']:$keyArray['rate_dettagli_tipo_spesa']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['tipo_saldo'])) || (isset($keyArray['rate_dettagli_tipo_saldo']))) {$this->setTiposaldo(isset($keyArray['tipo_saldo'])?$keyArray['tipo_saldo']:$keyArray['rate_dettagli_tipo_saldo']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['descrizione'])) || (isset($keyArray['rate_dettagli_descrizione']))) {$this->setDescrizione(isset($keyArray['descrizione'])?$keyArray['descrizione']:$keyArray['rate_dettagli_descrizione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['imponibile'])) || (isset($keyArray['rate_dettagli_imponibile']))) {$this->setImponibile(isset($keyArray['imponibile'])?$keyArray['imponibile']:$keyArray['rate_dettagli_imponibile']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['importo'])) || (isset($keyArray['rate_dettagli_importo']))) {$this->setImporto(isset($keyArray['importo'])?$keyArray['importo']:$keyArray['rate_dettagli_importo']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_piano_rate_dettagli'])) || (isset($keyArray['rate_dettagli_id_piano_rate_dettagli']))) {$this->setIdpianoratedettagli(isset($keyArray['id_piano_rate_dettagli'])?$keyArray['id_piano_rate_dettagli']:$keyArray['rate_dettagli_id_piano_rate_dettagli']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_imposta_registro'])) || (isset($keyArray['rate_dettagli_id_imposta_registro']))) {$this->setIdimpostaregistro(isset($keyArray['id_imposta_registro'])?$keyArray['id_imposta_registro']:$keyArray['rate_dettagli_id_imposta_registro']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_conduttore_associato'])) || (isset($keyArray['rate_dettagli_id_conduttore_associato']))) {$this->setIdconduttoreassociato(isset($keyArray['id_conduttore_associato'])?$keyArray['id_conduttore_associato']:$keyArray['rate_dettagli_id_conduttore_associato']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['id'] =$positionalArray[0];$values['id_rata'] =$positionalArray[1];$values['id_tipo_iva'] =$positionalArray[2];$values['id_categoria_spesa'] =($positionalArray[3]==self::NULL_VALUE)?null:$positionalArray[3];$values['tipo_spesa'] =$positionalArray[4];$values['tipo_saldo'] =$positionalArray[5];$values['descrizione'] =$positionalArray[6];$values['imponibile'] =$positionalArray[7];$values['importo'] =$positionalArray[8];$values['id_piano_rate_dettagli'] =($positionalArray[9]==self::NULL_VALUE)?null:$positionalArray[9];$values['id_imposta_registro'] =($positionalArray[10]==self::NULL_VALUE)?null:$positionalArray[10];$values['id_conduttore_associato'] =($positionalArray[11]==self::NULL_VALUE)?null:$positionalArray[11];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['id'] = null;$values['id_rata'] = null;$values['id_tipo_iva'] = null;$values['id_categoria_spesa'] = null;$values['tipo_spesa'] = null;$values['tipo_saldo'] = null;$values['descrizione'] = null;$values['imponibile'] = 0;$values['importo'] = 0;$values['id_piano_rate_dettagli'] = null;$values['id_imposta_registro'] = null;$values['id_conduttore_associato'] = null;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'rate_dettagli.id as rate_dettagli_id,rate_dettagli.id_rata as rate_dettagli_id_rata,rate_dettagli.id_tipo_iva as rate_dettagli_id_tipo_iva,rate_dettagli.id_categoria_spesa as rate_dettagli_id_categoria_spesa,rate_dettagli.tipo_spesa as rate_dettagli_tipo_spesa,rate_dettagli.tipo_saldo as rate_dettagli_tipo_saldo,rate_dettagli.descrizione as rate_dettagli_descrizione,rate_dettagli.imponibile as rate_dettagli_imponibile,rate_dettagli.importo as rate_dettagli_importo,rate_dettagli.id_piano_rate_dettagli as rate_dettagli_id_piano_rate_dettagli,rate_dettagli.id_imposta_registro as rate_dettagli_id_imposta_registro,rate_dettagli.id_conduttore_associato as rate_dettagli_id_conduttore_associato';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `rate_dettagli` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_rata` int(10) unsigned NOT NULL,
  `id_tipo_iva` int(10) unsigned NOT NULL,
  `id_categoria_spesa` varchar(1) DEFAULT NULL COMMENT 'A = AFFITTO\nB = BOLLO\nC = CONGUAGLIO\nE = ESTEMPORANEA\nF = SPESA FORFETTARIA\nI = IVA\nR = IMPOSTA REGISTRO\nS = SPESA\nT = ISTAT',
  `tipo_spesa` enum('E','C','O','I') NOT NULL COMMENT 'E = Estemporanea\nC = Canone\nO = Onere\nI = Imposte\n',
  `tipo_saldo` enum('C','F') NOT NULL COMMENT 'F = Forfettario\nC = A Conguaglio',
  `descrizione` varchar(45) NOT NULL,
  `imponibile` double NOT NULL DEFAULT '0',
  `importo` double NOT NULL DEFAULT '0',
  `id_piano_rate_dettagli` int(10) unsigned DEFAULT NULL,
  `id_imposta_registro` int(10) unsigned DEFAULT NULL,
  `id_conduttore_associato` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_id_imposta_registro` (`id_imposta_registro`),
  KEY `idx_id_rata` (`id_rata`),
  KEY `idx_id_tipo_iva` (`id_tipo_iva`),
  KEY `idx_id_piano_rate_dettagli` (`id_piano_rate_dettagli`),
  CONSTRAINT `fk_id_rata` FOREIGN KEY (`id_rata`) REFERENCES `rate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_id_tipo_iva` FOREIGN KEY (`id_tipo_iva`) REFERENCES `tipi_iva` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_rate_dettagli_1` FOREIGN KEY (`id_piano_rate_dettagli`) REFERENCES `piani_rate_dettagli` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4615 DEFAULT CHARSET=latin1 ");}
/**
 * @return integer
 */
public function getId(){return $this->id;}
/**
 * @param integer $id Id
 */
public function setId($id){$this->id=$id;}
/**
 * @return integer
 */
public function getIdRata(){return $this->idRata;}
/**
 * @param integer $idRata IdRata
 */
public function setIdRata($idRata){$this->idRata=$idRata;}
/**
 * @return integer
 */
public function getIdTipoIva(){return $this->idTipoIva;}
/**
 * @param integer $idTipoIva IdTipoIva
 */
public function setIdTipoIva($idTipoIva){$this->idTipoIva=$idTipoIva;}
/**
 * @return string
 */
public function getIdCategoriaSpesa(){return $this->idCategoriaSpesa;}
/**
 * @param string $idCategoriaSpesa IdCategoriaSpesa
 * @param int $encodeType
 */
public function setIdCategoriaSpesa($idCategoriaSpesa,$encodeType = self::STR_DEFAULT){$this->idCategoriaSpesa=$this->decodeString($idCategoriaSpesa,$encodeType);}
/**
 * @param bool $decode if true return decode value * @return string
 */
public function getTipoSpesa($decode=false){return ($decode)?$this->getTipoSpesaValuesList()[$this->tipoSpesa]:$this->tipoSpesa;}
/**
 * @param bool $json if true return value json's array else return array values * @return array|string
 */
public function getTipoSpesaValuesList($json=false){$kv=['E'=>'Estemporanea','C'=>'Canone','O'=>'Onere','I'=>'Imposte'];return ($json)?$this->createJsonKeyValArray($kv):$kv;}
/**
 * @param string (enum) $tipoSpesa TipoSpesa
 */
public function setTipoSpesa($tipoSpesa){$this->tipoSpesa=$tipoSpesa;}
/**
 * @param bool $decode if true return decode value * @return string
 */
public function getTipoSaldo($decode=false){return ($decode)?$this->getTipoSaldoValuesList()[$this->tipoSaldo]:$this->tipoSaldo;}
/**
 * @param bool $json if true return value json's array else return array values * @return array|string
 */
public function getTipoSaldoValuesList($json=false){$kv=['F'=>'Forfettario','C'=>'A Conguaglio'];return ($json)?$this->createJsonKeyValArray($kv):$kv;}
/**
 * @param string (enum) $tipoSaldo TipoSaldo
 */
public function setTipoSaldo($tipoSaldo){$this->tipoSaldo=$tipoSaldo;}
/**
 * @return string
 */
public function getDescrizione(){return $this->descrizione;}
/**
 * @param string $descrizione Descrizione
 * @param int $encodeType
 */
public function setDescrizione($descrizione,$encodeType = self::STR_DEFAULT){$this->descrizione=$this->decodeString($descrizione,$encodeType);}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getImponibile($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->imponibile:number_format($this->imponibile,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $imponibile Imponibile
 */
public function setImponibile($imponibile){$this->imponibile=$imponibile;}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getImporto($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->importo:number_format($this->importo,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $importo Importo
 */
public function setImporto($importo){$this->importo=$importo;}
/**
 * @return integer
 */
public function getIdPianoRateDettagli(){return $this->idPianoRateDettagli;}
/**
 * @param integer $idPianoRateDettagli IdPianoRateDettagli
 */
public function setIdPianoRateDettagli($idPianoRateDettagli){$this->idPianoRateDettagli=$idPianoRateDettagli;}
/**
 * @return integer
 */
public function getIdImpostaRegistro(){return $this->idImpostaRegistro;}
/**
 * @param integer $idImpostaRegistro IdImpostaRegistro
 */
public function setIdImpostaRegistro($idImpostaRegistro){$this->idImpostaRegistro=$idImpostaRegistro;}
/**
 * @return integer
 */
public function getIdConduttoreAssociato(){return $this->idConduttoreAssociato;}
/**
 * @param integer $idConduttoreAssociato IdConduttoreAssociato
 */
public function setIdConduttoreAssociato($idConduttoreAssociato){$this->idConduttoreAssociato=$idConduttoreAssociato;}
}