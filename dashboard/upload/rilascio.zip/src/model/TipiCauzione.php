<?php
/**
 * Created by Drakkar vers. 0.0.22(Hjortspring)
 * User: P.D.A. Srl
 * Date: 2017-11-27
 * Time: 18:25:51.978533
 */
namespace Click\Affitti\TblBase;
require_once 'TipiCauzioneModel.php';
use Click\Affitti\TblBase\TipiCauzioneModel;

class  TipiCauzione extends TipiCauzioneModel {
    function __construct($pdo){parent::__construct($pdo);}

}