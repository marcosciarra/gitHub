<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-15
* Time: 11:42:47.476048
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class FatturazioneDettagliModel extends PdaAbstractModel {
/** @var integer */
protected $id;
/** @var integer */
protected $idFatturazioneTesta;
/** @var integer */
protected $idTipoIva;
/** @var string */
protected $idCategoriaSpese;
/** @var string */
protected $descrizione;
/** @var string */
protected $dataInizio;
/** @var string */
protected $dataFine;
/** @var double */
protected $imponibile;
/** @var double */
protected $importo;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='fatturazione_dettagli';$this->tableName='fatturazione_dettagli';}

/**
 * find by tables' Primary Key: 
 * @return FatturazioneDettagli|array|string|null
 */
public function findByPk($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($id), $typeResult);}
/**
 * delete by tables' Primary Key: 
 */
public function deleteByPk($id){$query = "DELETE FROM $this->tableName  WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($id));}
/**
 * Find all record of table
 * @return FatturazioneDettagli[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * find by tables' Key idx_id_fatturazione_testa: 
 * @return FatturazioneDettagli[]|array|string
 */
public function findByIdxIdFatturazioneTesta($idFatturazioneTesta,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_id_fatturazione_testa) WHERE id_fatturazione_testa=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($idFatturazioneTesta), $typeResult);}

/**
 * find by tables' Key idx_id_tipo_iva: 
 * @return FatturazioneDettagli[]|array|string
 */
public function findByIdxIdTipoIva($idTipoIva,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_id_tipo_iva) WHERE id_tipo_iva=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($idTipoIva), $typeResult);}

/**
 * delete by tables' Key idx_id_fatturazione_testa: 
 * @return boolean
 */
public function deleteByIdxIdFatturazioneTesta($idFatturazioneTesta,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_fatturazione_testa=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idFatturazioneTesta));}
/**
 * delete by tables' Key idx_id_tipo_iva: 
 * @return boolean
 */
public function deleteByIdxIdTipoIva($idTipoIva,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_tipo_iva=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idTipoIva));}
/**
 * find by id
 * @return FatturazioneDettagli[]
 */
public function findById($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($id), $typeResult);}


/**
 * find by id_fatturazione_testa
 * @return FatturazioneDettagli[]
 */
public function findByIdFatturazioneTesta($idFatturazioneTesta,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id_fatturazione_testa=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($idFatturazioneTesta), $typeResult);}


/**
 * find by id_tipo_iva
 * @return FatturazioneDettagli[]
 */
public function findByIdTipoIva($idTipoIva,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id_tipo_iva=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($idTipoIva), $typeResult);}


/**
 * delete by id_fatturazione_testa
 * @return boolean
 */
public function deleteByIdFatturazioneTesta($idFatturazioneTesta){$query = "DELETE FROM $this->tableName WHERE id_fatturazione_testa=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idFatturazioneTesta));}

/**
 * delete by id_tipo_iva
 * @return boolean
 */
public function deleteByIdTipoIva($idTipoIva){$query = "DELETE FROM $this->tableName WHERE id_tipo_iva=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idTipoIva));}

/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->id))$arrayValue['id']=$this->id;if(isset($this->idFatturazioneTesta))$arrayValue['id_fatturazione_testa']=$this->idFatturazioneTesta;if(isset($this->idTipoIva))$arrayValue['id_tipo_iva']=$this->idTipoIva;if(isset($this->idCategoriaSpese))$arrayValue['id_categoria_spese']=($this->idCategoriaSpese==self::NULL_VALUE)?null:$this->idCategoriaSpese;if(isset($this->descrizione))$arrayValue['descrizione']=($this->descrizione==self::NULL_VALUE)?null:$this->descrizione;if(isset($this->dataInizio))$arrayValue['data_inizio']=($this->dataInizio==self::NULL_VALUE)?null:$this->dataInizio;if(isset($this->dataFine))$arrayValue['data_fine']=($this->dataFine==self::NULL_VALUE)?null:$this->dataFine;if(isset($this->imponibile))$arrayValue['imponibile']=($this->imponibile==self::NULL_VALUE)?null:$this->imponibile;if(isset($this->importo))$arrayValue['importo']=($this->importo==self::NULL_VALUE)?null:$this->importo;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['id'])) || (isset($keyArray['fatturazione_dettagli_id']))) {$this->setId(isset($keyArray['id'])?$keyArray['id']:$keyArray['fatturazione_dettagli_id']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_fatturazione_testa'])) || (isset($keyArray['fatturazione_dettagli_id_fatturazione_testa']))) {$this->setIdfatturazionetesta(isset($keyArray['id_fatturazione_testa'])?$keyArray['id_fatturazione_testa']:$keyArray['fatturazione_dettagli_id_fatturazione_testa']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_tipo_iva'])) || (isset($keyArray['fatturazione_dettagli_id_tipo_iva']))) {$this->setIdtipoiva(isset($keyArray['id_tipo_iva'])?$keyArray['id_tipo_iva']:$keyArray['fatturazione_dettagli_id_tipo_iva']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_categoria_spese'])) || (isset($keyArray['fatturazione_dettagli_id_categoria_spese']))) {$this->setIdcategoriaspese(isset($keyArray['id_categoria_spese'])?$keyArray['id_categoria_spese']:$keyArray['fatturazione_dettagli_id_categoria_spese']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['descrizione'])) || (isset($keyArray['fatturazione_dettagli_descrizione']))) {$this->setDescrizione(isset($keyArray['descrizione'])?$keyArray['descrizione']:$keyArray['fatturazione_dettagli_descrizione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['data_inizio'])) || (isset($keyArray['fatturazione_dettagli_data_inizio']))) {$this->setDatainizio(isset($keyArray['data_inizio'])?$keyArray['data_inizio']:$keyArray['fatturazione_dettagli_data_inizio']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['data_fine'])) || (isset($keyArray['fatturazione_dettagli_data_fine']))) {$this->setDatafine(isset($keyArray['data_fine'])?$keyArray['data_fine']:$keyArray['fatturazione_dettagli_data_fine']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['imponibile'])) || (isset($keyArray['fatturazione_dettagli_imponibile']))) {$this->setImponibile(isset($keyArray['imponibile'])?$keyArray['imponibile']:$keyArray['fatturazione_dettagli_imponibile']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['importo'])) || (isset($keyArray['fatturazione_dettagli_importo']))) {$this->setImporto(isset($keyArray['importo'])?$keyArray['importo']:$keyArray['fatturazione_dettagli_importo']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['id'] =$positionalArray[0];$values['id_fatturazione_testa'] =$positionalArray[1];$values['id_tipo_iva'] =$positionalArray[2];$values['id_categoria_spese'] =($positionalArray[3]==self::NULL_VALUE)?null:$positionalArray[3];$values['descrizione'] =($positionalArray[4]==self::NULL_VALUE)?null:$positionalArray[4];$values['data_inizio'] =($positionalArray[5]==self::NULL_VALUE)?null:$positionalArray[5];$values['data_fine'] =($positionalArray[6]==self::NULL_VALUE)?null:$positionalArray[6];$values['imponibile'] =($positionalArray[7]==self::NULL_VALUE)?null:$positionalArray[7];$values['importo'] =($positionalArray[8]==self::NULL_VALUE)?null:$positionalArray[8];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['id'] = null;$values['id_fatturazione_testa'] = null;$values['id_tipo_iva'] = null;$values['id_categoria_spese'] = null;$values['descrizione'] = null;$values['data_inizio'] = null;$values['data_fine'] = null;$values['imponibile'] = null;$values['importo'] = null;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'fatturazione_dettagli.id as fatturazione_dettagli_id,fatturazione_dettagli.id_fatturazione_testa as fatturazione_dettagli_id_fatturazione_testa,fatturazione_dettagli.id_tipo_iva as fatturazione_dettagli_id_tipo_iva,fatturazione_dettagli.id_categoria_spese as fatturazione_dettagli_id_categoria_spese,fatturazione_dettagli.descrizione as fatturazione_dettagli_descrizione,fatturazione_dettagli.data_inizio as fatturazione_dettagli_data_inizio,fatturazione_dettagli.data_fine as fatturazione_dettagli_data_fine,fatturazione_dettagli.imponibile as fatturazione_dettagli_imponibile,fatturazione_dettagli.importo as fatturazione_dettagli_importo';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `fatturazione_dettagli` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_fatturazione_testa` int(10) unsigned NOT NULL,
  `id_tipo_iva` int(10) unsigned NOT NULL,
  `id_categoria_spese` varchar(1) DEFAULT NULL,
  `descrizione` varchar(45) DEFAULT NULL,
  `data_inizio` date DEFAULT NULL,
  `data_fine` date DEFAULT NULL,
  `imponibile` double DEFAULT NULL,
  `importo` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_id_fatturazione_testa` (`id_fatturazione_testa`),
  KEY `idx_id_tipo_iva` (`id_tipo_iva`)
) ENGINE=InnoDB AUTO_INCREMENT=3304 DEFAULT CHARSET=latin1 ");}
/**
 * @return integer
 */
public function getId(){return $this->id;}
/**
 * @param integer $id Id
 */
public function setId($id){$this->id=$id;}
/**
 * @return integer
 */
public function getIdFatturazioneTesta(){return $this->idFatturazioneTesta;}
/**
 * @param integer $idFatturazioneTesta IdFatturazioneTesta
 */
public function setIdFatturazioneTesta($idFatturazioneTesta){$this->idFatturazioneTesta=$idFatturazioneTesta;}
/**
 * @return integer
 */
public function getIdTipoIva(){return $this->idTipoIva;}
/**
 * @param integer $idTipoIva IdTipoIva
 */
public function setIdTipoIva($idTipoIva){$this->idTipoIva=$idTipoIva;}
/**
 * @return string
 */
public function getIdCategoriaSpese(){return $this->idCategoriaSpese;}
/**
 * @param string $idCategoriaSpese IdCategoriaSpese
 * @param int $encodeType
 */
public function setIdCategoriaSpese($idCategoriaSpese,$encodeType = self::STR_DEFAULT){$this->idCategoriaSpese=$this->decodeString($idCategoriaSpese,$encodeType);}
/**
 * @return string
 */
public function getDescrizione(){return $this->descrizione;}
/**
 * @param string $descrizione Descrizione
 * @param int $encodeType
 */
public function setDescrizione($descrizione,$encodeType = self::STR_DEFAULT){$this->descrizione=$this->decodeString($descrizione,$encodeType);}
/**
 * @return string
 */
public function getDataInizio(){return $this->dataInizio;}
/**
 * @param string $dataInizio DataInizio
 * @param int $encodeType
 */
public function setDataInizio($dataInizio,$encodeType = self::STR_DEFAULT){$this->dataInizio=$this->decodeString($dataInizio,$encodeType);}
/**
 * @return string
 */
public function getDataFine(){return $this->dataFine;}
/**
 * @param string $dataFine DataFine
 * @param int $encodeType
 */
public function setDataFine($dataFine,$encodeType = self::STR_DEFAULT){$this->dataFine=$this->decodeString($dataFine,$encodeType);}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getImponibile($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->imponibile:number_format($this->imponibile,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $imponibile Imponibile
 */
public function setImponibile($imponibile){$this->imponibile=$imponibile;}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getImporto($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->importo:number_format($this->importo,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $importo Importo
 */
public function setImporto($importo){$this->importo=$importo;}
}