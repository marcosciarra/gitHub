<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 16/07/18
 * Time: 8.49
 */

namespace Click\Affitti\Viste;

require_once('TipoContrattoRli.php');

require_once('TipoContratto.php');
require_once('Contratti.php');
require_once('ContrattiPreferenze.php');
require_once('PeriodiContrattuali.php');
require_once('Gestioni.php');
require_once('ContrattiDettagli.php');
require_once('Rli.php');
require_once('ImpostaRegistro.php');
require_once('Rate.php');
require_once('RateDettagli.php');
require_once('Opzioni.php');

use Click\Affitti\TblBase\Contratti;
use Click\Affitti\TblBase\ImpostaRegistro;
use Click\Affitti\TblBase\Rate;
use Click\Affitti\TblBase\RateDettagli;
use Click\Affitti\TblBase\Rli;
use Click\Affitti\TblBase\TipoContrattoRli;
use Drakkar\DrakkarDbConnector;
use Click\Affitti\TblBase\ContrattiDettagli;
use Click\Affitti\TblBase\PeriodiContrattuali;
use Click\Affitti\TblBase\Gestioni;
use Click\Affitti\TblBase\TipoContratto;
use Click\Affitti\TblBase\ContrattiPreferenze;
use Click\Affitti\TblBase\Opzioni;

class ElaboraImpostaRegistro
{

    /** @var  DrakkarDbConnector */
    protected $conn;

    /** @var  DrakkarDbConnector */
    protected $conExt;

    /** @var Rli */
    protected $rli;

    /** @var ImpostaRegistro */
    protected $imposta;

    /** @var TipoContrattoRli */
    protected $tipoContrattoRli;

    /** @var integer */
    protected $idContratto;

    /** @var integer */
    protected $idGestione;

    /** @var PeriodiContrattuali */
    protected $periodoContrattuale;


    /**
     * ElaboraImpostaRegistro constructor.
     * @param $idContratto
     * @param $idGestione
     * @param DrakkarDbConnector $conn
     * @param DrakkarDbConnector $conExt
     */
    public function __construct($idContratto, $idGestione, DrakkarDbConnector $conn, DrakkarDbConnector $conExt)
    {
        $this->conn = $conn;
        $this->conExt = $conExt;

        $this->rli = new Rli($this->conn);
        $this->imposta = new ImpostaRegistro($this->conn);
        $this->tipoContrattoRli = new TipoContrattoRli($conExt);
        $this->periodoContrattuale = new PeriodiContrattuali($this->conn);

        $this->idContratto = $idContratto;
        $this->idGestione = $idGestione;

    }


    public function creaImposta()
    {
        $contratto = new Contratti($this->conn);
        $contratto->findByPk($this->idContratto);

        $idPeriodoContrattuale = $this->periodoContrattuale->findIdPeriodoContrattualeByIdGestione($this->idGestione);
        $this->periodoContrattuale->findByPk($idPeriodoContrattuale);
        $rli = new Rli($this->conn);
        $idRli = $rli->findByIdContrattoIdPeriodoContratto($this->idContratto, $this->periodoContrattuale->getId());
        $this->rli->findByPk($idRli);
        switch ($this->rli->getCedolareSecca()) {
            case '1':
                // TUTTI I LOCATORI OPTANO PER LA CEDOLARE SECCA
                return;

                break;
            case '2':
                //ALMENO UN LOCATORE OPTA PER LA CEDOLARE SECCA
                //TODO::Implementare il calcolo dell'imposta di registro nel caso in cui solo alcuni conduttori optano alla cedolare secca
                return;

                break;
            case '3':
                //NESSUN LOCATORE OPTA PER LA CEDOLARE SECCA
                //TODO :: GESTIRE IN FUTURO IL PAGAMENTO UNA TANTUM
                $dataRichiesta = $this->preparaDataRichiesta($this->idGestione);
                $idRli = $this->rli->findIdRliByData($this->idContratto, $dataRichiesta);
                $this->rli->findByPk($idRli);
                $tipoRinnovo = $this->getTipoRinnovo(
                    $this->periodoContrattuale->getDataInizio(),
                    $contratto->getIdTipoContratto(),
                    $dataRichiesta,
                    $this->periodoContrattuale->getId()
                );
                $opz = new Opzioni($this->conn);
                //Opzione che identifica se creare l'imposta con codice 1500
                $opz->findByPk(Opzioni::IMPOSTA_PRIMA_REGISTRAZIONE);
                if ($opz->getValore() == 1 || $tipoRinnovo != 'S') {
                    $idImposta = $this->creaImpostaRegistro($this->rli->getId(), $dataRichiesta, $tipoRinnovo);
                    if ($this->associaImpostaRata(
                            $dataRichiesta,
                            $this->rli->getImpostaRegistroImporto(),
                            $contratto->getDataInizio()
                        ) == false) {
                        $imposta = new ImpostaRegistro($this->conn);
                        $imposta->deleteByPk($idImposta);
                    }
                }
                break;
        }
    }


    private function associaImpostaRata($dataRichiesta, $importoImpostaRegistro, $dataInizioPeriodo)
    {
        //ASSOCIAZIONE IMPOSTA DI REGISTRO A RATA
        //Ordino per data scadenza così da avere l'id della prima rata che scade che contiene la data richiesta
        $rate = new Rate($this->conn);

        if ($dataRichiesta < $dataInizioPeriodo)
            $dataRichiesta = $dataInizioPeriodo;

        $contrattiP = new ContrattiPreferenze($this->conn);
        $contrattiP->findByPk($this->idContratto);
        /*
         * RICHIESTA ANTICIPATA / POSTICIPATA
         */
        if ($contrattiP->getImpostaRegistroTipoRichiesta() == 'A') {
            //RICHIESTA ANTICIPATA DELL'IMPOSTA DI REGISTRO
            $idRata = $rate->getIdRataByData($this->idContratto, $dataRichiesta);
        } else {
            //RICHIESTA POSTICIPATA DELL'IMPOSTA DI REGISTRO
            $idRata = $rate->getIdRataSuccessivaByData($this->idContratto, $dataRichiesta);
        }
        if ($idRata) {
            $rateDettagli = new RateDettagli($this->conn);
            $rateDettagli->associaImpostaRegistroRataDettaglio(
                $this->idContratto,
                $idRata,
                $this->imposta->getId(),
                $importoImpostaRegistro
            );
            $flag = true;
        } else {
            $flag = false;
        }
        return $flag;
    }


    private function creaImpostaRegistro($idRli, $dataRichiesta, $tipoRinnovo)
    {
        $this->rli->findByPk($idRli);
        $this->imposta->setIdRli($this->rli->getId());
        $this->imposta->setIdGestione($this->idGestione);
        //Codice identificativo per le locazioni
        $this->imposta->setIdCodiceIdentificativo($this->rli->getIdCodiceIdentificativoCoobbligato());
        $this->imposta->setCodiceUfficio($this->rli->getCodiceUfficio());
        $this->imposta->setSerie($this->rli->getSerie());
        $this->imposta->setNumero($this->rli->getNumero());
        $this->imposta->setSottonumero($this->rli->getSottonumero());
        $this->imposta->setTipoRinnovo($tipoRinnovo);

        //DATA SCADENZA E DATA VERSAMENTO
        $appDataRichiesta = explode('-', $dataRichiesta);
        $dataScadenza = date(
            'Y-m-d',
            mktime(null, null, null, $appDataRichiesta[1], $appDataRichiesta[2], $appDataRichiesta[0]));
        $this->imposta->setDataScadenza($dataScadenza);

        if (mktime(null, null, null, $appDataRichiesta[1], $appDataRichiesta[2] + 30, $appDataRichiesta[0]) < time())
            $this->imposta->setDataVersamento('1970-01-01');
        //IMPORTO IMPOSTA DI REGISTRO
        $canone = $this->imposta->calcolaCanonePerImpostaDiRegistro($this->idGestione);
        $importoImpostaRegistro = $this->calcolaImposta($canone, $idRli, $tipoRinnovo);
        $this->imposta->setImportoTotale($importoImpostaRegistro);

        //Creazione JSON dei dettagli dell'F24
        $codiceIdentificativo = $this->rli->getCodiceIdentificativo();
        $appData = explode('-', $dataRichiesta);
        $codice = '';
        switch ($tipoRinnovo) {
            case 'S':
                $codice = '1500';
                $codiceIdentificativo = '';
                break;
            case 'R':
                $codice = '1504';
                break;
            case 'P':
                $codice = '1501';
                break;
        }

        $app = array();
        $dettaglioImpReg = array(
            'tipo' => 'F',
            'elementi_identificativi' => $codiceIdentificativo,
            'codice' => $codice,
            'anno' => $appData[0],
            'importi' => round($importoImpostaRegistro, 2)
        );
        $app[] = $dettaglioImpReg;
        $this->imposta->setDettagli(json_encode($app));
        $idImposta = $this->imposta->saveOrUpdate();

        //Salvo l'importo totale della ritenuta
        $this->rli->setImpostaRegistroImporto($importoImpostaRegistro);
        $this->rli->saveOrUpdate();

        return $idImposta;
    }


    /**
     * Restituisce il tipo di rinnovo da elaborare
     *
     * @param $dataInizioContratto
     * @param $idTipoContratto
     * @param $dataRichiesta
     * @param $idPeriodoContrattuale
     * @return string
     */
    private function getTipoRinnovo($dataInizioContratto, $idTipoContratto, $dataRichiesta, $idPeriodoContrattuale)
    {
        $tipoContratto = new TipoContratto($this->conn);
        $tipoContratto->findByPk($idTipoContratto);
        $this->periodoContrattuale->findByPk($idPeriodoContrattuale);

        switch ($dataRichiesta) {
            case $dataInizioContratto:
                $tipoRinnovo = 'S'; //STIPULA CONTRATTO
                break;
            case calcolaData($dataInizioContratto, 0, $tipoContratto->getMesiPrimoRinnovo(), 0):
                $tipoRinnovo = 'R'; //RINNOVO
                break;
            default :
                $tipoRinnovo = 'P'; //PROROGA
                break;
        }
        return $tipoRinnovo;
    }


    /**
     *
     * Creazione data in cui richiedere l'imposta di registro
     *
     * @return false|string
     */
    public function preparaDataRichiesta()
    {
        $gestione = new Gestioni($this->conn);
        $gestione->findByPk($this->idGestione);
        $contratto = new Contratti($this->conn);
        $contratto->findByPk($this->idContratto);
        $appDataInizioContratto = explode('-', $contratto->getDataInizio());
        $dataInizioEsercizio = explode('-', $gestione->getDataInizio());
        $dataRichiesta = date(
            'Y-m-d',
            mktime(null, null, null, $appDataInizioContratto[1], $appDataInizioContratto[2], $dataInizioEsercizio[0])
        );
        return $dataRichiesta;
    }


    /**
     * @param $canone
     * @param $idRli
     * @param string $tipoProroga
     *
     * @return float
     */
    public function calcolaImposta($canone, $idRli, $tipoRinnovo = 'P')
    {
        $rli = new Rli($this->conn);
        $rli->findByPk($idRli);
        /** @var TipoContrattoRli $tipoRli */
        foreach ($this->tipoContrattoRli->findByCodice($rli->getTipoContrattoRli()) as $tipoRli) {
            if ($tipoRli->getImporto() > 0) {
                return round($tipoRli->getImporto(), 2);
            } else {
                if ($tipoRli->getPercentualeCanone() < 100) {
                    $canone = ($canone / 100) * $tipoRli->getPercentualeCanone();
                }
                $appImposta = ($canone / 100) * $tipoRli->getPercentuale();
                if ($tipoRinnovo != 'P' && $appImposta < 67) {
                    $appImposta = 67;
                }

                $opz = new Opzioni($this->conn);
                $opz->findByPk(Opzioni::IMPOSTA_ARROTONDATA);
                if ($opz->getValore() == 1) {
                    return round($appImposta);
                } else {
                    return round($appImposta, 2);
                }
            }
        }
    }


}