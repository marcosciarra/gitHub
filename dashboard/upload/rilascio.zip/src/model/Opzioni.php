<?php
/**
 * Created by Drakkar vers. 0.1.3(Hjortspring)
 * User: P.D.A. Srl
 * Date: 2018-07-31
 * Time: 15:08:43.983638
 */

namespace Click\Affitti\TblBase;
require_once 'OpzioniModel.php';

use Click\Affitti\TblBase\OpzioniModel;

class  Opzioni extends OpzioniModel
{

    //IMPOSTA REGISTRO
    const IMPOSTA_PRIMA_REGISTRAZIONE = 1;
    const IMPOSTA_ARROTONDATA = 7;
    const IMPOSTA_REGISTRO_TIPO_RICHIESTA_DEFAULT = 9;

    //STAMPE
    const STAMPA_INTESTAZIONE = 2;
    const STAMPA_LOGO = 3;
    const STAMPA_CODICE_CONTRATTO = 4;
    const STAMPA_LEGGI_SOGGETTO_IVA = 5;
    const STAMPA_LEGGI_NON_SOGGETTO_IVA = 6;
    const STAMPA_MOSTRA_DETTAGLI_INTESTATARI= 11;
    const STAMPA_ESTRATTO_CONTO_DETTAGLIATO= 10;

    //ISTAT
    const AZZERA_ISTAT_SE_NEGATIVO = 8;

    //CONTRATTO


    function __construct($pdo)
    {
        parent::__construct($pdo);
    }

}