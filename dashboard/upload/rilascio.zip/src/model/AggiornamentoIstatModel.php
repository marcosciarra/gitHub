<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-15
* Time: 11:42:47.246818
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class AggiornamentoIstatModel extends PdaAbstractModel {
/** @var integer */
protected $id;
/** @var string */
protected $codiceGruppo;
/** @var integer */
protected $idContratto;
/** @var integer */
protected $idPianoRateTesta;
/** @var integer */
protected $idRata;
/** @var double */
protected $canone;
/** @var double */
protected $nuovoCanone;
/** @var double */
protected $percentuale;
/** @var integer */
protected $mesiConguaglio;
/** @var double */
protected $conguaglio;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='aggiornamento_istat';$this->tableName='aggiornamento_istat';}

/**
 * find by tables' Primary Key: 
 * @return AggiornamentoIstat|array|string|null
 */
public function findByPk($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($id), $typeResult);}
/**
 * delete by tables' Primary Key: 
 */
public function deleteByPk($id){$query = "DELETE FROM $this->tableName  WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($id));}
/**
 * Find all record of table
 * @return AggiornamentoIstat[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * find by tables' Key idx_codice_gruppo: 
 * @return AggiornamentoIstat[]|array|string
 */
public function findByIdxCodiceGruppo($codiceGruppo,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_codice_gruppo) WHERE codice_gruppo=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($codiceGruppo), $typeResult);}

/**
 * find by tables' Key idx_id_contratto_id_piano_rate_testa: 
 * @return AggiornamentoIstat[]|array|string
 */
public function findByIdxIdContrattoIdPianoRateTesta($idContratto,$idPianoRateTesta,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_id_contratto_id_piano_rate_testa) WHERE id_contratto=? AND id_piano_rate_testa=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($idContratto,$idPianoRateTesta), $typeResult);}

/**
 * find by tables' Key idx_codice_gruppo_id_contratto: 
 * @return AggiornamentoIstat[]|array|string
 */
public function findByIdxCodiceGruppoIdContratto($codiceGruppo,$idContratto,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_codice_gruppo_id_contratto) WHERE codice_gruppo=? AND id_contratto=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($codiceGruppo,$idContratto), $typeResult);}

/**
 * delete by tables' Key idx_codice_gruppo: 
 * @return boolean
 */
public function deleteByIdxCodiceGruppo($codiceGruppo,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE codice_gruppo=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($codiceGruppo));}
/**
 * delete by tables' Key idx_id_contratto_id_piano_rate_testa: 
 * @return boolean
 */
public function deleteByIdxIdContrattoIdPianoRateTesta($idContratto,$idPianoRateTesta,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_contratto=? AND id_piano_rate_testa=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idContratto,$idPianoRateTesta));}
/**
 * delete by tables' Key idx_codice_gruppo_id_contratto: 
 * @return boolean
 */
public function deleteByIdxCodiceGruppoIdContratto($codiceGruppo,$idContratto,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE codice_gruppo=? AND id_contratto=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($codiceGruppo,$idContratto));}
/**
 * find by id
 * @return AggiornamentoIstat[]
 */
public function findById($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($id), $typeResult);}


/**
 * find by codice_gruppo
 * @return AggiornamentoIstat[]
 */
public function findByCodiceGruppo($codiceGruppo,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE codice_gruppo=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($codiceGruppo), $typeResult);}


/**
 * find like codice_gruppo
 * @return AggiornamentoIstat[]
 */
public function findLikeCodiceGruppo($codiceGruppo,$likeMatching=self::LIKE_MATCHING_BOTH, $typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE codice_gruppo like ?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($this->prepareLikeMatching($codiceGruppo,$likeMatching)), $typeResult);}

/**
 * find by id_contratto
 * @return AggiornamentoIstat[]
 */
public function findByIdContratto($idContratto,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id_contratto=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($idContratto), $typeResult);}


/**
 * delete by codice_gruppo
 * @return boolean
 */
public function deleteByCodiceGruppo($codiceGruppo){$query = "DELETE FROM $this->tableName WHERE codice_gruppo=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($codiceGruppo));}

/**
 * delete by id_contratto
 * @return boolean
 */
public function deleteByIdContratto($idContratto){$query = "DELETE FROM $this->tableName WHERE id_contratto=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idContratto));}

/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->id))$arrayValue['id']=$this->id;if(isset($this->codiceGruppo))$arrayValue['codice_gruppo']=($this->codiceGruppo==self::NULL_VALUE)?null:$this->codiceGruppo;if(isset($this->idContratto))$arrayValue['id_contratto']=$this->idContratto;if(isset($this->idPianoRateTesta))$arrayValue['id_piano_rate_testa']=$this->idPianoRateTesta;if(isset($this->idRata))$arrayValue['id_rata']=($this->idRata==self::NULL_VALUE)?null:$this->idRata;if(isset($this->canone))$arrayValue['canone']=($this->canone==self::NULL_VALUE)?null:$this->canone;if(isset($this->nuovoCanone))$arrayValue['nuovo_canone']=($this->nuovoCanone==self::NULL_VALUE)?null:$this->nuovoCanone;if(isset($this->percentuale))$arrayValue['percentuale']=($this->percentuale==self::NULL_VALUE)?null:$this->percentuale;if(isset($this->mesiConguaglio))$arrayValue['mesi_conguaglio']=($this->mesiConguaglio==self::NULL_VALUE)?null:$this->mesiConguaglio;if(isset($this->conguaglio))$arrayValue['conguaglio']=($this->conguaglio==self::NULL_VALUE)?null:$this->conguaglio;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['id'])) || (isset($keyArray['aggiornamento_istat_id']))) {$this->setId(isset($keyArray['id'])?$keyArray['id']:$keyArray['aggiornamento_istat_id']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['codice_gruppo'])) || (isset($keyArray['aggiornamento_istat_codice_gruppo']))) {$this->setCodicegruppo(isset($keyArray['codice_gruppo'])?$keyArray['codice_gruppo']:$keyArray['aggiornamento_istat_codice_gruppo']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_contratto'])) || (isset($keyArray['aggiornamento_istat_id_contratto']))) {$this->setIdcontratto(isset($keyArray['id_contratto'])?$keyArray['id_contratto']:$keyArray['aggiornamento_istat_id_contratto']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_piano_rate_testa'])) || (isset($keyArray['aggiornamento_istat_id_piano_rate_testa']))) {$this->setIdpianoratetesta(isset($keyArray['id_piano_rate_testa'])?$keyArray['id_piano_rate_testa']:$keyArray['aggiornamento_istat_id_piano_rate_testa']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_rata'])) || (isset($keyArray['aggiornamento_istat_id_rata']))) {$this->setIdrata(isset($keyArray['id_rata'])?$keyArray['id_rata']:$keyArray['aggiornamento_istat_id_rata']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['canone'])) || (isset($keyArray['aggiornamento_istat_canone']))) {$this->setCanone(isset($keyArray['canone'])?$keyArray['canone']:$keyArray['aggiornamento_istat_canone']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['nuovo_canone'])) || (isset($keyArray['aggiornamento_istat_nuovo_canone']))) {$this->setNuovocanone(isset($keyArray['nuovo_canone'])?$keyArray['nuovo_canone']:$keyArray['aggiornamento_istat_nuovo_canone']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['percentuale'])) || (isset($keyArray['aggiornamento_istat_percentuale']))) {$this->setPercentuale(isset($keyArray['percentuale'])?$keyArray['percentuale']:$keyArray['aggiornamento_istat_percentuale']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['mesi_conguaglio'])) || (isset($keyArray['aggiornamento_istat_mesi_conguaglio']))) {$this->setMesiconguaglio(isset($keyArray['mesi_conguaglio'])?$keyArray['mesi_conguaglio']:$keyArray['aggiornamento_istat_mesi_conguaglio']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['conguaglio'])) || (isset($keyArray['aggiornamento_istat_conguaglio']))) {$this->setConguaglio(isset($keyArray['conguaglio'])?$keyArray['conguaglio']:$keyArray['aggiornamento_istat_conguaglio']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['id'] =$positionalArray[0];$values['codice_gruppo'] =($positionalArray[1]==self::NULL_VALUE)?null:$positionalArray[1];$values['id_contratto'] =$positionalArray[2];$values['id_piano_rate_testa'] =$positionalArray[3];$values['id_rata'] =($positionalArray[4]==self::NULL_VALUE)?null:$positionalArray[4];$values['canone'] =($positionalArray[5]==self::NULL_VALUE)?null:$positionalArray[5];$values['nuovo_canone'] =($positionalArray[6]==self::NULL_VALUE)?null:$positionalArray[6];$values['percentuale'] =($positionalArray[7]==self::NULL_VALUE)?null:$positionalArray[7];$values['mesi_conguaglio'] =($positionalArray[8]==self::NULL_VALUE)?null:$positionalArray[8];$values['conguaglio'] =($positionalArray[9]==self::NULL_VALUE)?null:$positionalArray[9];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['id'] = null;$values['codice_gruppo'] = null;$values['id_contratto'] = null;$values['id_piano_rate_testa'] = null;$values['id_rata'] = null;$values['canone'] = null;$values['nuovo_canone'] = null;$values['percentuale'] = null;$values['mesi_conguaglio'] = null;$values['conguaglio'] = null;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'aggiornamento_istat.id as aggiornamento_istat_id,aggiornamento_istat.codice_gruppo as aggiornamento_istat_codice_gruppo,aggiornamento_istat.id_contratto as aggiornamento_istat_id_contratto,aggiornamento_istat.id_piano_rate_testa as aggiornamento_istat_id_piano_rate_testa,aggiornamento_istat.id_rata as aggiornamento_istat_id_rata,aggiornamento_istat.canone as aggiornamento_istat_canone,aggiornamento_istat.nuovo_canone as aggiornamento_istat_nuovo_canone,aggiornamento_istat.percentuale as aggiornamento_istat_percentuale,aggiornamento_istat.mesi_conguaglio as aggiornamento_istat_mesi_conguaglio,aggiornamento_istat.conguaglio as aggiornamento_istat_conguaglio';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `aggiornamento_istat` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codice_gruppo` varchar(45) DEFAULT NULL,
  `id_contratto` int(10) unsigned NOT NULL,
  `id_piano_rate_testa` int(10) unsigned NOT NULL,
  `id_rata` int(10) DEFAULT NULL,
  `canone` double DEFAULT NULL,
  `nuovo_canone` double DEFAULT NULL,
  `percentuale` decimal(6,4) DEFAULT NULL,
  `mesi_conguaglio` int(11) DEFAULT NULL,
  `conguaglio` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_codice_gruppo` (`codice_gruppo`),
  KEY `idx_id_contratto_id_piano_rate_testa` (`id_contratto`,`id_piano_rate_testa`),
  KEY `idx_codice_gruppo_id_contratto` (`codice_gruppo`,`id_contratto`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=latin1 ");}
/**
 * @return integer
 */
public function getId(){return $this->id;}
/**
 * @param integer $id Id
 */
public function setId($id){$this->id=$id;}
/**
 * @return string
 */
public function getCodiceGruppo(){return $this->codiceGruppo;}
/**
 * @param string $codiceGruppo CodiceGruppo
 * @param int $encodeType
 */
public function setCodiceGruppo($codiceGruppo,$encodeType = self::STR_DEFAULT){$this->codiceGruppo=$this->decodeString($codiceGruppo,$encodeType);}
/**
 * @return integer
 */
public function getIdContratto(){return $this->idContratto;}
/**
 * @param integer $idContratto IdContratto
 */
public function setIdContratto($idContratto){$this->idContratto=$idContratto;}
/**
 * @return integer
 */
public function getIdPianoRateTesta(){return $this->idPianoRateTesta;}
/**
 * @param integer $idPianoRateTesta IdPianoRateTesta
 */
public function setIdPianoRateTesta($idPianoRateTesta){$this->idPianoRateTesta=$idPianoRateTesta;}
/**
 * @return integer
 */
public function getIdRata(){return $this->idRata;}
/**
 * @param integer $idRata IdRata
 */
public function setIdRata($idRata){$this->idRata=$idRata;}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getCanone($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->canone:number_format($this->canone,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $canone Canone
 */
public function setCanone($canone){$this->canone=$canone;}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getNuovoCanone($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->nuovoCanone:number_format($this->nuovoCanone,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $nuovoCanone NuovoCanone
 */
public function setNuovoCanone($nuovoCanone){$this->nuovoCanone=$nuovoCanone;}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getPercentuale($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->percentuale:number_format($this->percentuale,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $percentuale Percentuale
 */
public function setPercentuale($percentuale){$this->percentuale=$percentuale;}
/**
 * @return integer
 */
public function getMesiConguaglio(){return $this->mesiConguaglio;}
/**
 * @param integer $mesiConguaglio MesiConguaglio
 */
public function setMesiConguaglio($mesiConguaglio){$this->mesiConguaglio=$mesiConguaglio;}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getConguaglio($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->conguaglio:number_format($this->conguaglio,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $conguaglio Conguaglio
 */
public function setConguaglio($conguaglio){$this->conguaglio=$conguaglio;}
}