<?php
/**
 * Created by Drakkar vers. 0.0.23(Hjortspring)
 * User: P.D.A. Srl
 * Date: 2017-12-06
 * Time: 15:21:59.598714
 */

namespace Click\Affitti\TblBase;
require_once 'IstatFoiModel.php';

use Click\Affitti\TblBase\IstatFoiModel;

class  IstatFoi extends IstatFoiModel
{
    function __construct($pdo)
    {
        parent::__construct($pdo);
    }

}