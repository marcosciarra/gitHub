<?php
/**
* Created by Drakkar vers. 0.0.23(Hjortspring)
* User: P.D.A. Srl
* Date: 2017-12-06
* Time: 15:21:59.679072
*/
namespace Click\Affitti\TblBase;
require_once 'ScaletteModel.php';
use Click\Affitti\TblBase\ScaletteModel;

class  Scalette extends ScaletteModel {
function __construct($pdo){parent::__construct($pdo);}

}