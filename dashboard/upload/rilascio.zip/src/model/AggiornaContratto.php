<?php
/**
 * Created by PhpStorm.
 * User: marco
 * Date: 28/03/18
 * Time: 15.22
 */

namespace Click\Affitti\Viste;


require_once 'ContrattoAffitto.php';
require_once 'PeriodiContrattuali.php';
require_once 'Gestioni.php';
require_once 'PianoRateTesta.php';
require_once 'PianiRateDettagli.php';
require_once 'Rate.php';
require_once 'RateDettagli.php';
require_once 'Rli.php';
require_once 'ImpostaRegistro.php';
require_once 'TipiIva.php';
require_once 'TipoContrattoRli.php';
require_once 'CanoniOneri.php';
require_once 'ElaboraImpostaRegistro.php';
require_once 'CanoniOneri.php';
require_once 'ElaboraContratto.php';


use Click\Affitti\TblBase\CanoniOneri;
use Drakkar\DrakkarDbConnector;
use Click\Affitti\Viste\ContrattoAffitto;
use Click\Affitti\TblBase\PeriodiContrattuali;
use Click\Affitti\TblBase\Gestioni;
use Click\Affitti\TblBase\PianoRateTesta;
use Click\Affitti\TblBase\PianiRateDettagli;
use Click\Affitti\TblBase\Rate;
use Click\Affitti\TblBase\RateDettagli;
use Click\Affitti\TblBase\Rli;
use Click\Affitti\TblBase\ImpostaRegistro;
use Click\Affitti\TblBase\TipiIva;
use Click\Affitti\TblBase\TipoContrattoRli;
use Click\Affitti\Viste\ElaboraImpostaRegistro;
use Click\Affitti\Viste\ElaboraContratto;

class AggiornaContratto
{

    /** @var  DrakkarDbConnector */
    protected $conn;

    /** @var  DrakkarDbConnector */
    protected $conExt;

    /** @var ContrattoAffitto */
    protected $contrattoAffitti;

    /** @var PeriodiContrattuali */
    protected $periodiContrattuali;

    /** @var Gestioni */
    protected $gestioni;

    /** @var PianoRateTesta */
    protected $pianiRateTestata;

    /** @var PianiRateDettagli */
    protected $pianiRateDettagli;

    /** @var Rate */
    protected $rate;

    /** @var RateDettagli */
    protected $rateDettagli;

    /** @var Rli */
    protected $rli;

    /** @var ImpostaRegistro */
    protected $impostaRegistro;

    /** @var TipiIva */
    protected $tipiIva;


    /**
     * AggiornaContratto constructor.
     * @param DrakkarDbConnector $conn
     * @param DrakkarDbConnector $conExt
     */
    public function __construct(DrakkarDbConnector $conn, DrakkarDbConnector $conExt)
    {
        $this->conn = $conn;
        $this->conExt = $conExt;
        $this->contrattoAffitti = new ContrattoAffitto($this->conn);
        $this->periodiContrattuali = new PeriodiContrattuali($this->conn);
        $this->gestioni = new Gestioni($this->conn);
        $this->pianiRateTestata = new PianoRateTesta($this->conn);
        $this->pianiRateDettagli = new PianiRateDettagli($this->conn);
        $this->rate = new Rate($this->conn);
        $this->rateDettagli = new RateDettagli($this->conn);
        $this->rli = new Rli($this->conn);
        $this->impostaRegistro = new ImpostaRegistro($this->conn);
        $this->tipiIva = new TipiIva($this->conn);
    }

    /*------------------------------------------------------NUOVA SPESA-----------------------------------------------*/
    /**
     * @param $idGestione
     * @param $canoneOnere CanoniOneri
     */
    public function aggiungiSpesa($idGestione, $canoneOnere)
    {
        $elaboraC = new ElaboraContratto($this->conn, $this->conExt);
        $this->gestioni->findByPk($idGestione);
        //Controllo se l'esercizio è già passato o no, (nel caso sia già passato imposto il conguaglio e la percentuale ISTAT a 0)
        if ($this->gestioni->getDataFine() < date('Y-m-d', time())) {
            $idPianoRateTesta = $elaboraC->creaPianoRateTesta($canoneOnere, true, $idGestione);
        } else {
            $idPianoRateTesta = $elaboraC->creaPianoRateTesta($canoneOnere, false, $idGestione);
        }

        //Creo il piano rate dettaglio
        $annoEsercizio = explode('-', $this->gestioni->getDataInizio());
        foreach (json_decode($canoneOnere->getRateizzazione()) as $rateizzazione) {
            $elaboraC->creaRateDettagli($idPianoRateTesta, $annoEsercizio[0], $canoneOnere, $rateizzazione);
        }

        //Creo i dettagli delle rate e li collego alle rate
        $rate = new Rate($this->conn);
        /** @var Rate $rate */
        foreach ($rate->findByIdxIdGestione($idGestione) as $rate) {
            $elaboraC->creaDettaglioRate($rate, $idGestione, $idPianoRateTesta);
        }

        //Elimino tutti i dettagli creati sule rate già emesse (bloccate)
        $pianoRateD = new PianiRateDettagli($this->conn);
        /** @var PianiRateDettagli $pianoRateD */
        foreach ($pianoRateD->findByIdxIdPianoRateTestaAndStatoRataBloccata($idPianoRateTesta, 1) as $pianoRateD) {
            $rateD = new RateDettagli($this->conn);
            /** @var RateDettagli $rateD */
            foreach ($rateD->findByIdxIdPianoRateDettagli($pianoRateD->getId()) as $rateD) {
                $dettaglioDaEliminare = new RateDettagli($this->conn);
                $dettaglioDaEliminare->deleteByPk($rateD->getId());
            }
            $rateDettaglioDaEliminare = new PianiRateDettagli($this->conn);
            $rateDettaglioDaEliminare->deleteByPk($pianoRateD->getId());
        }
    }


    /*------------------------------------------------------ELIMINAZIONE SPESA----------------------------------------*/

    public function eliminazioneSpesa($idPianoRateT, $idContratto, $idCanoneOnere, $dataInizio, $multiGestione = false)
    {
        /** @var Gestioni $gestioni */
        $this->gestioni->setOrderBase(' gestioni.data_inizio ASC');
        foreach ($this->gestioni->elencoGestioniDaDataByIdContratto($idContratto, $dataInizio, $multiGestione) as $gestioni) {
            /** @var PianoRateTesta $pianoRateT */
            foreach ($this->pianiRateTestata->findByIdGestioneIdCanoniOneri($gestioni->getId(), $idCanoneOnere) as $pianoRateT) {
                if ($idPianoRateT == $pianoRateT->getId()) {
                    /** @var PianiRateDettagli $pianoRateD */
                    foreach ($this->pianiRateDettagli->findByIdxIdPianoRateTesta($pianoRateT->getId()) as $pianoRateD) {
                        /** @var RateDettagli $rateD */
                        foreach ($this->rateDettagli->findByIdxIdPianoRateDettagli($pianoRateD->getId()) as $rateD) {
                            $this->rate->findByPk($rateD->getIdRata());
                            //Elimino tutti i dettagli delle rate non bloccate
                            if ($this->rate->getBloccata() == 0) {
                                $pianoRateD->deleteByPk($rateD->getIdPianoRateDettagli());
                                $rateD->deleteByPk($rateD->getId());
                            }
                        }
                    }
                    //Se tutti i dettagli del piano rate testa sono stati eliminati, lo elimino
                    $rateD = new RateDettagli($this->conn);
                    if (count($rateD->findAllByIdPianoRateTesta($pianoRateT->getId()), RateDettagli::FETCH_KEYARRAY) == 0) {
                        $pianoRateT->deleteByPk($pianoRateT->getId());
                    }
                }
            }
        }
    }

    /*------------------------------------------------------DESCRIZIONI-----------------------------------------------*/

    public function cambioDescrizione($newDescrizione, $idContratto, $idCanoneOnere, $dataInizio, $multiGestione = false)
    {
        /** @var Gestioni $gestioni */
        $this->gestioni->setOrderBase(' gestioni.data_inizio ASC');
        foreach ($this->gestioni->elencoGestioniDaDataByIdContratto($idContratto, $dataInizio, $multiGestione) as $gestioni) {
            /** @var PianoRateTesta $pianoRateT */
            foreach ($this->pianiRateTestata->findByIdGestioneIdCanoniOneri($gestioni->getId(), $idCanoneOnere) as $pianoRateT) {
                /** @var PianiRateDettagli $pianoRateD */
                foreach ($this->pianiRateDettagli->findByIdxIdPianoRateTesta($pianoRateT->getId()) as $pianoRateD) {
                    /** @var RateDettagli $rateD */
                    foreach ($this->rateDettagli->findByIdxIdPianoRateDettagli($pianoRateD->getId()) as $rateD) {
                        $this->rate->findByPk($rateD->getIdRata());
                        if ($this->rate->getBloccata() == 0) {
                            $rateD->setDescrizione($newDescrizione);
                            $rateD->saveOrUpdate();
                            if ($pianoRateT->getDescrizione() != $newDescrizione) {
                                $pianoRateT->setDescrizione($newDescrizione);
                                $pianoRateT->saveOrUpdate();
                            }
                        }
                    }
                }
            }
        }
    }

    /*---------------------------------------------------------SALDI--------------------------------------------------*/

    public function cambioTipoSaldo($newTipoSaldo, $idContratto, $idCanoneOnere, $dataInizio, $multiGestione = false)
    {
        /** @var Gestioni $gestioni */
        $this->gestioni->setOrderBase(' gestioni.data_inizio ASC');
        foreach ($this->gestioni->elencoGestioniDaDataByIdContratto($idContratto, $dataInizio, $multiGestione) as $gestioni) {
            /** @var PianoRateTesta $pianoRateT */
            foreach ($this->pianiRateTestata->findByIdGestioneIdCanoniOneri($gestioni->getId(), $idCanoneOnere) as $pianoRateT) {
                /** @var PianiRateDettagli $pianoRateD */
                foreach ($this->pianiRateDettagli->findByIdxIdPianoRateTesta($pianoRateT->getId()) as $pianoRateD) {
                    /** @var RateDettagli $rateD */
                    foreach ($this->rateDettagli->findByIdxIdPianoRateDettagli($pianoRateD->getId()) as $rateD) {
                        $this->rate->findByPk($rateD->getIdRata());
                        if ($this->rate->getBloccata() == 0) {
                            //Controllo che sia una spesa
                            if ($this->rateDettagli->getTipoSpesa() == 'O') {
                                if ($newTipoSaldo == 'F') {
                                    $newCategoriaSpese = 'F';
                                } else {
                                    $newCategoriaSpese = 'S';
                                }
                            } else {
                                $newCategoriaSpese = 'A';
                            }
                            $rateD->setTipoSaldo($newTipoSaldo);
                            $rateD->setIdCategoriaSpesa($newCategoriaSpese);
                            $rateD->saveOrUpdate();
                            if ($pianoRateT->getTipoSaldo() != $newTipoSaldo) {
                                $pianoRateT->setTipoSaldo($newTipoSaldo);
                                $pianoRateT->saveOrUpdate();
                            }
                        }
                    }
                }
            }
        }
    }

    /*----------------------------------------------------TIPO SPESA--------------------------------------------------*/

    public function cambioTipoSpese($newTipoSpesa, $idContratto, $idCanoneOnere, $dataInizio, $multiGestione = false)
    {
        /** @var Gestioni $gestioni */
        $this->gestioni->setOrderBase(' gestioni.data_inizio ASC');
        foreach ($this->gestioni->elencoGestioniDaDataByIdContratto($idContratto, $dataInizio, $multiGestione) as $gestioni) {
            /** @var PianoRateTesta $pianoRateT */
            foreach ($this->pianiRateTestata->findByIdGestioneIdCanoniOneri($gestioni->getId(), $idCanoneOnere) as $pianoRateT) {
                /** @var PianiRateDettagli $pianoRateD */
                foreach ($this->pianiRateDettagli->findByIdxIdPianoRateTesta($pianoRateT->getId()) as $pianoRateD) {
                    /** @var RateDettagli $rateD */
                    foreach ($this->rateDettagli->findByIdxIdPianoRateDettagli($pianoRateD->getId()) as $rateD) {
                        $this->rate->findByPk($rateD->getIdRata());
                        if ($this->rate->getBloccata() == 0) {
                            //Controllo che sia una spesa
                            if ($newTipoSpesa == 'O') {
                                $newCategoriaSpese = 'S';
                            } else {
                                $newCategoriaSpese = 'A';
                            }
                            $rateD->setTipoSpesa($newTipoSpesa);
                            $rateD->setIdCategoriaSpesa($newCategoriaSpese);
                            $rateD->saveOrUpdate();
                            if ($pianoRateT->getTipoSpesa() != $newTipoSpesa) {
                                $pianoRateT->setTipoSpesa($newTipoSpesa);
                                $pianoRateT->saveOrUpdate();
                            }
                        }
                    }
                }
            }
        }
    }

    /*-------------------------------------------------------IMPORTI--------------------------------------------------*/

    public function cambioImporti($newImponibile, $idContratto, $idCanoneOnere, $dataInizio, $multiGestione = false)
    {
        /** @var Gestioni $gestioni */
        $this->gestioni->setOrderBase(' gestioni.data_inizio ASC');
        foreach ($this->gestioni->elencoGestioniDaDataByIdContratto($idContratto, $dataInizio, $multiGestione) as $gestioni) {
            /** @var PianoRateTesta $pianoRateT */
            foreach ($this->pianiRateTestata->findByIdGestioneIdCanoniOneri($gestioni->getId(), $idCanoneOnere) as $pianoRateT) {
                /** @var PianiRateDettagli $pianoRateD */
                foreach ($this->pianiRateDettagli->findByIdxIdPianoRateTesta($pianoRateT->getId()) as $pianoRateD) {
                    /** @var RateDettagli $rateD */
                    foreach ($this->rateDettagli->findByIdxIdPianoRateDettagli($pianoRateD->getId()) as $rateD) {
                        $this->rate->findByPk($rateD->getIdRata());
                        if ($this->rate->getBloccata() == 0) {
                            $percentualeIva = $this->tipiIva->findByPk($pianoRateT->getIdTipoIva())->getAliquota();
                            $newImporto = $this->calcolaImporto(
                                round($newImponibile, 2),
                                $percentualeIva
                            );
                            $imponibileParziale = round($this->calcolaPercentualeImporto($newImponibile, $pianoRateD->getPercentuale()), 2);
                            $importoParziale = round($this->calcolaPercentualeImporto($newImporto, $pianoRateD->getPercentuale()), 2);

                            $rateD->setImponibile($imponibileParziale);
                            $rateD->setImporto($importoParziale);
                            $rateD->saveOrUpdate();

                            $pianoRateD->setImponibile($imponibileParziale);
                            $pianoRateD->setImporto($importoParziale);
                            $pianoRateD->saveOrUpdate();

                            $newImporto = $this->calcolaImporto(
                                round($newImponibile, 2),
                                $percentualeIva
                            );
                            $pianoRateT->setImponibile(round($newImponibile, 2));
                            $pianoRateT->setImporto(round($newImporto, 2));
                            $pianoRateT->saveOrUpdate();
                        }
                    }
                }
            }
            $this->aggiornaImpostaRegistro($gestioni->getId());
        }
    }

    /*--------------------------------------------------TIPI IVA------------------------------------------------------*/

    public function cambioTipoIva($newTipoIva, $idContratto, $idCanoneOnere, $dataInizio, $multiGestione = false)
    {
        $newImponibile = 0;
        /** @var Gestioni $gestioni */
        $this->gestioni->setOrderBase(' gestioni.data_inizio ASC');
        foreach ($this->gestioni->elencoGestioniDaDataByIdContratto($idContratto, $dataInizio, $multiGestione) as $gestioni) {
            /** @var PianoRateTesta $pianoRateT */
            foreach ($this->pianiRateTestata->findByIdGestioneIdCanoniOneri($gestioni->getId(), $idCanoneOnere) as $pianoRateT) {
                /** @var PianiRateDettagli $pianoRateD */
                foreach ($this->pianiRateDettagli->findByIdxIdPianoRateTesta($pianoRateT->getId()) as $pianoRateD) {
                    /** @var RateDettagli $rateD */
                    foreach ($this->rateDettagli->findByIdxIdPianoRateDettagli($pianoRateD->getId()) as $rateD) {
                        $this->rate->findByPk($rateD->getIdRata());
                        if ($this->rate->getBloccata() == 0) {

                            $rateD->setIdTipoIva($newTipoIva);
                            $rateD->saveOrUpdate();

                            $pianoRateD->setIdTipoIva($newTipoIva);
                            $pianoRateD->saveOrUpdate();

                            if ($pianoRateT->getIdTipoIva() != $newTipoIva) {
                                $pianoRateT->setIdTipoIva($newTipoIva);
                                $pianoRateT->saveOrUpdate();
                                $newImponibile = $pianoRateT->getImponibile();
                            }
                        }
                    }
                }
            }
        }
        $this->cambioImporti($newImponibile, $idContratto, $idCanoneOnere, $dataInizio, $multiGestione);
    }

    /*----------------------------------------------------PERCENTUALE RATE--------------------------------------------*/

    public function cambioPercentualeRateDettagli($newPercentuale, $idPianoRateT, $idPianoRateD)
    {
        $this->pianiRateTestata->findByPk($idPianoRateT);
        $imponibile = $this->pianiRateTestata->getImponibile();
        $importo = $this->pianiRateTestata->getImporto();

        $this->pianiRateDettagli->findByPk($idPianoRateD);
        $this->pianiRateDettagli->setPercentuale($newPercentuale);
        if ($newPercentuale > 0) {
            $this->pianiRateDettagli->setImponibile(round(($imponibile / 100) * $newPercentuale, 2));
            $this->pianiRateDettagli->setImporto(round(($importo / 100) * $newPercentuale, 2));
        } else {
            $this->pianiRateDettagli->setImponibile(0);
            $this->pianiRateDettagli->setImporto(0);
        }
        $this->pianiRateDettagli->saveOrUpdate();

        //AGGIORNO IMPORTO ED IMPONIBILE DELLA RATA DETTAGLIO
        /** @var RateDettagli $rateD */
        foreach ($this->rateDettagli->findByIdPianoRateDettagli($this->pianiRateDettagli->getId()) as $rateD) {
            break;
        }
        $rateD->setImponibile($this->pianiRateDettagli->getImponibile());
        $rateD->setImporto($this->pianiRateDettagli->getImporto());
        $rateD->saveOrUpdate();
    }

    /*----------------------------------------------------FUNZIONI GENERICHE------------------------------------------*/

    private function calcolaImporto($imponibile, $iva)
    {
        $iva = 1 + ($iva / 100);
        $app = $imponibile * $iva;
        return round($app, 2);
    }


    private function calcolaPercentualeImporto($importo, $percentuale)
    {
        if ($percentuale > 0) {
            $app = $importo / 100;
            return round($app * $percentuale, 2);
        }
        return 0;
    }


    private function aggiornaImpostaRegistro($idGestione)
    {
        $impReg = new ImpostaRegistro($this->conn);
        /** @var ImpostaRegistro $impReg */
        foreach ($impReg->findByIdGestione($idGestione) as $impReg) {
            break;
        }
        if ($impReg->getDataVersamento() == null || $impReg->getDataVersamento() == '0000-00-00') {
            if ($this->rateDettagli->findByIdxIdImpostaRegistro($impReg->getId())) {
                if ($this->rate->findByPk($this->rateDettagli->getIdRata())) {
                    if ($this->rate->getBloccata() == 0) {
                        $rli = new Rli($this->conn);
                        $rli->findByPk($impReg->getIdRli());

                        $canone = $impReg->calcolaCanonePerImpostaDiRegistro($idGestione);
                        $elaboraImpReg = new ElaboraImpostaRegistro($rli->getIdContratto(), $idGestione, $this->conn, $this->conExt);
                        $importoImpostaRegistro = round($elaboraImpReg->calcolaImposta($canone, $impReg->getIdRli(), $impReg->getTipoRinnovo()), 2);
                        $app = json_decode($impReg->getDettagli());
                        //Gestisco JSON
                        foreach ($app as $jsonDettaglio) {
                            if (
                                $jsonDettaglio->codice == '1500' ||
                                $jsonDettaglio->codice == '1504' ||
                                $jsonDettaglio->codice == '1501'
                            ) {
                                $jsonDettaglio->importi = $importoImpostaRegistro;
                            }
                        }
                        $impReg->setDettagli(json_encode($app));

                        $impReg->setImportoTotale($importoImpostaRegistro);
                        $impReg->saveOrUpdate();

                        $rataD = new RateDettagli($this->conn);
                        //AGGIORNO IL DETTAGLIO RATE
                        /** @var RateDettagli $rataD */
                        foreach ($rataD->findByIdxIdImpostaRegistro($impReg->getId()) as $rataD) {
                            break;
                        }

                        $percentualeLocCond = $this->contrattoAffitti->getContrattiPreferenze()->getImpostaRegistroPercLocatore();
                        if ($percentualeLocCond > 0) {
                            $importoImpostaRegistro = round(($importoImpostaRegistro / 100) * $percentualeLocCond, 2);
                        } else {
                            $importoImpostaRegistro = 0;
                        }
                        $rataD->setImponibile($importoImpostaRegistro);
                        $rataD->setImporto($importoImpostaRegistro);
                        $rataD->setIdCategoriaSpesa('R');
                        $rataD->saveOrUpdate();
                    }
                }
            }
        }
    }
}