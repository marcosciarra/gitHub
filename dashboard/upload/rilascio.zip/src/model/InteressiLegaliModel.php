<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-15
* Time: 11:42:56.099638
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class InteressiLegaliModel extends PdaAbstractModel {
/** @var integer */
protected $id;
/** @var integer */
protected $anno;
/** @var double */
protected $interesse;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='interessi_legali';$this->tableName='interessi_legali';}

/**
 * find by tables' Primary Key: 
 * @return InteressiLegali|array|string|null
 */
public function findByPk($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($id), $typeResult);}
/**
 * delete by tables' Primary Key: 
 */
public function deleteByPk($id){$query = "DELETE FROM $this->tableName  WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($id));}
/**
 * Find all record of table
 * @return InteressiLegali[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * find by id
 * @return InteressiLegali[]
 */
public function findById($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($id), $typeResult);}


/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->id))$arrayValue['id']=$this->id;if(isset($this->anno))$arrayValue['anno']=$this->anno;if(isset($this->interesse))$arrayValue['interesse']=$this->interesse;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['id'])) || (isset($keyArray['interessi_legali_id']))) {$this->setId(isset($keyArray['id'])?$keyArray['id']:$keyArray['interessi_legali_id']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['anno'])) || (isset($keyArray['interessi_legali_anno']))) {$this->setAnno(isset($keyArray['anno'])?$keyArray['anno']:$keyArray['interessi_legali_anno']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['interesse'])) || (isset($keyArray['interessi_legali_interesse']))) {$this->setInteresse(isset($keyArray['interesse'])?$keyArray['interesse']:$keyArray['interessi_legali_interesse']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['id'] =$positionalArray[0];$values['anno'] =$positionalArray[1];$values['interesse'] =$positionalArray[2];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['id'] = null;$values['anno'] = null;$values['interesse'] = null;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'interessi_legali.id as interessi_legali_id,interessi_legali.anno as interessi_legali_anno,interessi_legali.interesse as interessi_legali_interesse';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `interessi_legali` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `anno` int(10) unsigned NOT NULL,
  `interesse` decimal(8,4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ");}
/**
 * @return integer
 */
public function getId(){return $this->id;}
/**
 * @param integer $id Id
 */
public function setId($id){$this->id=$id;}
/**
 * @return integer
 */
public function getAnno(){return $this->anno;}
/**
 * @param integer $anno Anno
 */
public function setAnno($anno){$this->anno=$anno;}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getInteresse($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->interesse:number_format($this->interesse,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $interesse Interesse
 */
public function setInteresse($interesse){$this->interesse=$interesse;}
}