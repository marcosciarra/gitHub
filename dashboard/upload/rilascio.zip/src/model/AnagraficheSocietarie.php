<?php
/**
* Created by Drakkar vers. 0.0.23(Hjortspring)
* User: P.D.A. Srl
* Date: 2017-12-06
* Time: 15:21:59.496664
*/
namespace Click\Affitti\TblBase;
require_once 'AnagraficheSocietarieModel.php';
use Click\Affitti\TblBase\AnagraficheSocietarieModel;

class  AnagraficheSocietarie extends AnagraficheSocietarieModel {
    function __construct($pdo){
        parent::__construct($pdo);
    }
}