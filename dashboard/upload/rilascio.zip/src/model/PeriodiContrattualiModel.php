<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-15
* Time: 11:42:47.680325
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class PeriodiContrattualiModel extends PdaAbstractModel {
/** @var integer */
protected $id;
/** @var integer */
protected $idContratto;
/** @var integer */
protected $progressivo;
/** @var string */
protected $dataInizio;
/** @var string */
protected $dataFine;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='periodi_contrattuali';$this->tableName='periodi_contrattuali';}

/**
 * find by tables' Primary Key: 
 * @return PeriodiContrattuali|array|string|null
 */
public function findByPk($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($id), $typeResult);}
/**
 * delete by tables' Primary Key: 
 */
public function deleteByPk($id){$query = "DELETE FROM $this->tableName  WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($id));}
/**
 * Find all record of table
 * @return PeriodiContrattuali[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * find by tables' Key idx_id_contratto_progressivo: 
 * @return PeriodiContrattuali|array|string
 */
public function findByIdxIdContrattoProgressivo($idContratto,$progressivo,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(idx_id_contratto_progressivo) WHERE id_contratto=? AND progressivo=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($idContratto,$progressivo), $typeResult);}

/**
 * find by tables' Key idx_id_contratto: 
 * @return PeriodiContrattuali[]|array|string
 */
public function findByIdxIdContratto($idContratto,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_id_contratto) WHERE id_contratto=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($idContratto), $typeResult);}

/**
 * delete by tables' Key idx_id_contratto_progressivo: 
 * @return boolean
 */
public function deleteByIdxIdContrattoProgressivo($idContratto,$progressivo,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_contratto=? AND progressivo=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idContratto,$progressivo));}
/**
 * delete by tables' Key idx_id_contratto: 
 * @return boolean
 */
public function deleteByIdxIdContratto($idContratto,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_contratto=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idContratto));}
/**
 * find by id
 * @return PeriodiContrattuali[]
 */
public function findById($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($id), $typeResult);}


/**
 * find by id_contratto
 * @return PeriodiContrattuali[]
 */
public function findByIdContratto($idContratto,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id_contratto=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($idContratto), $typeResult);}


/**
 * delete by id_contratto
 * @return boolean
 */
public function deleteByIdContratto($idContratto){$query = "DELETE FROM $this->tableName WHERE id_contratto=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idContratto));}

/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->id))$arrayValue['id']=$this->id;if(isset($this->idContratto))$arrayValue['id_contratto']=$this->idContratto;if(isset($this->progressivo))$arrayValue['progressivo']=$this->progressivo;if(isset($this->dataInizio))$arrayValue['data_inizio']=$this->dataInizio;if(isset($this->dataFine))$arrayValue['data_fine']=$this->dataFine;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['id'])) || (isset($keyArray['periodi_contrattuali_id']))) {$this->setId(isset($keyArray['id'])?$keyArray['id']:$keyArray['periodi_contrattuali_id']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_contratto'])) || (isset($keyArray['periodi_contrattuali_id_contratto']))) {$this->setIdcontratto(isset($keyArray['id_contratto'])?$keyArray['id_contratto']:$keyArray['periodi_contrattuali_id_contratto']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['progressivo'])) || (isset($keyArray['periodi_contrattuali_progressivo']))) {$this->setProgressivo(isset($keyArray['progressivo'])?$keyArray['progressivo']:$keyArray['periodi_contrattuali_progressivo']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['data_inizio'])) || (isset($keyArray['periodi_contrattuali_data_inizio']))) {$this->setDatainizio(isset($keyArray['data_inizio'])?$keyArray['data_inizio']:$keyArray['periodi_contrattuali_data_inizio']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['data_fine'])) || (isset($keyArray['periodi_contrattuali_data_fine']))) {$this->setDatafine(isset($keyArray['data_fine'])?$keyArray['data_fine']:$keyArray['periodi_contrattuali_data_fine']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['id'] =$positionalArray[0];$values['id_contratto'] =$positionalArray[1];$values['progressivo'] =$positionalArray[2];$values['data_inizio'] =$positionalArray[3];$values['data_fine'] =$positionalArray[4];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['id'] = null;$values['id_contratto'] = null;$values['progressivo'] = null;$values['data_inizio'] = null;$values['data_fine'] = null;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'periodi_contrattuali.id as periodi_contrattuali_id,periodi_contrattuali.id_contratto as periodi_contrattuali_id_contratto,periodi_contrattuali.progressivo as periodi_contrattuali_progressivo,periodi_contrattuali.data_inizio as periodi_contrattuali_data_inizio,periodi_contrattuali.data_fine as periodi_contrattuali_data_fine';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `periodi_contrattuali` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_contratto` int(10) unsigned NOT NULL,
  `progressivo` int(10) unsigned NOT NULL,
  `data_inizio` date NOT NULL,
  `data_fine` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_id_contratto_progressivo` (`id_contratto`,`progressivo`),
  KEY `idx_id_contratto` (`id_contratto`),
  CONSTRAINT `fk_id_contratto_progressivo` FOREIGN KEY (`id_contratto`) REFERENCES `contratti` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=222 DEFAULT CHARSET=latin1 ");}
/**
 * @return integer
 */
public function getId(){return $this->id;}
/**
 * @param integer $id Id
 */
public function setId($id){$this->id=$id;}
/**
 * @return integer
 */
public function getIdContratto(){return $this->idContratto;}
/**
 * @param integer $idContratto IdContratto
 */
public function setIdContratto($idContratto){$this->idContratto=$idContratto;}
/**
 * @return integer
 */
public function getProgressivo(){return $this->progressivo;}
/**
 * @param integer $progressivo Progressivo
 */
public function setProgressivo($progressivo){$this->progressivo=$progressivo;}
/**
 * @return string
 */
public function getDataInizio(){return $this->dataInizio;}
/**
 * @param string $dataInizio DataInizio
 * @param int $encodeType
 */
public function setDataInizio($dataInizio,$encodeType = self::STR_DEFAULT){$this->dataInizio=$this->decodeString($dataInizio,$encodeType);}
/**
 * @return string
 */
public function getDataFine(){return $this->dataFine;}
/**
 * @param string $dataFine DataFine
 * @param int $encodeType
 */
public function setDataFine($dataFine,$encodeType = self::STR_DEFAULT){$this->dataFine=$this->decodeString($dataFine,$encodeType);}
}