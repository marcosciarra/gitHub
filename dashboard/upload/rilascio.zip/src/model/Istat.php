<?php
/**
 * Created by PhpStorm.
 * User: Duca
 * Date: 04/06/18
 * Time: 11:46
 */

namespace Click\Affitti\Viste;

require_once 'IstatFoi.php';
require_once 'IstatCustom.php';
require_once 'Opzioni.php';


use Click\Affitti\TblBase\DrakkarDbConnector;
use Click\Affitti\TblBase\DrakkarJsonException;
use Click\Affitti\TblBase\PdaInterfaceModel;
use Click\Affitti\TblBase\Opzioni;


class Istat implements PdaInterfaceModel
{
    protected $connCliente;

    protected $istat;

    protected $elencoTipiIstat = [];

    /**
     * Istat constructor.
     */
    public function __construct($conn, $connCliente, $type = 'Foi')
    {
        $this->elencoTipiIstat = ['Foi', 'Custom'];
        $class = 'Click\Affitti\TblBase\Istat' . ucfirst($type);
        $this->istat = new $class($conn);
        $this->connCliente = $connCliente;
    }


    /**
     * @param int $limit
     * @param int $offset
     * @return array
     */
    public function findAnni($limit = -1, $offset = -1)
    {
        $query = 'SELECT DISTINCT anno FROM ' . $this->istat->getTableName();
        // if ($this->whereBase) $query .= " WHERE $this->whereBase";
        // if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        //$query .= $this->istat->createLimitQuery($limit, $offset);
        return $this->istat->createResultArray($query, null, self::FETCH_VALUEARRAY);
    }

    /**
     * @param bool $distinct
     * @param int $typeResult
     * @param int $limit
     * @param int $offset
     * @return array|\Click\Affitti\TblBase\IstatFoi[]|string
     */
    public function findAll($distinct = false, $typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $app = $this->istat->findAll($distinct, $typeResult, $limit, $offset);
        $opz = new Opzioni($this->connCliente);
        //Controllo se da opzione devo mettere l'ISTAT a zero se è negativo
        if ($opz->findByPk(Opzioni::AZZERA_ISTAT_SE_NEGATIVO) == "1") {
            for ($i = 0; $i < count($app); $i++) {
                if ($app[$i]['a75'] < 0)
                    $app[$i]['a75'] = "0";
                if ($app[$i]['a100'] < 0)
                    $app[$i]['a100'] = "0";
                if ($app[$i]['b75'] < 0)
                    $app[$i]['b75'] = "0";
                if ($app[$i]['b100'] < 0)
                    $app[$i]['b100'] = "0";
            }
        }
        return $app;
    }



//TODO spostare in Contratti

    /**
     * select per pagina "aggiornamento istat"
     */
    public function findElencoAggiornamentoIstat($distinct = false, $typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $query = "
            SELECT 
                contratti.id AS idContratto,
                gestioni.id AS idGestione,
                gestioni.data_inizio,
                contratti_dettagli.mese_riferimento_istat,
                contratti_dettagli.colonna_tabella_istat,
                contratti_dettagli.mesi_conguaglio_istat,
                contratti_dettagli.tipo_tabella_istat,
                contratti.proprietari,
                contratti.conduttori,
                contratti.id_utente_riferimento,
                SUM(piano_rate_testa.importo) AS importo,
                YEAR(gestioni.data_inizio) AS anno
            FROM
                piano_rate_testa
                    INNER JOIN
                canoni_oneri ON piano_rate_testa.id_canoni_oneri = canoni_oneri.id
                    INNER JOIN
                contratti ON canoni_oneri.id_contratto = contratti.id
                    INNER JOIN
                contratti_dettagli ON contratti_dettagli.id = contratti.id
                    INNER JOIN
                gestioni ON piano_rate_testa.id_gestione = gestioni.id
            WHERE
                piano_rate_testa.data_aggiornamento_istat IS NULL
                    AND canoni_oneri.tipo_saldo = 'F'
                    AND contratti_dettagli.mese_riferimento_istat > 0
                    AND contratti.elaborato = 1
                    AND contratti.cestino = 0
                    AND gestioni.data_inizio <= NOW()
                    AND YEAR(contratti.data_inizio) < YEAR(gestioni.data_inizio) 
                    AND contratti_dettagli.mese_riferimento_istat < MONTH (NOW()) 
            GROUP BY contratti.id , YEAR(gestioni.data_inizio)
            ORDER BY mese_riferimento_istat
        ";
        //$query .= $this->istat->createLimitQuery($limit, $offset);
        return $this->istat->createResultArray($query, null, $typeResult);
    }

    /**
     * @return array
     */
    public function getElencoTipiIstat($perSelect = false): array
    {
        if ($perSelect) {
            $app = [];
            foreach ($this->elencoTipiIstat as $t) {
                $app[] = ['id' => strtolower($t), 'valore' => $t];
            }
            return $app;
        }
        return $this->elencoTipiIstat;
    }







    /* ----------------------------------------------------------------------------------------------------- */


    /**
     * Transforms the object into a key array
     *
     * @return array
     */
    public function createKeyArray()
    {
        // TODO: Implement toArrayAssoc() method.
    }

    /**
     * It transforms the keyarray in an object
     *
     * @param array $keyArray
     */
    public function createObjKeyArray(array $keyArray)
    {
        // TODO: Implement createObjKeyArray() method.
    }

    /**
     * @param array $positionalArray
     *
     * @return array
     */
    public function createKeyArrayFromPositional($positionalArray)
    {
        // TODO: Implement createKeyArrayFromPositional() method.
    }

    /**
     * Return columns' list
     *
     * @return string
     */
    public function getListColumns()
    {
        // TODO: Implement getListColumns() method.
    }

    /**
     * DDL Table
     */
    public function createTable()
    {
        // TODO: Implement createTable() method.
    }

    public function getEmptyDbKeyArray()
    {
        // TODO: Implement getEmptyDbKeyArray() method.
    }

    /**
     * Save the object into database
     *
     * @param bool $forcedInsert if true, save the object using the primary key that has been enhanced
     *
     * @return int|null|string
     */
    public function saveOrUpdate($forcedInsert)
    {
        // TODO: Implement saveOrUpdate() method.
    }

    /**
     * Save the object into database and save the operation log
     *
     * @param int $idUser
     * @param bool $forcedInsert if true, save the object using the primary key that has been enhanced
     *
     * @return int|null|string
     */
    public function saveOrUpdateAndLog($idUser, $forcedInsert)
    {
        // TODO: Implement saveOrUpdateAndLog() method.
    }

    /**
     * Truncate table's class
     *
     * @return  boolean
     */
    public function truncateTable()
    {
        // TODO: Implement truncateTable() method.
    }

    /**
     * Truncate table's class
     *
     * @param DrakkarDbConnector $conn
     *
     * @return  boolean
     */
    public static function truncateTableStatic($conn)
    {
        // TODO: Implement truncateTableStatic() method.
    }

    /**
     * Delete all data
     *
     * @return  boolean
     */
    public function deleteTable()
    {
        // TODO: Implement deleteTable() method.
    }

    /**
     * Delete all data
     * @param $idUser
     * @return  boolean
     */
    public function deleteTableAndLog($idUser)
    {
        // TODO: Implement deleteTableAndLog() method.
    }

    /**
     * Funzione per la cancellazione di tutto il contenuto della tabella
     *
     * @param DrakkarDbConnector $conn
     *
     * @return  boolean
     */
    public static function deleteTableStatic($conn)
    {
        // TODO: Implement deleteTableStatic() method.
    }

    /**
     * @return bool
     */
    public function checkPk()
    {
        // TODO: Implement checkPk() method.
    }

    /**
     * Exec Insert data on DB and set id
     *
     * @param $arrayValori
     *
     * @throws \Drakkar\Exception\DrakkarConnectionException
     * @throws \Drakkar\Exception\DrakkarException
     */
    public function insertDb($arrayValori)
    {
        // TODO: Implement insertDb() method.
    }

    /**
     * Dato un oggetto Json istanzia la classe e la popola con i valori
     *
     * @param      $json
     * @param bool $flgObjJson
     */
    public function creaObjJson($json, $flgObjJson = false)
    {
        // TODO: Implement creaObjJson() method.
    }

    /**
     * Restituisce la rappresentazione della classe in formato Json
     *
     * @return string
     */
    public function getEmptyObjJson()
    {
        // TODO: Implement getEmptyObjJson() method.
    }

    public function getEmptyDbJson()
    {
        // TODO: Implement getEmptyDbJson() method.
    }

    /**
     * Restituisce la rappresentazione della classe in formato array
     *
     * @return array
     */
    public function getEmptyObjKeyArray()
    {
        // TODO: Implement getEmptyObjKeyArray() method.
    }

    public function getJsonValue($metodo, $indice = null, $key = null)
    {
        // TODO: Implement getJsonValue() method.
    }

    /**
     * @param $input
     *
     * @return string|int
     */
    public function encodeObj($input)
    {
        // TODO: Implement encodeObj() method.
    }

    /**
     * @return DrakkarDbConnector
     */
    public function getConn()
    {
        // TODO: Implement getConn() method.
    }

    /**
     * @param DrakkarDbConnector $conn
     */
    public function setConn($conn)
    {
        // TODO: Implement setConn() method.
    }

    /**
     * @return string
     */
    public function getWhereBase()
    {
        // TODO: Implement getWhereBase() method.
    }

    /**
     * @param string $whereBase
     */
    public function setWhereBase($whereBase)
    {
        // TODO: Implement setWhereBase() method.
    }

    /**
     * @return string
     */
    public function getOrderBase()
    {
        // TODO: Implement getOrderBase() method.
    }

    /**
     * @param string $orderBase
     */
    public function setOrderBase($orderBase)
    {
        // TODO: Implement setOrderBase() method.
    }

    /**
     * @return string
     */
    public function getTableName()
    {
        // TODO: Implement getTableName() method.
    }

    /**
     * @param string $tableName
     */
    public function setTableName($tableName)
    {
        // TODO: Implement setTableName() method.
    }

    /**
     * @return integer
     */
    public function getLimitBase()
    {
        // TODO: Implement getLimitBase() method.
    }

    /**
     * @param integer $limitBase
     */
    public function setLimitBase($limitBase)
    {
        // TODO: Implement setLimitBase() method.
    }

    /**
     * @return integer
     */
    public function getOffsetBase()
    {
        // TODO: Implement getOffsetBase() method.
    }

    /**
     * @param integer $offsetBase
     */
    public function setOffsetBase($offsetBase)
    {
        // TODO: Implement setOffsetBase() method.
    }

    /**
     * @return bool
     */
    public function isFlagObjectDataValorized()
    {
        // TODO: Implement isFlagObjectDataValorized() method.
    }

    /**
     * @param $string
     *
     * @return bool
     */
    public function isJson($string)
    {
        // TODO: Implement isJson() method.
    }

    /**
     * @param $j
     *
     * @return string
     */
    public function jsonEncode($string)
    {
        // TODO: Implement jsonEncode() method.
    }

    /**
     * @param $string
     *
     * @return string
     * @throws DrakkarJsonException
     */
    public function jsonDecode($string)
    {
        // TODO: Implement jsonDecode() method.
    }
}