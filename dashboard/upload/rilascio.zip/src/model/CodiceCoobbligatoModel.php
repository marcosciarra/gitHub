<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-15
* Time: 11:42:56.032514
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class CodiceCoobbligatoModel extends PdaAbstractModel {
/** @var string */
protected $codice;
/** @var string */
protected $descrizione;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='codice_coobbligato';$this->tableName='codice_coobbligato';}

/**
 * find by tables' Primary Key: 
 * @return CodiceCoobbligato|array|string|null
 */
public function findByPk($codice,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE codice=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($codice), $typeResult);}
/**
 * delete by tables' Primary Key: 
 */
public function deleteByPk($codice){$query = "DELETE FROM $this->tableName  WHERE codice=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($codice));}
/**
 * Find all record of table
 * @return CodiceCoobbligato[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * find by codice
 * @return CodiceCoobbligato[]
 */
public function findByCodice($codice,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE codice=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($codice), $typeResult);}


/**
 * find like codice
 * @return CodiceCoobbligato[]
 */
public function findLikeCodice($codice,$likeMatching=self::LIKE_MATCHING_BOTH, $typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE codice like ?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($this->prepareLikeMatching($codice,$likeMatching)), $typeResult);}

/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->codice))$arrayValue['codice']=$this->codice;if(isset($this->descrizione))$arrayValue['descrizione']=($this->descrizione==self::NULL_VALUE)?null:$this->descrizione;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['codice'])) || (isset($keyArray['codice_coobbligato_codice']))) {$this->setCodice(isset($keyArray['codice'])?$keyArray['codice']:$keyArray['codice_coobbligato_codice']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['descrizione'])) || (isset($keyArray['codice_coobbligato_descrizione']))) {$this->setDescrizione(isset($keyArray['descrizione'])?$keyArray['descrizione']:$keyArray['codice_coobbligato_descrizione']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['codice'] =$positionalArray[0];$values['descrizione'] =($positionalArray[1]==self::NULL_VALUE)?null:$positionalArray[1];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['codice'] = null;$values['descrizione'] = null;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'codice_coobbligato.codice as codice_coobbligato_codice,codice_coobbligato.descrizione as codice_coobbligato_descrizione';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `codice_coobbligato` (
  `codice` varchar(2) NOT NULL,
  `descrizione` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`codice`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ");}
/**
 * @return string
 */
public function getCodice(){return $this->codice;}
/**
 * @param string $codice Codice
 * @param int $encodeType
 */
public function setCodice($codice,$encodeType = self::STR_DEFAULT){$this->codice=$this->decodeString($codice,$encodeType);}
/**
 * @return string
 */
public function getDescrizione(){return $this->descrizione;}
/**
 * @param string $descrizione Descrizione
 * @param int $encodeType
 */
public function setDescrizione($descrizione,$encodeType = self::STR_DEFAULT){$this->descrizione=$this->decodeString($descrizione,$encodeType);}
}