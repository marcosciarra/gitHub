<?php
/**
* Created by Drakkar vers. 0.1.2(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-06-26
* Time: 17:35:36.349175
*/
namespace Click\Affitti\TblBase;
require_once 'ContrattoNoteModel.php';
use Click\Affitti\TblBase\ContrattoNoteModel;

class  ContrattoNote extends ContrattoNoteModel {
function __construct($pdo){parent::__construct($pdo);}

}