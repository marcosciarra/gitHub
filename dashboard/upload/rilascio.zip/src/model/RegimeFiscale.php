<?php
/**
 * Created by Drakkar vers. 0.1.0(Hjortspring)
 * User: P.D.A. Srl
 * Date: 2018-04-04
 * Time: 17:19:33.774525
 */

namespace Click\Affitti\TblBase;
require_once 'RegimeFiscaleModel.php';

use Click\Affitti\TblBase\RegimeFiscaleModel;

class  RegimeFiscal extends RegimeFiscaleModel
{
    function __construct($pdo)
    {
        parent::__construct($pdo);
    }
}