<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-15
* Time: 11:42:47.585494
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class IstatCustomModel extends PdaAbstractModel {
/** @var integer */
protected $id;
/** @var integer */
protected $anno;
/** @var integer */
protected $mese;
/** @var double */
protected $a75;
/** @var double */
protected $a100;
/** @var double */
protected $b75;
/** @var double */
protected $b100;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='istat_custom';$this->tableName='istat_custom';}

/**
 * find by tables' Primary Key: 
 * @return IstatCustom|array|string|null
 */
public function findByPk($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($id), $typeResult);}
/**
 * delete by tables' Primary Key: 
 */
public function deleteByPk($id){$query = "DELETE FROM $this->tableName  WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($id));}
/**
 * Find all record of table
 * @return IstatCustom[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * find by id
 * @return IstatCustom[]
 */
public function findById($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($id), $typeResult);}


/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->id))$arrayValue['id']=$this->id;if(isset($this->anno))$arrayValue['anno']=$this->anno;if(isset($this->mese))$arrayValue['mese']=$this->mese;if(isset($this->a75))$arrayValue['a75']=($this->a75==self::NULL_VALUE)?null:$this->a75;if(isset($this->a100))$arrayValue['a100']=($this->a100==self::NULL_VALUE)?null:$this->a100;if(isset($this->b75))$arrayValue['b75']=($this->b75==self::NULL_VALUE)?null:$this->b75;if(isset($this->b100))$arrayValue['b100']=($this->b100==self::NULL_VALUE)?null:$this->b100;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['id'])) || (isset($keyArray['istat_custom_id']))) {$this->setId(isset($keyArray['id'])?$keyArray['id']:$keyArray['istat_custom_id']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['anno'])) || (isset($keyArray['istat_custom_anno']))) {$this->setAnno(isset($keyArray['anno'])?$keyArray['anno']:$keyArray['istat_custom_anno']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['mese'])) || (isset($keyArray['istat_custom_mese']))) {$this->setMese(isset($keyArray['mese'])?$keyArray['mese']:$keyArray['istat_custom_mese']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['a75'])) || (isset($keyArray['istat_custom_a75']))) {$this->setA75(isset($keyArray['a75'])?$keyArray['a75']:$keyArray['istat_custom_a75']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['a100'])) || (isset($keyArray['istat_custom_a100']))) {$this->setA100(isset($keyArray['a100'])?$keyArray['a100']:$keyArray['istat_custom_a100']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['b75'])) || (isset($keyArray['istat_custom_b75']))) {$this->setB75(isset($keyArray['b75'])?$keyArray['b75']:$keyArray['istat_custom_b75']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['b100'])) || (isset($keyArray['istat_custom_b100']))) {$this->setB100(isset($keyArray['b100'])?$keyArray['b100']:$keyArray['istat_custom_b100']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['id'] =$positionalArray[0];$values['anno'] =$positionalArray[1];$values['mese'] =$positionalArray[2];$values['a75'] =($positionalArray[3]==self::NULL_VALUE)?null:$positionalArray[3];$values['a100'] =($positionalArray[4]==self::NULL_VALUE)?null:$positionalArray[4];$values['b75'] =($positionalArray[5]==self::NULL_VALUE)?null:$positionalArray[5];$values['b100'] =($positionalArray[6]==self::NULL_VALUE)?null:$positionalArray[6];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['id'] = null;$values['anno'] = null;$values['mese'] = null;$values['a75'] = null;$values['a100'] = null;$values['b75'] = null;$values['b100'] = null;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'istat_custom.id as istat_custom_id,istat_custom.anno as istat_custom_anno,istat_custom.mese as istat_custom_mese,istat_custom.a75 as istat_custom_a75,istat_custom.a100 as istat_custom_a100,istat_custom.b75 as istat_custom_b75,istat_custom.b100 as istat_custom_b100';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `istat_custom` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `anno` int(10) unsigned NOT NULL,
  `mese` int(10) unsigned NOT NULL,
  `a75` decimal(6,4) DEFAULT NULL,
  `a100` decimal(6,4) DEFAULT NULL,
  `b75` decimal(6,4) DEFAULT NULL,
  `b100` decimal(6,4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ");}
/**
 * @return integer
 */
public function getId(){return $this->id;}
/**
 * @param integer $id Id
 */
public function setId($id){$this->id=$id;}
/**
 * @return integer
 */
public function getAnno(){return $this->anno;}
/**
 * @param integer $anno Anno
 */
public function setAnno($anno){$this->anno=$anno;}
/**
 * @return integer
 */
public function getMese(){return $this->mese;}
/**
 * @param integer $mese Mese
 */
public function setMese($mese){$this->mese=$mese;}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getA75($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->a75:number_format($this->a75,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $a75 A75
 */
public function setA75($a75){$this->a75=$a75;}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getA100($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->a100:number_format($this->a100,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $a100 A100
 */
public function setA100($a100){$this->a100=$a100;}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getB75($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->b75:number_format($this->b75,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $b75 B75
 */
public function setB75($b75){$this->b75=$b75;}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getB100($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->b100:number_format($this->b100,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $b100 B100
 */
public function setB100($b100){$this->b100=$b100;}
}