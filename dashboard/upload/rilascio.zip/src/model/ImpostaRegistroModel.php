<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-15
* Time: 11:42:47.535436
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class ImpostaRegistroModel extends PdaAbstractModel {
/** @var integer */
protected $id;
/** @var integer */
protected $idRli;
/** @var integer */
protected $idCodiceIdentificativo;
/** @var integer */
protected $idGestione;
/** @var string */
protected $codiceUfficio;
/** @var string */
protected $serie;
/** @var string */
protected $numero;
/** @var string */
protected $sottonumero;
/** @var objext (string) */
protected $dettagli;
/** @var double */
protected $importoTotale;
/** @var string (enum) S = STIPULA<br/>P = PROROGA<br/>R = RINNOVO<br/>D = DISDETTA*/
protected $tipoRinnovo;
/** @var string */
protected $dataScadenza;
/** @var string */
protected $dataVersamento;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='imposta_registro';$this->tableName='imposta_registro';}

/**
 * find by tables' Primary Key: 
 * @return ImpostaRegistro|array|string|null
 */
public function findByPk($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($id), $typeResult);}
/**
 * delete by tables' Primary Key: 
 */
public function deleteByPk($id){$query = "DELETE FROM $this->tableName  WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($id));}
/**
 * Find all record of table
 * @return ImpostaRegistro[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * find by tables' Key idx_id_rli: 
 * @return ImpostaRegistro[]|array|string
 */
public function findByIdxIdRli($idRli,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_id_rli) WHERE id_rli=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($idRli), $typeResult);}

/**
 * find by tables' Key fk_imposta_registro_2_idx: 
 * @return ImpostaRegistro[]|array|string
 */
public function findByFkImpostaRegistro2Idx($idGestione,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(fk_imposta_registro_2_idx) WHERE id_gestione=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($idGestione), $typeResult);}

/**
 * delete by tables' Key idx_id_rli: 
 * @return boolean
 */
public function deleteByIdxIdRli($idRli,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_rli=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idRli));}
/**
 * delete by tables' Key fk_imposta_registro_2_idx: 
 * @return boolean
 */
public function deleteByFkImpostaRegistro2Idx($idGestione,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_gestione=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idGestione));}
/**
 * find by id
 * @return ImpostaRegistro[]
 */
public function findById($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($id), $typeResult);}


/**
 * find by id_rli
 * @return ImpostaRegistro[]
 */
public function findByIdRli($idRli,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id_rli=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($idRli), $typeResult);}


/**
 * find by id_gestione
 * @return ImpostaRegistro[]
 */
public function findByIdGestione($idGestione,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id_gestione=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($idGestione), $typeResult);}


/**
 * delete by id_rli
 * @return boolean
 */
public function deleteByIdRli($idRli){$query = "DELETE FROM $this->tableName WHERE id_rli=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idRli));}

/**
 * delete by id_gestione
 * @return boolean
 */
public function deleteByIdGestione($idGestione){$query = "DELETE FROM $this->tableName WHERE id_gestione=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idGestione));}

/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->id))$arrayValue['id']=$this->id;if(isset($this->idRli))$arrayValue['id_rli']=($this->idRli==self::NULL_VALUE)?null:$this->idRli;if(isset($this->idCodiceIdentificativo))$arrayValue['id_codice_identificativo']=($this->idCodiceIdentificativo==self::NULL_VALUE)?null:$this->idCodiceIdentificativo;if(isset($this->idGestione))$arrayValue['id_gestione']=($this->idGestione==self::NULL_VALUE)?null:$this->idGestione;if(isset($this->codiceUfficio))$arrayValue['codice_ufficio']=($this->codiceUfficio==self::NULL_VALUE)?null:$this->codiceUfficio;if(isset($this->serie))$arrayValue['serie']=($this->serie==self::NULL_VALUE)?null:$this->serie;if(isset($this->numero))$arrayValue['numero']=($this->numero==self::NULL_VALUE)?null:$this->numero;if(isset($this->sottonumero))$arrayValue['sottonumero']=($this->sottonumero==self::NULL_VALUE)?null:$this->sottonumero;if(isset($this->dettagli))$arrayValue['dettagli']=$this->jsonEncode($this->dettagli);if(isset($this->importoTotale))$arrayValue['importo_totale']=($this->importoTotale==self::NULL_VALUE)?null:$this->importoTotale;if(isset($this->tipoRinnovo))$arrayValue['tipo_rinnovo']=($this->tipoRinnovo==self::NULL_VALUE)?null:$this->tipoRinnovo;if(isset($this->dataScadenza))$arrayValue['data_scadenza']=($this->dataScadenza==self::NULL_VALUE)?null:$this->dataScadenza;if(isset($this->dataVersamento))$arrayValue['data_versamento']=($this->dataVersamento==self::NULL_VALUE)?null:$this->dataVersamento;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['id'])) || (isset($keyArray['imposta_registro_id']))) {$this->setId(isset($keyArray['id'])?$keyArray['id']:$keyArray['imposta_registro_id']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_rli'])) || (isset($keyArray['imposta_registro_id_rli']))) {$this->setIdrli(isset($keyArray['id_rli'])?$keyArray['id_rli']:$keyArray['imposta_registro_id_rli']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_codice_identificativo'])) || (isset($keyArray['imposta_registro_id_codice_identificativo']))) {$this->setIdcodiceidentificativo(isset($keyArray['id_codice_identificativo'])?$keyArray['id_codice_identificativo']:$keyArray['imposta_registro_id_codice_identificativo']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_gestione'])) || (isset($keyArray['imposta_registro_id_gestione']))) {$this->setIdgestione(isset($keyArray['id_gestione'])?$keyArray['id_gestione']:$keyArray['imposta_registro_id_gestione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['codice_ufficio'])) || (isset($keyArray['imposta_registro_codice_ufficio']))) {$this->setCodiceufficio(isset($keyArray['codice_ufficio'])?$keyArray['codice_ufficio']:$keyArray['imposta_registro_codice_ufficio']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['serie'])) || (isset($keyArray['imposta_registro_serie']))) {$this->setSerie(isset($keyArray['serie'])?$keyArray['serie']:$keyArray['imposta_registro_serie']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['numero'])) || (isset($keyArray['imposta_registro_numero']))) {$this->setNumero(isset($keyArray['numero'])?$keyArray['numero']:$keyArray['imposta_registro_numero']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['sottonumero'])) || (isset($keyArray['imposta_registro_sottonumero']))) {$this->setSottonumero(isset($keyArray['sottonumero'])?$keyArray['sottonumero']:$keyArray['imposta_registro_sottonumero']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['dettagli'])) || (isset($keyArray['imposta_registro_dettagli']))) {$this->setDettagli(isset($keyArray['dettagli'])?$keyArray['dettagli']:$keyArray['imposta_registro_dettagli']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['importo_totale'])) || (isset($keyArray['imposta_registro_importo_totale']))) {$this->setImportototale(isset($keyArray['importo_totale'])?$keyArray['importo_totale']:$keyArray['imposta_registro_importo_totale']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['tipo_rinnovo'])) || (isset($keyArray['imposta_registro_tipo_rinnovo']))) {$this->setTiporinnovo(isset($keyArray['tipo_rinnovo'])?$keyArray['tipo_rinnovo']:$keyArray['imposta_registro_tipo_rinnovo']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['data_scadenza'])) || (isset($keyArray['imposta_registro_data_scadenza']))) {$this->setDatascadenza(isset($keyArray['data_scadenza'])?$keyArray['data_scadenza']:$keyArray['imposta_registro_data_scadenza']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['data_versamento'])) || (isset($keyArray['imposta_registro_data_versamento']))) {$this->setDataversamento(isset($keyArray['data_versamento'])?$keyArray['data_versamento']:$keyArray['imposta_registro_data_versamento']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['id'] =$positionalArray[0];$values['id_rli'] =($positionalArray[1]==self::NULL_VALUE)?null:$positionalArray[1];$values['id_codice_identificativo'] =($positionalArray[2]==self::NULL_VALUE)?null:$positionalArray[2];$values['id_gestione'] =($positionalArray[3]==self::NULL_VALUE)?null:$positionalArray[3];$values['codice_ufficio'] =($positionalArray[4]==self::NULL_VALUE)?null:$positionalArray[4];$values['serie'] =($positionalArray[5]==self::NULL_VALUE)?null:$positionalArray[5];$values['numero'] =($positionalArray[6]==self::NULL_VALUE)?null:$positionalArray[6];$values['sottonumero'] =($positionalArray[7]==self::NULL_VALUE)?null:$positionalArray[7];$values['dettagli'] =($positionalArray[8]==self::NULL_VALUE)?null:$positionalArray[8];$values['importo_totale'] =($positionalArray[9]==self::NULL_VALUE)?null:$positionalArray[9];$values['tipo_rinnovo'] =($positionalArray[10]==self::NULL_VALUE)?null:$positionalArray[10];$values['data_scadenza'] =($positionalArray[11]==self::NULL_VALUE)?null:$positionalArray[11];$values['data_versamento'] =($positionalArray[12]==self::NULL_VALUE)?null:$positionalArray[12];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['id'] = null;$values['id_rli'] = null;$values['id_codice_identificativo'] = null;$values['id_gestione'] = null;$values['codice_ufficio'] = null;$values['serie'] = null;$values['numero'] = null;$values['sottonumero'] = null;$values['dettagli'] = null;$values['importo_totale'] = null;$values['tipo_rinnovo'] = null;$values['data_scadenza'] = null;$values['data_versamento'] = null;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'imposta_registro.id as imposta_registro_id,imposta_registro.id_rli as imposta_registro_id_rli,imposta_registro.id_codice_identificativo as imposta_registro_id_codice_identificativo,imposta_registro.id_gestione as imposta_registro_id_gestione,imposta_registro.codice_ufficio as imposta_registro_codice_ufficio,imposta_registro.serie as imposta_registro_serie,imposta_registro.numero as imposta_registro_numero,imposta_registro.sottonumero as imposta_registro_sottonumero,imposta_registro.dettagli as imposta_registro_dettagli,imposta_registro.importo_totale as imposta_registro_importo_totale,imposta_registro.tipo_rinnovo as imposta_registro_tipo_rinnovo,imposta_registro.data_scadenza as imposta_registro_data_scadenza,imposta_registro.data_versamento as imposta_registro_data_versamento';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `imposta_registro` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_rli` int(10) unsigned DEFAULT NULL,
  `id_codice_identificativo` int(10) unsigned DEFAULT NULL,
  `id_gestione` int(10) unsigned DEFAULT NULL,
  `codice_ufficio` varchar(3) DEFAULT NULL,
  `serie` varchar(2) DEFAULT NULL,
  `numero` varchar(6) DEFAULT NULL,
  `sottonumero` varchar(3) DEFAULT NULL,
  `dettagli` json DEFAULT NULL,
  `importo_totale` double DEFAULT NULL,
  `tipo_rinnovo` enum('S','P','R','D') DEFAULT NULL COMMENT 'S = STIPULA\nP = PROROGA\nR = RINNOVO\nD = DISDETTA',
  `data_scadenza` date DEFAULT NULL,
  `data_versamento` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_id_rli` (`id_rli`),
  KEY `fk_imposta_registro_2_idx` (`id_gestione`),
  CONSTRAINT `fk_imposta_registro_1` FOREIGN KEY (`id_rli`) REFERENCES `rli` (`id`),
  CONSTRAINT `fk_imposta_registro_2` FOREIGN KEY (`id_gestione`) REFERENCES `gestioni` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=950 DEFAULT CHARSET=latin1 ");}
/**
 * @return integer
 */
public function getId(){return $this->id;}
/**
 * @param integer $id Id
 */
public function setId($id){$this->id=$id;}
/**
 * @return integer
 */
public function getIdRli(){return $this->idRli;}
/**
 * @param integer $idRli IdRli
 */
public function setIdRli($idRli){$this->idRli=$idRli;}
/**
 * @return integer
 */
public function getIdCodiceIdentificativo(){return $this->idCodiceIdentificativo;}
/**
 * @param integer $idCodiceIdentificativo IdCodiceIdentificativo
 */
public function setIdCodiceIdentificativo($idCodiceIdentificativo){$this->idCodiceIdentificativo=$idCodiceIdentificativo;}
/**
 * @return integer
 */
public function getIdGestione(){return $this->idGestione;}
/**
 * @param integer $idGestione IdGestione
 */
public function setIdGestione($idGestione){$this->idGestione=$idGestione;}
/**
 * @return string
 */
public function getCodiceUfficio(){return $this->codiceUfficio;}
/**
 * @param string $codiceUfficio CodiceUfficio
 * @param int $encodeType
 */
public function setCodiceUfficio($codiceUfficio,$encodeType = self::STR_DEFAULT){$this->codiceUfficio=$this->decodeString($codiceUfficio,$encodeType);}
/**
 * @return string
 */
public function getSerie(){return $this->serie;}
/**
 * @param string $serie Serie
 * @param int $encodeType
 */
public function setSerie($serie,$encodeType = self::STR_DEFAULT){$this->serie=$this->decodeString($serie,$encodeType);}
/**
 * @return string
 */
public function getNumero(){return $this->numero;}
/**
 * @param string $numero Numero
 * @param int $encodeType
 */
public function setNumero($numero,$encodeType = self::STR_DEFAULT){$this->numero=$this->decodeString($numero,$encodeType);}
/**
 * @return string
 */
public function getSottonumero(){return $this->sottonumero;}
/**
 * @param string $sottonumero Sottonumero
 * @param int $encodeType
 */
public function setSottonumero($sottonumero,$encodeType = self::STR_DEFAULT){$this->sottonumero=$this->decodeString($sottonumero,$encodeType);}
/**
 * @return objext (string)
 */
public function getDettagli(){return $this->dettagli;}
/**
 * @param objext (string) $dettagli Dettagli
 */
public function setDettagli($dettagli){$this->dettagli=$dettagli;}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getImportoTotale($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->importoTotale:number_format($this->importoTotale,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $importoTotale ImportoTotale
 */
public function setImportoTotale($importoTotale){$this->importoTotale=$importoTotale;}
/**
 * @param bool $decode if true return decode value * @return string
 */
public function getTipoRinnovo($decode=false){return ($decode)?$this->getTipoRinnovoValuesList()[$this->tipoRinnovo]:$this->tipoRinnovo;}
/**
 * @param bool $json if true return value json's array else return array values * @return array|string
 */
public function getTipoRinnovoValuesList($json=false){$kv=['S'=>'STIPULA','P'=>'PROROGA','R'=>'RINNOVO','D'=>'DISDETTA'];return ($json)?$this->createJsonKeyValArray($kv):$kv;}
/**
 * @param string (enum) $tipoRinnovo TipoRinnovo
 */
public function setTipoRinnovo($tipoRinnovo){$this->tipoRinnovo=$tipoRinnovo;}
/**
 * @return string
 */
public function getDataScadenza(){return $this->dataScadenza;}
/**
 * @param string $dataScadenza DataScadenza
 * @param int $encodeType
 */
public function setDataScadenza($dataScadenza,$encodeType = self::STR_DEFAULT){$this->dataScadenza=$this->decodeString($dataScadenza,$encodeType);}
/**
 * @return string
 */
public function getDataVersamento(){return $this->dataVersamento;}
/**
 * @param string $dataVersamento DataVersamento
 * @param int $encodeType
 */
public function setDataVersamento($dataVersamento,$encodeType = self::STR_DEFAULT){$this->dataVersamento=$this->decodeString($dataVersamento,$encodeType);}
}