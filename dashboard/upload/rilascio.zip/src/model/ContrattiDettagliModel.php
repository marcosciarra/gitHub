<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-16
* Time: 14:23:01.514564
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class ContrattiDettagliModel extends PdaAbstractModel {
/** @var integer */
protected $id;
/** @var string (enum) */
protected $tipoTabellaIstat;
/** @var string (enum) */
protected $colonnaTabellaIstat;
/** @var integer */
protected $meseRiferimentoIstat=0;
/** @var integer */
protected $mesiConguaglioIstat=0;
/** @var string */
protected $dataConsegnaChiavi;
/** @var integer */
protected $idContoCorrente;
/** @var string (enum) F = FATTURA<br/>M = MAV<br/>A = AVVISO DI PAGAMENTO<br/>R = RID*/
protected $bollettazioneTipo;
/** @var string (enum) N = NO EMISSIONE<br/>V = A VISTA<br/>P = PAGAMENTO*/
protected $bollettazioneFatttura='N';
/** @var string (enum) N = NESSUNA RIMESSA<br/>P = PERCENTUALE SUL CANONE ANNUO<br/>Q = QUOTA FISSA*/
protected $tipoRimessa;
/** @var integer */
protected $percentualeRimessa;
/** @var double */
protected $quotaRimessa;
/** @var string */
protected $dataRataIniziale;
/** @var integer */
protected $idGruppoFatturazione;
/** @var string */
protected $dataRegistrazione;
/** @var string */
protected $luogoStipula;
/** @var string */
protected $descrizioneBolloRegistrazione='Bollo per la registrazione del contratto';
/** @var double */
protected $bolloRegistrazione=0.00;
/** @var integer */
protected $intestatarioLocatore;
/** @var integer */
protected $intestatarioConduttore;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='contratti_dettagli';$this->tableName='contratti_dettagli';}

/**
 * find by tables' Primary Key: 
 * @return ContrattiDettagli|array|string|null
 */
public function findByPk($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($id), $typeResult);}
/**
 * delete by tables' Primary Key: 
 */
public function deleteByPk($id){$query = "DELETE FROM $this->tableName  WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($id));}
/**
 * Find all record of table
 * @return ContrattiDettagli[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * find by tables' Key fk_contratti_dettagli_gruppo_fatturazione1_idx: 
 * @return ContrattiDettagli[]|array|string
 */
public function findByFkContrattiDettagliGruppoFatturazione1Idx($idGruppoFatturazione,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(fk_contratti_dettagli_gruppo_fatturazione1_idx) WHERE id_gruppo_fatturazione=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($idGruppoFatturazione), $typeResult);}

/**
 * find by tables' Key fk_conti_correnti_idx: 
 * @return ContrattiDettagli[]|array|string
 */
public function findByFkContiCorrentiIdx($idContoCorrente,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(fk_conti_correnti_idx) WHERE id_conto_corrente=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($idContoCorrente), $typeResult);}

/**
 * find by tables' Key idx_intestatario_locatore: 
 * @return ContrattiDettagli[]|array|string
 */
public function findByIdxIntestatarioLocatore($intestatarioLocatore,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_intestatario_locatore) WHERE intestatario_locatore=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($intestatarioLocatore), $typeResult);}

/**
 * find by tables' Key idx_intestatario_conduttore: 
 * @return ContrattiDettagli[]|array|string
 */
public function findByIdxIntestatarioConduttore($intestatarioConduttore,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_intestatario_conduttore) WHERE intestatario_conduttore=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($intestatarioConduttore), $typeResult);}

/**
 * delete by tables' Key fk_contratti_dettagli_gruppo_fatturazione1_idx: 
 * @return boolean
 */
public function deleteByFkContrattiDettagliGruppoFatturazione1Idx($idGruppoFatturazione,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_gruppo_fatturazione=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idGruppoFatturazione));}
/**
 * delete by tables' Key fk_conti_correnti_idx: 
 * @return boolean
 */
public function deleteByFkContiCorrentiIdx($idContoCorrente,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_conto_corrente=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idContoCorrente));}
/**
 * delete by tables' Key idx_intestatario_locatore: 
 * @return boolean
 */
public function deleteByIdxIntestatarioLocatore($intestatarioLocatore,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE intestatario_locatore=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($intestatarioLocatore));}
/**
 * delete by tables' Key idx_intestatario_conduttore: 
 * @return boolean
 */
public function deleteByIdxIntestatarioConduttore($intestatarioConduttore,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE intestatario_conduttore=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($intestatarioConduttore));}
/**
 * find by id
 * @return ContrattiDettagli[]
 */
public function findById($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($id), $typeResult);}


/**
 * find by id_conto_corrente
 * @return ContrattiDettagli[]
 */
public function findByIdContoCorrente($idContoCorrente,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id_conto_corrente=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($idContoCorrente), $typeResult);}


/**
 * find by id_gruppo_fatturazione
 * @return ContrattiDettagli[]
 */
public function findByIdGruppoFatturazione($idGruppoFatturazione,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id_gruppo_fatturazione=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($idGruppoFatturazione), $typeResult);}


/**
 * find by intestatario_locatore
 * @return ContrattiDettagli[]
 */
public function findByIntestatarioLocatore($intestatarioLocatore,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE intestatario_locatore=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($intestatarioLocatore), $typeResult);}


/**
 * find by intestatario_conduttore
 * @return ContrattiDettagli[]
 */
public function findByIntestatarioConduttore($intestatarioConduttore,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE intestatario_conduttore=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($intestatarioConduttore), $typeResult);}


/**
 * delete by id_conto_corrente
 * @return boolean
 */
public function deleteByIdContoCorrente($idContoCorrente){$query = "DELETE FROM $this->tableName WHERE id_conto_corrente=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idContoCorrente));}

/**
 * delete by id_gruppo_fatturazione
 * @return boolean
 */
public function deleteByIdGruppoFatturazione($idGruppoFatturazione){$query = "DELETE FROM $this->tableName WHERE id_gruppo_fatturazione=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idGruppoFatturazione));}

/**
 * delete by intestatario_locatore
 * @return boolean
 */
public function deleteByIntestatarioLocatore($intestatarioLocatore){$query = "DELETE FROM $this->tableName WHERE intestatario_locatore=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($intestatarioLocatore));}

/**
 * delete by intestatario_conduttore
 * @return boolean
 */
public function deleteByIntestatarioConduttore($intestatarioConduttore){$query = "DELETE FROM $this->tableName WHERE intestatario_conduttore=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($intestatarioConduttore));}

/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->id))$arrayValue['id']=$this->id;if(isset($this->tipoTabellaIstat))$arrayValue['tipo_tabella_istat']=($this->tipoTabellaIstat==self::NULL_VALUE)?null:$this->tipoTabellaIstat;if(isset($this->colonnaTabellaIstat))$arrayValue['colonna_tabella_istat']=($this->colonnaTabellaIstat==self::NULL_VALUE)?null:$this->colonnaTabellaIstat;if(isset($this->meseRiferimentoIstat))$arrayValue['mese_riferimento_istat']=($this->meseRiferimentoIstat==self::NULL_VALUE)?null:$this->meseRiferimentoIstat;if(isset($this->mesiConguaglioIstat))$arrayValue['mesi_conguaglio_istat']=($this->mesiConguaglioIstat==self::NULL_VALUE)?null:$this->mesiConguaglioIstat;if(isset($this->dataConsegnaChiavi))$arrayValue['data_consegna_chiavi']=($this->dataConsegnaChiavi==self::NULL_VALUE)?null:$this->dataConsegnaChiavi;if(isset($this->idContoCorrente))$arrayValue['id_conto_corrente']=($this->idContoCorrente==self::NULL_VALUE)?null:$this->idContoCorrente;if(isset($this->bollettazioneTipo))$arrayValue['bollettazione_tipo']=$this->bollettazioneTipo;if(isset($this->bollettazioneFatttura))$arrayValue['bollettazione_fatttura']=$this->bollettazioneFatttura;if(isset($this->tipoRimessa))$arrayValue['tipo_rimessa']=($this->tipoRimessa==self::NULL_VALUE)?null:$this->tipoRimessa;if(isset($this->percentualeRimessa))$arrayValue['percentuale_rimessa']=$this->percentualeRimessa;if(isset($this->quotaRimessa))$arrayValue['quota_rimessa']=$this->quotaRimessa;if(isset($this->dataRataIniziale))$arrayValue['data_rata_iniziale']=($this->dataRataIniziale==self::NULL_VALUE)?null:$this->dataRataIniziale;if(isset($this->idGruppoFatturazione))$arrayValue['id_gruppo_fatturazione']=($this->idGruppoFatturazione==self::NULL_VALUE)?null:$this->idGruppoFatturazione;if(isset($this->dataRegistrazione))$arrayValue['data_registrazione']=($this->dataRegistrazione==self::NULL_VALUE)?null:$this->dataRegistrazione;if(isset($this->luogoStipula))$arrayValue['luogo_stipula']=($this->luogoStipula==self::NULL_VALUE)?null:$this->luogoStipula;if(isset($this->descrizioneBolloRegistrazione))$arrayValue['descrizione_bollo_registrazione']=($this->descrizioneBolloRegistrazione==self::NULL_VALUE)?null:$this->descrizioneBolloRegistrazione;if(isset($this->bolloRegistrazione))$arrayValue['bollo_registrazione']=($this->bolloRegistrazione==self::NULL_VALUE)?null:$this->bolloRegistrazione;if(isset($this->intestatarioLocatore))$arrayValue['intestatario_locatore']=($this->intestatarioLocatore==self::NULL_VALUE)?null:$this->intestatarioLocatore;if(isset($this->intestatarioConduttore))$arrayValue['intestatario_conduttore']=($this->intestatarioConduttore==self::NULL_VALUE)?null:$this->intestatarioConduttore;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['id'])) || (isset($keyArray['contratti_dettagli_id']))) {$this->setId(isset($keyArray['id'])?$keyArray['id']:$keyArray['contratti_dettagli_id']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['tipo_tabella_istat'])) || (isset($keyArray['contratti_dettagli_tipo_tabella_istat']))) {$this->setTipotabellaistat(isset($keyArray['tipo_tabella_istat'])?$keyArray['tipo_tabella_istat']:$keyArray['contratti_dettagli_tipo_tabella_istat']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['colonna_tabella_istat'])) || (isset($keyArray['contratti_dettagli_colonna_tabella_istat']))) {$this->setColonnatabellaistat(isset($keyArray['colonna_tabella_istat'])?$keyArray['colonna_tabella_istat']:$keyArray['contratti_dettagli_colonna_tabella_istat']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['mese_riferimento_istat'])) || (isset($keyArray['contratti_dettagli_mese_riferimento_istat']))) {$this->setMeseriferimentoistat(isset($keyArray['mese_riferimento_istat'])?$keyArray['mese_riferimento_istat']:$keyArray['contratti_dettagli_mese_riferimento_istat']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['mesi_conguaglio_istat'])) || (isset($keyArray['contratti_dettagli_mesi_conguaglio_istat']))) {$this->setMesiconguaglioistat(isset($keyArray['mesi_conguaglio_istat'])?$keyArray['mesi_conguaglio_istat']:$keyArray['contratti_dettagli_mesi_conguaglio_istat']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['data_consegna_chiavi'])) || (isset($keyArray['contratti_dettagli_data_consegna_chiavi']))) {$this->setDataconsegnachiavi(isset($keyArray['data_consegna_chiavi'])?$keyArray['data_consegna_chiavi']:$keyArray['contratti_dettagli_data_consegna_chiavi']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_conto_corrente'])) || (isset($keyArray['contratti_dettagli_id_conto_corrente']))) {$this->setIdcontocorrente(isset($keyArray['id_conto_corrente'])?$keyArray['id_conto_corrente']:$keyArray['contratti_dettagli_id_conto_corrente']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['bollettazione_tipo'])) || (isset($keyArray['contratti_dettagli_bollettazione_tipo']))) {$this->setBollettazionetipo(isset($keyArray['bollettazione_tipo'])?$keyArray['bollettazione_tipo']:$keyArray['contratti_dettagli_bollettazione_tipo']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['bollettazione_fatttura'])) || (isset($keyArray['contratti_dettagli_bollettazione_fatttura']))) {$this->setBollettazionefatttura(isset($keyArray['bollettazione_fatttura'])?$keyArray['bollettazione_fatttura']:$keyArray['contratti_dettagli_bollettazione_fatttura']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['tipo_rimessa'])) || (isset($keyArray['contratti_dettagli_tipo_rimessa']))) {$this->setTiporimessa(isset($keyArray['tipo_rimessa'])?$keyArray['tipo_rimessa']:$keyArray['contratti_dettagli_tipo_rimessa']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['percentuale_rimessa'])) || (isset($keyArray['contratti_dettagli_percentuale_rimessa']))) {$this->setPercentualerimessa(isset($keyArray['percentuale_rimessa'])?$keyArray['percentuale_rimessa']:$keyArray['contratti_dettagli_percentuale_rimessa']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['quota_rimessa'])) || (isset($keyArray['contratti_dettagli_quota_rimessa']))) {$this->setQuotarimessa(isset($keyArray['quota_rimessa'])?$keyArray['quota_rimessa']:$keyArray['contratti_dettagli_quota_rimessa']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['data_rata_iniziale'])) || (isset($keyArray['contratti_dettagli_data_rata_iniziale']))) {$this->setDataratainiziale(isset($keyArray['data_rata_iniziale'])?$keyArray['data_rata_iniziale']:$keyArray['contratti_dettagli_data_rata_iniziale']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_gruppo_fatturazione'])) || (isset($keyArray['contratti_dettagli_id_gruppo_fatturazione']))) {$this->setIdgruppofatturazione(isset($keyArray['id_gruppo_fatturazione'])?$keyArray['id_gruppo_fatturazione']:$keyArray['contratti_dettagli_id_gruppo_fatturazione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['data_registrazione'])) || (isset($keyArray['contratti_dettagli_data_registrazione']))) {$this->setDataregistrazione(isset($keyArray['data_registrazione'])?$keyArray['data_registrazione']:$keyArray['contratti_dettagli_data_registrazione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['luogo_stipula'])) || (isset($keyArray['contratti_dettagli_luogo_stipula']))) {$this->setLuogostipula(isset($keyArray['luogo_stipula'])?$keyArray['luogo_stipula']:$keyArray['contratti_dettagli_luogo_stipula']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['descrizione_bollo_registrazione'])) || (isset($keyArray['contratti_dettagli_descrizione_bollo_registrazione']))) {$this->setDescrizionebolloregistrazione(isset($keyArray['descrizione_bollo_registrazione'])?$keyArray['descrizione_bollo_registrazione']:$keyArray['contratti_dettagli_descrizione_bollo_registrazione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['bollo_registrazione'])) || (isset($keyArray['contratti_dettagli_bollo_registrazione']))) {$this->setBolloregistrazione(isset($keyArray['bollo_registrazione'])?$keyArray['bollo_registrazione']:$keyArray['contratti_dettagli_bollo_registrazione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['intestatario_locatore'])) || (isset($keyArray['contratti_dettagli_intestatario_locatore']))) {$this->setIntestatariolocatore(isset($keyArray['intestatario_locatore'])?$keyArray['intestatario_locatore']:$keyArray['contratti_dettagli_intestatario_locatore']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['intestatario_conduttore'])) || (isset($keyArray['contratti_dettagli_intestatario_conduttore']))) {$this->setIntestatarioconduttore(isset($keyArray['intestatario_conduttore'])?$keyArray['intestatario_conduttore']:$keyArray['contratti_dettagli_intestatario_conduttore']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['id'] =$positionalArray[0];$values['tipo_tabella_istat'] =($positionalArray[1]==self::NULL_VALUE)?null:$positionalArray[1];$values['colonna_tabella_istat'] =($positionalArray[2]==self::NULL_VALUE)?null:$positionalArray[2];$values['mese_riferimento_istat'] =($positionalArray[3]==self::NULL_VALUE)?null:$positionalArray[3];$values['mesi_conguaglio_istat'] =($positionalArray[4]==self::NULL_VALUE)?null:$positionalArray[4];$values['data_consegna_chiavi'] =($positionalArray[5]==self::NULL_VALUE)?null:$positionalArray[5];$values['id_conto_corrente'] =($positionalArray[6]==self::NULL_VALUE)?null:$positionalArray[6];$values['bollettazione_tipo'] =$positionalArray[7];$values['bollettazione_fatttura'] =$positionalArray[8];$values['tipo_rimessa'] =($positionalArray[9]==self::NULL_VALUE)?null:$positionalArray[9];$values['percentuale_rimessa'] =$positionalArray[10];$values['quota_rimessa'] =$positionalArray[11];$values['data_rata_iniziale'] =($positionalArray[12]==self::NULL_VALUE)?null:$positionalArray[12];$values['id_gruppo_fatturazione'] =($positionalArray[13]==self::NULL_VALUE)?null:$positionalArray[13];$values['data_registrazione'] =($positionalArray[14]==self::NULL_VALUE)?null:$positionalArray[14];$values['luogo_stipula'] =($positionalArray[15]==self::NULL_VALUE)?null:$positionalArray[15];$values['descrizione_bollo_registrazione'] =($positionalArray[16]==self::NULL_VALUE)?null:$positionalArray[16];$values['bollo_registrazione'] =($positionalArray[17]==self::NULL_VALUE)?null:$positionalArray[17];$values['intestatario_locatore'] =($positionalArray[18]==self::NULL_VALUE)?null:$positionalArray[18];$values['intestatario_conduttore'] =($positionalArray[19]==self::NULL_VALUE)?null:$positionalArray[19];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['id'] = null;$values['tipo_tabella_istat'] = null;$values['colonna_tabella_istat'] = null;$values['mese_riferimento_istat'] = 0;$values['mesi_conguaglio_istat'] = 0;$values['data_consegna_chiavi'] = null;$values['id_conto_corrente'] = null;$values['bollettazione_tipo'] = null;$values['bollettazione_fatttura'] = 'N';$values['tipo_rimessa'] = null;$values['percentuale_rimessa'] = null;$values['quota_rimessa'] = null;$values['data_rata_iniziale'] = null;$values['id_gruppo_fatturazione'] = null;$values['data_registrazione'] = null;$values['luogo_stipula'] = null;$values['descrizione_bollo_registrazione'] = 'Bollo per la registrazione del contratto';$values['bollo_registrazione'] = 0.00;$values['intestatario_locatore'] = null;$values['intestatario_conduttore'] = null;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'contratti_dettagli.id as contratti_dettagli_id,contratti_dettagli.tipo_tabella_istat as contratti_dettagli_tipo_tabella_istat,contratti_dettagli.colonna_tabella_istat as contratti_dettagli_colonna_tabella_istat,contratti_dettagli.mese_riferimento_istat as contratti_dettagli_mese_riferimento_istat,contratti_dettagli.mesi_conguaglio_istat as contratti_dettagli_mesi_conguaglio_istat,contratti_dettagli.data_consegna_chiavi as contratti_dettagli_data_consegna_chiavi,contratti_dettagli.id_conto_corrente as contratti_dettagli_id_conto_corrente,contratti_dettagli.bollettazione_tipo as contratti_dettagli_bollettazione_tipo,contratti_dettagli.bollettazione_fatttura as contratti_dettagli_bollettazione_fatttura,contratti_dettagli.tipo_rimessa as contratti_dettagli_tipo_rimessa,contratti_dettagli.percentuale_rimessa as contratti_dettagli_percentuale_rimessa,contratti_dettagli.quota_rimessa as contratti_dettagli_quota_rimessa,contratti_dettagli.data_rata_iniziale as contratti_dettagli_data_rata_iniziale,contratti_dettagli.id_gruppo_fatturazione as contratti_dettagli_id_gruppo_fatturazione,contratti_dettagli.data_registrazione as contratti_dettagli_data_registrazione,contratti_dettagli.luogo_stipula as contratti_dettagli_luogo_stipula,contratti_dettagli.descrizione_bollo_registrazione as contratti_dettagli_descrizione_bollo_registrazione,contratti_dettagli.bollo_registrazione as contratti_dettagli_bollo_registrazione,contratti_dettagli.intestatario_locatore as contratti_dettagli_intestatario_locatore,contratti_dettagli.intestatario_conduttore as contratti_dettagli_intestatario_conduttore';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `contratti_dettagli` (
  `id` int(11) unsigned NOT NULL,
  `tipo_tabella_istat` enum('foi','custom') DEFAULT NULL,
  `colonna_tabella_istat` enum('a75','a100','b75','b100') DEFAULT NULL,
  `mese_riferimento_istat` int(10) unsigned DEFAULT '0',
  `mesi_conguaglio_istat` int(10) unsigned DEFAULT '0',
  `data_consegna_chiavi` date DEFAULT NULL,
  `id_conto_corrente` int(11) DEFAULT NULL,
  `bollettazione_tipo` enum('F','M','A','R') NOT NULL COMMENT 'F = FATTURA\nM = MAV\nA = AVVISO DI PAGAMENTO\nR = RID',
  `bollettazione_fatttura` enum('N','V','P') NOT NULL DEFAULT 'N' COMMENT 'N = NO EMISSIONE\nV = A VISTA\nP = PAGAMENTO',
  `tipo_rimessa` enum('N','P','Q') DEFAULT NULL COMMENT 'N = NESSUNA RIMESSA\nP = PERCENTUALE SUL CANONE ANNUO\nQ = QUOTA FISSA',
  `percentuale_rimessa` tinyint(8) NOT NULL,
  `quota_rimessa` decimal(10,2) NOT NULL,
  `data_rata_iniziale` date DEFAULT NULL,
  `id_gruppo_fatturazione` int(11) DEFAULT NULL,
  `data_registrazione` date DEFAULT NULL,
  `luogo_stipula` varchar(45) DEFAULT NULL,
  `descrizione_bollo_registrazione` varchar(150) DEFAULT 'Bollo per la registrazione del contratto',
  `bollo_registrazione` decimal(10,2) DEFAULT '0.00',
  `intestatario_locatore` int(11) unsigned DEFAULT NULL,
  `intestatario_conduttore` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_contratti_dettagli_gruppo_fatturazione1_idx` (`id_gruppo_fatturazione`),
  KEY `fk_conti_correnti_idx` (`id_conto_corrente`),
  KEY `idx_intestatario_locatore` (`intestatario_locatore`),
  KEY `idx_intestatario_conduttore` (`intestatario_conduttore`),
  CONSTRAINT `fk_contratti_dettagli_gruppo_fatturazione1` FOREIGN KEY (`id_gruppo_fatturazione`) REFERENCES `gruppi_fatturazione` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ");}
/**
 * @return integer
 */
public function getId(){return $this->id;}
/**
 * @param integer $id Id
 */
public function setId($id){$this->id=$id;}
/**
 * @param bool $decode if true return decode value * @return string
 */
public function getTipoTabellaIstat($decode=false){return ($decode)?$this->getTipoTabellaIstatValuesList()[$this->tipoTabellaIstat]:$this->tipoTabellaIstat;}
/**
 * @param bool $json if true return value json's array else return array values * @return array|string
 */
public function getTipoTabellaIstatValuesList($json=false){$kv=[];return ($json)?$this->createJsonKeyValArray($kv):$kv;}
/**
 * @param string (enum) $tipoTabellaIstat TipoTabellaIstat
 */
public function setTipoTabellaIstat($tipoTabellaIstat){$this->tipoTabellaIstat=$tipoTabellaIstat;}
/**
 * @param bool $decode if true return decode value * @return string
 */
public function getColonnaTabellaIstat($decode=false){return ($decode)?$this->getColonnaTabellaIstatValuesList()[$this->colonnaTabellaIstat]:$this->colonnaTabellaIstat;}
/**
 * @param bool $json if true return value json's array else return array values * @return array|string
 */
public function getColonnaTabellaIstatValuesList($json=false){$kv=[];return ($json)?$this->createJsonKeyValArray($kv):$kv;}
/**
 * @param string (enum) $colonnaTabellaIstat ColonnaTabellaIstat
 */
public function setColonnaTabellaIstat($colonnaTabellaIstat){$this->colonnaTabellaIstat=$colonnaTabellaIstat;}
/**
 * @return integer
 */
public function getMeseRiferimentoIstat(){return $this->meseRiferimentoIstat;}
/**
 * @param integer $meseRiferimentoIstat MeseRiferimentoIstat
 */
public function setMeseRiferimentoIstat($meseRiferimentoIstat){$this->meseRiferimentoIstat=$meseRiferimentoIstat;}
/**
 * @return integer
 */
public function getMesiConguaglioIstat(){return $this->mesiConguaglioIstat;}
/**
 * @param integer $mesiConguaglioIstat MesiConguaglioIstat
 */
public function setMesiConguaglioIstat($mesiConguaglioIstat){$this->mesiConguaglioIstat=$mesiConguaglioIstat;}
/**
 * @return string
 */
public function getDataConsegnaChiavi(){return $this->dataConsegnaChiavi;}
/**
 * @param string $dataConsegnaChiavi DataConsegnaChiavi
 * @param int $encodeType
 */
public function setDataConsegnaChiavi($dataConsegnaChiavi,$encodeType = self::STR_DEFAULT){$this->dataConsegnaChiavi=$this->decodeString($dataConsegnaChiavi,$encodeType);}
/**
 * @return integer
 */
public function getIdContoCorrente(){return $this->idContoCorrente;}
/**
 * @param integer $idContoCorrente IdContoCorrente
 */
public function setIdContoCorrente($idContoCorrente){$this->idContoCorrente=$idContoCorrente;}
/**
 * @param bool $decode if true return decode value * @return string
 */
public function getBollettazioneTipo($decode=false){return ($decode)?$this->getBollettazioneTipoValuesList()[$this->bollettazioneTipo]:$this->bollettazioneTipo;}
/**
 * @param bool $json if true return value json's array else return array values * @return array|string
 */
public function getBollettazioneTipoValuesList($json=false){$kv=['F'=>'FATTURA','M'=>'MAV','A'=>'AVVISO DI PAGAMENTO','R'=>'RID'];return ($json)?$this->createJsonKeyValArray($kv):$kv;}
/**
 * @param string (enum) $bollettazioneTipo BollettazioneTipo
 */
public function setBollettazioneTipo($bollettazioneTipo){$this->bollettazioneTipo=$bollettazioneTipo;}
/**
 * @param bool $decode if true return decode value * @return string
 */
public function getBollettazioneFatttura($decode=false){return ($decode)?$this->getBollettazioneFattturaValuesList()[$this->bollettazioneFatttura]:$this->bollettazioneFatttura;}
/**
 * @param bool $json if true return value json's array else return array values * @return array|string
 */
public function getBollettazioneFattturaValuesList($json=false){$kv=['N'=>'NO EMISSIONE','V'=>'A VISTA','P'=>'PAGAMENTO'];return ($json)?$this->createJsonKeyValArray($kv):$kv;}
/**
 * @param string (enum) $bollettazioneFatttura BollettazioneFatttura
 */
public function setBollettazioneFatttura($bollettazioneFatttura){$this->bollettazioneFatttura=$bollettazioneFatttura;}
/**
 * @param bool $decode if true return decode value * @return string
 */
public function getTipoRimessa($decode=false){return ($decode)?$this->getTipoRimessaValuesList()[$this->tipoRimessa]:$this->tipoRimessa;}
/**
 * @param bool $json if true return value json's array else return array values * @return array|string
 */
public function getTipoRimessaValuesList($json=false){$kv=['N'=>'NESSUNA RIMESSA','P'=>'PERCENTUALE SUL CANONE ANNUO','Q'=>'QUOTA FISSA'];return ($json)?$this->createJsonKeyValArray($kv):$kv;}
/**
 * @param string (enum) $tipoRimessa TipoRimessa
 */
public function setTipoRimessa($tipoRimessa){$this->tipoRimessa=$tipoRimessa;}
/**
 * @return integer
 */
public function getPercentualeRimessa(){return $this->percentualeRimessa;}
/**
 * @param integer $percentualeRimessa PercentualeRimessa
 */
public function setPercentualeRimessa($percentualeRimessa){$this->percentualeRimessa=$percentualeRimessa;}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getQuotaRimessa($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->quotaRimessa:number_format($this->quotaRimessa,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $quotaRimessa QuotaRimessa
 */
public function setQuotaRimessa($quotaRimessa){$this->quotaRimessa=$quotaRimessa;}
/**
 * @return string
 */
public function getDataRataIniziale(){return $this->dataRataIniziale;}
/**
 * @param string $dataRataIniziale DataRataIniziale
 * @param int $encodeType
 */
public function setDataRataIniziale($dataRataIniziale,$encodeType = self::STR_DEFAULT){$this->dataRataIniziale=$this->decodeString($dataRataIniziale,$encodeType);}
/**
 * @return integer
 */
public function getIdGruppoFatturazione(){return $this->idGruppoFatturazione;}
/**
 * @param integer $idGruppoFatturazione IdGruppoFatturazione
 */
public function setIdGruppoFatturazione($idGruppoFatturazione){$this->idGruppoFatturazione=$idGruppoFatturazione;}
/**
 * @return string
 */
public function getDataRegistrazione(){return $this->dataRegistrazione;}
/**
 * @param string $dataRegistrazione DataRegistrazione
 * @param int $encodeType
 */
public function setDataRegistrazione($dataRegistrazione,$encodeType = self::STR_DEFAULT){$this->dataRegistrazione=$this->decodeString($dataRegistrazione,$encodeType);}
/**
 * @return string
 */
public function getLuogoStipula(){return $this->luogoStipula;}
/**
 * @param string $luogoStipula LuogoStipula
 * @param int $encodeType
 */
public function setLuogoStipula($luogoStipula,$encodeType = self::STR_DEFAULT){$this->luogoStipula=$this->decodeString($luogoStipula,$encodeType);}
/**
 * @return string
 */
public function getDescrizioneBolloRegistrazione(){return $this->descrizioneBolloRegistrazione;}
/**
 * @param string $descrizioneBolloRegistrazione DescrizioneBolloRegistrazione
 * @param int $encodeType
 */
public function setDescrizioneBolloRegistrazione($descrizioneBolloRegistrazione,$encodeType = self::STR_DEFAULT){$this->descrizioneBolloRegistrazione=$this->decodeString($descrizioneBolloRegistrazione,$encodeType);}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getBolloRegistrazione($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->bolloRegistrazione:number_format($this->bolloRegistrazione,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $bolloRegistrazione BolloRegistrazione
 */
public function setBolloRegistrazione($bolloRegistrazione){$this->bolloRegistrazione=$bolloRegistrazione;}
/**
 * @return integer
 */
public function getIntestatarioLocatore(){return $this->intestatarioLocatore;}
/**
 * @param integer $intestatarioLocatore IntestatarioLocatore
 */
public function setIntestatarioLocatore($intestatarioLocatore){$this->intestatarioLocatore=$intestatarioLocatore;}
/**
 * @return integer
 */
public function getIntestatarioConduttore(){return $this->intestatarioConduttore;}
/**
 * @param integer $intestatarioConduttore IntestatarioConduttore
 */
public function setIntestatarioConduttore($intestatarioConduttore){$this->intestatarioConduttore=$intestatarioConduttore;}
}