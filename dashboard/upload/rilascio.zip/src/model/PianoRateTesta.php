<?php
/**
 * Created by Drakkar vers. 0.0.25(Hjortspring)
 * User: P.D.A. Srl
 * Date: 2018-02-22
 * Time: 12:53:27.564075
 */

namespace Click\Affitti\TblBase;
require_once 'PianoRateTestaModel.php';

use Click\Affitti\TblBase\PianoRateTestaModel;

class  PianoRateTesta extends PianoRateTestaModel
{

    /** @var PianiRateDettagli[] */
    protected $pianoRateD;

    function __construct($pdo)
    {
        parent::__construct($pdo);
    }


    public function findPianoRateTestaByData($data, $idContratto, $typeResult = self::FETCH_OBJ){
        {
            $query =
            "
            SELECT 
                piano_rate_testa.*
            FROM
                piano_rate_testa
                    INNER JOIN
                gestioni ON piano_rate_testa.id_gestione = gestioni.id
                    INNER JOIN
                periodi_contrattuali ON gestioni.id_periodo_contrattuale = periodi_contrattuali.id
            WHERE
                periodi_contrattuali.id_contratto = ?
                    AND '$data' BETWEEN gestioni.data_inizio AND gestioni.data_fine
            GROUP BY piano_rate_testa.tipo_spesa
            ";
            return $this->createResultArray($query, array($idContratto), $typeResult = self::FETCH_OBJ);
        }
    }


    public function findByIdGestioneIdCanoniOneri($idGestione, $idCanoniOneri, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName WHERE id_gestione=? AND id_canoni_oneri=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        return $this->createResultArray($query, array($idGestione, $idCanoniOneri), $typeResult);
    }


    public function findByPkConPianoRateDettagli($id, $typeResult = self::FETCH_OBJ)
    {
        $app = $this->findByPk($id, $typeResult);
        $this->pianoRateD = new PianiRateDettagli($this->conn);
        $this->pianoRateD = $this->pianoRateD->findByIdPianoRateTestaConDettagli($id, $typeResult);

        if ($typeResult != self::FETCH_OBJ) {
            $app['pianoRateD'] = $this->pianoRateD;
            return $app;
        }

        return $this;
    }

    function findByIdGestioneConDettagli($id, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT id FROM $this->tableName WHERE id_gestione=?";
        $app = [];
        foreach ($this->createResultArray($query, array($id), self::FETCH_KEYARRAY) as $idPrT) {
            $app[] = $this->findByPkConPianoRateDettagli($idPrT['id'], $typeResult);
        }
        return $app;
    }

    function findAllByIdContrattoDettagliGestione($id, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT id FROM $this->tableName WHERE id_gestione=?";
        $app = [];
        foreach ($this->createResultArray($query, array($id), self::FETCH_KEYARRAY) as $idPrT) {
            $app[] = $this->findByPkConPianoRateDettagli($idPrT['id'], $typeResult);
        }
        return $app;
    }


    /**
     * @param $idContratto
     * @param $idCanoneOnere
     * @param int $typeResult
     * @param int $limit
     * @param int $offset
     * @return array|string
     *
     * Restituisce l'elenco dei piani_rate_testa di un contratto ordinate per data inizio gestione
     *
     */
    public function findAllConDate($idContratto, $idCanoneOnere, $typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $query =
            "
            SELECT 
                piano_rate_testa.*,
                gestioni.data_inizio,
                gestioni.data_fine
            FROM
                piano_rate_testa
                    INNER JOIN
                gestioni ON piano_rate_testa.id_gestione = gestioni.id
                    INNER JOIN
                periodi_contrattuali ON gestioni.id_periodo_contrattuale = periodi_contrattuali.id
            WHERE
                periodi_contrattuali.id_contratto = ? AND 
                piano_rate_testa.id_canoni_oneri = ?
            ORDER BY 
                gestioni.data_fine
            ";
        if ($this->whereBase) $query .= " WHERE $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        $query .= $this->createLimitQuery($limit, $offset);
        return $this->createResultArray($query, array($idContratto, $idCanoneOnere), $typeResult);
    }

    public function getImportoTotaleForfettariByIdGestione($idGestione)
    {
        return $this->getImportoTotaleByIdGestione($idGestione, 'F');
    }

    public function getImportoTotaleAConguaglioByIdGestione($idGestione)
    {
        return $this->getImportoTotaleByIdGestione($idGestione, 'C');
    }

    public function getImportoTotaleByIdGestione($idGestione, $tipo = 'ALL')
    {
        if ($tipo == 'ALL') {
            $query = "SELECT SUM(importo) FROM piano_rate_testa WHERE id_gestione=?";
            return $this->createResultValue($query, array($idGestione));
        } else {
            $query = "SELECT SUM(importo) FROM piano_rate_testa WHERE id_gestione=? AND tipo_saldo=?";
            return $this->createResultValue($query, array($idGestione, $tipo));
        }
    }
}