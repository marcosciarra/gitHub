<?php
/**
* Created by Drakkar vers. 0.1.2(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-06-27
* Time: 16:12:30.781539
*/
namespace Click\Affitti\TblBase;
require_once 'TipoSoggettoModel.php';
use Click\Affitti\TblBase\TipoSoggettoModel;

class  TipoSoggetto extends TipoSoggettoModel {
function __construct($pdo){parent::__construct($pdo);}

}