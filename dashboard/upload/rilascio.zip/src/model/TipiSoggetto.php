<?php
/**
* Created by Drakkar vers. 0.0.23(Hjortspring)
* User: P.D.A. Srl
* Date: 2017-12-06
* Time: 15:21:59.701974
*/
namespace Click\Affitti\TblBase;
require_once 'TipiSoggettoModel.php';
use Click\Affitti\TblBase\TipiSoggettoModel;

class  TipiSoggetto extends TipiSoggettoModel {
    function __construct($pdo){parent::__construct($pdo);}

    public function getTipoSoggettoDefault ($str){
        $query = "SELECT id FROM tipi_soggetto WHERE descrizione=?";
        return $this->createResultValue($query, $str);
    }
    public static function getTipoSoggettoDefaultStatic($con,$str){
        $ts = new self($con);
        return $ts->getTipoSoggettoDefault($str);
    }

    public function getTipoGruppoById($id){
        $query = "SELECT gruppo FROM tipi_soggetto WHERE id=?";
        return $this->createResultValue($query, $id);
    }
    public static function getTipoGruppoByIdStatic($con,$id){
        $ts = new self($con);
        return $ts->getTipoGruppoById($id);
    }

    public function findTipiSoggetoPerSelect($typeResult=self::FETCH_OBJ){
        $query = "SELECT id,descrizione FROM tipi_soggetto";
        return $this->createResultArray($query,null,$typeResult);
    }
}