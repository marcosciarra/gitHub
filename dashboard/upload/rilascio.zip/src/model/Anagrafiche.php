<?php
/**
 * Created by Drakkar vers. 0.0.22(Hjortspring)
 * User: P.D.A. Srl
 * Date: 2017-11-27
 * Time: 18:25:51.881921
 */

namespace Click\Affitti\TblBase;
require_once 'AnagraficheModel.php';
require_once 'AnagraficheSocietarie.php';


use Click\Affitti\TblBase\AnagraficheModel;
use Click\Affitti\TblBase\AnagraficheSocietarie;

class  Anagrafiche extends AnagraficheModel
{
    /** @var AnagraficheSocietarie */
    protected $datiSocieta;

    function __construct($pdo)
    {
        parent::__construct($pdo);
    }

    public function findbyIdArray($arrayId, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT id,CONCAT_WS(' ',anagrafiche.ragione_sociale,anagrafiche.cognome,anagrafiche.nome) AS descrizione 
                  FROM $this->tableName WHERE id IN ($arrayId) order by descrizione";
        return $this->createResultArray($query, null, $typeResult);
    }

    public function findAllPerSelect($typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $query = "SELECT id,CONCAT_WS(' ',anagrafiche.ragione_sociale,anagrafiche.cognome,anagrafiche.nome) AS descrizione 
                  FROM $this->tableName ";
        if ($this->whereBase) $query .= " WHERE $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        $query .= $this->createLimitQuery($limit, $offset);
        return $this->createResultArray($query, null, $typeResult);
    }

    public function findAllPerSelectPiva($typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $query = "SELECT id, CONCAT_WS( ' ', ragione_sociale, nome, cognome ) AS descrizione 
                  FROM $this->tableName WHERE id_tipi_soggetto != 2";
        $query .= $this->createLimitQuery($limit, $offset);
        return $this->createResultArray($query, null, $typeResult);
    }


    public function findAllAgenziaImmobiliare($typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $query =
            "
            SELECT 
                id,
                IF(id_tipi_soggetto = 1,
                    CONCAT_WS(' ', cognome, nome),
                    ragione_sociale) AS descrizione
            FROM
                anagrafiche
            WHERE
                societa_fatturazione = TRUE
            ";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        $query .= $this->createLimitQuery($limit, $offset);
        return $this->createResultArray($query, null, $typeResult);
    }

    public function getNominativo()
    {
        return (is_null($this->getRagioneSociale())) ? $this->getCognome() . " " . $this->getNome() : $this->getRagioneSociale();
    }

    /**
     * find by tables' Primary Key CON derivate:
     * @return Anagrafiche|array|string|null
     */
    public function findByPkFull($id, $typeResult = self::FETCH_OBJ)
    {
        $ds = new AnagraficheSocietarie($this->conn);
        $app = parent::findByPk($id, $typeResult);
        if ($typeResult == self::FETCH_OBJ) {
            $app->datiSocieta = $ds->findByPk($id, $typeResult);
        } else {
            $app['datiSocieta'] = $ds->findByPk($id, $typeResult);
        }
        return $app;
    }

    /*
     * Metodo che restituisce l'elenco delle anagrafiche in join con tipi_soggetto
     */
    public function getElencoAnagrafiche($distinct = false, $typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $distinctStr = ($distinct) ? 'DISTINCT' : '';
        $query =
            "
            SELECT 
                anagrafiche.id AS anagrafica_id,
                tipi_soggetto.id AS tipi_soggetto_id,
                gruppo,
                descrizione,
                anagrafiche.cestino,
                COALESCE(CONCAT(anagrafiche.cognome,
                                ' ',
                                anagrafiche.nome),
                        anagrafiche.ragione_sociale) AS nome,
                anagrafiche.codice_fiscale,
                anagrafiche.partita_iva,
                anagrafiche.indirizzi,
                anagrafiche.email,
                anagrafiche.telefoni,
                anagrafiche.cellulari,
                anagrafiche.societa_fatturazione,
                anagrafiche.amministratore_condominio,
                anagrafiche.fornitore,
                proprietari.id AS proprietario,
                inquilini.id AS inquilino
            FROM
                anagrafiche
                    LEFT JOIN
                tipi_soggetto ON anagrafiche.id_tipi_soggetto = tipi_soggetto.id
                    LEFT JOIN
                proprietari ON anagrafiche.id = proprietari.id
                    LEFT JOIN
                inquilini ON anagrafiche.id = inquilini.id
            ";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        $query .= $this->createLimitQuery($limit, $offset);
        return $this->createResultArray($query, null, $typeResult);
    }


    public function elencoContrattiPerAnagrafica($idAnagrafica, $typeResult = self::FETCH_OBJ)
    {
        //FIXME::QUERY PROVVISORIA PER AVERE ELENCO DAL JSON
        $query =
            "
                SELECT
                  *
                FROM
                  contratti
                WHERE
                    cestino = 0 AND elaborato = 1 AND
                    contratti.proprietari->'$[0].id'=$idAnagrafica OR
                    contratti.proprietari->'$[1].id'=$idAnagrafica OR
                    contratti.proprietari->'$[2].id'=$idAnagrafica OR
                    contratti.proprietari->'$[3].id'=$idAnagrafica OR
                    contratti.proprietari->'$[4].id'=$idAnagrafica OR
                    contratti.proprietari->'$[5].id'=$idAnagrafica OR
                    contratti.proprietari->'$[6].id'=$idAnagrafica OR
                    contratti.proprietari->'$[7].id'=$idAnagrafica OR
                    contratti.proprietari->'$[8].id'=$idAnagrafica OR
                    contratti.proprietari->'$[9].id'=$idAnagrafica OR
                    contratti.conduttori->'$[0].id'=$idAnagrafica OR
                    contratti.conduttori->'$[1].id'=$idAnagrafica OR
                    contratti.conduttori->'$[2].id'=$idAnagrafica OR
                    contratti.conduttori->'$[3].id'=$idAnagrafica OR
                    contratti.conduttori->'$[4].id'=$idAnagrafica OR
                    contratti.conduttori->'$[5].id'=$idAnagrafica OR
                    contratti.conduttori->'$[6].id'=$idAnagrafica OR
                    contratti.conduttori->'$[7].id'=$idAnagrafica OR
                    contratti.conduttori->'$[8].id'=$idAnagrafica OR
                    contratti.conduttori->'$[9].id'=$idAnagrafica
                ";
        return $this->createResultArray($query, null, $typeResult);
    }


    public function elencoInquiliniPerProprietario($idAnagrafica, $typeResult = self::FETCH_OBJ)
    {
        //FIXME::QUERY PROVVISORIA PER AVERE ELENCO DAL JSON
        $query =
            "
                select anagrafiche.* from anagrafiche,
                    (SELECT 
                        contratti.conduttori
                    FROM
                        anagrafiche
                            INNER JOIN contratti ON 
                            anagrafiche.id = contratti.proprietari->'$[0].id' OR
                            anagrafiche.id = contratti.proprietari->'$[1].id' OR
                            anagrafiche.id = contratti.proprietari->'$[2].id' OR
                            anagrafiche.id = contratti.proprietari->'$[3].id' OR
                            anagrafiche.id = contratti.proprietari->'$[4].id' OR
                            anagrafiche.id = contratti.proprietari->'$[5].id' OR
                            anagrafiche.id = contratti.proprietari->'$[6].id' OR
                            anagrafiche.id = contratti.proprietari->'$[7].id' OR
                            anagrafiche.id = contratti.proprietari->'$[8].id' OR
                            anagrafiche.id = contratti.proprietari->'$[9].id'
                        where contratti.cestino=0 and contratti.elaborato=1 and anagrafiche.id =?
                    group by contratti.id) cond
                where 
                        anagrafiche.id = cond.conduttori->'$[0].id' OR
                        anagrafiche.id = cond.conduttori->'$[1].id' OR
                        anagrafiche.id = cond.conduttori->'$[2].id' OR
                        anagrafiche.id = cond.conduttori->'$[3].id' OR
                        anagrafiche.id = cond.conduttori->'$[4].id' OR
                        anagrafiche.id = cond.conduttori->'$[5].id' OR
                        anagrafiche.id = cond.conduttori->'$[6].id' OR
                        anagrafiche.id = cond.conduttori->'$[7].id' OR
                        anagrafiche.id = cond.conduttori->'$[8].id' OR
                        anagrafiche.id = cond.conduttori->'$[9].id'
                group by anagrafiche.id
                ";
        return $this->createResultArray($query, array($idAnagrafica), $typeResult);
    }


    public function elencoProprietariPerInquilini($idAnagrafica, $typeResult = self::FETCH_OBJ)
    {
        //FIXME::QUERY PROVVISORIA PER AVERE ELENCO DAL JSON
        $query =
            "
              select anagrafiche.* from anagrafiche,
                    (SELECT 
                        contratti.proprietari
                    FROM
                        anagrafiche
                            INNER JOIN contratti ON 
                            anagrafiche.id = contratti.conduttori->'$[0].id' OR
                            anagrafiche.id = contratti.conduttori->'$[1].id' OR
                            anagrafiche.id = contratti.conduttori->'$[2].id' OR
                            anagrafiche.id = contratti.conduttori->'$[3].id' OR
                            anagrafiche.id = contratti.conduttori->'$[4].id' OR
                            anagrafiche.id = contratti.conduttori->'$[5].id' OR
                            anagrafiche.id = contratti.conduttori->'$[6].id' OR
                            anagrafiche.id = contratti.conduttori->'$[7].id' OR
                            anagrafiche.id = contratti.conduttori->'$[8].id' OR
                            anagrafiche.id = contratti.conduttori->'$[9].id'
                        where contratti.cestino=0 and contratti.elaborato=1 and anagrafiche.id =?
                    group by contratti.id) prop
                where 
                        anagrafiche.id = prop.proprietari->'$[0].id' OR
                        anagrafiche.id = prop.proprietari->'$[1].id' OR
                        anagrafiche.id = prop.proprietari->'$[2].id' OR
                        anagrafiche.id = prop.proprietari->'$[3].id' OR
                        anagrafiche.id = prop.proprietari->'$[4].id' OR
                        anagrafiche.id = prop.proprietari->'$[5].id' OR
                        anagrafiche.id = prop.proprietari->'$[6].id' OR
                        anagrafiche.id = prop.proprietari->'$[7].id' OR
                        anagrafiche.id = prop.proprietari->'$[8].id' OR
                        anagrafiche.id = prop.proprietari->'$[9].id'
                group by anagrafiche.id                ";
        return $this->createResultArray($query, array($idAnagrafica), $typeResult);
    }


    /**
     * struttura classe Anagrafiche con struttura 'AnagraficheSocietarie'
     * @return array
     */
    public function getEmptyDbKeyArrayFull()
    {
        $ds = new AnagraficheSocietarie($this->conn);
        $app = parent::getEmptyDbKeyArray();
        $app['datiSocieta'] = $ds->getEmptyDbKeyArray();
        return $app;
    }

    /**
     * @param bool $json parametro che indica la modalità di riotrno del metodo, se TRUE ritorna JSON. Di default FALSE ritorna un array associativo
     * @return array|string
     * parametro 'indirizzo_spedizione' di default a False
     */
    public function getEmptyIndirizzo($json = false)
    {
        $indirizzo = ['descrizione' => '', 'via' => '', 'civico' => '', 'citta' => '', 'cap' => '', 'frazione' => '', 'provincia' => '', 'stato' => '', 'presso' => '', 'indirizzo_spedizione' => false, 'domicilio_fiscale' => false];
        if ($json) {
            return json_encode($indirizzo);
        } else {
            return $indirizzo;
        }
    }

    /**
     * @param bool $json parametro che indica la modalità di riotrno del metodo, se TRUE ritorna JSON. Di default FALSE ritorna un array associativo
     */
    public function getEmptyTelefono($json = false)
    {
        $telefono = ['descrizione' => '', 'telefono' => ''];
        if ($json) {
            return json_encode($telefono);
        } else {
            return $telefono;
        }
    }

    /**
     * @param bool $json parametro che indica la modalità di riotrno del metodo, se TRUE ritorna JSON. Di default FALSE ritorna un array associativo
     */
    public function getEmptyCellulare($json = false)
    {
        $cellulare = ['descrizione' => '', 'cellulare' => ''];
        if ($json) {
            return json_encode($cellulare);
        } else {
            return $cellulare;
        }
    }

    /**
     * @param bool $json parametro che indica la modalità di riotrno del metodo, se TRUE ritorna JSON. Di default FALSE ritorna un array associativo
     */
    public function getEmptyEmail($json = false)
    {
        $email = ['descrizione' => '', 'email' => '', 'predefinito' => false];
        if ($json) {
            return json_encode($email);
        } else {
            return $email;
        }
    }

    /**
     * @param bool $json parametro che indica la modalità di riotrno del metodo, se TRUE ritorna JSON. Di default FALSE ritorna un array associativo
     */
    public function getEmptyPec($json = false)
    {
        $pec = ['descrizione' => '', 'pec' => '', 'predefinitoPec' => false];
        if ($json) {
            return json_encode($pec);
        } else {
            return $pec;
        }
    }


    public function getMaxId()
    {
        $query = "SELECT MAX(id) FROM $this->nomeTabella";
        return $this->createResultValue($query);
    }


    public function getIndirizzi($indice = null, $key = null)
    {
        if (is_null($indice)) {
            return parent::getIndirizzi();
        }

        $app = json_decode(parent::getIndirizzi());

        if (is_null($key)) {
            return $app[$indice];
        }

        return isset($app[$indice]->$key) ? $app[$indice]->$key : null;
    }


    public function getIndirizzoRecapito($idAnagrafica)
    {
        $this->findByPk($idAnagrafica);
        $app = $this->getIndirizzi();
        foreach (json_decode($app) as $recapito) {
            if ($recapito->indirizzo_spedizione == true) {
                return json_encode($recapito);
            }
        }
        return null;
    }


    public function getObjIndirizzoDomicilioFiscale($id)
    {
        $indirizzo = ['descrizione' => '', 'via' => '', 'civico' => '', 'citta' => '', 'cap' => '', 'frazione' => '', 'provincia' => '', 'stato' => '', 'presso' => ''];
        $this->findByPk($id);
        $indirizzi = json_decode($this->getIndirizzi());
        foreach ($indirizzi as $ind) {
            if ($ind->domicilio_fiscale == true) {
                $indirizzo['descrizione'] = $ind->descrizione;
                $indirizzo['via'] = $ind->via;
                $indirizzo['civico'] = $ind->civico;
                $indirizzo['citta'] = $ind->citta;
                $indirizzo['cap'] = $ind->cap;
                $indirizzo['frazione'] = $ind->frazione;
                $indirizzo['provincia'] = $ind->provincia;
                $indirizzo['stato'] = $ind->stato;
                $indirizzo['presso'] = $ind->presso;
                return $indirizzo;
            }
        }
    }


    public function getObjIndirizzoSpedizione($id)
    {
        $indirizzo = ['descrizione' => '', 'via' => '', 'civico' => '', 'citta' => '', 'cap' => '', 'frazione' => '', 'provincia' => '', 'stato' => '', 'presso' => ''];
        $this->findByPk($id);
        $indirizzi = json_decode($this->getIndirizzi());
        foreach ($indirizzi as $ind) {
            if ($ind->indirizzo_spedizione == true) {
                $indirizzo['descrizione'] = $ind->descrizione;
                $indirizzo['via'] = $ind->via;
                $indirizzo['civico'] = $ind->civico;
                $indirizzo['citta'] = $ind->citta;
                $indirizzo['cap'] = $ind->cap;
                $indirizzo['frazione'] = $ind->frazione;
                $indirizzo['provincia'] = $ind->provincia;
                $indirizzo['stato'] = $ind->stato;
                $indirizzo['presso'] = $ind->presso;
                return $indirizzo;
            }
        }
    }

}