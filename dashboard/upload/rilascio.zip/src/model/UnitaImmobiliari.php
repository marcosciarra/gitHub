<?php
	/**
	 * Created by Drakkar vers. 0.0.22(Hjortspring)
	 * User: P.D.A. Srl
	 * Date: 2017-11-27
	 * Time: 18:25:52.009485
	 */
	
	namespace Click\Affitti\TblBase;
	require_once 'UnitaImmobiliariModel.php';
	require_once 'Stabili.php';

	use Click\Affitti\TblBase\UnitaImmobiliariModel;
	use Click\Affitti\TblBase\Stabili;
	
	class  UnitaImmobiliari extends UnitaImmobiliariModel
	{


	    /** @var Stabili */
	    protected $stabili;


		function __construct($pdo)
		{
			parent::__construct($pdo);
		}


		public function elencoImmobiliPerAnagrafica($idAnagrafica,$typeResult = self::FETCH_OBJ){
		    //FIXME::QUERY PROVVISORIA PER AVERE ELENCO DAL JSON
            $query =
                "
                SELECT * FROM $this->tableName where 
                proprietari->'$[0].id'=$idAnagrafica OR 
                proprietari->'$[1].id'=$idAnagrafica OR 
                proprietari->'$[2].id'=$idAnagrafica OR 
                proprietari->'$[3].id'=$idAnagrafica OR 
                proprietari->'$[4].id'=$idAnagrafica OR 
                proprietari->'$[5].id'=$idAnagrafica OR 
                proprietari->'$[6].id'=$idAnagrafica OR 
                proprietari->'$[7].id'=$idAnagrafica OR 
                proprietari->'$[8].id'=$idAnagrafica OR 
                proprietari->'$[9].id'=$idAnagrafica
                ";
            if ($this->whereBase) $query .= " WHERE $this->whereBase";
            if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
            return $this->createResultArray($query, null, $typeResult);
        }

        /**
         * @param bool $json parametro che indica la modalità di riotrno del metodo, se TRUE ritorna JSON. Di default FALSE ritorna un array associativo
         * @return array|string
         * parametro 'proprietari' di default a False
         */
        public function getEmptyElencoProprietari($json = false)
        {
            $proprietari = ['id' => '', 'descrizione' => '', 'percentuale_possesso' => '', 'id_tipo_soggetto' => ''];
            if ($json) {
                return json_encode($proprietari);
            } else {
                return $proprietari;
            }
        }


        public function findAllPerSelect($typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
		{
			$query = "SELECT id , descrizione, indirizzo,proprietari FROM $this->tableName ";
			if ($this->whereBase) $query .= " WHERE $this->whereBase";
			if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
			$query .= $this->createLimitQuery($limit, $offset);
			return $this->createResultArray($query, null, $typeResult);
		}
		
		/*
		 * Metodo che restituisce l'elenco delle unità immobiliari
		 */
		public function getElencoUI($distinct = false, $typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
		{
			$distinctStr = ($distinct) ? 'DISTINCT' : '';
			$query =
                "
                SELECT 
                    unita_immobiliari.id,
                    unita_immobiliari.id_tipo_uso,
                    unita_immobiliari.descrizione,
                    unita_immobiliari.indirizzo,
                    unita_immobiliari.interno,
                    tipi_uso.descrizione AS tipo_uso,
                    unita_immobiliari.cestino,
                    unita_immobiliari.id_stabili,
                    immobili_allocati.percentuale
                FROM
                    unita_immobiliari
                        INNER JOIN
                    tipi_uso ON tipi_uso.id = unita_immobiliari.id_tipo_uso
                        LEFT JOIN
                    immobili_allocati ON unita_immobiliari.id = immobili_allocati.id
                ";
            if ($this->whereBase) $query .= " WHERE $this->whereBase";
			if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
			$query .= $this->createLimitQuery($limit, $offset);
			return $this->createResultArray($query, null, $typeResult);
		}
		
		/**
		 * @param bool $json parametro che indica la modalità di riotrno del metodo, se TRUE ritorna JSON. Di default
		 *                   FALSE ritorna un array associativo
		 */
		public function getEmptyIndirizzo($json = false)
		{
			$indirizzo = ['comune'        => '', 'codice_comune' => '', 'cap' => '', 'provincia' => '', 'stato' => '',
						  'tipoIndirizzo' => '', 'indirizzo' => '', 'civico' => '', 'interno' => '', 'frazione' => ''];
			
			if ($json) {
				return json_encode($indirizzo);
			}
			else {
				return $indirizzo;
			}
		}
		
		
		/**
		 * @param $idContratto
		 * @param int $typeResult
		 * @param int $limit
		 * @param int $offset
		 *
		 * @return UnitaImmobiliari[]|array|string
		 */
		public function findByIdContratto($idContratto, $typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
		{
			$query = "SELECT  unita_immobiliari.* FROM unita_immobiliari
					INNER JOIN unita_immobiliari_contratti on unita_immobiliari_contratti.id_unita_immobiliare = unita_immobiliari.id
					WHERE unita_immobiliari_contratti.id_contratto = ? ";
			if ($this->whereBase) $query .= " AND $this->whereBase";
			if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
			$query .= $this->createLimitQuery($limit, $offset);

			$app=[];
			/** @var UnitaImmobiliari $ui */
            foreach ( $this->createResultArray($query, array($idContratto) ) as $ui){
                $stabili=new Stabili($this->conn);
                $ui->setStabili($stabili->findByPk($ui->getIdStabili()));
                $app[]=$ui;
            }

            return $this->returnResult($typeResult,$app);
		}

        public function toArrayAssoc()
        {
            $app=parent::toArrayAssoc(); // TODO: Change the autogenerated stub
            if(isset($this->stabili)) {
                $app['stabili']=$this->stabili->toArrayAssoc();
            }
            return $app;
        }


        /**
         * @return \Click\Affitti\TblBase\Stabili
         */
        public function getStabili(): \Click\Affitti\TblBase\Stabili
        {
            return $this->stabili;
        }

        /**
         * @param \Click\Affitti\TblBase\Stabili $stabili
         */
        public function setStabili(\Click\Affitti\TblBase\Stabili $stabili): void
        {
            $this->stabili = $stabili;
        }

	}