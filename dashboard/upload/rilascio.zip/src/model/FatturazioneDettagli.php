<?php
/**
 * Created by Drakkar vers. 0.1.2(Hjortspring)
 * User: P.D.A. Srl
 * Date: 2018-05-02
 * Time: 17:31:39.860998
 */

namespace Click\Affitti\TblBase;
require_once 'FatturazioneDettagliModel.php';
require_once 'TipiIva.php';

use Click\Affitti\TblBase\FatturazioneDettagliModel;
use Click\Affitti\TblBase\TipiIva;

class  FatturazioneDettagli extends FatturazioneDettagliModel
{

    protected $tipoIva;


    function __construct($pdo)
    {
        parent::__construct($pdo);
    }

    public function findByIdxIdFatturazioneTesta($idFatturazioneTesta, $typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $result = [];
        foreach ($this->findByIdxIdFatturazioneTestaOrdianata($idFatturazioneTesta, $typeResult, $limit, $offset) as $app) {
            $t = new TipiIva($this->conn);
            $t->findByPk($app->getIdTipoIva());
            $app->setTipoIva($t);
            $result[] = $app;
        }
        return $result;
    }


    public function getTotaleImportoPerIva($idFatturazioneTesta, $idTipoIva)
    {
        $query =
            "
            SELECT 
                sum(fatturazione_dettagli.importo) as importo
            FROM
                fatturazione_dettagli
            WHERE
                id_fatturazione_testa = ?
                    AND id_tipo_iva = ?
            ";
        return $this->createResultValue($query, array($idFatturazioneTesta, $idTipoIva));
    }


    public function getTotaleImponibilePerIva($idFatturazioneTesta, $idTipoIva)
    {
        $query =
            "
            SELECT 
                sum(fatturazione_dettagli.imponibile) as imponibile
            FROM
                fatturazione_dettagli
            WHERE
                id_fatturazione_testa = ?
                    AND id_tipo_iva = ?
            ";
        return $this->createResultValue($query, array($idFatturazioneTesta, $idTipoIva));
    }


    public function getPeriodo($format)
    {
        $returnValue = '';
        $tipiPeriodo = array('A', 'F', 'S');

        if (in_array($this->getIdCategoriaSpese(), $tipiPeriodo))
            $returnValue = formattaDate($this->getDataInizio(), $format) . ' - ' . formattaDate($this->getDataFine(), $format);
        return $returnValue;
    }


    /**
     * @return mixed
     */
    public function getTipoIva()
    {
        return $this->tipoIva;
    }

    /**
     * @param mixed $tipoIva
     */
    public function setTipoIva($tipoIva)
    {
        $this->tipoIva = $tipoIva;
    }


    public function findByIdxIdFatturazioneTestaOrdianata($idFatturazioneTesta, $typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $query = "
            SELECT 
                fatturazione_dettagli.*,
                categorie_spesa.ordinamento as ordinamento
            FROM
                fatturazione_dettagli
                    INNER JOIN
                categorie_spesa ON fatturazione_dettagli.id_categoria_spese = categorie_spesa.id
            WHERE
                id_fatturazione_testa = ? AND fatturazione_dettagli.id_categoria_spese!='Z'
            ORDER BY ordinamento ASC
        ";
        return $this->createResultArray($query, array($idFatturazioneTesta), $typeResult);
    }


    public function findTotaleGruppiIvaByIdFatturaTesta($idFatturazioneTesta, $typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $query =
            "
            SELECT 
                tipi_iva.*,
                SUM(fatturazione_dettagli.imponibile) AS imponibile,
                SUM(fatturazione_dettagli.importo) AS importo
            FROM
                fatturazione_testa
                    INNER JOIN
                fatturazione_dettagli ON fatturazione_testa.id = fatturazione_dettagli.id_fatturazione_testa
                    INNER JOIN
                tipi_iva ON fatturazione_dettagli.id_tipo_iva = tipi_iva.id
            WHERE
                fatturazione_testa.id = ?
            GROUP BY tipi_iva.id
            ";
        return $this->createResultArray($query, array($idFatturazioneTesta), $typeResult);
    }




}