<?php
/**
 * Created by Drakkar vers. 0.1.3(Hjortspring)
 * User: P.D.A. Srl
 * Date: 2018-11-15
 * Time: 11:42:47.513725
 */

namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';

use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class GruppiFatturazioneModel extends PdaAbstractModel
{
    /** @var integer */
    protected $id;
    /** @var string */
    protected $sigla;
    /** @var integer */
    protected $ultimoNumero = 0;
    /** @var integer */
    protected $anno;
    /** @var integer */
    protected $idAnagrafica;
    /** @var integer */
    protected $flagFattura = 0;
    /** @var integer */
    protected $flagNumeroZero = 0;


    function __construct($pdo)
    {
        parent::__construct($pdo);
        $this->nomeTabella = 'gruppi_fatturazione';
        $this->tableName = 'gruppi_fatturazione';
    }

    /**
     * find by tables' Primary Key:
     * @return GruppiFatturazione|array|string|null
     */
    public function findByPk($id, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResult($query, array($id), $typeResult);
    }

    /**
     * delete by tables' Primary Key:
     */
    public function deleteByPk($id)
    {
        $query = "DELETE FROM $this->tableName  WHERE id=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultValue($query, array($id));
    }

    /**
     * Find all record of table
     * @return GruppiFatturazione[]|array|string
     */
    public function findAll($distinct = false, $typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $distinctStr = ($distinct) ? 'DISTINCT' : '';
        $query = "SELECT $distinctStr * FROM $this->tableName ";
        if ($this->whereBase) $query .= " WHERE $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        $query .= $this->createLimitQuery($limit, $offset);
        return $this->createResultArray($query, null, $typeResult);
    }

    /**
     * find by tables' Key fk_gruppo_fatturazione_anagrafiche1_idx:
     * @return GruppiFatturazione[]|array|string
     */
    public function findByFkGruppoFatturazioneAnagrafiche1Idx($idAnagrafica, $typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $query = "SELECT * FROM $this->tableName USE INDEX(fk_gruppo_fatturazione_anagrafiche1_idx) WHERE id_anagrafica=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultArray($query, array($idAnagrafica), $typeResult);
    }

    /**
     * delete by tables' Key fk_gruppo_fatturazione_anagrafiche1_idx:
     * @return boolean
     */
    public function deleteByFkGruppoFatturazioneAnagrafiche1Idx($idAnagrafica, $typeResult = self::FETCH_OBJ)
    {
        $query = "DELETE FROM $this->tableName WHERE id_anagrafica=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultValue($query, array($idAnagrafica));
    }

    /**
     * find by id
     * @return GruppiFatturazione[]
     */
    public function findById($id, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName WHERE id=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        return $this->createResultArray($query, array($id), $typeResult);
    }


    /**
     * find by id_anagrafica
     * @return GruppiFatturazione[]
     */
    public function findByIdAnagrafica($idAnagrafica, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName WHERE id_anagrafica=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        return $this->createResultArray($query, array($idAnagrafica), $typeResult);
    }


    /**
     * delete by id_anagrafica
     * @return boolean
     */
    public function deleteByIdAnagrafica($idAnagrafica)
    {
        $query = "DELETE FROM $this->tableName WHERE id_anagrafica=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultValue($query, array($idAnagrafica));
    }

    /**
     * Transforms the object into a key array
     * @return array
     */
    public function toArrayAssoc()
    {
        $arrayValue = array();
        if (isset($this->id)) $arrayValue['id'] = $this->id;
        if (isset($this->sigla)) $arrayValue['sigla'] = ($this->sigla == self::NULL_VALUE) ? null : $this->sigla;
        if (isset($this->ultimoNumero)) $arrayValue['ultimo_numero'] = $this->ultimoNumero;
        if (isset($this->anno)) $arrayValue['anno'] = ($this->anno == self::NULL_VALUE) ? null : $this->anno;
        if (isset($this->idAnagrafica)) $arrayValue['id_anagrafica'] = $this->idAnagrafica;
        if (isset($this->flagFattura)) $arrayValue['flag_fattura'] = $this->flagFattura;
        if (isset($this->flagNumeroZero)) $arrayValue['flag_numero_zero'] = $this->flagNumeroZero;
        return $arrayValue;
    }

    /**
     * It transforms the keyarray in an $positionalArray[%s]object
     */
    public function createObjKeyArray(array $keyArray)
    {
        $this->flagObjectDataValorized = false;
        if ((isset($keyArray['id'])) || (isset($keyArray['gruppi_fatturazione_id']))) {
            $this->setId(isset($keyArray['id']) ? $keyArray['id'] : $keyArray['gruppi_fatturazione_id']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['sigla'])) || (isset($keyArray['gruppi_fatturazione_sigla']))) {
            $this->setSigla(isset($keyArray['sigla']) ? $keyArray['sigla'] : $keyArray['gruppi_fatturazione_sigla']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['ultimo_numero'])) || (isset($keyArray['gruppi_fatturazione_ultimo_numero']))) {
            $this->setUltimonumero(isset($keyArray['ultimo_numero']) ? $keyArray['ultimo_numero'] : $keyArray['gruppi_fatturazione_ultimo_numero']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['anno'])) || (isset($keyArray['gruppi_fatturazione_anno']))) {
            $this->setAnno(isset($keyArray['anno']) ? $keyArray['anno'] : $keyArray['gruppi_fatturazione_anno']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['id_anagrafica'])) || (isset($keyArray['gruppi_fatturazione_id_anagrafica']))) {
            $this->setIdanagrafica(isset($keyArray['id_anagrafica']) ? $keyArray['id_anagrafica'] : $keyArray['gruppi_fatturazione_id_anagrafica']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['flag_fattura'])) || (isset($keyArray['gruppi_fatturazione_flag_fattura']))) {
            $this->setFlagFattura(isset($keyArray['flag_fattura']) ? $keyArray['flag_fattura'] : $keyArray['gruppi_fatturazione_flag_fattura']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['flag_numero_zero'])) || (isset($keyArray['gruppi_fatturazione_flag_numero_zero']))) {
            $this->setFlagNumeroZero(isset($keyArray['flag_numero_zero']) ? $keyArray['flag_numero_zero'] : $keyArray['gruppi_fatturazione_flag_numero_zero']);
            $this->flagObjectDataValorized = true;
        }
    }

    /**
     * @return array
     */
    public function createKeyArrayFromPositional($positionalArray)
    {
        $values = array();
        $values['id'] = $positionalArray[0];
        $values['sigla'] = ($positionalArray[1] == self::NULL_VALUE) ? null : $positionalArray[1];
        $values['ultimo_numero'] = $positionalArray[2];
        $values['anno'] = ($positionalArray[3] == self::NULL_VALUE) ? null : $positionalArray[3];
        $values['id_anagrafica'] = $positionalArray[4];
        $values['flag_fattura'] = $positionalArray[5];
        $values['flag_numero_zero'] = $positionalArray[6];
        return $values;
    }

    /**
     * @return array
     */
    public function getEmptyDbKeyArray()
    {
        $values = array();
        $values['id'] = null;
        $values['sigla'] = null;
        $values['ultimo_numero'] = 0;
        $values['anno'] = null;
        $values['id_anagrafica'] = null;
        $values['flag_fattura'] = 0;
        $values['flag_numero_zero'] = 0;
        return $values;
    }

    /**
     * Return columns' list
     * @return string
     */
    public function getListColumns()
    {
        return 'gruppi_fatturazione.id as gruppi_fatturazione_id,gruppi_fatturazione.sigla as gruppi_fatturazione_sigla,gruppi_fatturazione.ultimo_numero as gruppi_fatturazione_ultimo_numero,gruppi_fatturazione.anno as gruppi_fatturazione_anno,gruppi_fatturazione.id_anagrafica as gruppi_fatturazione_id_anagrafica';
    }

    /**
     * DDL Table
     */
    public function createTable()
    {
        return $this->pdo->exec("CREATE TABLE `gruppi_fatturazione` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sigla` varchar(10) DEFAULT NULL,
  `ultimo_numero` int(11) NOT NULL DEFAULT '0',
  `anno` int(11) DEFAULT NULL,
  `id_anagrafica` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_gruppo_fatturazione_anagrafiche1_idx` (`id_anagrafica`),
  CONSTRAINT `fk_gruppo_fatturazione_anagrafiche1` FOREIGN KEY (`id_anagrafica`) REFERENCES `anagrafiche` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1 ");
    }

    /**
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param integer $id Id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return string
     */
    public function getSigla()
    {
        return $this->sigla;
    }

    /**
     * @param string $sigla Sigla
     * @param int $encodeType
     */
    public function setSigla($sigla, $encodeType = self::STR_DEFAULT)
    {
        $this->sigla = $this->decodeString($sigla, $encodeType);
    }

    /**
     * @return integer
     */
    public function getUltimoNumero()
    {
        return $this->ultimoNumero;
    }

    /**
     * @param integer $ultimoNumero UltimoNumero
     */
    public function setUltimoNumero($ultimoNumero)
    {
        $this->ultimoNumero = $ultimoNumero;
    }

    /**
     * @return integer
     */
    public function getAnno()
    {
        return $this->anno;
    }

    /**
     * @param integer $anno Anno
     */
    public function setAnno($anno)
    {
        $this->anno = $anno;
    }

    /**
     * @return integer
     */
    public function getIdAnagrafica()
    {
        return $this->idAnagrafica;
    }

    /**
     * @param integer $idAnagrafica IdAnagrafica
     */
    public function setIdAnagrafica($idAnagrafica)
    {
        $this->idAnagrafica = $idAnagrafica;
    }

    /**
     * @return int
     */
    public function getFlagFattura()
    {
        return $this->flagFattura;
    }

    /**
     * @param int $flagFattura
     */
    public function setFlagFattura($flagFattura)
    {
        $this->flagFattura = $flagFattura;
    }

    /**
     * @return int
     */
    public function getFlagNumeroZero()
    {
        return $this->flagNumeroZero;
    }

    /**
     * @param int $flagNumeroZero
     */
    public function setFlagNumeroZero($flagNumeroZero)
    {
        $this->flagNumeroZero = $flagNumeroZero;
    }

}