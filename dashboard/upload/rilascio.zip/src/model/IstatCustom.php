<?php
/**
* Created by Drakkar vers. 0.0.23(Hjortspring)
* User: P.D.A. Srl
* Date: 2017-12-06
* Time: 15:21:59.589180
*/
namespace Click\Affitti\TblBase;
require_once 'IstatCustomModel.php';
use Click\Affitti\TblBase\IstatCustomModel;

class  IstatCustom extends IstatCustomModel {
function __construct($pdo){parent::__construct($pdo);}

}