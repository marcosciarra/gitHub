<?php
/**
* Created by Drakkar vers. 0.0.25(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-01-31
* Time: 17:07:56.167493
*/
namespace Click\Affitti\TblBase;
require_once 'ListacomuniModel.php';
use Click\Affitti\TblBase\ListacomuniModel;

class  Listacomuni extends ListacomuniModel {
function __construct($pdo){parent::__construct($pdo);}

}