<?php
/**
 * Created by Drakkar vers. 0.1.0(Hjortspring)
 * User: P.D.A. Srl
 * Date: 2018-04-04
 * Time: 17:19:33.774525
 */

namespace Click\Affitti\TblBase;
require_once 'CodiceTributiModel.php';

use Click\Affitti\TblBase\CodiceTributiModel;

class  CodiceTributi extends CodiceTributiModel
{
    function __construct($pdo)
    {
        parent::__construct($pdo);
    }

    /**
     * Find all record of table
     * @return CodiceTributi[]|array|string
     */
    public function findAllConCodiceDescrizione($typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $query = "SELECT *,CONCAT_WS(' - ',codice,descrizione)as codiceDescrizione FROM $this->tableName ";
        if ($this->whereBase) $query .= " WHERE $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        $query .= $this->createLimitQuery($limit, $offset);
        return $this->createResultArray($query, null, $typeResult);
    }

}