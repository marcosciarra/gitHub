<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-15
* Time: 11:42:47.749561
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class ProprietariModel extends PdaAbstractModel {
/** @var integer */
protected $id=0;
/** @var integer */
protected $idTipiSoggetto;
/** @var string */
protected $titolo;
/** @var string */
protected $codiceFiscale;
/** @var string */
protected $partitaIvaNazione;
/** @var string */
protected $partitaIva;
/** @var string */
protected $ragioneSociale;
/** @var string */
protected $nome;
/** @var string */
protected $cognome;
/** @var string */
protected $nascitaData;
/** @var string */
protected $nascitaLuogo;
/** @var string */
protected $nascitaProvincia;
/** @var string */
protected $nascitaStato;
/** @var string (enum) */
protected $sesso;
/** @var objext (string) */
protected $telefoni;
/** @var objext (string) */
protected $cellulari;
/** @var objext (string) */
protected $email;
/** @var objext (string) */
protected $indirizzi;
/** @var integer */
protected $ultimaModificaUtente;
/** @var string */
protected $ultimaModificaData;
/** @var integer */
protected $idRappresentante;
/** @var integer */
protected $idTipoRappresentante;
/** @var integer */
protected $cestino=0;
/** @var string */
protected $fileLogo;
/** @var string */
protected $fileFirma;
/** @var integer */
protected $idUtente;
/** @var integer indica se una societ� � un'anagrafica di fatturazione o no (agenzie, immobiliari, amministratori, ecc)*/
protected $societaFatturazione=0;
/** @var integer */
protected $amministratoreCondominio=0;
/** @var integer */
protected $fornitore=0;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='proprietari';$this->tableName='proprietari';}

/**
 * Find all record of table
 * @return Proprietari[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->id))$arrayValue['id']=$this->id;if(isset($this->idTipiSoggetto))$arrayValue['id_tipi_soggetto']=$this->idTipiSoggetto;if(isset($this->titolo))$arrayValue['titolo']=($this->titolo==self::NULL_VALUE)?null:$this->titolo;if(isset($this->codiceFiscale))$arrayValue['codice_fiscale']=$this->codiceFiscale;if(isset($this->partitaIvaNazione))$arrayValue['partita_iva_nazione']=($this->partitaIvaNazione==self::NULL_VALUE)?null:$this->partitaIvaNazione;if(isset($this->partitaIva))$arrayValue['partita_iva']=($this->partitaIva==self::NULL_VALUE)?null:$this->partitaIva;if(isset($this->ragioneSociale))$arrayValue['ragione_sociale']=($this->ragioneSociale==self::NULL_VALUE)?null:$this->ragioneSociale;if(isset($this->nome))$arrayValue['nome']=($this->nome==self::NULL_VALUE)?null:$this->nome;if(isset($this->cognome))$arrayValue['cognome']=($this->cognome==self::NULL_VALUE)?null:$this->cognome;if(isset($this->nascitaData))$arrayValue['nascita_data']=($this->nascitaData==self::NULL_VALUE)?null:$this->nascitaData;if(isset($this->nascitaLuogo))$arrayValue['nascita_luogo']=($this->nascitaLuogo==self::NULL_VALUE)?null:$this->nascitaLuogo;if(isset($this->nascitaProvincia))$arrayValue['nascita_provincia']=($this->nascitaProvincia==self::NULL_VALUE)?null:$this->nascitaProvincia;if(isset($this->nascitaStato))$arrayValue['nascita_stato']=($this->nascitaStato==self::NULL_VALUE)?null:$this->nascitaStato;if(isset($this->sesso))$arrayValue['sesso']=($this->sesso==self::NULL_VALUE)?null:$this->sesso;if(isset($this->telefoni))$arrayValue['telefoni']=$this->jsonEncode($this->telefoni);if(isset($this->cellulari))$arrayValue['cellulari']=$this->jsonEncode($this->cellulari);if(isset($this->email))$arrayValue['email']=$this->jsonEncode($this->email);if(isset($this->indirizzi))$arrayValue['indirizzi']=$this->jsonEncode($this->indirizzi);if(isset($this->ultimaModificaUtente))$arrayValue['ultima_modifica_utente']=$this->ultimaModificaUtente;if(isset($this->ultimaModificaData))$arrayValue['ultima_modifica_data']=($this->ultimaModificaData==self::NULL_VALUE)?null:$this->ultimaModificaData;if(isset($this->idRappresentante))$arrayValue['id_rappresentante']=($this->idRappresentante==self::NULL_VALUE)?null:$this->idRappresentante;if(isset($this->idTipoRappresentante))$arrayValue['id_tipo_rappresentante']=($this->idTipoRappresentante==self::NULL_VALUE)?null:$this->idTipoRappresentante;if(isset($this->cestino))$arrayValue['cestino']=$this->cestino;if(isset($this->fileLogo))$arrayValue['file_logo']=($this->fileLogo==self::NULL_VALUE)?null:$this->fileLogo;if(isset($this->fileFirma))$arrayValue['file_firma']=($this->fileFirma==self::NULL_VALUE)?null:$this->fileFirma;if(isset($this->idUtente))$arrayValue['id_utente']=($this->idUtente==self::NULL_VALUE)?null:$this->idUtente;if(isset($this->societaFatturazione))$arrayValue['societa_fatturazione']=($this->societaFatturazione==self::NULL_VALUE)?null:$this->societaFatturazione;if(isset($this->amministratoreCondominio))$arrayValue['amministratore_condominio']=($this->amministratoreCondominio==self::NULL_VALUE)?null:$this->amministratoreCondominio;if(isset($this->fornitore))$arrayValue['fornitore']=($this->fornitore==self::NULL_VALUE)?null:$this->fornitore;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['id'])) || (isset($keyArray['proprietari_id']))) {$this->setId(isset($keyArray['id'])?$keyArray['id']:$keyArray['proprietari_id']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_tipi_soggetto'])) || (isset($keyArray['proprietari_id_tipi_soggetto']))) {$this->setIdtipisoggetto(isset($keyArray['id_tipi_soggetto'])?$keyArray['id_tipi_soggetto']:$keyArray['proprietari_id_tipi_soggetto']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['titolo'])) || (isset($keyArray['proprietari_titolo']))) {$this->setTitolo(isset($keyArray['titolo'])?$keyArray['titolo']:$keyArray['proprietari_titolo']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['codice_fiscale'])) || (isset($keyArray['proprietari_codice_fiscale']))) {$this->setCodicefiscale(isset($keyArray['codice_fiscale'])?$keyArray['codice_fiscale']:$keyArray['proprietari_codice_fiscale']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['partita_iva_nazione'])) || (isset($keyArray['proprietari_partita_iva_nazione']))) {$this->setPartitaivanazione(isset($keyArray['partita_iva_nazione'])?$keyArray['partita_iva_nazione']:$keyArray['proprietari_partita_iva_nazione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['partita_iva'])) || (isset($keyArray['proprietari_partita_iva']))) {$this->setPartitaiva(isset($keyArray['partita_iva'])?$keyArray['partita_iva']:$keyArray['proprietari_partita_iva']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['ragione_sociale'])) || (isset($keyArray['proprietari_ragione_sociale']))) {$this->setRagionesociale(isset($keyArray['ragione_sociale'])?$keyArray['ragione_sociale']:$keyArray['proprietari_ragione_sociale']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['nome'])) || (isset($keyArray['proprietari_nome']))) {$this->setNome(isset($keyArray['nome'])?$keyArray['nome']:$keyArray['proprietari_nome']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['cognome'])) || (isset($keyArray['proprietari_cognome']))) {$this->setCognome(isset($keyArray['cognome'])?$keyArray['cognome']:$keyArray['proprietari_cognome']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['nascita_data'])) || (isset($keyArray['proprietari_nascita_data']))) {$this->setNascitadata(isset($keyArray['nascita_data'])?$keyArray['nascita_data']:$keyArray['proprietari_nascita_data']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['nascita_luogo'])) || (isset($keyArray['proprietari_nascita_luogo']))) {$this->setNascitaluogo(isset($keyArray['nascita_luogo'])?$keyArray['nascita_luogo']:$keyArray['proprietari_nascita_luogo']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['nascita_provincia'])) || (isset($keyArray['proprietari_nascita_provincia']))) {$this->setNascitaprovincia(isset($keyArray['nascita_provincia'])?$keyArray['nascita_provincia']:$keyArray['proprietari_nascita_provincia']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['nascita_stato'])) || (isset($keyArray['proprietari_nascita_stato']))) {$this->setNascitastato(isset($keyArray['nascita_stato'])?$keyArray['nascita_stato']:$keyArray['proprietari_nascita_stato']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['sesso'])) || (isset($keyArray['proprietari_sesso']))) {$this->setSesso(isset($keyArray['sesso'])?$keyArray['sesso']:$keyArray['proprietari_sesso']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['telefoni'])) || (isset($keyArray['proprietari_telefoni']))) {$this->setTelefoni(isset($keyArray['telefoni'])?$keyArray['telefoni']:$keyArray['proprietari_telefoni']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['cellulari'])) || (isset($keyArray['proprietari_cellulari']))) {$this->setCellulari(isset($keyArray['cellulari'])?$keyArray['cellulari']:$keyArray['proprietari_cellulari']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['email'])) || (isset($keyArray['proprietari_email']))) {$this->setEmail(isset($keyArray['email'])?$keyArray['email']:$keyArray['proprietari_email']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['indirizzi'])) || (isset($keyArray['proprietari_indirizzi']))) {$this->setIndirizzi(isset($keyArray['indirizzi'])?$keyArray['indirizzi']:$keyArray['proprietari_indirizzi']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['ultima_modifica_utente'])) || (isset($keyArray['proprietari_ultima_modifica_utente']))) {$this->setUltimamodificautente(isset($keyArray['ultima_modifica_utente'])?$keyArray['ultima_modifica_utente']:$keyArray['proprietari_ultima_modifica_utente']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['ultima_modifica_data'])) || (isset($keyArray['proprietari_ultima_modifica_data']))) {$this->setUltimamodificadata(isset($keyArray['ultima_modifica_data'])?$keyArray['ultima_modifica_data']:$keyArray['proprietari_ultima_modifica_data']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_rappresentante'])) || (isset($keyArray['proprietari_id_rappresentante']))) {$this->setIdrappresentante(isset($keyArray['id_rappresentante'])?$keyArray['id_rappresentante']:$keyArray['proprietari_id_rappresentante']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_tipo_rappresentante'])) || (isset($keyArray['proprietari_id_tipo_rappresentante']))) {$this->setIdtiporappresentante(isset($keyArray['id_tipo_rappresentante'])?$keyArray['id_tipo_rappresentante']:$keyArray['proprietari_id_tipo_rappresentante']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['cestino'])) || (isset($keyArray['proprietari_cestino']))) {$this->setCestino(isset($keyArray['cestino'])?$keyArray['cestino']:$keyArray['proprietari_cestino']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['file_logo'])) || (isset($keyArray['proprietari_file_logo']))) {$this->setFilelogo(isset($keyArray['file_logo'])?$keyArray['file_logo']:$keyArray['proprietari_file_logo']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['file_firma'])) || (isset($keyArray['proprietari_file_firma']))) {$this->setFilefirma(isset($keyArray['file_firma'])?$keyArray['file_firma']:$keyArray['proprietari_file_firma']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_utente'])) || (isset($keyArray['proprietari_id_utente']))) {$this->setIdutente(isset($keyArray['id_utente'])?$keyArray['id_utente']:$keyArray['proprietari_id_utente']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['societa_fatturazione'])) || (isset($keyArray['proprietari_societa_fatturazione']))) {$this->setSocietafatturazione(isset($keyArray['societa_fatturazione'])?$keyArray['societa_fatturazione']:$keyArray['proprietari_societa_fatturazione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['amministratore_condominio'])) || (isset($keyArray['proprietari_amministratore_condominio']))) {$this->setAmministratorecondominio(isset($keyArray['amministratore_condominio'])?$keyArray['amministratore_condominio']:$keyArray['proprietari_amministratore_condominio']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['fornitore'])) || (isset($keyArray['proprietari_fornitore']))) {$this->setFornitore(isset($keyArray['fornitore'])?$keyArray['fornitore']:$keyArray['proprietari_fornitore']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['id'] =$positionalArray[0];$values['id_tipi_soggetto'] =$positionalArray[1];$values['titolo'] =($positionalArray[2]==self::NULL_VALUE)?null:$positionalArray[2];$values['codice_fiscale'] =$positionalArray[3];$values['partita_iva_nazione'] =($positionalArray[4]==self::NULL_VALUE)?null:$positionalArray[4];$values['partita_iva'] =($positionalArray[5]==self::NULL_VALUE)?null:$positionalArray[5];$values['ragione_sociale'] =($positionalArray[6]==self::NULL_VALUE)?null:$positionalArray[6];$values['nome'] =($positionalArray[7]==self::NULL_VALUE)?null:$positionalArray[7];$values['cognome'] =($positionalArray[8]==self::NULL_VALUE)?null:$positionalArray[8];$values['nascita_data'] =($positionalArray[9]==self::NULL_VALUE)?null:$positionalArray[9];$values['nascita_luogo'] =($positionalArray[10]==self::NULL_VALUE)?null:$positionalArray[10];$values['nascita_provincia'] =($positionalArray[11]==self::NULL_VALUE)?null:$positionalArray[11];$values['nascita_stato'] =($positionalArray[12]==self::NULL_VALUE)?null:$positionalArray[12];$values['sesso'] =($positionalArray[13]==self::NULL_VALUE)?null:$positionalArray[13];$values['telefoni'] =($positionalArray[14]==self::NULL_VALUE)?null:$positionalArray[14];$values['cellulari'] =($positionalArray[15]==self::NULL_VALUE)?null:$positionalArray[15];$values['email'] =($positionalArray[16]==self::NULL_VALUE)?null:$positionalArray[16];$values['indirizzi'] =($positionalArray[17]==self::NULL_VALUE)?null:$positionalArray[17];$values['ultima_modifica_utente'] =$positionalArray[18];$values['ultima_modifica_data'] =($positionalArray[19]==self::NULL_VALUE)?null:$positionalArray[19];$values['id_rappresentante'] =($positionalArray[20]==self::NULL_VALUE)?null:$positionalArray[20];$values['id_tipo_rappresentante'] =($positionalArray[21]==self::NULL_VALUE)?null:$positionalArray[21];$values['cestino'] =$positionalArray[22];$values['file_logo'] =($positionalArray[23]==self::NULL_VALUE)?null:$positionalArray[23];$values['file_firma'] =($positionalArray[24]==self::NULL_VALUE)?null:$positionalArray[24];$values['id_utente'] =($positionalArray[25]==self::NULL_VALUE)?null:$positionalArray[25];$values['societa_fatturazione'] =($positionalArray[26]==self::NULL_VALUE)?null:$positionalArray[26];$values['amministratore_condominio'] =($positionalArray[27]==self::NULL_VALUE)?null:$positionalArray[27];$values['fornitore'] =($positionalArray[28]==self::NULL_VALUE)?null:$positionalArray[28];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['id'] = 0;$values['id_tipi_soggetto'] = null;$values['titolo'] = null;$values['codice_fiscale'] = '';$values['partita_iva_nazione'] = null;$values['partita_iva'] = null;$values['ragione_sociale'] = null;$values['nome'] = null;$values['cognome'] = null;$values['nascita_data'] = null;$values['nascita_luogo'] = null;$values['nascita_provincia'] = null;$values['nascita_stato'] = null;$values['sesso'] = null;$values['telefoni'] = null;$values['cellulari'] = null;$values['email'] = null;$values['indirizzi'] = null;$values['ultima_modifica_utente'] = null;$values['ultima_modifica_data'] = null;$values['id_rappresentante'] = null;$values['id_tipo_rappresentante'] = null;$values['cestino'] = 0;$values['file_logo'] = null;$values['file_firma'] = null;$values['id_utente'] = null;$values['societa_fatturazione'] = 0;$values['amministratore_condominio'] = 0;$values['fornitore'] = 0;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'proprietari.id as proprietari_id,proprietari.id_tipi_soggetto as proprietari_id_tipi_soggetto,proprietari.titolo as proprietari_titolo,proprietari.codice_fiscale as proprietari_codice_fiscale,proprietari.partita_iva_nazione as proprietari_partita_iva_nazione,proprietari.partita_iva as proprietari_partita_iva,proprietari.ragione_sociale as proprietari_ragione_sociale,proprietari.nome as proprietari_nome,proprietari.cognome as proprietari_cognome,proprietari.nascita_data as proprietari_nascita_data,proprietari.nascita_luogo as proprietari_nascita_luogo,proprietari.nascita_provincia as proprietari_nascita_provincia,proprietari.nascita_stato as proprietari_nascita_stato,proprietari.sesso as proprietari_sesso,proprietari.telefoni as proprietari_telefoni,proprietari.cellulari as proprietari_cellulari,proprietari.email as proprietari_email,proprietari.indirizzi as proprietari_indirizzi,proprietari.ultima_modifica_utente as proprietari_ultima_modifica_utente,proprietari.ultima_modifica_data as proprietari_ultima_modifica_data,proprietari.id_rappresentante as proprietari_id_rappresentante,proprietari.id_tipo_rappresentante as proprietari_id_tipo_rappresentante,proprietari.cestino as proprietari_cestino,proprietari.file_logo as proprietari_file_logo,proprietari.file_firma as proprietari_file_firma,proprietari.id_utente as proprietari_id_utente,proprietari.societa_fatturazione as proprietari_societa_fatturazione,proprietari.amministratore_condominio as proprietari_amministratore_condominio,proprietari.fornitore as proprietari_fornitore';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`%` SQL SECURITY DEFINER VIEW `proprietari` AS select distinct `anagrafiche`.`id` AS `id`,`anagrafiche`.`id_tipi_soggetto` AS `id_tipi_soggetto`,`anagrafiche`.`titolo` AS `titolo`,`anagrafiche`.`codice_fiscale` AS `codice_fiscale`,`anagrafiche`.`partita_iva_nazione` AS `partita_iva_nazione`,`anagrafiche`.`partita_iva` AS `partita_iva`,`anagrafiche`.`ragione_sociale` AS `ragione_sociale`,`anagrafiche`.`nome` AS `nome`,`anagrafiche`.`cognome` AS `cognome`,`anagrafiche`.`nascita_data` AS `nascita_data`,`anagrafiche`.`nascita_luogo` AS `nascita_luogo`,`anagrafiche`.`nascita_provincia` AS `nascita_provincia`,`anagrafiche`.`nascita_stato` AS `nascita_stato`,`anagrafiche`.`sesso` AS `sesso`,`anagrafiche`.`telefoni` AS `telefoni`,`anagrafiche`.`cellulari` AS `cellulari`,`anagrafiche`.`email` AS `email`,`anagrafiche`.`indirizzi` AS `indirizzi`,`anagrafiche`.`ultima_modifica_utente` AS `ultima_modifica_utente`,`anagrafiche`.`ultima_modifica_data` AS `ultima_modifica_data`,`anagrafiche`.`id_rappresentante` AS `id_rappresentante`,`anagrafiche`.`id_tipo_rappresentante` AS `id_tipo_rappresentante`,`anagrafiche`.`cestino` AS `cestino`,`anagrafiche`.`file_logo` AS `file_logo`,`anagrafiche`.`file_firma` AS `file_firma`,`anagrafiche`.`id_utente` AS `id_utente`,`anagrafiche`.`societa_fatturazione` AS `societa_fatturazione`,`anagrafiche`.`amministratore_condominio` AS `amministratore_condominio`,`anagrafiche`.`fornitore` AS `fornitore` from (`anagrafiche` join `contratti` on(((`anagrafiche`.`id` = json_extract(`contratti`.`proprietari`,'$[0].id')) or (`anagrafiche`.`id` = json_extract(`contratti`.`proprietari`,'$[1].id')) or (`anagrafiche`.`id` = json_extract(`contratti`.`proprietari`,'$[2].id')) or (`anagrafiche`.`id` = json_extract(`contratti`.`proprietari`,'$[3].id')) or (`anagrafiche`.`id` = json_extract(`contratti`.`proprietari`,'$[4].id')) or (`anagrafiche`.`id` = json_extract(`contratti`.`proprietari`,'$[5].id')) or (`anagrafiche`.`id` = json_extract(`contratti`.`proprietari`,'$[6].id')) or (`anagrafiche`.`id` = json_extract(`contratti`.`proprietari`,'$[7].id')) or (`anagrafiche`.`id` = json_extract(`contratti`.`proprietari`,'$[8].id')) or (`anagrafiche`.`id` = json_extract(`contratti`.`proprietari`,'$[9].id'))))) where ((`anagrafiche`.`cestino` = 0) and (`contratti`.`cestino` = 0)) ");}
/**
 * @return integer
 */
public function getId(){return $this->id;}
/**
 * @param integer $id Id
 */
public function setId($id){$this->id=$id;}
/**
 * @return integer
 */
public function getIdTipiSoggetto(){return $this->idTipiSoggetto;}
/**
 * @param integer $idTipiSoggetto IdTipiSoggetto
 */
public function setIdTipiSoggetto($idTipiSoggetto){$this->idTipiSoggetto=$idTipiSoggetto;}
/**
 * @return string
 */
public function getTitolo(){return $this->titolo;}
/**
 * @param string $titolo Titolo
 * @param int $encodeType
 */
public function setTitolo($titolo,$encodeType = self::STR_DEFAULT){$this->titolo=$this->decodeString($titolo,$encodeType);}
/**
 * @return string
 */
public function getCodiceFiscale(){return $this->codiceFiscale;}
/**
 * @param string $codiceFiscale CodiceFiscale
 * @param int $encodeType
 */
public function setCodiceFiscale($codiceFiscale,$encodeType = self::STR_DEFAULT){$this->codiceFiscale=$this->decodeString($codiceFiscale,$encodeType);}
/**
 * @return string
 */
public function getPartitaIvaNazione(){return $this->partitaIvaNazione;}
/**
 * @param string $partitaIvaNazione PartitaIvaNazione
 * @param int $encodeType
 */
public function setPartitaIvaNazione($partitaIvaNazione,$encodeType = self::STR_DEFAULT){$this->partitaIvaNazione=$this->decodeString($partitaIvaNazione,$encodeType);}
/**
 * @return string
 */
public function getPartitaIva(){return $this->partitaIva;}
/**
 * @param string $partitaIva PartitaIva
 * @param int $encodeType
 */
public function setPartitaIva($partitaIva,$encodeType = self::STR_DEFAULT){$this->partitaIva=$this->decodeString($partitaIva,$encodeType);}
/**
 * @return string
 */
public function getRagioneSociale(){return $this->ragioneSociale;}
/**
 * @param string $ragioneSociale RagioneSociale
 * @param int $encodeType
 */
public function setRagioneSociale($ragioneSociale,$encodeType = self::STR_DEFAULT){$this->ragioneSociale=$this->decodeString($ragioneSociale,$encodeType);}
/**
 * @return string
 */
public function getNome(){return $this->nome;}
/**
 * @param string $nome Nome
 * @param int $encodeType
 */
public function setNome($nome,$encodeType = self::STR_DEFAULT){$this->nome=$this->decodeString($nome,$encodeType);}
/**
 * @return string
 */
public function getCognome(){return $this->cognome;}
/**
 * @param string $cognome Cognome
 * @param int $encodeType
 */
public function setCognome($cognome,$encodeType = self::STR_DEFAULT){$this->cognome=$this->decodeString($cognome,$encodeType);}
/**
 * @return string
 */
public function getNascitaData(){return $this->nascitaData;}
/**
 * @param string $nascitaData NascitaData
 * @param int $encodeType
 */
public function setNascitaData($nascitaData,$encodeType = self::STR_DEFAULT){$this->nascitaData=$this->decodeString($nascitaData,$encodeType);}
/**
 * @return string
 */
public function getNascitaLuogo(){return $this->nascitaLuogo;}
/**
 * @param string $nascitaLuogo NascitaLuogo
 * @param int $encodeType
 */
public function setNascitaLuogo($nascitaLuogo,$encodeType = self::STR_DEFAULT){$this->nascitaLuogo=$this->decodeString($nascitaLuogo,$encodeType);}
/**
 * @return string
 */
public function getNascitaProvincia(){return $this->nascitaProvincia;}
/**
 * @param string $nascitaProvincia NascitaProvincia
 * @param int $encodeType
 */
public function setNascitaProvincia($nascitaProvincia,$encodeType = self::STR_DEFAULT){$this->nascitaProvincia=$this->decodeString($nascitaProvincia,$encodeType);}
/**
 * @return string
 */
public function getNascitaStato(){return $this->nascitaStato;}
/**
 * @param string $nascitaStato NascitaStato
 * @param int $encodeType
 */
public function setNascitaStato($nascitaStato,$encodeType = self::STR_DEFAULT){$this->nascitaStato=$this->decodeString($nascitaStato,$encodeType);}
/**
 * @param bool $decode if true return decode value * @return string
 */
public function getSesso($decode=false){return ($decode)?$this->getSessoValuesList()[$this->sesso]:$this->sesso;}
/**
 * @param bool $json if true return value json's array else return array values * @return array|string
 */
public function getSessoValuesList($json=false){$kv=[];return ($json)?$this->createJsonKeyValArray($kv):$kv;}
/**
 * @param string (enum) $sesso Sesso
 */
public function setSesso($sesso){$this->sesso=$sesso;}
/**
 * @return objext (string)
 */
public function getTelefoni(){return $this->telefoni;}
/**
 * @param objext (string) $telefoni Telefoni
 */
public function setTelefoni($telefoni){$this->telefoni=$telefoni;}
/**
 * @return objext (string)
 */
public function getCellulari(){return $this->cellulari;}
/**
 * @param objext (string) $cellulari Cellulari
 */
public function setCellulari($cellulari){$this->cellulari=$cellulari;}
/**
 * @return objext (string)
 */
public function getEmail(){return $this->email;}
/**
 * @param objext (string) $email Email
 */
public function setEmail($email){$this->email=$email;}
/**
 * @return objext (string)
 */
public function getIndirizzi(){return $this->indirizzi;}
/**
 * @param objext (string) $indirizzi Indirizzi
 */
public function setIndirizzi($indirizzi){$this->indirizzi=$indirizzi;}
/**
 * @return integer
 */
public function getUltimaModificaUtente(){return $this->ultimaModificaUtente;}
/**
 * @param integer $ultimaModificaUtente UltimaModificaUtente
 */
public function setUltimaModificaUtente($ultimaModificaUtente){$this->ultimaModificaUtente=$ultimaModificaUtente;}
/**
 * @return string
 */
public function getUltimaModificaData(){return $this->ultimaModificaData;}
/**
 * @param string $ultimaModificaData UltimaModificaData
 * @param int $encodeType
 */
public function setUltimaModificaData($ultimaModificaData,$encodeType = self::STR_DEFAULT){$this->ultimaModificaData=$this->decodeString($ultimaModificaData,$encodeType);}
/**
 * @return integer
 */
public function getIdRappresentante(){return $this->idRappresentante;}
/**
 * @param integer $idRappresentante IdRappresentante
 */
public function setIdRappresentante($idRappresentante){$this->idRappresentante=$idRappresentante;}
/**
 * @return integer
 */
public function getIdTipoRappresentante(){return $this->idTipoRappresentante;}
/**
 * @param integer $idTipoRappresentante IdTipoRappresentante
 */
public function setIdTipoRappresentante($idTipoRappresentante){$this->idTipoRappresentante=$idTipoRappresentante;}
/**
 * @return integer
 */
public function getCestino(){return $this->cestino;}
/**
 * @param integer $cestino Cestino
 */
public function setCestino($cestino){$this->cestino=$cestino;}
/**
 * @return string
 */
public function getFileLogo(){return $this->fileLogo;}
/**
 * @param string $fileLogo FileLogo
 * @param int $encodeType
 */
public function setFileLogo($fileLogo,$encodeType = self::STR_DEFAULT){$this->fileLogo=$this->decodeString($fileLogo,$encodeType);}
/**
 * @return string
 */
public function getFileFirma(){return $this->fileFirma;}
/**
 * @param string $fileFirma FileFirma
 * @param int $encodeType
 */
public function setFileFirma($fileFirma,$encodeType = self::STR_DEFAULT){$this->fileFirma=$this->decodeString($fileFirma,$encodeType);}
/**
 * @return integer
 */
public function getIdUtente(){return $this->idUtente;}
/**
 * @param integer $idUtente IdUtente
 */
public function setIdUtente($idUtente){$this->idUtente=$idUtente;}
/**
 * @return integer
 */
public function getSocietaFatturazione(){return $this->societaFatturazione;}
/**
 * @param integer $societaFatturazione SocietaFatturazione
 */
public function setSocietaFatturazione($societaFatturazione){$this->societaFatturazione=$societaFatturazione;}
/**
 * @return integer
 */
public function getAmministratoreCondominio(){return $this->amministratoreCondominio;}
/**
 * @param integer $amministratoreCondominio AmministratoreCondominio
 */
public function setAmministratoreCondominio($amministratoreCondominio){$this->amministratoreCondominio=$amministratoreCondominio;}
/**
 * @return integer
 */
public function getFornitore(){return $this->fornitore;}
/**
 * @param integer $fornitore Fornitore
 */
public function setFornitore($fornitore){$this->fornitore=$fornitore;}
}