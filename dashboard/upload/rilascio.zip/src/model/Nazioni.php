<?php
/**
* Created by Drakkar vers. 0.0.24(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-01-12
* Time: 17:43:07.883905
*/
namespace Click\Affitti\TblBase;
require_once 'NazioniModel.php';
use Click\Affitti\TblBase\NazioniModel;

class  Nazioni extends NazioniModel {
function __construct($pdo){parent::__construct($pdo);}

}