<?php
/**
* Created by Drakkar vers. 0.1.2(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-06-22
* Time: 11:24:17.346917
*/
namespace Click\Affitti\TblBase;
require_once 'ScadenzarioModel.php';
use Click\Affitti\TblBase\ScadenzarioModel;

class  Scadenzario extends ScadenzarioModel {
function __construct($pdo){parent::__construct($pdo);}

}