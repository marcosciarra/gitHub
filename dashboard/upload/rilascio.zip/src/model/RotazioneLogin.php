<?php
/**
 * Created by Drakkar vers. 0.1.2(Hjortspring)
 * User: P.D.A. Srl
 * Date: 2018-05-02
 * Time: 17:31:40.119286
 */

namespace Click\Affitti\TblBase;
require_once 'RotazioneLoginModel.php';

use Click\Affitti\TblBase\RotazioneLoginModel;

class  RotazioneLogin extends RotazioneLoginModel
{
    function __construct($pdo)
    {
        parent::__construct($pdo);
    }

    public function controllaRotazionePasswordByIdUtente($idUtente,$password){
        $query = "SELECT id FROM $this->tableName WHERE id_login=? AND password=?";
        return $this->createResultValue($query, array($idUtente,$password));
    }

    public static function controllaRotazionePasswordByIdUtenteStatic($pdo,$idUtente,$password){
        $rotazione = new self($pdo);
        return $rotazione->controllaRotazionePasswordByIdUtente($idUtente,$password);
    }

}