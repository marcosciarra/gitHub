<?php
/**
* Created by Drakkar vers. 0.0.23(Hjortspring)
* User: P.D.A. Srl
* Date: 2017-12-06
* Time: 15:21:59.580437
*/
namespace Click\Affitti\TblBase;
require_once 'InteressiLegaliModel.php';
use Click\Affitti\TblBase\InteressiLegaliModel;

class  InteressiLegali extends InteressiLegaliModel {
function __construct($pdo){parent::__construct($pdo);}

}