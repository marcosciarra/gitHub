<?php
/**
 * Created by Drakkar vers. 0.0.24(Hjortspring)
 * User: P.D.A. Srl
 * Date: 2018-01-11
 * Time: 16:23:56.398786
 */

namespace Click\Affitti\TblBase;
require_once 'GruppiFatturazioneModel.php';

use Click\Affitti\TblBase\GruppiFatturazioneModel;

class  GruppiFatturazione extends GruppiFatturazioneModel
{
    function __construct($pdo)
    {
        parent::__construct($pdo);
    }

    /**
     * Find all record of table
     * @return GruppiFatturazione[]|array|string
     */
    public function findElencoUltimiGruppi($distinct = false, $typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $query = "
        SELECT 
            gruppi_fatturazione.*,
            IF(gruppi_fatturazione.sigla IS NULL,
                CONCAT_WS(' ',
                        anagrafiche.ragione_sociale,
                        anagrafiche.nome,
                        anagrafiche.cognome),
                CONCAT_WS(' ',
                        anagrafiche.ragione_sociale,
                        anagrafiche.nome,
                        anagrafiche.cognome,
                        ' (',
                        gruppi_fatturazione.sigla,
                        ')')) AS descrizione
        FROM
            gruppi_fatturazione
                INNER JOIN
            anagrafiche ON anagrafiche.id = gruppi_fatturazione.id_anagrafica
        GROUP BY id_anagrafica , sigla
        ";
        $query .= $this->createLimitQuery($limit, $offset);
        return $this->createResultArray($query, array(), $typeResult);
    }


    /**
     * Find all record of table
     * @return GruppiFatturazione[]|array|string
     */
    public function findElencoUltimiGruppiFiltrato($flagFattura = 0, $typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $query = "
        SELECT 
            gruppi_fatturazione.*,
            IF(gruppi_fatturazione.sigla IS NULL,
                CONCAT_WS(' ',
                        anagrafiche.ragione_sociale,
                        anagrafiche.nome,
                        anagrafiche.cognome),
                CONCAT_WS(' ',
                        anagrafiche.ragione_sociale,
                        anagrafiche.nome,
                        anagrafiche.cognome,
                        ' (',
                        gruppi_fatturazione.sigla,
                        ')')) AS descrizione
        FROM
            gruppi_fatturazione
                INNER JOIN
            anagrafiche ON anagrafiche.id = gruppi_fatturazione.id_anagrafica
            where gruppi_fatturazione.flag_fattura=?
        GROUP BY id_anagrafica , sigla
        ";
        $query .= $this->createLimitQuery($limit, $offset);
        return $this->createResultArray($query, array($flagFattura), $typeResult);
    }


    public function getNewGruppo($idGruppoFatturazione)
    {
        return $this->newNumberGruppo($idGruppoFatturazione);
    }


    public function newNumberGruppo($idGruppoFatturazione)
    {
        $this->findByPk($idGruppoFatturazione);
        $idGruppoFatturazione = $this->getIdLastNumberGruppo($idGruppoFatturazione,$this->getSigla());
        $this->findByPk($idGruppoFatturazione);
        if($this->getFlagNumeroZero()==0) {
            $this->setUltimoNumero($this->getUltimoNumero() + 1);
        }
        $this->saveOrUpdate();
        return $this->getUltimoNumero();
    }


    public function getIdLastNumberGruppo($idGruppoFatturazione,$sigla)
    {
        $this->findByPk($idGruppoFatturazione);

        $query = "
        SELECT 
            *
        FROM
            gruppi_fatturazione
        WHERE
           id_anagrafica=? AND sigla=?
        GROUP BY id_anagrafica , sigla
        ";
        return $this->createResultValue($query, array($this->getIdAnagrafica(),$sigla));
    }


}