<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-15
* Time: 11:42:47.341036
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class CategorieSpesaModel extends PdaAbstractModel {
/** @var string */
protected $id;
/** @var integer */
protected $ordinamento;
/** @var string */
protected $descrizione;
/** @var string */
protected $codiceSottoconto;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='categorie_spesa';$this->tableName='categorie_spesa';}

/**
 * find by tables' Primary Key: 
 * @return CategorieSpesa|array|string|null
 */
public function findByPk($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($id), $typeResult);}
/**
 * delete by tables' Primary Key: 
 */
public function deleteByPk($id){$query = "DELETE FROM $this->tableName  WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($id));}
/**
 * Find all record of table
 * @return CategorieSpesa[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * find by id
 * @return CategorieSpesa[]
 */
public function findById($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($id), $typeResult);}


/**
 * find like id
 * @return CategorieSpesa[]
 */
public function findLikeId($id,$likeMatching=self::LIKE_MATCHING_BOTH, $typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id like ?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($this->prepareLikeMatching($id,$likeMatching)), $typeResult);}

/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->id))$arrayValue['id']=$this->id;if(isset($this->ordinamento))$arrayValue['ordinamento']=$this->ordinamento;if(isset($this->descrizione))$arrayValue['descrizione']=($this->descrizione==self::NULL_VALUE)?null:$this->descrizione;if(isset($this->codiceSottoconto))$arrayValue['codice_sottoconto']=($this->codiceSottoconto==self::NULL_VALUE)?null:$this->codiceSottoconto;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['id'])) || (isset($keyArray['categorie_spesa_id']))) {$this->setId(isset($keyArray['id'])?$keyArray['id']:$keyArray['categorie_spesa_id']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['ordinamento'])) || (isset($keyArray['categorie_spesa_ordinamento']))) {$this->setOrdinamento(isset($keyArray['ordinamento'])?$keyArray['ordinamento']:$keyArray['categorie_spesa_ordinamento']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['descrizione'])) || (isset($keyArray['categorie_spesa_descrizione']))) {$this->setDescrizione(isset($keyArray['descrizione'])?$keyArray['descrizione']:$keyArray['categorie_spesa_descrizione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['codice_sottoconto'])) || (isset($keyArray['categorie_spesa_codice_sottoconto']))) {$this->setCodicesottoconto(isset($keyArray['codice_sottoconto'])?$keyArray['codice_sottoconto']:$keyArray['categorie_spesa_codice_sottoconto']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['id'] =$positionalArray[0];$values['ordinamento'] =$positionalArray[1];$values['descrizione'] =($positionalArray[2]==self::NULL_VALUE)?null:$positionalArray[2];$values['codice_sottoconto'] =($positionalArray[3]==self::NULL_VALUE)?null:$positionalArray[3];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['id'] = null;$values['ordinamento'] = null;$values['descrizione'] = null;$values['codice_sottoconto'] = null;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'categorie_spesa.id as categorie_spesa_id,categorie_spesa.ordinamento as categorie_spesa_ordinamento,categorie_spesa.descrizione as categorie_spesa_descrizione,categorie_spesa.codice_sottoconto as categorie_spesa_codice_sottoconto';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `categorie_spesa` (
  `id` varchar(1) NOT NULL,
  `ordinamento` int(1) unsigned NOT NULL,
  `descrizione` varchar(45) DEFAULT NULL,
  `codice_sottoconto` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ");}
/**
 * @return string
 */
public function getId(){return $this->id;}
/**
 * @param string $id Id
 * @param int $encodeType
 */
public function setId($id,$encodeType = self::STR_DEFAULT){$this->id=$this->decodeString($id,$encodeType);}
/**
 * @return integer
 */
public function getOrdinamento(){return $this->ordinamento;}
/**
 * @param integer $ordinamento Ordinamento
 */
public function setOrdinamento($ordinamento){$this->ordinamento=$ordinamento;}
/**
 * @return string
 */
public function getDescrizione(){return $this->descrizione;}
/**
 * @param string $descrizione Descrizione
 * @param int $encodeType
 */
public function setDescrizione($descrizione,$encodeType = self::STR_DEFAULT){$this->descrizione=$this->decodeString($descrizione,$encodeType);}
/**
 * @return string
 */
public function getCodiceSottoconto(){return $this->codiceSottoconto;}
/**
 * @param string $codiceSottoconto CodiceSottoconto
 * @param int $encodeType
 */
public function setCodiceSottoconto($codiceSottoconto,$encodeType = self::STR_DEFAULT){$this->codiceSottoconto=$this->decodeString($codiceSottoconto,$encodeType);}
}