<?php
/**
* Created by Drakkar vers. 0.0.22(Hjortspring)
* User: P.D.A. Srl
* Date: 2017-11-27
* Time: 18:25:51.983591
*/
namespace Click\Affitti\TblBase;
require_once 'TipiUsoModel.php';
use Click\Affitti\TblBase\TipiUsoModel;

class  TipiUso extends TipiUsoModel {
function __construct($pdo){parent::__construct($pdo);}

}