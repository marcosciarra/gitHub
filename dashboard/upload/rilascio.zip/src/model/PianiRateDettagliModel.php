<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-15
* Time: 11:42:47.691678
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class PianiRateDettagliModel extends PdaAbstractModel {
/** @var integer */
protected $id;
/** @var integer */
protected $idPianoRateTestata;
/** @var double */
protected $percentuale;
/** @var string */
protected $dataScadenza;
/** @var double */
protected $imponibile=0;
/** @var double */
protected $importo=0;
/** @var integer */
protected $idTipoIva;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='piani_rate_dettagli';$this->tableName='piani_rate_dettagli';}

/**
 * find by tables' Primary Key: 
 * @return PianiRateDettagli|array|string|null
 */
public function findByPk($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($id), $typeResult);}
/**
 * delete by tables' Primary Key: 
 */
public function deleteByPk($id){$query = "DELETE FROM $this->tableName  WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($id));}
/**
 * Find all record of table
 * @return PianiRateDettagli[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * find by tables' Key idx_id_piano_rate_testa: 
 * @return PianiRateDettagli[]|array|string
 */
public function findByIdxIdPianoRateTesta($idPianoRateTestata,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_id_piano_rate_testa) WHERE id_piano_rate_testata=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($idPianoRateTestata), $typeResult);}

/**
 * find by tables' Key idx_id_tipo_iva: 
 * @return PianiRateDettagli[]|array|string
 */
public function findByIdxIdTipoIva($idTipoIva,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_id_tipo_iva) WHERE id_tipo_iva=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($idTipoIva), $typeResult);}

/**
 * delete by tables' Key idx_id_piano_rate_testa: 
 * @return boolean
 */
public function deleteByIdxIdPianoRateTesta($idPianoRateTestata,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_piano_rate_testata=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idPianoRateTestata));}
/**
 * delete by tables' Key idx_id_tipo_iva: 
 * @return boolean
 */
public function deleteByIdxIdTipoIva($idTipoIva,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_tipo_iva=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idTipoIva));}
/**
 * find by id
 * @return PianiRateDettagli[]
 */
public function findById($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($id), $typeResult);}


/**
 * find by id_piano_rate_testata
 * @return PianiRateDettagli[]
 */
public function findByIdPianoRateTestata($idPianoRateTestata,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id_piano_rate_testata=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($idPianoRateTestata), $typeResult);}


/**
 * find by id_tipo_iva
 * @return PianiRateDettagli[]
 */
public function findByIdTipoIva($idTipoIva,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id_tipo_iva=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($idTipoIva), $typeResult);}


/**
 * delete by id_piano_rate_testata
 * @return boolean
 */
public function deleteByIdPianoRateTestata($idPianoRateTestata){$query = "DELETE FROM $this->tableName WHERE id_piano_rate_testata=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idPianoRateTestata));}

/**
 * delete by id_tipo_iva
 * @return boolean
 */
public function deleteByIdTipoIva($idTipoIva){$query = "DELETE FROM $this->tableName WHERE id_tipo_iva=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idTipoIva));}

/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->id))$arrayValue['id']=$this->id;if(isset($this->idPianoRateTestata))$arrayValue['id_piano_rate_testata']=$this->idPianoRateTestata;if(isset($this->percentuale))$arrayValue['percentuale']=$this->percentuale;if(isset($this->dataScadenza))$arrayValue['data_scadenza']=$this->dataScadenza;if(isset($this->imponibile))$arrayValue['imponibile']=($this->imponibile==self::NULL_VALUE)?null:$this->imponibile;if(isset($this->importo))$arrayValue['importo']=($this->importo==self::NULL_VALUE)?null:$this->importo;if(isset($this->idTipoIva))$arrayValue['id_tipo_iva']=$this->idTipoIva;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['id'])) || (isset($keyArray['piani_rate_dettagli_id']))) {$this->setId(isset($keyArray['id'])?$keyArray['id']:$keyArray['piani_rate_dettagli_id']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_piano_rate_testata'])) || (isset($keyArray['piani_rate_dettagli_id_piano_rate_testata']))) {$this->setIdpianoratetestata(isset($keyArray['id_piano_rate_testata'])?$keyArray['id_piano_rate_testata']:$keyArray['piani_rate_dettagli_id_piano_rate_testata']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['percentuale'])) || (isset($keyArray['piani_rate_dettagli_percentuale']))) {$this->setPercentuale(isset($keyArray['percentuale'])?$keyArray['percentuale']:$keyArray['piani_rate_dettagli_percentuale']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['data_scadenza'])) || (isset($keyArray['piani_rate_dettagli_data_scadenza']))) {$this->setDatascadenza(isset($keyArray['data_scadenza'])?$keyArray['data_scadenza']:$keyArray['piani_rate_dettagli_data_scadenza']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['imponibile'])) || (isset($keyArray['piani_rate_dettagli_imponibile']))) {$this->setImponibile(isset($keyArray['imponibile'])?$keyArray['imponibile']:$keyArray['piani_rate_dettagli_imponibile']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['importo'])) || (isset($keyArray['piani_rate_dettagli_importo']))) {$this->setImporto(isset($keyArray['importo'])?$keyArray['importo']:$keyArray['piani_rate_dettagli_importo']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_tipo_iva'])) || (isset($keyArray['piani_rate_dettagli_id_tipo_iva']))) {$this->setIdtipoiva(isset($keyArray['id_tipo_iva'])?$keyArray['id_tipo_iva']:$keyArray['piani_rate_dettagli_id_tipo_iva']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['id'] =$positionalArray[0];$values['id_piano_rate_testata'] =$positionalArray[1];$values['percentuale'] =$positionalArray[2];$values['data_scadenza'] =$positionalArray[3];$values['imponibile'] =($positionalArray[4]==self::NULL_VALUE)?null:$positionalArray[4];$values['importo'] =($positionalArray[5]==self::NULL_VALUE)?null:$positionalArray[5];$values['id_tipo_iva'] =$positionalArray[6];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['id'] = null;$values['id_piano_rate_testata'] = null;$values['percentuale'] = null;$values['data_scadenza'] = null;$values['imponibile'] = 0;$values['importo'] = 0;$values['id_tipo_iva'] = null;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'piani_rate_dettagli.id as piani_rate_dettagli_id,piani_rate_dettagli.id_piano_rate_testata as piani_rate_dettagli_id_piano_rate_testata,piani_rate_dettagli.percentuale as piani_rate_dettagli_percentuale,piani_rate_dettagli.data_scadenza as piani_rate_dettagli_data_scadenza,piani_rate_dettagli.imponibile as piani_rate_dettagli_imponibile,piani_rate_dettagli.importo as piani_rate_dettagli_importo,piani_rate_dettagli.id_tipo_iva as piani_rate_dettagli_id_tipo_iva';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `piani_rate_dettagli` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_piano_rate_testata` int(10) unsigned NOT NULL,
  `percentuale` decimal(6,4) NOT NULL,
  `data_scadenza` date NOT NULL,
  `imponibile` double DEFAULT '0',
  `importo` double DEFAULT '0',
  `id_tipo_iva` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_id_piano_rate_testa` (`id_piano_rate_testata`),
  KEY `idx_id_tipo_iva` (`id_tipo_iva`)
) ENGINE=InnoDB AUTO_INCREMENT=3572 DEFAULT CHARSET=latin1 ");}
/**
 * @return integer
 */
public function getId(){return $this->id;}
/**
 * @param integer $id Id
 */
public function setId($id){$this->id=$id;}
/**
 * @return integer
 */
public function getIdPianoRateTestata(){return $this->idPianoRateTestata;}
/**
 * @param integer $idPianoRateTestata IdPianoRateTestata
 */
public function setIdPianoRateTestata($idPianoRateTestata){$this->idPianoRateTestata=$idPianoRateTestata;}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getPercentuale($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->percentuale:number_format($this->percentuale,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $percentuale Percentuale
 */
public function setPercentuale($percentuale){$this->percentuale=$percentuale;}
/**
 * @return string
 */
public function getDataScadenza(){return $this->dataScadenza;}
/**
 * @param string $dataScadenza DataScadenza
 * @param int $encodeType
 */
public function setDataScadenza($dataScadenza,$encodeType = self::STR_DEFAULT){$this->dataScadenza=$this->decodeString($dataScadenza,$encodeType);}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getImponibile($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->imponibile:number_format($this->imponibile,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $imponibile Imponibile
 */
public function setImponibile($imponibile){$this->imponibile=$imponibile;}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getImporto($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->importo:number_format($this->importo,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $importo Importo
 */
public function setImporto($importo){$this->importo=$importo;}
/**
 * @return integer
 */
public function getIdTipoIva(){return $this->idTipoIva;}
/**
 * @param integer $idTipoIva IdTipoIva
 */
public function setIdTipoIva($idTipoIva){$this->idTipoIva=$idTipoIva;}
}