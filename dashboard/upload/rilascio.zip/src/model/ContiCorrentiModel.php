<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-21
* Time: 12:23:39.011491
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class ContiCorrentiModel extends PdaAbstractModel {
/** @var integer */
protected $id;
/** @var integer */
protected $idAnagrafica;
/** @var string */
protected $abi;
/** @var string */
protected $intestatario;
/** @var string */
protected $agenzia;
/** @var string */
protected $cab;
/** @var string */
protected $conto;
/** @var string */
protected $cin;
/** @var string */
protected $nazione;
/** @var string */
protected $ckdigit;
/** @var string */
protected $sia;
/** @var string */
protected $cuc;
/** @var string */
protected $bic;
/** @var double */
protected $speseIncasso;
/** @var string */
protected $codiceFiscale;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='conti_correnti';$this->tableName='conti_correnti';}

/**
 * find by tables' Primary Key: 
 * @return ContiCorrenti|array|string|null
 */
public function findByPk($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($id), $typeResult);}
/**
 * delete by tables' Primary Key: 
 */
public function deleteByPk($id){$query = "DELETE FROM $this->tableName  WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($id));}
/**
 * Find all record of table
 * @return ContiCorrenti[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * find by tables' Key idx_id_anagrafica: 
 * @return ContiCorrenti[]|array|string
 */
public function findByIdxIdAnagrafica($idAnagrafica,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_id_anagrafica) WHERE id_anagrafica=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($idAnagrafica), $typeResult);}

/**
 * find by tables' Key idx_id_banca: 
 * @return ContiCorrenti[]|array|string
 */
public function findByIdxIdBanca($abi,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_id_banca) WHERE abi=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($abi), $typeResult);}

/**
 * delete by tables' Key idx_id_anagrafica: 
 * @return boolean
 */
public function deleteByIdxIdAnagrafica($idAnagrafica,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_anagrafica=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idAnagrafica));}
/**
 * delete by tables' Key idx_id_banca: 
 * @return boolean
 */
public function deleteByIdxIdBanca($abi,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE abi=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($abi));}
/**
 * find by id
 * @return ContiCorrenti[]
 */
public function findById($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($id), $typeResult);}


/**
 * find by id_anagrafica
 * @return ContiCorrenti[]
 */
public function findByIdAnagrafica($idAnagrafica,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id_anagrafica=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($idAnagrafica), $typeResult);}


/**
 * find by abi
 * @return ContiCorrenti[]
 */
public function findByAbi($abi,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE abi=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($abi), $typeResult);}


/**
 * find like abi
 * @return ContiCorrenti[]
 */
public function findLikeAbi($abi,$likeMatching=self::LIKE_MATCHING_BOTH, $typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE abi like ?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($this->prepareLikeMatching($abi,$likeMatching)), $typeResult);}

/**
 * delete by id_anagrafica
 * @return boolean
 */
public function deleteByIdAnagrafica($idAnagrafica){$query = "DELETE FROM $this->tableName WHERE id_anagrafica=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idAnagrafica));}

/**
 * delete by abi
 * @return boolean
 */
public function deleteByAbi($abi){$query = "DELETE FROM $this->tableName WHERE abi=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($abi));}

/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->id))$arrayValue['id']=$this->id;if(isset($this->idAnagrafica))$arrayValue['id_anagrafica']=$this->idAnagrafica;if(isset($this->abi))$arrayValue['abi']=($this->abi==self::NULL_VALUE)?null:$this->abi;if(isset($this->intestatario))$arrayValue['intestatario']=($this->intestatario==self::NULL_VALUE)?null:$this->intestatario;if(isset($this->agenzia))$arrayValue['agenzia']=($this->agenzia==self::NULL_VALUE)?null:$this->agenzia;if(isset($this->cab))$arrayValue['cab']=($this->cab==self::NULL_VALUE)?null:$this->cab;if(isset($this->conto))$arrayValue['conto']=($this->conto==self::NULL_VALUE)?null:$this->conto;if(isset($this->cin))$arrayValue['cin']=($this->cin==self::NULL_VALUE)?null:$this->cin;if(isset($this->nazione))$arrayValue['nazione']=($this->nazione==self::NULL_VALUE)?null:$this->nazione;if(isset($this->ckdigit))$arrayValue['ckdigit']=($this->ckdigit==self::NULL_VALUE)?null:$this->ckdigit;if(isset($this->sia))$arrayValue['sia']=($this->sia==self::NULL_VALUE)?null:$this->sia;if(isset($this->cuc))$arrayValue['cuc']=($this->cuc==self::NULL_VALUE)?null:$this->cuc;if(isset($this->bic))$arrayValue['bic']=($this->bic==self::NULL_VALUE)?null:$this->bic;if(isset($this->speseIncasso))$arrayValue['spese_incasso']=($this->speseIncasso==self::NULL_VALUE)?null:$this->speseIncasso;if(isset($this->codiceFiscale))$arrayValue['codice_fiscale']=($this->codiceFiscale==self::NULL_VALUE)?null:$this->codiceFiscale;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['id'])) || (isset($keyArray['conti_correnti_id']))) {$this->setId(isset($keyArray['id'])?$keyArray['id']:$keyArray['conti_correnti_id']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_anagrafica'])) || (isset($keyArray['conti_correnti_id_anagrafica']))) {$this->setIdanagrafica(isset($keyArray['id_anagrafica'])?$keyArray['id_anagrafica']:$keyArray['conti_correnti_id_anagrafica']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['abi'])) || (isset($keyArray['conti_correnti_abi']))) {$this->setAbi(isset($keyArray['abi'])?$keyArray['abi']:$keyArray['conti_correnti_abi']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['intestatario'])) || (isset($keyArray['conti_correnti_intestatario']))) {$this->setIntestatario(isset($keyArray['intestatario'])?$keyArray['intestatario']:$keyArray['conti_correnti_intestatario']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['agenzia'])) || (isset($keyArray['conti_correnti_agenzia']))) {$this->setAgenzia(isset($keyArray['agenzia'])?$keyArray['agenzia']:$keyArray['conti_correnti_agenzia']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['cab'])) || (isset($keyArray['conti_correnti_cab']))) {$this->setCab(isset($keyArray['cab'])?$keyArray['cab']:$keyArray['conti_correnti_cab']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['conto'])) || (isset($keyArray['conti_correnti_conto']))) {$this->setConto(isset($keyArray['conto'])?$keyArray['conto']:$keyArray['conti_correnti_conto']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['cin'])) || (isset($keyArray['conti_correnti_cin']))) {$this->setCin(isset($keyArray['cin'])?$keyArray['cin']:$keyArray['conti_correnti_cin']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['nazione'])) || (isset($keyArray['conti_correnti_nazione']))) {$this->setNazione(isset($keyArray['nazione'])?$keyArray['nazione']:$keyArray['conti_correnti_nazione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['ckdigit'])) || (isset($keyArray['conti_correnti_ckdigit']))) {$this->setCkdigit(isset($keyArray['ckdigit'])?$keyArray['ckdigit']:$keyArray['conti_correnti_ckdigit']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['sia'])) || (isset($keyArray['conti_correnti_sia']))) {$this->setSia(isset($keyArray['sia'])?$keyArray['sia']:$keyArray['conti_correnti_sia']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['cuc'])) || (isset($keyArray['conti_correnti_cuc']))) {$this->setCuc(isset($keyArray['cuc'])?$keyArray['cuc']:$keyArray['conti_correnti_cuc']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['bic'])) || (isset($keyArray['conti_correnti_bic']))) {$this->setBic(isset($keyArray['bic'])?$keyArray['bic']:$keyArray['conti_correnti_bic']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['spese_incasso'])) || (isset($keyArray['conti_correnti_spese_incasso']))) {$this->setSpeseincasso(isset($keyArray['spese_incasso'])?$keyArray['spese_incasso']:$keyArray['conti_correnti_spese_incasso']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['codice_fiscale'])) || (isset($keyArray['conti_correnti_codice_fiscale']))) {$this->setCodicefiscale(isset($keyArray['codice_fiscale'])?$keyArray['codice_fiscale']:$keyArray['conti_correnti_codice_fiscale']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['id'] =$positionalArray[0];$values['id_anagrafica'] =$positionalArray[1];$values['abi'] =($positionalArray[2]==self::NULL_VALUE)?null:$positionalArray[2];$values['intestatario'] =($positionalArray[3]==self::NULL_VALUE)?null:$positionalArray[3];$values['agenzia'] =($positionalArray[4]==self::NULL_VALUE)?null:$positionalArray[4];$values['cab'] =($positionalArray[5]==self::NULL_VALUE)?null:$positionalArray[5];$values['conto'] =($positionalArray[6]==self::NULL_VALUE)?null:$positionalArray[6];$values['cin'] =($positionalArray[7]==self::NULL_VALUE)?null:$positionalArray[7];$values['nazione'] =($positionalArray[8]==self::NULL_VALUE)?null:$positionalArray[8];$values['ckdigit'] =($positionalArray[9]==self::NULL_VALUE)?null:$positionalArray[9];$values['sia'] =($positionalArray[10]==self::NULL_VALUE)?null:$positionalArray[10];$values['cuc'] =($positionalArray[11]==self::NULL_VALUE)?null:$positionalArray[11];$values['bic'] =($positionalArray[12]==self::NULL_VALUE)?null:$positionalArray[12];$values['spese_incasso'] =($positionalArray[13]==self::NULL_VALUE)?null:$positionalArray[13];$values['codice_fiscale'] =($positionalArray[14]==self::NULL_VALUE)?null:$positionalArray[14];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['id'] = null;$values['id_anagrafica'] = null;$values['abi'] = null;$values['intestatario'] = null;$values['agenzia'] = null;$values['cab'] = null;$values['conto'] = null;$values['cin'] = null;$values['nazione'] = null;$values['ckdigit'] = null;$values['sia'] = null;$values['cuc'] = null;$values['bic'] = null;$values['spese_incasso'] = null;$values['codice_fiscale'] = null;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'conti_correnti.id as conti_correnti_id,conti_correnti.id_anagrafica as conti_correnti_id_anagrafica,conti_correnti.abi as conti_correnti_abi,conti_correnti.intestatario as conti_correnti_intestatario,conti_correnti.agenzia as conti_correnti_agenzia,conti_correnti.cab as conti_correnti_cab,conti_correnti.conto as conti_correnti_conto,conti_correnti.cin as conti_correnti_cin,conti_correnti.nazione as conti_correnti_nazione,conti_correnti.ckdigit as conti_correnti_ckdigit,conti_correnti.sia as conti_correnti_sia,conti_correnti.cuc as conti_correnti_cuc,conti_correnti.bic as conti_correnti_bic,conti_correnti.spese_incasso as conti_correnti_spese_incasso,conti_correnti.codice_fiscale as conti_correnti_codice_fiscale';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `conti_correnti` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_anagrafica` int(11) unsigned NOT NULL,
  `abi` varchar(5) DEFAULT NULL,
  `intestatario` varchar(45) DEFAULT NULL,
  `agenzia` varchar(45) DEFAULT NULL,
  `cab` varchar(5) DEFAULT NULL,
  `conto` varchar(12) DEFAULT NULL,
  `cin` varchar(1) DEFAULT NULL,
  `nazione` varchar(2) DEFAULT NULL,
  `ckdigit` varchar(2) DEFAULT NULL,
  `sia` varchar(5) DEFAULT NULL,
  `cuc` varchar(8) DEFAULT NULL,
  `bic` varchar(11) DEFAULT NULL,
  `spese_incasso` double DEFAULT NULL,
  `codice_fiscale` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_id_anagrafica` (`id_anagrafica`),
  KEY `idx_id_banca` (`abi`),
  CONSTRAINT `fk_conti_correnti_anagrafiche1` FOREIGN KEY (`id_anagrafica`) REFERENCES `anagrafiche` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 ");}
/**
 * @return integer
 */
public function getId(){return $this->id;}
/**
 * @param integer $id Id
 */
public function setId($id){$this->id=$id;}
/**
 * @return integer
 */
public function getIdAnagrafica(){return $this->idAnagrafica;}
/**
 * @param integer $idAnagrafica IdAnagrafica
 */
public function setIdAnagrafica($idAnagrafica){$this->idAnagrafica=$idAnagrafica;}
/**
 * @return string
 */
public function getAbi(){return $this->abi;}
/**
 * @param string $abi Abi
 * @param int $encodeType
 */
public function setAbi($abi,$encodeType = self::STR_DEFAULT){$this->abi=$this->decodeString($abi,$encodeType);}
/**
 * @return string
 */
public function getIntestatario(){return $this->intestatario;}
/**
 * @param string $intestatario Intestatario
 * @param int $encodeType
 */
public function setIntestatario($intestatario,$encodeType = self::STR_DEFAULT){$this->intestatario=$this->decodeString($intestatario,$encodeType);}
/**
 * @return string
 */
public function getAgenzia(){return $this->agenzia;}
/**
 * @param string $agenzia Agenzia
 * @param int $encodeType
 */
public function setAgenzia($agenzia,$encodeType = self::STR_DEFAULT){$this->agenzia=$this->decodeString($agenzia,$encodeType);}
/**
 * @return string
 */
public function getCab(){return $this->cab;}
/**
 * @param string $cab Cab
 * @param int $encodeType
 */
public function setCab($cab,$encodeType = self::STR_DEFAULT){$this->cab=$this->decodeString($cab,$encodeType);}
/**
 * @return string
 */
public function getConto(){return $this->conto;}
/**
 * @param string $conto Conto
 * @param int $encodeType
 */
public function setConto($conto,$encodeType = self::STR_DEFAULT){$this->conto=$this->decodeString($conto,$encodeType);}
/**
 * @return string
 */
public function getCin(){return $this->cin;}
/**
 * @param string $cin Cin
 * @param int $encodeType
 */
public function setCin($cin,$encodeType = self::STR_DEFAULT){$this->cin=$this->decodeString($cin,$encodeType);}
/**
 * @return string
 */
public function getNazione(){return $this->nazione;}
/**
 * @param string $nazione Nazione
 * @param int $encodeType
 */
public function setNazione($nazione,$encodeType = self::STR_DEFAULT){$this->nazione=$this->decodeString($nazione,$encodeType);}
/**
 * @return string
 */
public function getCkdigit(){return $this->ckdigit;}
/**
 * @param string $ckdigit Ckdigit
 * @param int $encodeType
 */
public function setCkdigit($ckdigit,$encodeType = self::STR_DEFAULT){$this->ckdigit=$this->decodeString($ckdigit,$encodeType);}
/**
 * @return string
 */
public function getSia(){return $this->sia;}
/**
 * @param string $sia Sia
 * @param int $encodeType
 */
public function setSia($sia,$encodeType = self::STR_DEFAULT){$this->sia=$this->decodeString($sia,$encodeType);}
/**
 * @return string
 */
public function getCuc(){return $this->cuc;}
/**
 * @param string $cuc Cuc
 * @param int $encodeType
 */
public function setCuc($cuc,$encodeType = self::STR_DEFAULT){$this->cuc=$this->decodeString($cuc,$encodeType);}
/**
 * @return string
 */
public function getBic(){return $this->bic;}
/**
 * @param string $bic Bic
 * @param int $encodeType
 */
public function setBic($bic,$encodeType = self::STR_DEFAULT){$this->bic=$this->decodeString($bic,$encodeType);}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getSpeseIncasso($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->speseIncasso:number_format($this->speseIncasso,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $speseIncasso SpeseIncasso
 */
public function setSpeseIncasso($speseIncasso){$this->speseIncasso=$speseIncasso;}
/**
 * @return string
 */
public function getCodiceFiscale(){return $this->codiceFiscale;}
/**
 * @param string $codiceFiscale CodiceFiscale
 * @param int $encodeType
 */
public function setCodiceFiscale($codiceFiscale,$encodeType = self::STR_DEFAULT){$this->codiceFiscale=$this->decodeString($codiceFiscale,$encodeType);}
}