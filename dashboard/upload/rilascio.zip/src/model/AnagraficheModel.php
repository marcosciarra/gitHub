<?php
/**
 * Created by Drakkar vers. 0.1.3(Hjortspring)
 * User: P.D.A. Srl
 * Date: 2018-11-15
 * Time: 12:01:30.746523
 */

namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';

use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class AnagraficheModel extends PdaAbstractModel
{
    /** @var integer */
    protected $id;
    /** @var integer */
    protected $idTipiSoggetto;
    /** @var string */
    protected $titolo;
    /** @var string */
    protected $codiceFiscale;
    /** @var string */
    protected $partitaIvaNazione;
    /** @var string */
    protected $partitaIva;
    /** @var string */
    protected $ragioneSociale;
    /** @var string */
    protected $nome;
    /** @var string */
    protected $cognome;
    /** @var string */
    protected $nascitaData;
    /** @var string */
    protected $nascitaLuogo;
    /** @var string */
    protected $nascitaProvincia;
    /** @var string */
    protected $nascitaStato;
    /** @var string (enum) */
    protected $sesso;
    /** @var objext (string) */
    protected $telefoni;
    /** @var objext (string) */
    protected $cellulari;
    /** @var objext (string) */
    protected $email;
    /** @var objext (string) */
    protected $pec;
    /** @var objext (string) */
    protected $indirizzi;
    /** @var integer */
    protected $ultimaModificaUtente;
    /** @var string */
    protected $ultimaModificaData;
    /** @var integer */
    protected $idRappresentante;
    /** @var integer */
    protected $idTipoRappresentante;
    /** @var integer */
    protected $cestino = 0;
    /** @var string */
    protected $fileLogo;
    /** @var string */
    protected $fileFirma;
    /** @var integer */
    protected $idUtente;
    /** @var integer indica se una societ� � un'anagrafica di fatturazione o no (agenzie, immobiliari, amministratori, ecc) */
    protected $societaFatturazione = 0;
    /** @var integer */
    protected $amministratoreCondominio = 0;
    /** @var integer */
    protected $fornitore = 0;
    /** @var objext (string) */
    protected $documento;
    /** @var integer */
    protected $fatturaElettronicaMittenteAttivo = 0;
    /** @var string */
    protected $fatturaElettronicaMittentePec;
    /** @var string */
    protected $fatturaElettronicaMittenteCodice = '0000000';
    /** @var integer */
    protected $fatturaElettronicaDestinatarioAttivo = 0;
    /** @var string */
    protected $fatturaElettronicaDestinatarioPec;
    /** @var string */
    protected $fatturaElettronicaDestinatarioCodice = '0000000';
    /** @var string */
    protected $regimeFiscale = 'RF01';
    /** @var integer */
    protected $efattura = 1;

    function __construct($pdo)
    {
        parent::__construct($pdo);
        $this->nomeTabella = 'anagrafiche';
        $this->tableName = 'anagrafiche';
    }

    /**
     * find by tables' Primary Key:
     * @return Anagrafiche|array|string|null
     */
    public function findByPk($id, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResult($query, array($id), $typeResult);
    }

    /**
     * delete by tables' Primary Key:
     */
    public function deleteByPk($id)
    {
        $query = "DELETE FROM $this->tableName  WHERE id=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultValue($query, array($id));
    }

    /**
     * Find all record of table
     * @return Anagrafiche[]|array|string
     */
    public function findAll($distinct = false, $typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $distinctStr = ($distinct) ? 'DISTINCT' : '';
        $query = "SELECT $distinctStr * FROM $this->tableName ";
        if ($this->whereBase) $query .= " WHERE $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        $query .= $this->createLimitQuery($limit, $offset);
        return $this->createResultArray($query, null, $typeResult);
    }

    /**
     * find by tables' Key idx_codice_fiscale:
     * @return Anagrafiche|array|string
     */
    public function findByIdxCodiceFiscale($codiceFiscale, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName USE INDEX(idx_codice_fiscale) WHERE codice_fiscale=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResult($query, array($codiceFiscale), $typeResult);
    }

    /**
     * find by tables' Key idx_partita_iva:
     * @return Anagrafiche|array|string
     */
    public function findByIdxPartitaIva($partitaIvaNazione, $partitaIva, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName USE INDEX(idx_partita_iva) WHERE partita_iva_nazione=? AND partita_iva=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResult($query, array($partitaIvaNazione, $partitaIva), $typeResult);
    }

    /**
     * find by tables' Key fk_anagrafiche_tipi_soggetto1_idx:
     * @return Anagrafiche[]|array|string
     */
    public function findByFkAnagraficheTipiSoggetto1Idx($idTipiSoggetto, $typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $query = "SELECT * FROM $this->tableName USE INDEX(fk_anagrafiche_tipi_soggetto1_idx) WHERE id_tipi_soggetto=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultArray($query, array($idTipiSoggetto), $typeResult);
    }

    /**
     * find by tables' Key fk_anagrafiche_login1_idx:
     * @return Anagrafiche[]|array|string
     */
    public function findByFkAnagraficheLogin1Idx($ultimaModificaUtente, $typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $query = "SELECT * FROM $this->tableName USE INDEX(fk_anagrafiche_login1_idx) WHERE ultima_modifica_utente=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultArray($query, array($ultimaModificaUtente), $typeResult);
    }

    /**
     * find by tables' Key idx_id_rappresentante:
     * @return Anagrafiche[]|array|string
     */
    public function findByIdxIdRappresentante($idRappresentante, $typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $query = "SELECT * FROM $this->tableName USE INDEX(idx_id_rappresentante) WHERE id_rappresentante=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultArray($query, array($idRappresentante), $typeResult);
    }

    /**
     * find by tables' Key idx_id_tipo_rappresentante:
     * @return Anagrafiche[]|array|string
     */
    public function findByIdxIdTipoRappresentante($idTipoRappresentante, $typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $query = "SELECT * FROM $this->tableName USE INDEX(idx_id_tipo_rappresentante) WHERE id_tipo_rappresentante=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultArray($query, array($idTipoRappresentante), $typeResult);
    }

    /**
     * delete by tables' Key idx_codice_fiscale:
     * @return boolean
     */
    public function deleteByIdxCodiceFiscale($codiceFiscale, $typeResult = self::FETCH_OBJ)
    {
        $query = "DELETE FROM $this->tableName WHERE codice_fiscale=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultValue($query, array($codiceFiscale));
    }

    /**
     * delete by tables' Key idx_partita_iva:
     * @return boolean
     */
    public function deleteByIdxPartitaIva($partitaIvaNazione, $partitaIva, $typeResult = self::FETCH_OBJ)
    {
        $query = "DELETE FROM $this->tableName WHERE partita_iva_nazione=? AND partita_iva=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultValue($query, array($partitaIvaNazione, $partitaIva));
    }

    /**
     * delete by tables' Key fk_anagrafiche_tipi_soggetto1_idx:
     * @return boolean
     */
    public function deleteByFkAnagraficheTipiSoggetto1Idx($idTipiSoggetto, $typeResult = self::FETCH_OBJ)
    {
        $query = "DELETE FROM $this->tableName WHERE id_tipi_soggetto=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultValue($query, array($idTipiSoggetto));
    }

    /**
     * delete by tables' Key fk_anagrafiche_login1_idx:
     * @return boolean
     */
    public function deleteByFkAnagraficheLogin1Idx($ultimaModificaUtente, $typeResult = self::FETCH_OBJ)
    {
        $query = "DELETE FROM $this->tableName WHERE ultima_modifica_utente=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultValue($query, array($ultimaModificaUtente));
    }

    /**
     * delete by tables' Key idx_id_rappresentante:
     * @return boolean
     */
    public function deleteByIdxIdRappresentante($idRappresentante, $typeResult = self::FETCH_OBJ)
    {
        $query = "DELETE FROM $this->tableName WHERE id_rappresentante=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultValue($query, array($idRappresentante));
    }

    /**
     * delete by tables' Key idx_id_tipo_rappresentante:
     * @return boolean
     */
    public function deleteByIdxIdTipoRappresentante($idTipoRappresentante, $typeResult = self::FETCH_OBJ)
    {
        $query = "DELETE FROM $this->tableName WHERE id_tipo_rappresentante=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultValue($query, array($idTipoRappresentante));
    }

    /**
     * find by id
     * @return Anagrafiche[]
     */
    public function findById($id, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName WHERE id=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        return $this->createResultArray($query, array($id), $typeResult);
    }


    /**
     * find by id_tipi_soggetto
     * @return Anagrafiche[]
     */
    public function findByIdTipiSoggetto($idTipiSoggetto, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName WHERE id_tipi_soggetto=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        return $this->createResultArray($query, array($idTipiSoggetto), $typeResult);
    }


    /**
     * find by codice_fiscale
     * @return Anagrafiche
     */
    public function findByCodiceFiscale($codiceFiscale, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName WHERE codice_fiscale=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        return $this->createResult($query, array($codiceFiscale), $typeResult);
    }


    /**
     * find like codice_fiscale
     * @return Anagrafiche[]
     */
    public function findLikeCodiceFiscale($codiceFiscale, $likeMatching = self::LIKE_MATCHING_BOTH, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName WHERE codice_fiscale like ?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultArray($query, array($this->prepareLikeMatching($codiceFiscale, $likeMatching)), $typeResult);
    }

    /**
     * find by partita_iva_nazione
     * @return Anagrafiche[]
     */
    public function findByPartitaIvaNazione($partitaIvaNazione, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName WHERE partita_iva_nazione=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        return $this->createResultArray($query, array($partitaIvaNazione), $typeResult);
    }


    /**
     * find like partita_iva_nazione
     * @return Anagrafiche[]
     */
    public function findLikePartitaIvaNazione($partitaIvaNazione, $likeMatching = self::LIKE_MATCHING_BOTH, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName WHERE partita_iva_nazione like ?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultArray($query, array($this->prepareLikeMatching($partitaIvaNazione, $likeMatching)), $typeResult);
    }

    /**
     * find by ultima_modifica_utente
     * @return Anagrafiche[]
     */
    public function findByUltimaModificaUtente($ultimaModificaUtente, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName WHERE ultima_modifica_utente=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        return $this->createResultArray($query, array($ultimaModificaUtente), $typeResult);
    }


    /**
     * find by id_rappresentante
     * @return Anagrafiche[]
     */
    public function findByIdRappresentante($idRappresentante, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName WHERE id_rappresentante=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        return $this->createResultArray($query, array($idRappresentante), $typeResult);
    }


    /**
     * find by id_tipo_rappresentante
     * @return Anagrafiche[]
     */
    public function findByIdTipoRappresentante($idTipoRappresentante, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName WHERE id_tipo_rappresentante=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        return $this->createResultArray($query, array($idTipoRappresentante), $typeResult);
    }


    /**
     * delete by id_tipi_soggetto
     * @return boolean
     */
    public function deleteByIdTipiSoggetto($idTipiSoggetto)
    {
        $query = "DELETE FROM $this->tableName WHERE id_tipi_soggetto=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultValue($query, array($idTipiSoggetto));
    }

    /**
     * delete by codice_fiscale
     * @return boolean
     */
    public function deleteByCodiceFiscale($codiceFiscale)
    {
        $query = "DELETE FROM $this->tableName WHERE codice_fiscale=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultValue($query, array($codiceFiscale));
    }

    /**
     * delete by partita_iva_nazione
     * @return boolean
     */
    public function deleteByPartitaIvaNazione($partitaIvaNazione)
    {
        $query = "DELETE FROM $this->tableName WHERE partita_iva_nazione=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultValue($query, array($partitaIvaNazione));
    }

    /**
     * delete by ultima_modifica_utente
     * @return boolean
     */
    public function deleteByUltimaModificaUtente($ultimaModificaUtente)
    {
        $query = "DELETE FROM $this->tableName WHERE ultima_modifica_utente=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultValue($query, array($ultimaModificaUtente));
    }

    /**
     * delete by id_rappresentante
     * @return boolean
     */
    public function deleteByIdRappresentante($idRappresentante)
    {
        $query = "DELETE FROM $this->tableName WHERE id_rappresentante=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultValue($query, array($idRappresentante));
    }

    /**
     * delete by id_tipo_rappresentante
     * @return boolean
     */
    public function deleteByIdTipoRappresentante($idTipoRappresentante)
    {
        $query = "DELETE FROM $this->tableName WHERE id_tipo_rappresentante=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultValue($query, array($idTipoRappresentante));
    }

    /**
     * Transforms the object into a key array
     * @return array
     */
    public function toArrayAssoc()
    {
        $arrayValue = array();
        if (isset($this->id)) $arrayValue['id'] = $this->id;
        if (isset($this->idTipiSoggetto)) $arrayValue['id_tipi_soggetto'] = $this->idTipiSoggetto;
        if (isset($this->titolo)) $arrayValue['titolo'] = ($this->titolo == self::NULL_VALUE) ? null : $this->titolo;
        if (isset($this->codiceFiscale)) $arrayValue['codice_fiscale'] = $this->codiceFiscale;
        if (isset($this->partitaIvaNazione)) $arrayValue['partita_iva_nazione'] = ($this->partitaIvaNazione == self::NULL_VALUE) ? null : $this->partitaIvaNazione;
        if (isset($this->partitaIva)) $arrayValue['partita_iva'] = ($this->partitaIva == self::NULL_VALUE) ? null : $this->partitaIva;
        if (isset($this->ragioneSociale)) $arrayValue['ragione_sociale'] = ($this->ragioneSociale == self::NULL_VALUE) ? null : $this->ragioneSociale;
        if (isset($this->nome)) $arrayValue['nome'] = ($this->nome == self::NULL_VALUE) ? null : $this->nome;
        if (isset($this->cognome)) $arrayValue['cognome'] = ($this->cognome == self::NULL_VALUE) ? null : $this->cognome;
        if (isset($this->nascitaData)) $arrayValue['nascita_data'] = ($this->nascitaData == self::NULL_VALUE) ? null : $this->nascitaData;
        if (isset($this->nascitaLuogo)) $arrayValue['nascita_luogo'] = ($this->nascitaLuogo == self::NULL_VALUE) ? null : $this->nascitaLuogo;
        if (isset($this->nascitaProvincia)) $arrayValue['nascita_provincia'] = ($this->nascitaProvincia == self::NULL_VALUE) ? null : $this->nascitaProvincia;
        if (isset($this->nascitaStato)) $arrayValue['nascita_stato'] = ($this->nascitaStato == self::NULL_VALUE) ? null : $this->nascitaStato;
        if (isset($this->sesso)) $arrayValue['sesso'] = ($this->sesso == self::NULL_VALUE) ? null : $this->sesso;
        if (isset($this->telefoni)) $arrayValue['telefoni'] = $this->jsonEncode($this->telefoni);
        if (isset($this->cellulari)) $arrayValue['cellulari'] = $this->jsonEncode($this->cellulari);
        if (isset($this->email)) $arrayValue['email'] = $this->jsonEncode($this->email);
        if (isset($this->pec)) $arrayValue['pec'] = $this->jsonEncode($this->pec);
        if (isset($this->indirizzi)) $arrayValue['indirizzi'] = $this->jsonEncode($this->indirizzi);
        if (isset($this->ultimaModificaUtente)) $arrayValue['ultima_modifica_utente'] = $this->ultimaModificaUtente;
        if (isset($this->ultimaModificaData)) $arrayValue['ultima_modifica_data'] = ($this->ultimaModificaData == self::NULL_VALUE) ? null : $this->ultimaModificaData;
        if (isset($this->idRappresentante)) $arrayValue['id_rappresentante'] = ($this->idRappresentante == self::NULL_VALUE) ? null : $this->idRappresentante;
        if (isset($this->idTipoRappresentante)) $arrayValue['id_tipo_rappresentante'] = ($this->idTipoRappresentante == self::NULL_VALUE) ? null : $this->idTipoRappresentante;
        if (isset($this->cestino)) $arrayValue['cestino'] = $this->cestino;
        if (isset($this->fileLogo)) $arrayValue['file_logo'] = ($this->fileLogo == self::NULL_VALUE) ? null : $this->fileLogo;
        if (isset($this->fileFirma)) $arrayValue['file_firma'] = ($this->fileFirma == self::NULL_VALUE) ? null : $this->fileFirma;
        if (isset($this->idUtente)) $arrayValue['id_utente'] = ($this->idUtente == self::NULL_VALUE) ? null : $this->idUtente;
        if (isset($this->societaFatturazione)) $arrayValue['societa_fatturazione'] = ($this->societaFatturazione == self::NULL_VALUE) ? null : $this->societaFatturazione;
        if (isset($this->amministratoreCondominio)) $arrayValue['amministratore_condominio'] = ($this->amministratoreCondominio == self::NULL_VALUE) ? null : $this->amministratoreCondominio;
        if (isset($this->fornitore)) $arrayValue['fornitore'] = ($this->fornitore == self::NULL_VALUE) ? null : $this->fornitore;
        if (isset($this->documento)) $arrayValue['documento'] = $this->jsonEncode($this->documento);
        if (isset($this->fatturaElettronicaMittenteAttivo)) $arrayValue['fattura_elettronica_mittente_attivo'] = ($this->fatturaElettronicaMittenteAttivo == self::NULL_VALUE) ? null : $this->fatturaElettronicaMittenteAttivo;
        if (isset($this->fatturaElettronicaMittentePec)) $arrayValue['fattura_elettronica_mittente_pec'] = ($this->fatturaElettronicaMittentePec == self::NULL_VALUE) ? null : $this->fatturaElettronicaMittentePec;
        if (isset($this->fatturaElettronicaMittenteCodice)) $arrayValue['fattura_elettronica_mittente_codice'] = ($this->fatturaElettronicaMittenteCodice == self::NULL_VALUE) ? null : $this->fatturaElettronicaMittenteCodice;
        if (isset($this->fatturaElettronicaDestinatarioAttivo)) $arrayValue['fattura_elettronica_destinatario_attivo'] = ($this->fatturaElettronicaDestinatarioAttivo == self::NULL_VALUE) ? null : $this->fatturaElettronicaDestinatarioAttivo;
        if (isset($this->fatturaElettronicaDestinatarioPec)) $arrayValue['fattura_elettronica_destinatario_pec'] = ($this->fatturaElettronicaDestinatarioPec == self::NULL_VALUE) ? null : $this->fatturaElettronicaDestinatarioPec;
        if (isset($this->fatturaElettronicaDestinatarioCodice)) $arrayValue['fattura_elettronica_destinatario_codice'] = ($this->fatturaElettronicaDestinatarioCodice == self::NULL_VALUE) ? null : $this->fatturaElettronicaDestinatarioCodice;
        if (isset($this->regimeFiscale)) $arrayValue['regime_fiscale'] = ($this->regimeFiscale == self::NULL_VALUE) ? null : $this->regimeFiscale;
        if (isset($this->efattura)) $arrayValue['efattura'] = ($this->efattura == self::NULL_VALUE) ? null : $this->efattura;
        return $arrayValue;
    }

    /**
     * It transforms the keyarray in an $positionalArray[%s]object
     */
    public function createObjKeyArray(array $keyArray)
    {
        $this->flagObjectDataValorized = false;
        if ((isset($keyArray['id'])) || (isset($keyArray['anagrafiche_id']))) {
            $this->setId(isset($keyArray['id']) ? $keyArray['id'] : $keyArray['anagrafiche_id']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['id_tipi_soggetto'])) || (isset($keyArray['anagrafiche_id_tipi_soggetto']))) {
            $this->setIdtipisoggetto(isset($keyArray['id_tipi_soggetto']) ? $keyArray['id_tipi_soggetto'] : $keyArray['anagrafiche_id_tipi_soggetto']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['titolo'])) || (isset($keyArray['anagrafiche_titolo']))) {
            $this->setTitolo(isset($keyArray['titolo']) ? $keyArray['titolo'] : $keyArray['anagrafiche_titolo']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['codice_fiscale'])) || (isset($keyArray['anagrafiche_codice_fiscale']))) {
            $this->setCodicefiscale(isset($keyArray['codice_fiscale']) ? $keyArray['codice_fiscale'] : $keyArray['anagrafiche_codice_fiscale']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['partita_iva_nazione'])) || (isset($keyArray['anagrafiche_partita_iva_nazione']))) {
            $this->setPartitaivanazione(isset($keyArray['partita_iva_nazione']) ? $keyArray['partita_iva_nazione'] : $keyArray['anagrafiche_partita_iva_nazione']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['partita_iva'])) || (isset($keyArray['anagrafiche_partita_iva']))) {
            $this->setPartitaiva(isset($keyArray['partita_iva']) ? $keyArray['partita_iva'] : $keyArray['anagrafiche_partita_iva']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['ragione_sociale'])) || (isset($keyArray['anagrafiche_ragione_sociale']))) {
            $this->setRagionesociale(isset($keyArray['ragione_sociale']) ? $keyArray['ragione_sociale'] : $keyArray['anagrafiche_ragione_sociale']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['nome'])) || (isset($keyArray['anagrafiche_nome']))) {
            $this->setNome(isset($keyArray['nome']) ? $keyArray['nome'] : $keyArray['anagrafiche_nome']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['cognome'])) || (isset($keyArray['anagrafiche_cognome']))) {
            $this->setCognome(isset($keyArray['cognome']) ? $keyArray['cognome'] : $keyArray['anagrafiche_cognome']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['nascita_data'])) || (isset($keyArray['anagrafiche_nascita_data']))) {
            $this->setNascitadata(isset($keyArray['nascita_data']) ? $keyArray['nascita_data'] : $keyArray['anagrafiche_nascita_data']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['nascita_luogo'])) || (isset($keyArray['anagrafiche_nascita_luogo']))) {
            $this->setNascitaluogo(isset($keyArray['nascita_luogo']) ? $keyArray['nascita_luogo'] : $keyArray['anagrafiche_nascita_luogo']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['nascita_provincia'])) || (isset($keyArray['anagrafiche_nascita_provincia']))) {
            $this->setNascitaprovincia(isset($keyArray['nascita_provincia']) ? $keyArray['nascita_provincia'] : $keyArray['anagrafiche_nascita_provincia']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['nascita_stato'])) || (isset($keyArray['anagrafiche_nascita_stato']))) {
            $this->setNascitastato(isset($keyArray['nascita_stato']) ? $keyArray['nascita_stato'] : $keyArray['anagrafiche_nascita_stato']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['sesso'])) || (isset($keyArray['anagrafiche_sesso']))) {
            $this->setSesso(isset($keyArray['sesso']) ? $keyArray['sesso'] : $keyArray['anagrafiche_sesso']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['telefoni'])) || (isset($keyArray['anagrafiche_telefoni']))) {
            $this->setTelefoni(isset($keyArray['telefoni']) ? $keyArray['telefoni'] : $keyArray['anagrafiche_telefoni']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['cellulari'])) || (isset($keyArray['anagrafiche_cellulari']))) {
            $this->setCellulari(isset($keyArray['cellulari']) ? $keyArray['cellulari'] : $keyArray['anagrafiche_cellulari']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['email'])) || (isset($keyArray['anagrafiche_email']))) {
            $this->setEmail(isset($keyArray['email']) ? $keyArray['email'] : $keyArray['anagrafiche_email']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['pec'])) || (isset($keyArray['anagrafiche_pec']))) {
            $this->setPec(isset($keyArray['pec']) ? $keyArray['pec'] : $keyArray['anagrafiche_pec']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['indirizzi'])) || (isset($keyArray['anagrafiche_indirizzi']))) {
            $this->setIndirizzi(isset($keyArray['indirizzi']) ? $keyArray['indirizzi'] : $keyArray['anagrafiche_indirizzi']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['ultima_modifica_utente'])) || (isset($keyArray['anagrafiche_ultima_modifica_utente']))) {
            $this->setUltimamodificautente(isset($keyArray['ultima_modifica_utente']) ? $keyArray['ultima_modifica_utente'] : $keyArray['anagrafiche_ultima_modifica_utente']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['ultima_modifica_data'])) || (isset($keyArray['anagrafiche_ultima_modifica_data']))) {
            $this->setUltimamodificadata(isset($keyArray['ultima_modifica_data']) ? $keyArray['ultima_modifica_data'] : $keyArray['anagrafiche_ultima_modifica_data']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['id_rappresentante'])) || (isset($keyArray['anagrafiche_id_rappresentante']))) {
            $this->setIdrappresentante(isset($keyArray['id_rappresentante']) ? $keyArray['id_rappresentante'] : $keyArray['anagrafiche_id_rappresentante']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['id_tipo_rappresentante'])) || (isset($keyArray['anagrafiche_id_tipo_rappresentante']))) {
            $this->setIdtiporappresentante(isset($keyArray['id_tipo_rappresentante']) ? $keyArray['id_tipo_rappresentante'] : $keyArray['anagrafiche_id_tipo_rappresentante']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['cestino'])) || (isset($keyArray['anagrafiche_cestino']))) {
            $this->setCestino(isset($keyArray['cestino']) ? $keyArray['cestino'] : $keyArray['anagrafiche_cestino']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['file_logo'])) || (isset($keyArray['anagrafiche_file_logo']))) {
            $this->setFilelogo(isset($keyArray['file_logo']) ? $keyArray['file_logo'] : $keyArray['anagrafiche_file_logo']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['file_firma'])) || (isset($keyArray['anagrafiche_file_firma']))) {
            $this->setFilefirma(isset($keyArray['file_firma']) ? $keyArray['file_firma'] : $keyArray['anagrafiche_file_firma']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['id_utente'])) || (isset($keyArray['anagrafiche_id_utente']))) {
            $this->setIdutente(isset($keyArray['id_utente']) ? $keyArray['id_utente'] : $keyArray['anagrafiche_id_utente']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['societa_fatturazione'])) || (isset($keyArray['anagrafiche_societa_fatturazione']))) {
            $this->setSocietafatturazione(isset($keyArray['societa_fatturazione']) ? $keyArray['societa_fatturazione'] : $keyArray['anagrafiche_societa_fatturazione']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['amministratore_condominio'])) || (isset($keyArray['anagrafiche_amministratore_condominio']))) {
            $this->setAmministratorecondominio(isset($keyArray['amministratore_condominio']) ? $keyArray['amministratore_condominio'] : $keyArray['anagrafiche_amministratore_condominio']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['fornitore'])) || (isset($keyArray['anagrafiche_fornitore']))) {
            $this->setFornitore(isset($keyArray['fornitore']) ? $keyArray['fornitore'] : $keyArray['anagrafiche_fornitore']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['documento'])) || (isset($keyArray['anagrafiche_documento']))) {
            $this->setDocumento(isset($keyArray['documento']) ? $keyArray['documento'] : $keyArray['anagrafiche_documento']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['fattura_elettronica_mittente_attivo'])) || (isset($keyArray['anagrafiche_fattura_elettronica_mittente_attivo']))) {
            $this->setFatturaelettronicamittenteattivo(isset($keyArray['fattura_elettronica_mittente_attivo']) ? $keyArray['fattura_elettronica_mittente_attivo'] : $keyArray['anagrafiche_fattura_elettronica_mittente_attivo']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['fattura_elettronica_mittente_pec'])) || (isset($keyArray['anagrafiche_fattura_elettronica_mittente_pec']))) {
            $this->setFatturaelettronicamittentepec(isset($keyArray['fattura_elettronica_mittente_pec']) ? $keyArray['fattura_elettronica_mittente_pec'] : $keyArray['anagrafiche_fattura_elettronica_mittente_pec']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['fattura_elettronica_mittente_codice'])) || (isset($keyArray['anagrafiche_fattura_elettronica_mittente_codice']))) {
            $this->setFatturaelettronicamittentecodice(isset($keyArray['fattura_elettronica_mittente_codice']) ? $keyArray['fattura_elettronica_mittente_codice'] : $keyArray['anagrafiche_fattura_elettronica_mittente_codice']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['fattura_elettronica_destinatario_attivo'])) || (isset($keyArray['anagrafiche_fattura_elettronica_destinatario_attivo']))) {
            $this->setFatturaelettronicadestinatarioattivo(isset($keyArray['fattura_elettronica_destinatario_attivo']) ? $keyArray['fattura_elettronica_destinatario_attivo'] : $keyArray['anagrafiche_fattura_elettronica_destinatario_attivo']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['fattura_elettronica_destinatario_pec'])) || (isset($keyArray['anagrafiche_fattura_elettronica_destinatario_pec']))) {
            $this->setFatturaelettronicadestinatariopec(isset($keyArray['fattura_elettronica_destinatario_pec']) ? $keyArray['fattura_elettronica_destinatario_pec'] : $keyArray['anagrafiche_fattura_elettronica_destinatario_pec']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['fattura_elettronica_destinatario_codice'])) || (isset($keyArray['anagrafiche_fattura_elettronica_destinatario_codice']))) {
            $this->setFatturaelettronicadestinatariocodice(isset($keyArray['fattura_elettronica_destinatario_codice']) ? $keyArray['fattura_elettronica_destinatario_codice'] : $keyArray['anagrafiche_fattura_elettronica_destinatario_codice']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['regime_fiscale'])) || (isset($keyArray['anagrafiche_regime_fiscale']))) {
            $this->setRegimeFiscale(isset($keyArray['regime_fiscale']) ? $keyArray['regime_fiscale'] : $keyArray['anagrafiche_regime_fiscale']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['efattura'])) || (isset($keyArray['anagrafiche_efattura']))) {
            $this->setEfattura(isset($keyArray['efattura']) ? $keyArray['efattura'] : $keyArray['anagrafiche_efattura']);
            $this->flagObjectDataValorized = true;
        }
    }

    /**
     * @return array
     */
    public function createKeyArrayFromPositional($positionalArray)
    {
        $values = array();
        $values['id'] = $positionalArray[0];
        $values['id_tipi_soggetto'] = $positionalArray[1];
        $values['titolo'] = ($positionalArray[2] == self::NULL_VALUE) ? null : $positionalArray[2];
        $values['codice_fiscale'] = $positionalArray[3];
        $values['partita_iva_nazione'] = ($positionalArray[4] == self::NULL_VALUE) ? null : $positionalArray[4];
        $values['partita_iva'] = ($positionalArray[5] == self::NULL_VALUE) ? null : $positionalArray[5];
        $values['ragione_sociale'] = ($positionalArray[6] == self::NULL_VALUE) ? null : $positionalArray[6];
        $values['nome'] = ($positionalArray[7] == self::NULL_VALUE) ? null : $positionalArray[7];
        $values['cognome'] = ($positionalArray[8] == self::NULL_VALUE) ? null : $positionalArray[8];
        $values['nascita_data'] = ($positionalArray[9] == self::NULL_VALUE) ? null : $positionalArray[9];
        $values['nascita_luogo'] = ($positionalArray[10] == self::NULL_VALUE) ? null : $positionalArray[10];
        $values['nascita_provincia'] = ($positionalArray[11] == self::NULL_VALUE) ? null : $positionalArray[11];
        $values['nascita_stato'] = ($positionalArray[12] == self::NULL_VALUE) ? null : $positionalArray[12];
        $values['sesso'] = ($positionalArray[13] == self::NULL_VALUE) ? null : $positionalArray[13];
        $values['telefoni'] = ($positionalArray[14] == self::NULL_VALUE) ? null : $positionalArray[14];
        $values['cellulari'] = ($positionalArray[15] == self::NULL_VALUE) ? null : $positionalArray[15];
        $values['email'] = ($positionalArray[16] == self::NULL_VALUE) ? null : $positionalArray[16];
        $values['pec'] = ($positionalArray[17] == self::NULL_VALUE) ? null : $positionalArray[17];
        $values['indirizzi'] = ($positionalArray[18] == self::NULL_VALUE) ? null : $positionalArray[18];
        $values['ultima_modifica_utente'] = $positionalArray[19];
        $values['ultima_modifica_data'] = ($positionalArray[20] == self::NULL_VALUE) ? null : $positionalArray[20];
        $values['id_rappresentante'] = ($positionalArray[21] == self::NULL_VALUE) ? null : $positionalArray[21];
        $values['id_tipo_rappresentante'] = ($positionalArray[22] == self::NULL_VALUE) ? null : $positionalArray[22];
        $values['cestino'] = $positionalArray[23];
        $values['file_logo'] = ($positionalArray[24] == self::NULL_VALUE) ? null : $positionalArray[24];
        $values['file_firma'] = ($positionalArray[25] == self::NULL_VALUE) ? null : $positionalArray[25];
        $values['id_utente'] = ($positionalArray[26] == self::NULL_VALUE) ? null : $positionalArray[26];
        $values['societa_fatturazione'] = ($positionalArray[27] == self::NULL_VALUE) ? null : $positionalArray[27];
        $values['amministratore_condominio'] = ($positionalArray[28] == self::NULL_VALUE) ? null : $positionalArray[28];
        $values['fornitore'] = ($positionalArray[29] == self::NULL_VALUE) ? null : $positionalArray[29];
        $values['documento'] = ($positionalArray[30] == self::NULL_VALUE) ? null : $positionalArray[30];
        $values['fattura_elettronica_mittente_attivo'] = ($positionalArray[31] == self::NULL_VALUE) ? null : $positionalArray[31];
        $values['fattura_elettronica_mittente_pec'] = ($positionalArray[32] == self::NULL_VALUE) ? null : $positionalArray[32];
        $values['fattura_elettronica_mittente_codice'] = ($positionalArray[33] == self::NULL_VALUE) ? null : $positionalArray[33];
        $values['fattura_elettronica_destinatario_attivo'] = ($positionalArray[34] == self::NULL_VALUE) ? null : $positionalArray[34];
        $values['fattura_elettronica_destinatario_pec'] = ($positionalArray[35] == self::NULL_VALUE) ? null : $positionalArray[35];
        $values['fattura_elettronica_destinatario_codice'] = ($positionalArray[36] == self::NULL_VALUE) ? null : $positionalArray[36];
        $values['regime_fiscale'] = ($positionalArray[37] == self::NULL_VALUE) ? null : $positionalArray[37];
        $values['efattura'] = ($positionalArray[38] == self::NULL_VALUE) ? null : $positionalArray[38];
        return $values;
    }

    /**
     * @return array
     */
    public function getEmptyDbKeyArray()
    {
        $values = array();
        $values['id'] = null;
        $values['id_tipi_soggetto'] = null;
        $values['titolo'] = null;
        $values['codice_fiscale'] = '';
        $values['partita_iva_nazione'] = null;
        $values['partita_iva'] = null;
        $values['ragione_sociale'] = null;
        $values['nome'] = null;
        $values['cognome'] = null;
        $values['nascita_data'] = null;
        $values['nascita_luogo'] = null;
        $values['nascita_provincia'] = null;
        $values['nascita_stato'] = null;
        $values['sesso'] = null;
        $values['telefoni'] = null;
        $values['cellulari'] = null;
        $values['email'] = null;
        $values['pec'] = null;
        $values['indirizzi'] = null;
        $values['ultima_modifica_utente'] = null;
        $values['ultima_modifica_data'] = null;
        $values['id_rappresentante'] = null;
        $values['id_tipo_rappresentante'] = null;
        $values['cestino'] = 0;
        $values['file_logo'] = null;
        $values['file_firma'] = null;
        $values['id_utente'] = null;
        $values['societa_fatturazione'] = 0;
        $values['amministratore_condominio'] = 0;
        $values['fornitore'] = 0;
        $values['documento'] = null;
        $values['fattura_elettronica_mittente_attivo'] = 0;
        $values['fattura_elettronica_mittente_pec'] = null;
        $values['fattura_elettronica_mittente_codice'] = '0000000';
        $values['fattura_elettronica_destinatario_attivo'] = 0;
        $values['fattura_elettronica_destinatario_pec'] = null;
        $values['fattura_elettronica_destinatario_codice'] = '0000000';
        $values['regime_fiscale'] ='RF01';
        $values['efattura'] =1;
        return $values;
    }

    /**
     * Return columns' list
     * @return string
     */
    public function getListColumns()
    {
        return 'anagrafiche.id as anagrafiche_id,anagrafiche.id_tipi_soggetto as anagrafiche_id_tipi_soggetto,anagrafiche.titolo as anagrafiche_titolo,anagrafiche.codice_fiscale as anagrafiche_codice_fiscale,anagrafiche.partita_iva_nazione as anagrafiche_partita_iva_nazione,anagrafiche.partita_iva as anagrafiche_partita_iva,anagrafiche.ragione_sociale as anagrafiche_ragione_sociale,anagrafiche.nome as anagrafiche_nome,anagrafiche.cognome as anagrafiche_cognome,anagrafiche.nascita_data as anagrafiche_nascita_data,anagrafiche.nascita_luogo as anagrafiche_nascita_luogo,anagrafiche.nascita_provincia as anagrafiche_nascita_provincia,anagrafiche.nascita_stato as anagrafiche_nascita_stato,anagrafiche.sesso as anagrafiche_sesso,anagrafiche.telefoni as anagrafiche_telefoni,anagrafiche.cellulari as anagrafiche_cellulari,anagrafiche.email as anagrafiche_email,anagrafiche.pec as anagrafiche_pec,anagrafiche.indirizzi as anagrafiche_indirizzi,anagrafiche.ultima_modifica_utente as anagrafiche_ultima_modifica_utente,anagrafiche.ultima_modifica_data as anagrafiche_ultima_modifica_data,anagrafiche.id_rappresentante as anagrafiche_id_rappresentante,anagrafiche.id_tipo_rappresentante as anagrafiche_id_tipo_rappresentante,anagrafiche.cestino as anagrafiche_cestino,anagrafiche.file_logo as anagrafiche_file_logo,anagrafiche.file_firma as anagrafiche_file_firma,anagrafiche.id_utente as anagrafiche_id_utente,anagrafiche.societa_fatturazione as anagrafiche_societa_fatturazione,anagrafiche.amministratore_condominio as anagrafiche_amministratore_condominio,anagrafiche.fornitore as anagrafiche_fornitore,anagrafiche.documento as anagrafiche_documento,anagrafiche.fattura_elettronica_mittente_attivo as anagrafiche_fattura_elettronica_mittente_attivo,anagrafiche.fattura_elettronica_mittente_pec as anagrafiche_fattura_elettronica_mittente_pec,anagrafiche.fattura_elettronica_mittente_codice as anagrafiche_fattura_elettronica_mittente_codice,anagrafiche.fattura_elettronica_destinatario_attivo as anagrafiche_fattura_elettronica_destinatario_attivo,anagrafiche.fattura_elettronica_destinatario_pec as anagrafiche_fattura_elettronica_destinatario_pec,anagrafiche.fattura_elettronica_destinatario_codice as anagrafiche_fattura_elettronica_destinatario_codice';
    }

    /**
     * DDL Table
     */
    public function createTable()
    {
        return $this->pdo->exec("CREATE TABLE `anagrafiche` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_tipi_soggetto` int(11) NOT NULL,
  `titolo` varchar(15) DEFAULT NULL,
  `codice_fiscale` varchar(16) NOT NULL DEFAULT '',
  `partita_iva_nazione` varchar(2) DEFAULT NULL,
  `partita_iva` varchar(11) DEFAULT NULL,
  `ragione_sociale` varchar(100) DEFAULT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `cognome` varchar(100) DEFAULT NULL,
  `nascita_data` date DEFAULT NULL,
  `nascita_luogo` varchar(45) DEFAULT NULL,
  `nascita_provincia` varchar(2) DEFAULT NULL,
  `nascita_stato` varchar(45) DEFAULT NULL,
  `sesso` enum('M','F') DEFAULT NULL,
  `telefoni` json DEFAULT NULL,
  `cellulari` json DEFAULT NULL,
  `email` json DEFAULT NULL,
  `pec` json DEFAULT NULL,
  `indirizzi` json DEFAULT NULL,
  `ultima_modifica_utente` int(10) unsigned NOT NULL,
  `ultima_modifica_data` datetime DEFAULT NULL,
  `id_rappresentante` int(11) DEFAULT NULL,
  `id_tipo_rappresentante` int(11) DEFAULT NULL,
  `cestino` tinyint(1) NOT NULL DEFAULT '0',
  `file_logo` varchar(45) DEFAULT NULL,
  `file_firma` varchar(45) DEFAULT NULL,
  `id_utente` int(11) DEFAULT NULL,
  `societa_fatturazione` tinyint(1) DEFAULT '0' COMMENT 'indica se una societ� � un''anagrafica di fatturazione o no (agenzie, immobiliari, amministratori, ecc)',
  `amministratore_condominio` tinyint(1) DEFAULT '0',
  `fornitore` tinyint(1) DEFAULT '0',
  `documento` json DEFAULT NULL,
  `fattura_elettronica_mittente_attivo` tinyint(1) DEFAULT '0',
  `fattura_elettronica_mittente_pec` varchar(100) DEFAULT NULL,
  `fattura_elettronica_mittente_codice` varchar(7) DEFAULT '0000000',
  `fattura_elettronica_destinatario_attivo` tinyint(1) DEFAULT '0',
  `fattura_elettronica_destinatario_pec` varchar(100) DEFAULT NULL,
  `fattura_elettronica_destinatario_codice` varchar(7) DEFAULT '0000000',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_codice_fiscale` (`codice_fiscale`),
  UNIQUE KEY `idx_partita_iva` (`partita_iva_nazione`,`partita_iva`),
  KEY `fk_anagrafiche_tipi_soggetto1_idx` (`id_tipi_soggetto`),
  KEY `fk_anagrafiche_login1_idx` (`ultima_modifica_utente`),
  KEY `idx_id_rappresentante` (`id_rappresentante`),
  KEY `idx_id_tipo_rappresentante` (`id_tipo_rappresentante`),
  CONSTRAINT `fk_anagrafiche_login1` FOREIGN KEY (`ultima_modifica_utente`) REFERENCES `login` (`id`),
  CONSTRAINT `idx_id_tipo_soggetto` FOREIGN KEY (`id_tipi_soggetto`) REFERENCES `tipi_soggetto` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1 COMMENT='banche_id' ");
    }

    /**
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param integer $id Id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return integer
     */
    public function getIdTipiSoggetto()
    {
        return $this->idTipiSoggetto;
    }

    /**
     * @param integer $idTipiSoggetto IdTipiSoggetto
     */
    public function setIdTipiSoggetto($idTipiSoggetto)
    {
        $this->idTipiSoggetto = $idTipiSoggetto;
    }

    /**
     * @return string
     */
    public function getTitolo()
    {
        return $this->titolo;
    }

    /**
     * @param string $titolo Titolo
     * @param int $encodeType
     */
    public function setTitolo($titolo, $encodeType = self::STR_DEFAULT)
    {
        $this->titolo = $this->decodeString($titolo, $encodeType);
    }

    /**
     * @return string
     */
    public function getCodiceFiscale()
    {
        return $this->codiceFiscale;
    }

    /**
     * @param string $codiceFiscale CodiceFiscale
     * @param int $encodeType
     */
    public function setCodiceFiscale($codiceFiscale, $encodeType = self::STR_DEFAULT)
    {
        $this->codiceFiscale = $this->decodeString($codiceFiscale, $encodeType);
    }

    /**
     * @return string
     */
    public function getPartitaIvaNazione()
    {
        return $this->partitaIvaNazione;
    }

    /**
     * @param string $partitaIvaNazione PartitaIvaNazione
     * @param int $encodeType
     */
    public function setPartitaIvaNazione($partitaIvaNazione, $encodeType = self::STR_DEFAULT)
    {
        $this->partitaIvaNazione = $this->decodeString($partitaIvaNazione, $encodeType);
    }

    /**
     * @return string
     */
    public function getPartitaIva()
    {
        return $this->partitaIva;
    }

    /**
     * @param string $partitaIva PartitaIva
     * @param int $encodeType
     */
    public function setPartitaIva($partitaIva, $encodeType = self::STR_DEFAULT)
    {
        $this->partitaIva = $this->decodeString($partitaIva, $encodeType);
    }

    /**
     * @return string
     */
    public function getRagioneSociale()
    {
        return $this->ragioneSociale;
    }

    /**
     * @param string $ragioneSociale RagioneSociale
     * @param int $encodeType
     */
    public function setRagioneSociale($ragioneSociale, $encodeType = self::STR_DEFAULT)
    {
        $this->ragioneSociale = $this->decodeString($ragioneSociale, $encodeType);
    }

    /**
     * @return string
     */
    public function getNome()
    {
        return $this->nome;
    }

    /**
     * @param string $nome Nome
     * @param int $encodeType
     */
    public function setNome($nome, $encodeType = self::STR_DEFAULT)
    {
        $this->nome = $this->decodeString($nome, $encodeType);
    }

    /**
     * @return string
     */
    public function getCognome()
    {
        return $this->cognome;
    }

    /**
     * @param string $cognome Cognome
     * @param int $encodeType
     */
    public function setCognome($cognome, $encodeType = self::STR_DEFAULT)
    {
        $this->cognome = $this->decodeString($cognome, $encodeType);
    }

    /**
     * @return string
     */
    public function getNascitaData()
    {
        return $this->nascitaData;
    }

    /**
     * @param string $nascitaData NascitaData
     * @param int $encodeType
     */
    public function setNascitaData($nascitaData, $encodeType = self::STR_DEFAULT)
    {
        $this->nascitaData = $this->decodeString($nascitaData, $encodeType);
    }

    /**
     * @return string
     */
    public function getNascitaLuogo()
    {
        return $this->nascitaLuogo;
    }

    /**
     * @param string $nascitaLuogo NascitaLuogo
     * @param int $encodeType
     */
    public function setNascitaLuogo($nascitaLuogo, $encodeType = self::STR_DEFAULT)
    {
        $this->nascitaLuogo = $this->decodeString($nascitaLuogo, $encodeType);
    }

    /**
     * @return string
     */
    public function getNascitaProvincia()
    {
        return $this->nascitaProvincia;
    }

    /**
     * @param string $nascitaProvincia NascitaProvincia
     * @param int $encodeType
     */
    public function setNascitaProvincia($nascitaProvincia, $encodeType = self::STR_DEFAULT)
    {
        $this->nascitaProvincia = $this->decodeString($nascitaProvincia, $encodeType);
    }

    /**
     * @return string
     */
    public function getNascitaStato()
    {
        return $this->nascitaStato;
    }

    /**
     * @param string $nascitaStato NascitaStato
     * @param int $encodeType
     */
    public function setNascitaStato($nascitaStato, $encodeType = self::STR_DEFAULT)
    {
        $this->nascitaStato = $this->decodeString($nascitaStato, $encodeType);
    }

    /**
     * @param bool $decode if true return decode value * @return string
     */
    public function getSesso($decode = false)
    {
        return ($decode) ? $this->getSessoValuesList()[$this->sesso] : $this->sesso;
    }

    /**
     * @param bool $json if true return value json's array else return array values * @return array|string
     */
    public function getSessoValuesList($json = false)
    {
        $kv = [];
        return ($json) ? $this->createJsonKeyValArray($kv) : $kv;
    }

    /**
     * @param string (enum) $sesso Sesso
     */
    public function setSesso($sesso)
    {
        $this->sesso = $sesso;
    }

    /**
     * @return objext (string)
     */
    public function getTelefoni()
    {
        return $this->telefoni;
    }

    /**
     * @param objext (string) $telefoni Telefoni
     */
    public function setTelefoni($telefoni)
    {
        $this->telefoni = $telefoni;
    }

    /**
     * @return objext (string)
     */
    public function getCellulari()
    {
        return $this->cellulari;
    }

    /**
     * @param objext (string) $cellulari Cellulari
     */
    public function setCellulari($cellulari)
    {
        $this->cellulari = $cellulari;
    }

    /**
     * @return objext (string)
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * @param objext (string) $email Email
     */
    public function setEmail($email)
    {
        $this->email = $email;
    }

    /**
     * @return objext (string)
     */
    public function getPec()
    {
        return $this->pec;
    }

    /**
     * @param objext (string) $pec Pec
     */
    public function setPec($pec)
    {
        $this->pec = $pec;
    }

    /**
     * @return objext (string)
     */
    public function getIndirizzi()
    {
        return $this->indirizzi;
    }

    /**
     * @param objext (string) $indirizzi Indirizzi
     */
    public function setIndirizzi($indirizzi)
    {
        $this->indirizzi = $indirizzi;
    }

    /**
     * @return integer
     */
    public function getUltimaModificaUtente()
    {
        return $this->ultimaModificaUtente;
    }

    /**
     * @param integer $ultimaModificaUtente UltimaModificaUtente
     */
    public function setUltimaModificaUtente($ultimaModificaUtente)
    {
        $this->ultimaModificaUtente = $ultimaModificaUtente;
    }

    /**
     * @return string
     */
    public function getUltimaModificaData()
    {
        return $this->ultimaModificaData;
    }

    /**
     * @param string $ultimaModificaData UltimaModificaData
     * @param int $encodeType
     */
    public function setUltimaModificaData($ultimaModificaData, $encodeType = self::STR_DEFAULT)
    {
        $this->ultimaModificaData = $this->decodeString($ultimaModificaData, $encodeType);
    }

    /**
     * @return integer
     */
    public function getIdRappresentante()
    {
        return $this->idRappresentante;
    }

    /**
     * @param integer $idRappresentante IdRappresentante
     */
    public function setIdRappresentante($idRappresentante)
    {
        $this->idRappresentante = $idRappresentante;
    }

    /**
     * @return integer
     */
    public function getIdTipoRappresentante()
    {
        return $this->idTipoRappresentante;
    }

    /**
     * @param integer $idTipoRappresentante IdTipoRappresentante
     */
    public function setIdTipoRappresentante($idTipoRappresentante)
    {
        $this->idTipoRappresentante = $idTipoRappresentante;
    }

    /**
     * @return integer
     */
    public function getCestino()
    {
        return $this->cestino;
    }

    /**
     * @param integer $cestino Cestino
     */
    public function setCestino($cestino)
    {
        $this->cestino = $cestino;
    }

    /**
     * @return string
     */
    public function getFileLogo()
    {
        return $this->fileLogo;
    }

    /**
     * @param string $fileLogo FileLogo
     * @param int $encodeType
     */
    public function setFileLogo($fileLogo, $encodeType = self::STR_DEFAULT)
    {
        $this->fileLogo = $this->decodeString($fileLogo, $encodeType);
    }

    /**
     * @return string
     */
    public function getFileFirma()
    {
        return $this->fileFirma;
    }

    /**
     * @param string $fileFirma FileFirma
     * @param int $encodeType
     */
    public function setFileFirma($fileFirma, $encodeType = self::STR_DEFAULT)
    {
        $this->fileFirma = $this->decodeString($fileFirma, $encodeType);
    }

    /**
     * @return integer
     */
    public function getIdUtente()
    {
        return $this->idUtente;
    }

    /**
     * @param integer $idUtente IdUtente
     */
    public function setIdUtente($idUtente)
    {
        $this->idUtente = $idUtente;
    }

    /**
     * @return integer
     */
    public function getSocietaFatturazione()
    {
        return $this->societaFatturazione;
    }

    /**
     * @param integer $societaFatturazione SocietaFatturazione
     */
    public function setSocietaFatturazione($societaFatturazione)
    {
        $this->societaFatturazione = $societaFatturazione;
    }

    /**
     * @return integer
     */
    public function getAmministratoreCondominio()
    {
        return $this->amministratoreCondominio;
    }

    /**
     * @param integer $amministratoreCondominio AmministratoreCondominio
     */
    public function setAmministratoreCondominio($amministratoreCondominio)
    {
        $this->amministratoreCondominio = $amministratoreCondominio;
    }

    /**
     * @return integer
     */
    public function getFornitore()
    {
        return $this->fornitore;
    }

    /**
     * @param integer $fornitore Fornitore
     */
    public function setFornitore($fornitore)
    {
        $this->fornitore = $fornitore;
    }

    /**
     * @return objext (string)
     */
    public function getDocumento()
    {
        return $this->documento;
    }

    /**
     * @param objext (string) $documento Documento
     */
    public function setDocumento($documento)
    {
        $this->documento = $documento;
    }

    /**
     * @return integer
     */
    public function getFatturaElettronicaMittenteAttivo()
    {
        return $this->fatturaElettronicaMittenteAttivo;
    }

    /**
     * @param integer $fatturaElettronicaMittenteAttivo FatturaElettronicaMittenteAttivo
     */
    public function setFatturaElettronicaMittenteAttivo($fatturaElettronicaMittenteAttivo)
    {
        $this->fatturaElettronicaMittenteAttivo = $fatturaElettronicaMittenteAttivo;
    }

    /**
     * @return string
     */
    public function getFatturaElettronicaMittentePec()
    {
        return $this->fatturaElettronicaMittentePec;
    }

    /**
     * @param string $fatturaElettronicaMittentePec FatturaElettronicaMittentePec
     * @param int $encodeType
     */
    public function setFatturaElettronicaMittentePec($fatturaElettronicaMittentePec, $encodeType = self::STR_DEFAULT)
    {
        $this->fatturaElettronicaMittentePec = $this->decodeString($fatturaElettronicaMittentePec, $encodeType);
    }

    /**
     * @return string
     */
    public function getFatturaElettronicaMittenteCodice()
    {
        return $this->fatturaElettronicaMittenteCodice;
    }

    /**
     * @param string $fatturaElettronicaMittenteCodice FatturaElettronicaMittenteCodice
     * @param int $encodeType
     */
    public function setFatturaElettronicaMittenteCodice($fatturaElettronicaMittenteCodice, $encodeType = self::STR_DEFAULT)
    {
        $this->fatturaElettronicaMittenteCodice = $this->decodeString($fatturaElettronicaMittenteCodice, $encodeType);
    }

    /**
     * @return integer
     */
    public function getFatturaElettronicaDestinatarioAttivo()
    {
        return $this->fatturaElettronicaDestinatarioAttivo;
    }

    /**
     * @param integer $fatturaElettronicaDestinatarioAttivo FatturaElettronicaDestinatarioAttivo
     */
    public function setFatturaElettronicaDestinatarioAttivo($fatturaElettronicaDestinatarioAttivo)
    {
        $this->fatturaElettronicaDestinatarioAttivo = $fatturaElettronicaDestinatarioAttivo;
    }

    /**
     * @return string
     */
    public function getFatturaElettronicaDestinatarioPec()
    {
        return $this->fatturaElettronicaDestinatarioPec;
    }

    /**
     * @param string $fatturaElettronicaDestinatarioPec FatturaElettronicaDestinatarioPec
     * @param int $encodeType
     */
    public function setFatturaElettronicaDestinatarioPec($fatturaElettronicaDestinatarioPec, $encodeType = self::STR_DEFAULT)
    {
        $this->fatturaElettronicaDestinatarioPec = $this->decodeString($fatturaElettronicaDestinatarioPec, $encodeType);
    }

    /**
     * @return string
     */
    public function getFatturaElettronicaDestinatarioCodice()
    {
        return $this->fatturaElettronicaDestinatarioCodice;
    }

    /**
     * @param string $fatturaElettronicaDestinatarioCodice FatturaElettronicaDestinatarioCodice
     * @param int $encodeType
     */
    public function setFatturaElettronicaDestinatarioCodice($fatturaElettronicaDestinatarioCodice, $encodeType = self::STR_DEFAULT)
    {
        $this->fatturaElettronicaDestinatarioCodice = $this->decodeString($fatturaElettronicaDestinatarioCodice, $encodeType);
    }

    /**
     * @return string
     */
    public function getRegimeFiscale()
    {
        return $this->regimeFiscale;
    }

    /**
     * @param string $regimeFiscale
     */
    public function setRegimeFiscale($regimeFiscale)
    {
        $this->regimeFiscale = $regimeFiscale;
    }

    /**
     * @return int
     */
    public function getEfattura()
    {
        return $this->efattura;
    }

    /**
     * @param int $efattura
     */
    public function setEfattura($efattura)
    {
        $this->efattura = $efattura;
    }

}