<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-15
* Time: 11:42:56.124642
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class ListacomuniModel extends PdaAbstractModel {
/** @var integer */
protected $istat;
/** @var string */
protected $comune;
/** @var string */
protected $provincia;
/** @var string */
protected $regione;
/** @var integer */
protected $prefisso;
/** @var integer */
protected $cap;
/** @var string */
protected $codfisco;
/** @var integer */
protected $abitanti;
/** @var string */
protected $link;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='listacomuni';$this->tableName='listacomuni';}

/**
 * Find all record of table
 * @return Listacomuni[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->istat))$arrayValue['Istat']=($this->istat==self::NULL_VALUE)?null:$this->istat;if(isset($this->comune))$arrayValue['Comune']=($this->comune==self::NULL_VALUE)?null:$this->comune;if(isset($this->provincia))$arrayValue['Provincia']=($this->provincia==self::NULL_VALUE)?null:$this->provincia;if(isset($this->regione))$arrayValue['Regione']=($this->regione==self::NULL_VALUE)?null:$this->regione;if(isset($this->prefisso))$arrayValue['Prefisso']=($this->prefisso==self::NULL_VALUE)?null:$this->prefisso;if(isset($this->cap))$arrayValue['CAP']=($this->cap==self::NULL_VALUE)?null:$this->cap;if(isset($this->codfisco))$arrayValue['CodFisco']=($this->codfisco==self::NULL_VALUE)?null:$this->codfisco;if(isset($this->abitanti))$arrayValue['Abitanti']=($this->abitanti==self::NULL_VALUE)?null:$this->abitanti;if(isset($this->link))$arrayValue['Link']=($this->link==self::NULL_VALUE)?null:$this->link;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['Istat'])) || (isset($keyArray['listacomuni_Istat']))) {$this->setIstat(isset($keyArray['Istat'])?$keyArray['Istat']:$keyArray['listacomuni_Istat']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['Comune'])) || (isset($keyArray['listacomuni_Comune']))) {$this->setComune(isset($keyArray['Comune'])?$keyArray['Comune']:$keyArray['listacomuni_Comune']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['Provincia'])) || (isset($keyArray['listacomuni_Provincia']))) {$this->setProvincia(isset($keyArray['Provincia'])?$keyArray['Provincia']:$keyArray['listacomuni_Provincia']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['Regione'])) || (isset($keyArray['listacomuni_Regione']))) {$this->setRegione(isset($keyArray['Regione'])?$keyArray['Regione']:$keyArray['listacomuni_Regione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['Prefisso'])) || (isset($keyArray['listacomuni_Prefisso']))) {$this->setPrefisso(isset($keyArray['Prefisso'])?$keyArray['Prefisso']:$keyArray['listacomuni_Prefisso']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['CAP'])) || (isset($keyArray['listacomuni_CAP']))) {$this->setCap(isset($keyArray['CAP'])?$keyArray['CAP']:$keyArray['listacomuni_CAP']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['CodFisco'])) || (isset($keyArray['listacomuni_CodFisco']))) {$this->setCodfisco(isset($keyArray['CodFisco'])?$keyArray['CodFisco']:$keyArray['listacomuni_CodFisco']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['Abitanti'])) || (isset($keyArray['listacomuni_Abitanti']))) {$this->setAbitanti(isset($keyArray['Abitanti'])?$keyArray['Abitanti']:$keyArray['listacomuni_Abitanti']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['Link'])) || (isset($keyArray['listacomuni_Link']))) {$this->setLink(isset($keyArray['Link'])?$keyArray['Link']:$keyArray['listacomuni_Link']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['Istat'] =($positionalArray[0]==self::NULL_VALUE)?null:$positionalArray[0];$values['Comune'] =($positionalArray[1]==self::NULL_VALUE)?null:$positionalArray[1];$values['Provincia'] =($positionalArray[2]==self::NULL_VALUE)?null:$positionalArray[2];$values['Regione'] =($positionalArray[3]==self::NULL_VALUE)?null:$positionalArray[3];$values['Prefisso'] =($positionalArray[4]==self::NULL_VALUE)?null:$positionalArray[4];$values['CAP'] =($positionalArray[5]==self::NULL_VALUE)?null:$positionalArray[5];$values['CodFisco'] =($positionalArray[6]==self::NULL_VALUE)?null:$positionalArray[6];$values['Abitanti'] =($positionalArray[7]==self::NULL_VALUE)?null:$positionalArray[7];$values['Link'] =($positionalArray[8]==self::NULL_VALUE)?null:$positionalArray[8];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['Istat'] = null;$values['Comune'] = null;$values['Provincia'] = null;$values['Regione'] = null;$values['Prefisso'] = null;$values['CAP'] = null;$values['CodFisco'] = null;$values['Abitanti'] = null;$values['Link'] = null;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'listacomuni.Istat as listacomuni_Istat,listacomuni.Comune as listacomuni_Comune,listacomuni.Provincia as listacomuni_Provincia,listacomuni.Regione as listacomuni_Regione,listacomuni.Prefisso as listacomuni_Prefisso,listacomuni.CAP as listacomuni_CAP,listacomuni.CodFisco as listacomuni_CodFisco,listacomuni.Abitanti as listacomuni_Abitanti,listacomuni.Link as listacomuni_Link';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `listacomuni` (
  `Istat` int(11) DEFAULT NULL,
  `Comune` text,
  `Provincia` text,
  `Regione` text,
  `Prefisso` int(11) DEFAULT NULL,
  `CAP` int(11) DEFAULT NULL,
  `CodFisco` text,
  `Abitanti` int(11) DEFAULT NULL,
  `Link` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ");}
/**
 * @return integer
 */
public function getIstat(){return $this->istat;}
/**
 * @param integer $istat Istat
 */
public function setIstat($istat){$this->istat=$istat;}
/**
 * @return string
 */
public function getComune(){return $this->comune;}
/**
 * @param string $comune Comune
 * @param int $encodeType
 */
public function setComune($comune,$encodeType = self::STR_DEFAULT){$this->comune=$this->decodeString($comune,$encodeType);}
/**
 * @return string
 */
public function getProvincia(){return $this->provincia;}
/**
 * @param string $provincia Provincia
 * @param int $encodeType
 */
public function setProvincia($provincia,$encodeType = self::STR_DEFAULT){$this->provincia=$this->decodeString($provincia,$encodeType);}
/**
 * @return string
 */
public function getRegione(){return $this->regione;}
/**
 * @param string $regione Regione
 * @param int $encodeType
 */
public function setRegione($regione,$encodeType = self::STR_DEFAULT){$this->regione=$this->decodeString($regione,$encodeType);}
/**
 * @return integer
 */
public function getPrefisso(){return $this->prefisso;}
/**
 * @param integer $prefisso Prefisso
 */
public function setPrefisso($prefisso){$this->prefisso=$prefisso;}
/**
 * @return integer
 */
public function getCap(){return $this->cap;}
/**
 * @param integer $cap Cap
 */
public function setCap($cap){$this->cap=$cap;}
/**
 * @return string
 */
public function getCodfisco(){return $this->codfisco;}
/**
 * @param string $codfisco Codfisco
 * @param int $encodeType
 */
public function setCodfisco($codfisco,$encodeType = self::STR_DEFAULT){$this->codfisco=$this->decodeString($codfisco,$encodeType);}
/**
 * @return integer
 */
public function getAbitanti(){return $this->abitanti;}
/**
 * @param integer $abitanti Abitanti
 */
public function setAbitanti($abitanti){$this->abitanti=$abitanti;}
/**
 * @return string
 */
public function getLink(){return $this->link;}
/**
 * @param string $link Link
 * @param int $encodeType
 */
public function setLink($link,$encodeType = self::STR_DEFAULT){$this->link=$this->decodeString($link,$encodeType);}
}