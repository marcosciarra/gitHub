<?php
/**
 * Created by Drakkar vers. 0.1.2(Hjortspring)
 * User: P.D.A. Srl
 * Date: 2018-06-05
 * Time: 12:10:51.185840
 */

namespace Click\Affitti\TblBase;
require_once 'BolliModel.php';

use Click\Affitti\TblBase\BolliModel;

class  Bolli extends BolliModel
{
    function __construct($pdo)
    {
        parent::__construct($pdo);
    }


    public function findByCategoriaAndData($categoria, $data, $typeResult = self::FETCH_OBJ)
    {
        $query =
            "
            SELECT 
                *
            FROM
                $this->tableName
            WHERE
                categoria = ?
                    AND ? > data_inizio
                    AND (? < data_fine
                    OR data_fine IS NULL)
            ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        return $this->createResultArray($query, array($categoria, $data, $data), $typeResult);
    }


}