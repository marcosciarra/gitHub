<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-15
* Time: 11:42:47.462423
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class ContrattoNoteModel extends PdaAbstractModel {
/** @var integer */
protected $id;
/** @var integer */
protected $idContratto;
/** @var string */
protected $titolo;
/** @var string */
protected $descrizione;
/** @var integer */
protected $cestino=0;
/** @var integer */
protected $ultimaModificaUtente;
/** @var string */
protected $ultimaModificaData;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='contratto_note';$this->tableName='contratto_note';}

/**
 * find by tables' Primary Key: 
 * @return ContrattoNote|array|string|null
 */
public function findByPk($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($id), $typeResult);}
/**
 * delete by tables' Primary Key: 
 */
public function deleteByPk($id){$query = "DELETE FROM $this->tableName  WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($id));}
/**
 * Find all record of table
 * @return ContrattoNote[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * find by tables' Key idx_id_contratto: 
 * @return ContrattoNote[]|array|string
 */
public function findByIdxIdContratto($idContratto,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_id_contratto) WHERE id_contratto=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($idContratto), $typeResult);}

/**
 * delete by tables' Key idx_id_contratto: 
 * @return boolean
 */
public function deleteByIdxIdContratto($idContratto,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_contratto=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idContratto));}
/**
 * find by id
 * @return ContrattoNote[]
 */
public function findById($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($id), $typeResult);}


/**
 * find by id_contratto
 * @return ContrattoNote[]
 */
public function findByIdContratto($idContratto,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id_contratto=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($idContratto), $typeResult);}


/**
 * delete by id_contratto
 * @return boolean
 */
public function deleteByIdContratto($idContratto){$query = "DELETE FROM $this->tableName WHERE id_contratto=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idContratto));}

/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->id))$arrayValue['id']=$this->id;if(isset($this->idContratto))$arrayValue['id_contratto']=$this->idContratto;if(isset($this->titolo))$arrayValue['titolo']=($this->titolo==self::NULL_VALUE)?null:$this->titolo;if(isset($this->descrizione))$arrayValue['descrizione']=($this->descrizione==self::NULL_VALUE)?null:$this->descrizione;if(isset($this->cestino))$arrayValue['cestino']=($this->cestino==self::NULL_VALUE)?null:$this->cestino;if(isset($this->ultimaModificaUtente))$arrayValue['ultima_modifica_utente']=$this->ultimaModificaUtente;if(isset($this->ultimaModificaData))$arrayValue['ultima_modifica_data']=($this->ultimaModificaData==self::NULL_VALUE)?null:$this->ultimaModificaData;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['id'])) || (isset($keyArray['contratto_note_id']))) {$this->setId(isset($keyArray['id'])?$keyArray['id']:$keyArray['contratto_note_id']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_contratto'])) || (isset($keyArray['contratto_note_id_contratto']))) {$this->setIdcontratto(isset($keyArray['id_contratto'])?$keyArray['id_contratto']:$keyArray['contratto_note_id_contratto']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['titolo'])) || (isset($keyArray['contratto_note_titolo']))) {$this->setTitolo(isset($keyArray['titolo'])?$keyArray['titolo']:$keyArray['contratto_note_titolo']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['descrizione'])) || (isset($keyArray['contratto_note_descrizione']))) {$this->setDescrizione(isset($keyArray['descrizione'])?$keyArray['descrizione']:$keyArray['contratto_note_descrizione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['cestino'])) || (isset($keyArray['contratto_note_cestino']))) {$this->setCestino(isset($keyArray['cestino'])?$keyArray['cestino']:$keyArray['contratto_note_cestino']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['ultima_modifica_utente'])) || (isset($keyArray['contratto_note_ultima_modifica_utente']))) {$this->setUltimamodificautente(isset($keyArray['ultima_modifica_utente'])?$keyArray['ultima_modifica_utente']:$keyArray['contratto_note_ultima_modifica_utente']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['ultima_modifica_data'])) || (isset($keyArray['contratto_note_ultima_modifica_data']))) {$this->setUltimamodificadata(isset($keyArray['ultima_modifica_data'])?$keyArray['ultima_modifica_data']:$keyArray['contratto_note_ultima_modifica_data']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['id'] =$positionalArray[0];$values['id_contratto'] =$positionalArray[1];$values['titolo'] =($positionalArray[2]==self::NULL_VALUE)?null:$positionalArray[2];$values['descrizione'] =($positionalArray[3]==self::NULL_VALUE)?null:$positionalArray[3];$values['cestino'] =($positionalArray[4]==self::NULL_VALUE)?null:$positionalArray[4];$values['ultima_modifica_utente'] =$positionalArray[5];$values['ultima_modifica_data'] =($positionalArray[6]==self::NULL_VALUE)?null:$positionalArray[6];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['id'] = null;$values['id_contratto'] = null;$values['titolo'] = '';$values['descrizione'] = '';$values['cestino'] = 0;$values['ultima_modifica_utente'] = null;$values['ultima_modifica_data'] = null;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'contratto_note.id as contratto_note_id,contratto_note.id_contratto as contratto_note_id_contratto,contratto_note.titolo as contratto_note_titolo,contratto_note.descrizione as contratto_note_descrizione,contratto_note.cestino as contratto_note_cestino,contratto_note.ultima_modifica_utente as contratto_note_ultima_modifica_utente,contratto_note.ultima_modifica_data as contratto_note_ultima_modifica_data';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `contratto_note` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_contratto` int(10) unsigned NOT NULL,
  `titolo` varchar(45) DEFAULT '',
  `descrizione` varchar(250) DEFAULT '',
  `cestino` tinyint(1) unsigned DEFAULT '0',
  `ultima_modifica_utente` int(11) unsigned NOT NULL,
  `ultima_modifica_data` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_id_contratto` (`id_contratto`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=latin1 ");}
/**
 * @return integer
 */
public function getId(){return $this->id;}
/**
 * @param integer $id Id
 */
public function setId($id){$this->id=$id;}
/**
 * @return integer
 */
public function getIdContratto(){return $this->idContratto;}
/**
 * @param integer $idContratto IdContratto
 */
public function setIdContratto($idContratto){$this->idContratto=$idContratto;}
/**
 * @return string
 */
public function getTitolo(){return $this->titolo;}
/**
 * @param string $titolo Titolo
 * @param int $encodeType
 */
public function setTitolo($titolo,$encodeType = self::STR_DEFAULT){$this->titolo=$this->decodeString($titolo,$encodeType);}
/**
 * @return string
 */
public function getDescrizione(){return $this->descrizione;}
/**
 * @param string $descrizione Descrizione
 * @param int $encodeType
 */
public function setDescrizione($descrizione,$encodeType = self::STR_DEFAULT){$this->descrizione=$this->decodeString($descrizione,$encodeType);}
/**
 * @return integer
 */
public function getCestino(){return $this->cestino;}
/**
 * @param integer $cestino Cestino
 */
public function setCestino($cestino){$this->cestino=$cestino;}
/**
 * @return integer
 */
public function getUltimaModificaUtente(){return $this->ultimaModificaUtente;}
/**
 * @param integer $ultimaModificaUtente UltimaModificaUtente
 */
public function setUltimaModificaUtente($ultimaModificaUtente){$this->ultimaModificaUtente=$ultimaModificaUtente;}
/**
 * @return string
 */
public function getUltimaModificaData(){return $this->ultimaModificaData;}
/**
 * @param string $ultimaModificaData UltimaModificaData
 * @param int $encodeType
 */
public function setUltimaModificaData($ultimaModificaData,$encodeType = self::STR_DEFAULT){$this->ultimaModificaData=$this->decodeString($ultimaModificaData,$encodeType);}
}