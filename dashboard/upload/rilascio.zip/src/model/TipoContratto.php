<?php
/**
 * Created by Drakkar vers. 0.0.22(Hjortspring)
 * User: P.D.A. Srl
 * Date: 2017-11-27
 * Time: 18:25:51.988221
 */

namespace Click\Affitti\TblBase;
require_once 'TipoContrattoModel.php';

use Click\Affitti\TblBase\TipoContrattoModel;

class  TipoContratto extends TipoContrattoModel
{
    function __construct($pdo)
    {
        parent::__construct($pdo);
    }


    public function findAllConDescrizione($typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $query = "SELECT * FROM $this->tableName ";
        if ($this->whereBase) $query .= " WHERE $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        $query .= $this->createLimitQuery($limit, $offset);
        return $this->createResultArray($query, null, $typeResult);
    }

    public function getPrimoRinnovoById($idTipoContratto)
    {
        $query = "SELECT primo_rinnovo FROM tipo_contratto WHERE id=?";
        $primoRinnovo = $this->createResultValue($query, $idTipoContratto);
        $query = "SELECT tipo_periodo FROM tipo_contratto WHERE id=?";
        $tipo_periodo = $this->createResultValue($query, $idTipoContratto);
        if ($tipo_periodo == 'A')
            $primoRinnovo = $primoRinnovo * 12;
        return $primoRinnovo;
    }

    public static function getPrimoRinnovoByIdStatic($con, $idTipoContratto)
    {
        $tipoContratto = new self($con);
        return $tipoContratto->getPrimoRinnovoById($idTipoContratto);
    }

    public function getSecondoRinnovoById($idTipoContratto)
    {
        $query = "SELECT secondo_rinnovo FROM tipo_contratto WHERE id=?";
        $secondoRinnovo = $this->createResultValue($query, $idTipoContratto);
        $query = "SELECT tipo_periodo FROM tipo_contratto WHERE id=?";
        $tipo_periodo = $this->createResultValue($query, $idTipoContratto);
        if ($tipo_periodo == 'A')
            $secondoRinnovo = $secondoRinnovo * 12;
        return $secondoRinnovo;
    }

    public static function getSecondoRinnovoByIdStatic($con, $idTipoContratto)
    {
        $tipoContratto = new self($con);
        return $tipoContratto->getSecondoRinnovoById($idTipoContratto);
    }

    public function getMesiPrimoRinnovo()
    {
        if ($this->getTipoPeriodo() == 'A') {
            return $this->primoRinnovo * 12;
        }
        return $this->primoRinnovo;
    }

    public function getMesiSecondoRinnovo()
    {
        if ($this->getTipoPeriodo() == 'A') {
            return $this->secondoRinnovo * 12;
        }
        return $this->secondoRinnovo;
    }

    public function getMesiRinnovoSuccessivo()
    {
        if ($this->getTipoPeriodo() == 'A') {
            return $this->rinnovoSuccessivo * 12;
        }
        return $this->rinnovoSuccessivo;
    }

}