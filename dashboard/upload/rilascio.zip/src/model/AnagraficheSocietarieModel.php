<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-15
* Time: 11:42:47.308107
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class AnagraficheSocietarieModel extends PdaAbstractModel {
/** @var integer */
protected $id;
/** @var integer */
protected $soggettoARitenuta;
/** @var string */
protected $rea;
/** @var integer */
protected $capitaleSociale;
/** @var integer */
protected $cdcNumero;
/** @var string */
protected $cdcCitta;
/** @var integer */
protected $inLiquidazione;
/** @var objext (string) */
protected $alboProfessionale;
/** @var string (enum) RF01 = Ordinario<br/>RF02 = Contribuenti minimi<br/>RF04 = Agricoltura e pesca<br/>RF05 = Sali e tabacchi<br/>RF06 = Commercio di fiammiferi<br/>RF07 = Editoria<br/>RF08 = Servizi di telefonia pubblica<br/>RF09 = Rivendita documenti di trasporto e sosta<br/>RF10 = Intrattenimenti e giochi<br/>RF11 = Agenzie di viaggio<br/>RF12 = Agriturismo<br/>RF13 = Vendite a domicilio<br/>RF14 = Beni usati e arte<br/>RF15 = Vendite all�asta<br/>RF16 = IVA per cassa P.A.<br/>RF17 = IVA per cassa<br/>RF18 = Altro<br/>RF19 = Forfettario*/
protected $regimeFiscale;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='anagrafiche_societarie';$this->tableName='anagrafiche_societarie';}

/**
 * find by tables' Primary Key: 
 * @return AnagraficheSocietarie|array|string|null
 */
public function findByPk($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($id), $typeResult);}
/**
 * delete by tables' Primary Key: 
 */
public function deleteByPk($id){$query = "DELETE FROM $this->tableName  WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($id));}
/**
 * Find all record of table
 * @return AnagraficheSocietarie[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * find by id
 * @return AnagraficheSocietarie[]
 */
public function findById($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($id), $typeResult);}


/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->id))$arrayValue['id']=$this->id;if(isset($this->soggettoARitenuta))$arrayValue['soggetto_a_ritenuta']=($this->soggettoARitenuta==self::NULL_VALUE)?null:$this->soggettoARitenuta;if(isset($this->rea))$arrayValue['rea']=($this->rea==self::NULL_VALUE)?null:$this->rea;if(isset($this->capitaleSociale))$arrayValue['capitale_sociale']=($this->capitaleSociale==self::NULL_VALUE)?null:$this->capitaleSociale;if(isset($this->cdcNumero))$arrayValue['cdc_numero']=($this->cdcNumero==self::NULL_VALUE)?null:$this->cdcNumero;if(isset($this->cdcCitta))$arrayValue['cdc_citta']=($this->cdcCitta==self::NULL_VALUE)?null:$this->cdcCitta;if(isset($this->inLiquidazione))$arrayValue['in_liquidazione']=($this->inLiquidazione==self::NULL_VALUE)?null:$this->inLiquidazione;if(isset($this->alboProfessionale))$arrayValue['albo_professionale']=$this->jsonEncode($this->alboProfessionale);if(isset($this->regimeFiscale))$arrayValue['regime_fiscale']=($this->regimeFiscale==self::NULL_VALUE)?null:$this->regimeFiscale;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['id'])) || (isset($keyArray['anagrafiche_societarie_id']))) {$this->setId(isset($keyArray['id'])?$keyArray['id']:$keyArray['anagrafiche_societarie_id']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['soggetto_a_ritenuta'])) || (isset($keyArray['anagrafiche_societarie_soggetto_a_ritenuta']))) {$this->setSoggettoaritenuta(isset($keyArray['soggetto_a_ritenuta'])?$keyArray['soggetto_a_ritenuta']:$keyArray['anagrafiche_societarie_soggetto_a_ritenuta']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['rea'])) || (isset($keyArray['anagrafiche_societarie_rea']))) {$this->setRea(isset($keyArray['rea'])?$keyArray['rea']:$keyArray['anagrafiche_societarie_rea']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['capitale_sociale'])) || (isset($keyArray['anagrafiche_societarie_capitale_sociale']))) {$this->setCapitalesociale(isset($keyArray['capitale_sociale'])?$keyArray['capitale_sociale']:$keyArray['anagrafiche_societarie_capitale_sociale']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['cdc_numero'])) || (isset($keyArray['anagrafiche_societarie_cdc_numero']))) {$this->setCdcnumero(isset($keyArray['cdc_numero'])?$keyArray['cdc_numero']:$keyArray['anagrafiche_societarie_cdc_numero']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['cdc_citta'])) || (isset($keyArray['anagrafiche_societarie_cdc_citta']))) {$this->setCdccitta(isset($keyArray['cdc_citta'])?$keyArray['cdc_citta']:$keyArray['anagrafiche_societarie_cdc_citta']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['in_liquidazione'])) || (isset($keyArray['anagrafiche_societarie_in_liquidazione']))) {$this->setInliquidazione(isset($keyArray['in_liquidazione'])?$keyArray['in_liquidazione']:$keyArray['anagrafiche_societarie_in_liquidazione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['albo_professionale'])) || (isset($keyArray['anagrafiche_societarie_albo_professionale']))) {$this->setAlboprofessionale(isset($keyArray['albo_professionale'])?$keyArray['albo_professionale']:$keyArray['anagrafiche_societarie_albo_professionale']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['regime_fiscale'])) || (isset($keyArray['anagrafiche_societarie_regime_fiscale']))) {$this->setRegimefiscale(isset($keyArray['regime_fiscale'])?$keyArray['regime_fiscale']:$keyArray['anagrafiche_societarie_regime_fiscale']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['id'] =$positionalArray[0];$values['soggetto_a_ritenuta'] =($positionalArray[1]==self::NULL_VALUE)?null:$positionalArray[1];$values['rea'] =($positionalArray[2]==self::NULL_VALUE)?null:$positionalArray[2];$values['capitale_sociale'] =($positionalArray[3]==self::NULL_VALUE)?null:$positionalArray[3];$values['cdc_numero'] =($positionalArray[4]==self::NULL_VALUE)?null:$positionalArray[4];$values['cdc_citta'] =($positionalArray[5]==self::NULL_VALUE)?null:$positionalArray[5];$values['in_liquidazione'] =($positionalArray[6]==self::NULL_VALUE)?null:$positionalArray[6];$values['albo_professionale'] =($positionalArray[7]==self::NULL_VALUE)?null:$positionalArray[7];$values['regime_fiscale'] =($positionalArray[8]==self::NULL_VALUE)?null:$positionalArray[8];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['id'] = null;$values['soggetto_a_ritenuta'] = null;$values['rea'] = null;$values['capitale_sociale'] = null;$values['cdc_numero'] = null;$values['cdc_citta'] = null;$values['in_liquidazione'] = null;$values['albo_professionale'] = null;$values['regime_fiscale'] = null;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'anagrafiche_societarie.id as anagrafiche_societarie_id,anagrafiche_societarie.soggetto_a_ritenuta as anagrafiche_societarie_soggetto_a_ritenuta,anagrafiche_societarie.rea as anagrafiche_societarie_rea,anagrafiche_societarie.capitale_sociale as anagrafiche_societarie_capitale_sociale,anagrafiche_societarie.cdc_numero as anagrafiche_societarie_cdc_numero,anagrafiche_societarie.cdc_citta as anagrafiche_societarie_cdc_citta,anagrafiche_societarie.in_liquidazione as anagrafiche_societarie_in_liquidazione,anagrafiche_societarie.albo_professionale as anagrafiche_societarie_albo_professionale,anagrafiche_societarie.regime_fiscale as anagrafiche_societarie_regime_fiscale';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `anagrafiche_societarie` (
  `id` int(10) unsigned NOT NULL,
  `soggetto_a_ritenuta` tinyint(1) DEFAULT NULL,
  `rea` varchar(12) DEFAULT NULL,
  `capitale_sociale` int(11) DEFAULT NULL,
  `cdc_numero` int(11) DEFAULT NULL,
  `cdc_citta` varchar(45) DEFAULT NULL,
  `in_liquidazione` tinyint(1) DEFAULT NULL,
  `albo_professionale` json DEFAULT NULL,
  `regime_fiscale` enum('RF01','RF02','RF04','RF05','RF06','RF07','RF08','RF09','RF10','RF11','RF12','RF13','RF14','RF15','RF16','RF17','RF18','RF19') DEFAULT NULL COMMENT 'RF01 = Ordinario\nRF02 = Contribuenti minimi\nRF04 = Agricoltura e pesca\nRF05 = Sali e tabacchi\nRF06 = Commercio di fiammiferi\nRF07 = Editoria\nRF08 = Servizi di telefonia pubblica\nRF09 = Rivendita documenti di trasporto e sosta\nRF10 = Intrattenimenti e giochi\nRF11 = Agenzie di viaggio\nRF12 = Agriturismo\nRF13 = Vendite a domicilio\nRF14 = Beni usati e arte\nRF15 = Vendite all�asta\nRF16 = IVA per cassa P.A.\nRF17 = IVA per cassa\nRF18 = Altro\nRF19 = Forfettario',
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_anagrafiche_societarie_anagrafiche1` FOREIGN KEY (`id`) REFERENCES `anagrafiche` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ");}
/**
 * @return integer
 */
public function getId(){return $this->id;}
/**
 * @param integer $id Id
 */
public function setId($id){$this->id=$id;}
/**
 * @return integer
 */
public function getSoggettoARitenuta(){return $this->soggettoARitenuta;}
/**
 * @param integer $soggettoARitenuta SoggettoARitenuta
 */
public function setSoggettoARitenuta($soggettoARitenuta){$this->soggettoARitenuta=$soggettoARitenuta;}
/**
 * @return string
 */
public function getRea(){return $this->rea;}
/**
 * @param string $rea Rea
 * @param int $encodeType
 */
public function setRea($rea,$encodeType = self::STR_DEFAULT){$this->rea=$this->decodeString($rea,$encodeType);}
/**
 * @return integer
 */
public function getCapitaleSociale(){return $this->capitaleSociale;}
/**
 * @param integer $capitaleSociale CapitaleSociale
 */
public function setCapitaleSociale($capitaleSociale){$this->capitaleSociale=$capitaleSociale;}
/**
 * @return integer
 */
public function getCdcNumero(){return $this->cdcNumero;}
/**
 * @param integer $cdcNumero CdcNumero
 */
public function setCdcNumero($cdcNumero){$this->cdcNumero=$cdcNumero;}
/**
 * @return string
 */
public function getCdcCitta(){return $this->cdcCitta;}
/**
 * @param string $cdcCitta CdcCitta
 * @param int $encodeType
 */
public function setCdcCitta($cdcCitta,$encodeType = self::STR_DEFAULT){$this->cdcCitta=$this->decodeString($cdcCitta,$encodeType);}
/**
 * @return integer
 */
public function getInLiquidazione(){return $this->inLiquidazione;}
/**
 * @param integer $inLiquidazione InLiquidazione
 */
public function setInLiquidazione($inLiquidazione){$this->inLiquidazione=$inLiquidazione;}
/**
 * @return objext (string)
 */
public function getAlboProfessionale(){return $this->alboProfessionale;}
/**
 * @param objext (string) $alboProfessionale AlboProfessionale
 */
public function setAlboProfessionale($alboProfessionale){$this->alboProfessionale=$alboProfessionale;}
/**
 * @param bool $decode if true return decode value * @return string
 */
public function getRegimeFiscale($decode=false){return ($decode)?$this->getRegimeFiscaleValuesList()[$this->regimeFiscale]:$this->regimeFiscale;}
/**
 * @param bool $json if true return value json's array else return array values * @return array|string
 */
public function getRegimeFiscaleValuesList($json=false){$kv=['RF01'=>'Ordinario','RF02'=>'Contribuenti minimi','RF04'=>'Agricoltura e pesca','RF05'=>'Sali e tabacchi','RF06'=>'Commercio di fiammiferi','RF07'=>'Editoria','RF08'=>'Servizi di telefonia pubblica','RF09'=>'Rivendita documenti di trasporto e sosta','RF10'=>'Intrattenimenti e giochi','RF11'=>'Agenzie di viaggio','RF12'=>'Agriturismo','RF13'=>'Vendite a domicilio','RF14'=>'Beni usati e arte','RF15'=>'Vendite all�asta','RF16'=>'IVA per cassa P.A.','RF17'=>'IVA per cassa','RF18'=>'Altro','RF19'=>'Forfettario'];return ($json)?$this->createJsonKeyValArray($kv):$kv;}
/**
 * @param string (enum) $regimeFiscale RegimeFiscale
 */
public function setRegimeFiscale($regimeFiscale){$this->regimeFiscale=$regimeFiscale;}
}