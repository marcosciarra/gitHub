<?php
/**
 * Created by Drakkar vers. 0.0.23(Hjortspring)
 * User: P.D.A. Srl
 * Date: 2017-12-06
 * Time: 15:21:59.753368
 */

namespace Click\Affitti\TblBase;
require_once 'UnitaImmobiliariContrattiModel.php';

use Click\Affitti\TblBase\UnitaImmobiliariContrattiModel;

class  UnitaImmobiliariContratti extends UnitaImmobiliariContrattiModel
{
    function __construct($pdo)
    {
        parent::__construct($pdo);
    }

    public function elencoImmobiliPerContratto($idContratto, $typeResult = self::FETCH_OBJ)
    {
        $query = "
        SELECT 
            unita_immobiliari_contratti.id_contratto,
            unita_immobiliari.*
        FROM
            unita_immobiliari
                INNER JOIN
            unita_immobiliari_contratti ON unita_immobiliari_contratti.id_unita_immobiliare = unita_immobiliari.id
        WHERE
            unita_immobiliari_contratti.id_contratto = ? 
        ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultArray($query, array($idContratto), $typeResult);
    }
}