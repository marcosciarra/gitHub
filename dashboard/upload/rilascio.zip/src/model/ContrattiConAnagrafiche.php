<?php
/**
 * Created by PhpStorm.
 * User: Duca
 * Date: 22/05/18
 * Time: 15:14
 */

namespace Click\Affitti\Viste;
require_once 'Contratti.php';
require_once 'Anagrafiche.php';
require_once 'UnitaImmobiliari.php';

use Click\Affitti\TblBase\Anagrafiche;
use Click\Affitti\TblBase\Contratti;
use Click\Affitti\TblBase\UnitaImmobiliari;
use Drakkar\DrakkarDbConnector;

class ContrattiConAnagrafiche extends Contratti
{

    /** @var Anagrafiche[] */
    protected $anagraficaConduttori;
    /** @var Anagrafiche[] */
    protected $anagraficaLocatori;
    /** @var UnitaImmobiliari[] */
    protected $unitaImmobiliari;

    /**
     * @inheritDoc
     */
    public function __construct(DrakkarDbConnector $pdo, string $statoCestino = 'A')
    {
        parent::__construct($pdo, $statoCestino);
        $this->anagraficaConduttori = [];
        $this->anagraficaLocatori = [];
        $this->unitaImmobiliari = [];
    }


    /**
     * @inheritDoc
     */
    public function findByPkConAnagrafiche($id, $typeResult = self::FETCH_OBJ)
    {
        parent::findByPk($id);
        foreach (json_decode($this->getConduttori()) as $c) {
            $a = new Anagrafiche($this->conn);
            $this->anagraficaConduttori[] = $a->findByPk($c->id);
        }
        foreach (json_decode($this->getProprietari()) as $p) {
            $a = new Anagrafiche($this->conn);
            $this->anagraficaLocatori[] = $a->findByPk($p->id);
        }
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function findByPk($id, $typeResult = self::FETCH_OBJ)
    {
        $this->findByPkConAnagrafiche($id, self::FETCH_OBJ);
        $ui = new UnitaImmobiliari($this->conn);
        $this->unitaImmobiliari = $ui->findByIdContratto($this->id, self::FETCH_OBJ);

        return $this->returnResult($typeResult);

    }


    public function returnResult($typeResult, $value = null)
    {
        switch ($typeResult) {
            case self::FETCH_OBJ:
                return $typeResult;
                break;
            case self::FETCH_KEYARRAY:
            case self::FETCH_ASSOC:
                return $this->toArrayAssoc();
                break;
            default:
                return false;  //TODO da finire e sistemare
        }

    }


    /**
     * @inheritDoc
     */
    public function toArrayAssoc()
    {
        $app = parent::toArrayAssoc();

        $app['anagrafica_locatori'] = [];
        foreach ($this->getAnagraficaLocatori() as $l) {
            $app['anagrafica_locatori'][] = $l->toArrayAssoc();
        }

        $app['anagrafica_conduttori'] = [];
        foreach ($this->getAnagraficaConduttori() as $c) {
            $app['anagrafica_conduttori'][] = $c->toArrayAssoc();
        }

        $app['unita_immobiliari'] = [];
        foreach ($this->getUnitaImmobiliari() as $ui) {
            $app['unita_immobiliari'][] = $ui->toArrayAssoc();
        }

        return $app;

    }

    /**
     * @return Anagrafiche[]
     */
    public function getAnagraficaConduttori(): array
    {
        return $this->anagraficaConduttori;
    }

    /**
     * @param Anagrafiche[] $anagraficaConduttori
     */
    public function setAnagraficaConduttori(array $anagraficaConduttori): void
    {
        $this->anagraficaConduttori = $anagraficaConduttori;
    }

    /**
     * @return Anagrafiche[]
     */
    public function getAnagraficaLocatori(): array
    {
        return $this->anagraficaLocatori;
    }

    /**
     * @param Anagrafiche[] $anagraficaLocatori
     */
    public function setAnagraficaLocatori(array $anagraficaLocatori): void
    {
        $this->anagraficaLocatori = $anagraficaLocatori;
    }

    /**
     * @return UnitaImmobiliari[]
     */
    public function getUnitaImmobiliari(): array
    {
        return $this->unitaImmobiliari;
    }

    /**
     * @param UnitaImmobiliari[] $unitaImmobiliari
     */
    public function setUnitaImmobiliari(array $unitaImmobiliari): void
    {
        $this->unitaImmobiliari = $unitaImmobiliari;
    }

}