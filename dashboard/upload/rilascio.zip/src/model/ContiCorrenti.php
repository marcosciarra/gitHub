<?php
/**
 * Created by Drakkar vers. 0.0.24(Hjortspring)
 * User: P.D.A. Srl
 * Date: 2018-01-11
 * Time: 16:23:56.143657
 */

namespace Click\Affitti\TblBase;
require_once 'ContiCorrentiModel.php';

use Click\Affitti\TblBase\ContiCorrentiModel;

class  ContiCorrenti extends ContiCorrentiModel
{
    protected $conBancheComuni;

    /** @var Banche */
    protected $banca;


    function __construct($pdo, $pdoBanche = null)
    {
        parent::__construct($pdo);
        $this->conBancheComuni = $pdoBanche;
    }

    public function getInfoBancaByAbi($abi)
    {
        $query = "SELECT * FROM banche where abi = ?";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        //$query .= $this->createLimitQuery($limit, $offset);
        return $this->createResult($query, $abi, self::FETCH_KEYARRAY);
    }

    /**
     * @return array
     */
    public function getEmptyDbKeyArray()
    {
        $values = parent::getEmptyDbKeyArray();
        $values['intestatario'] = '';
        $values['abi'] = '';
        $values['nomeBanca'] = '';
        return $values;
    }


    public function getIban($separatore = '')
    {
        return $this->getNazione() . $separatore .
            $this->getCkdigit() . $separatore .
            $this->getCin() . $separatore .
            $this->getAbi() . $separatore .
            $this->getCab() . $separatore .
            $this->getConto();
    }


    public function getElencoContiContratto($array, $typeResult = self::FETCH_OBJ)
    {
        $query = "
        select 
            id, agenzia, 
            CONCAT('******', (SUBSTRING(conto, 9, 4))) AS fineCC
        from 
        conti_correnti
        where id_anagrafica IN ( ".join(",", $array)." )
         ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultArray($query, array(), $typeResult);
    }

    public function controllaUsoContoCorrente($id){
        $query = "SELECT
                   COUNT(contratti.id)
                FROM
                   contratti
                       INNER JOIN
                   contratti_dettagli ON contratti.id = contratti_dettagli.id
                       INNER JOIN
                   rli ON contratti.id = rli.id_contratto
                WHERE
                    contratti.elaborato=1 AND
                   (contratti_dettagli.id_conto_corrente=? Or
                   rli.id_conto_corrente=?)";
        return $this->createResultValue($query,array($id,$id));
    }
    public static function controllaUsoContoCorrenteStatic($con,$id){
        $ts = new self($con);
        return $ts->controllaUsoContoCorrente($id);
    }


}