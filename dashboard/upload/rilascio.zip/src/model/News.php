<?php
/**
 * Created by Drakkar vers. 0.1.3(Hjortspring)
 * User: P.D.A. Srl
 * Date: 2018-08-01
 * Time: 11:36:57.328411
 */

namespace Click\Affitti\TblBase;
require_once 'NewsModel.php';

use Click\Affitti\TblBase\NewsModel;

class  News extends NewsModel
{
    function __construct($pdo)
    {
        parent::__construct($pdo);
    }


    public function countAvvisiNonLetti($idNewsLetta)
    {
        $query = "SELECT count(id) FROM $this->tableName WHERE id>? AND cestino=0";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        return $this->createResultValue($query, array($idNewsLetta));
    }


    public function getAvvisiLetti($idNewsLetta, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName WHERE id<=? AND cestino=0";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        return $this->createResultArray($query, array($idNewsLetta), $typeResult);
    }


    public function getAvvisiNonLetti($idNewsLetta, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName WHERE id>? AND cestino=0 OR isnull(cestino)";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        return $this->createResultArray($query, array($idNewsLetta), $typeResult);
    }

}