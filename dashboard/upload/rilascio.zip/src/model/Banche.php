<?php
/**
* Created by Drakkar vers. 0.0.24(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-01-12
* Time: 17:43:07.617477
*/
namespace Click\Affitti\TblBase;
require_once 'BancheModel.php';
use Click\Affitti\TblBase\BancheModel;

class  Banche extends BancheModel {
function __construct($pdo){parent::__construct($pdo);}

}