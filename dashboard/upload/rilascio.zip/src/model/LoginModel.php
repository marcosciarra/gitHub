<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-15
* Time: 11:42:47.604469
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class LoginModel extends PdaAbstractModel {
/** @var integer */
protected $id;
/** @var string */
protected $username;
/** @var string */
protected $password;
/** @var string */
protected $nome;
/** @var string */
protected $cognome;
/** @var string */
protected $email;
/** @var string (enum) SU= Super User<br/>U= Utente<br/>A= Amministratore*/
protected $tipoUtente='U';
/** @var integer */
protected $bloccato=0;
/** @var string */
protected $ultimoAccesso;
/** @var string */
protected $idSessione;
/** @var string */
protected $dataScadenza;
/** @var integer */
protected $idNewsLetta;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='login';$this->tableName='login';}

/**
 * find by tables' Primary Key: 
 * @return Login|array|string|null
 */
public function findByPk($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($id), $typeResult);}
/**
 * delete by tables' Primary Key: 
 */
public function deleteByPk($id){$query = "DELETE FROM $this->tableName  WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($id));}
/**
 * Find all record of table
 * @return Login[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * find by tables' Key idx_username: 
 * @return Login|array|string
 */
public function findByIdxUsername($username,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(idx_username) WHERE username=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($username), $typeResult);}

/**
 * find by tables' Key idx_email: 
 * @return Login|array|string
 */
public function findByIdxEmail($email,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(idx_email) WHERE email=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($email), $typeResult);}

/**
 * delete by tables' Key idx_username: 
 * @return boolean
 */
public function deleteByIdxUsername($username,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE username=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($username));}
/**
 * delete by tables' Key idx_email: 
 * @return boolean
 */
public function deleteByIdxEmail($email,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE email=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($email));}
/**
 * find by id
 * @return Login[]
 */
public function findById($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($id), $typeResult);}


/**
 * find by username
 * @return Login
 */
public function findByUsername($username,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE username=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResult($query, array($username), $typeResult);}


/**
 * find like username
 * @return Login[]
 */
public function findLikeUsername($username,$likeMatching=self::LIKE_MATCHING_BOTH, $typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE username like ?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($this->prepareLikeMatching($username,$likeMatching)), $typeResult);}

/**
 * find by email
 * @return Login
 */
public function findByEmail($email,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE email=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResult($query, array($email), $typeResult);}


/**
 * find like email
 * @return Login[]
 */
public function findLikeEmail($email,$likeMatching=self::LIKE_MATCHING_BOTH, $typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE email like ?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($this->prepareLikeMatching($email,$likeMatching)), $typeResult);}

/**
 * delete by username
 * @return boolean
 */
public function deleteByUsername($username){$query = "DELETE FROM $this->tableName WHERE username=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($username));}

/**
 * delete by email
 * @return boolean
 */
public function deleteByEmail($email){$query = "DELETE FROM $this->tableName WHERE email=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($email));}

/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->id))$arrayValue['id']=$this->id;if(isset($this->username))$arrayValue['username']=$this->username;if(isset($this->password))$arrayValue['password']=$this->password;if(isset($this->nome))$arrayValue['nome']=($this->nome==self::NULL_VALUE)?null:$this->nome;if(isset($this->cognome))$arrayValue['cognome']=($this->cognome==self::NULL_VALUE)?null:$this->cognome;if(isset($this->email))$arrayValue['email']=$this->email;if(isset($this->tipoUtente))$arrayValue['tipo_utente']=$this->tipoUtente;if(isset($this->bloccato))$arrayValue['bloccato']=$this->bloccato;if(isset($this->ultimoAccesso))$arrayValue['ultimo_accesso']=($this->ultimoAccesso==self::NULL_VALUE)?null:$this->ultimoAccesso;if(isset($this->idSessione))$arrayValue['id_sessione']=($this->idSessione==self::NULL_VALUE)?null:$this->idSessione;if(isset($this->dataScadenza))$arrayValue['data_scadenza']=($this->dataScadenza==self::NULL_VALUE)?null:$this->dataScadenza;if(isset($this->idNewsLetta))$arrayValue['id_news_letta']=($this->idNewsLetta==self::NULL_VALUE)?null:$this->idNewsLetta;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['id'])) || (isset($keyArray['login_id']))) {$this->setId(isset($keyArray['id'])?$keyArray['id']:$keyArray['login_id']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['username'])) || (isset($keyArray['login_username']))) {$this->setUsername(isset($keyArray['username'])?$keyArray['username']:$keyArray['login_username']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['password'])) || (isset($keyArray['login_password']))) {$this->setPassword(isset($keyArray['password'])?$keyArray['password']:$keyArray['login_password']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['nome'])) || (isset($keyArray['login_nome']))) {$this->setNome(isset($keyArray['nome'])?$keyArray['nome']:$keyArray['login_nome']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['cognome'])) || (isset($keyArray['login_cognome']))) {$this->setCognome(isset($keyArray['cognome'])?$keyArray['cognome']:$keyArray['login_cognome']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['email'])) || (isset($keyArray['login_email']))) {$this->setEmail(isset($keyArray['email'])?$keyArray['email']:$keyArray['login_email']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['tipo_utente'])) || (isset($keyArray['login_tipo_utente']))) {$this->setTipoutente(isset($keyArray['tipo_utente'])?$keyArray['tipo_utente']:$keyArray['login_tipo_utente']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['bloccato'])) || (isset($keyArray['login_bloccato']))) {$this->setBloccato(isset($keyArray['bloccato'])?$keyArray['bloccato']:$keyArray['login_bloccato']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['ultimo_accesso'])) || (isset($keyArray['login_ultimo_accesso']))) {$this->setUltimoaccesso(isset($keyArray['ultimo_accesso'])?$keyArray['ultimo_accesso']:$keyArray['login_ultimo_accesso']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_sessione'])) || (isset($keyArray['login_id_sessione']))) {$this->setIdsessione(isset($keyArray['id_sessione'])?$keyArray['id_sessione']:$keyArray['login_id_sessione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['data_scadenza'])) || (isset($keyArray['login_data_scadenza']))) {$this->setDatascadenza(isset($keyArray['data_scadenza'])?$keyArray['data_scadenza']:$keyArray['login_data_scadenza']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_news_letta'])) || (isset($keyArray['login_id_news_letta']))) {$this->setIdnewsletta(isset($keyArray['id_news_letta'])?$keyArray['id_news_letta']:$keyArray['login_id_news_letta']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['id'] =$positionalArray[0];$values['username'] =$positionalArray[1];$values['password'] =$positionalArray[2];$values['nome'] =($positionalArray[3]==self::NULL_VALUE)?null:$positionalArray[3];$values['cognome'] =($positionalArray[4]==self::NULL_VALUE)?null:$positionalArray[4];$values['email'] =$positionalArray[5];$values['tipo_utente'] =$positionalArray[6];$values['bloccato'] =$positionalArray[7];$values['ultimo_accesso'] =($positionalArray[8]==self::NULL_VALUE)?null:$positionalArray[8];$values['id_sessione'] =($positionalArray[9]==self::NULL_VALUE)?null:$positionalArray[9];$values['data_scadenza'] =($positionalArray[10]==self::NULL_VALUE)?null:$positionalArray[10];$values['id_news_letta'] =($positionalArray[11]==self::NULL_VALUE)?null:$positionalArray[11];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['id'] = null;$values['username'] = null;$values['password'] = null;$values['nome'] = null;$values['cognome'] = null;$values['email'] = null;$values['tipo_utente'] = 'U';$values['bloccato'] = 0;$values['ultimo_accesso'] = null;$values['id_sessione'] = null;$values['data_scadenza'] = null;$values['id_news_letta'] = null;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'login.id as login_id,login.username as login_username,login.password as login_password,login.nome as login_nome,login.cognome as login_cognome,login.email as login_email,login.tipo_utente as login_tipo_utente,login.bloccato as login_bloccato,login.ultimo_accesso as login_ultimo_accesso,login.id_sessione as login_id_sessione,login.data_scadenza as login_data_scadenza,login.id_news_letta as login_id_news_letta';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `login` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nome` varchar(45) DEFAULT NULL,
  `cognome` varchar(45) DEFAULT NULL,
  `email` varchar(45) NOT NULL,
  `tipo_utente` enum('SU','U','A') NOT NULL DEFAULT 'U' COMMENT 'SU= Super User\nU= Utente\nA= Amministratore',
  `bloccato` tinyint(1) NOT NULL DEFAULT '0',
  `ultimo_accesso` datetime DEFAULT NULL,
  `id_sessione` varchar(255) DEFAULT NULL,
  `data_scadenza` date DEFAULT NULL,
  `id_news_letta` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_username` (`username`),
  UNIQUE KEY `idx_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1 ");}
/**
 * @return integer
 */
public function getId(){return $this->id;}
/**
 * @param integer $id Id
 */
public function setId($id){$this->id=$id;}
/**
 * @return string
 */
public function getUsername(){return $this->username;}
/**
 * @param string $username Username
 * @param int $encodeType
 */
public function setUsername($username,$encodeType = self::STR_DEFAULT){$this->username=$this->decodeString($username,$encodeType);}
/**
 * @return string
 */
public function getPassword(){return $this->password;}
/**
 * @param string $password Password
 * @param int $encodeType
 */
public function setPassword($password,$encodeType = self::STR_DEFAULT){$this->password=$this->decodeString($password,$encodeType);}
/**
 * @return string
 */
public function getNome(){return $this->nome;}
/**
 * @param string $nome Nome
 * @param int $encodeType
 */
public function setNome($nome,$encodeType = self::STR_DEFAULT){$this->nome=$this->decodeString($nome,$encodeType);}
/**
 * @return string
 */
public function getCognome(){return $this->cognome;}
/**
 * @param string $cognome Cognome
 * @param int $encodeType
 */
public function setCognome($cognome,$encodeType = self::STR_DEFAULT){$this->cognome=$this->decodeString($cognome,$encodeType);}
/**
 * @return string
 */
public function getEmail(){return $this->email;}
/**
 * @param string $email Email
 * @param int $encodeType
 */
public function setEmail($email,$encodeType = self::STR_DEFAULT){$this->email=$this->decodeString($email,$encodeType);}
/**
 * @param bool $decode if true return decode value * @return string
 */
public function getTipoUtente($decode=false){return ($decode)?$this->getTipoUtenteValuesList()[$this->tipoUtente]:$this->tipoUtente;}
/**
 * @param bool $json if true return value json's array else return array values * @return array|string
 */
public function getTipoUtenteValuesList($json=false){$kv=['SU'=>'Super User','U'=>'Utente','A'=>'Amministratore'];return ($json)?$this->createJsonKeyValArray($kv):$kv;}
/**
 * @param string (enum) $tipoUtente TipoUtente
 */
public function setTipoUtente($tipoUtente){$this->tipoUtente=$tipoUtente;}
/**
 * @return integer
 */
public function getBloccato(){return $this->bloccato;}
/**
 * @param integer $bloccato Bloccato
 */
public function setBloccato($bloccato){$this->bloccato=$bloccato;}
/**
 * @return string
 */
public function getUltimoAccesso(){return $this->ultimoAccesso;}
/**
 * @param string $ultimoAccesso UltimoAccesso
 * @param int $encodeType
 */
public function setUltimoAccesso($ultimoAccesso,$encodeType = self::STR_DEFAULT){$this->ultimoAccesso=$this->decodeString($ultimoAccesso,$encodeType);}
/**
 * @return string
 */
public function getIdSessione(){return $this->idSessione;}
/**
 * @param string $idSessione IdSessione
 * @param int $encodeType
 */
public function setIdSessione($idSessione,$encodeType = self::STR_DEFAULT){$this->idSessione=$this->decodeString($idSessione,$encodeType);}
/**
 * @return string
 */
public function getDataScadenza(){return $this->dataScadenza;}
/**
 * @param string $dataScadenza DataScadenza
 * @param int $encodeType
 */
public function setDataScadenza($dataScadenza,$encodeType = self::STR_DEFAULT){$this->dataScadenza=$this->decodeString($dataScadenza,$encodeType);}
/**
 * @return integer
 */
public function getIdNewsLetta(){return $this->idNewsLetta;}
/**
 * @param integer $idNewsLetta IdNewsLetta
 */
public function setIdNewsLetta($idNewsLetta){$this->idNewsLetta=$idNewsLetta;}
}