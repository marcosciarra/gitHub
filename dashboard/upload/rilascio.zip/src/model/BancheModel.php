<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-15
* Time: 11:42:56.003213
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class BancheModel extends PdaAbstractModel {
/** @var string */
protected $abi;
/** @var string */
protected $descrizione;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='banche';$this->tableName='banche';}

/**
 * Find all record of table
 * @return Banche[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * find by tables' Key PRIMARY4: 
 * @return Banche[]|array|string
 */
public function findByPrimary4($abi,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY4) WHERE abi=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($abi), $typeResult);}

/**
 * delete by tables' Key PRIMARY4: 
 * @return boolean
 */
public function deleteByPrimary4($abi,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE abi=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($abi));}
/**
 * find by abi
 * @return Banche[]
 */
public function findByAbi($abi,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE abi=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($abi), $typeResult);}


/**
 * find like abi
 * @return Banche[]
 */
public function findLikeAbi($abi,$likeMatching=self::LIKE_MATCHING_BOTH, $typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE abi like ?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($this->prepareLikeMatching($abi,$likeMatching)), $typeResult);}

/**
 * delete by abi
 * @return boolean
 */
public function deleteByAbi($abi){$query = "DELETE FROM $this->tableName WHERE abi=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($abi));}

/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->abi))$arrayValue['abi']=($this->abi==self::NULL_VALUE)?null:$this->abi;if(isset($this->descrizione))$arrayValue['descrizione']=($this->descrizione==self::NULL_VALUE)?null:$this->descrizione;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['abi'])) || (isset($keyArray['banche_abi']))) {$this->setAbi(isset($keyArray['abi'])?$keyArray['abi']:$keyArray['banche_abi']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['descrizione'])) || (isset($keyArray['banche_descrizione']))) {$this->setDescrizione(isset($keyArray['descrizione'])?$keyArray['descrizione']:$keyArray['banche_descrizione']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['abi'] =($positionalArray[0]==self::NULL_VALUE)?null:$positionalArray[0];$values['descrizione'] =($positionalArray[1]==self::NULL_VALUE)?null:$positionalArray[1];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['abi'] = null;$values['descrizione'] = null;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'banche.abi as banche_abi,banche.descrizione as banche_descrizione';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `banche` (
  `abi` varchar(5) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `descrizione` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  KEY `PRIMARY4` (`abi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ");}
/**
 * @return string
 */
public function getAbi(){return $this->abi;}
/**
 * @param string $abi Abi
 * @param int $encodeType
 */
public function setAbi($abi,$encodeType = self::STR_DEFAULT){$this->abi=$this->decodeString($abi,$encodeType);}
/**
 * @return string
 */
public function getDescrizione(){return $this->descrizione;}
/**
 * @param string $descrizione Descrizione
 * @param int $encodeType
 */
public function setDescrizione($descrizione,$encodeType = self::STR_DEFAULT){$this->descrizione=$this->decodeString($descrizione,$encodeType);}
}