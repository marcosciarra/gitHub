<?php
/**
* Created by Drakkar vers. 0.1.2(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-05-15
* Time: 18:21:58.100392
*/
namespace Click\Affitti\TblBase;
require_once 'CategorieSpesaModel.php';
use Click\Affitti\TblBase\CategorieSpesaModel;

class  CategorieSpesa extends CategorieSpesaModel {
function __construct($pdo){parent::__construct($pdo);}

}