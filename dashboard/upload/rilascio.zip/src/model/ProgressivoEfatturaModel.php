<?php
/**
 * Created by Drakkar vers. 0.1.3(Hjortspring)
 * User: P.D.A. Srl
 * Date: 2018-11-15
 * Time: 11:42:47.965431
 */

namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';

use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class ProgressivoEfatturaModel extends PdaAbstractModel
{
    /** @var integer */
    protected $id;
    /** @var integer */
    protected $idFatturazioneTesta;

    function __construct($pdo)
    {
        parent::__construct($pdo);
        $this->nomeTabella = 'progressivo_efattura';
        $this->tableName = 'progressivo_efattura';
    }

    /**
     * find by tables' Primary Key:
     * @return ProgressivoEfattura|array|string|null
     */
    public function findByPk($id, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResult($query, array($id), $typeResult);
    }

    /**
     * delete by tables' Primary Key:
     */
    public function deleteByPk($id)
    {
        $query = "DELETE FROM $this->tableName  WHERE id=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultValue($query, array($id));
    }

    /**
     * Find all record of table
     * @return ProgressivoEfattura[]|array|string
     */
    public function findAll($distinct = false, $typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $distinctStr = ($distinct) ? 'DISTINCT' : '';
        $query = "SELECT $distinctStr * FROM $this->tableName ";
        if ($this->whereBase) $query .= " WHERE $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        $query .= $this->createLimitQuery($limit, $offset);
        return $this->createResultArray($query, null, $typeResult);
    }

    /**
     * find by id
     * @return ProgressivoEfattura[]
     */
    public function findById($id, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName WHERE id=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        return $this->createResultArray($query, array($id), $typeResult);
    }


    /**
     * Transforms the object into a key array
     * @return array
     */
    public function toArrayAssoc()
    {
        $arrayValue = array();
        if (isset($this->id)) $arrayValue['id'] = $this->id;
        if (isset($this->idFatturazioneTesta)) $arrayValue['id_fatturazione_testa'] = $this->idFatturazioneTesta;
        return $arrayValue;
    }

    /**
     * It transforms the keyarray in an $positionalArray[%s]object
     */
    public function createObjKeyArray(array $keyArray)
    {
        $this->flagObjectDataValorized = false;
        if ((isset($keyArray['id'])) || (isset($keyArray['progressivo_efattura_id']))) {
            $this->setId(isset($keyArray['id']) ? $keyArray['id'] : $keyArray['progressivo_efattura_id']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['id_fatturazione_testa'])) || (isset($keyArray['progressivo_efattura_id_fatturazione_testa']))) {
            $this->setIdFatturazioneTesta(isset($keyArray['id_fatturazione_testa']) ? $keyArray['id_fatturazione_testa'] : $keyArray['progressivo_efattura_id_fatturazione_testa']);
            $this->flagObjectDataValorized = true;
        }
    }

    /**
     * @return array
     */
    public function createKeyArrayFromPositional($positionalArray)
    {
        $values = array();
        $values['id'] = $positionalArray[0];
        $values['id_fatturazione_testa'] = $positionalArray[1];
        return $values;
    }

    /**
     * @return array
     */
    public function getEmptyDbKeyArray()
    {
        $values = array();
        $values['id'] = null;
        $values['id_fatturazione_testa'] = null;
        return $values;
    }

    /**
     * Return columns' list
     * @return string
     */
    public function getListColumns()
    {
        return 'progressivo_efattura.id as progressivo_efattura_id,progressivo_efattura.id_fatturazione_testa as progressivo_efattura_id_fatturazione_testa';
    }

    /**
     * DDL Table
     */
    public function createTable()
    {
        return $this->pdo->exec("CREATE TABLE `progressivo_efattura` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `editabile` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 ");
    }

    /**
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param integer $id Id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return int
     */
    public function getIdFatturazioneTesta()
    {
        return $this->idFatturazioneTesta;
    }

    /**
     * @param int $idFatturazioneTesta
     */
    public function setIdFatturazioneTesta($idFatturazioneTesta)
    {
        $this->idFatturazioneTesta = $idFatturazioneTesta;
    }

}