<?php
/**
* Created by Drakkar vers. 0.1.2(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-06-13
* Time: 11:38:33.633525
*/
namespace Click\Affitti\TblBase;
require_once 'TestiLettereModel.php';
use Click\Affitti\TblBase\TestiLettereModel;

class  TestiLettere extends TestiLettereModel {
function __construct($pdo){parent::__construct($pdo);}

}