<?php
/**
 * Created by Drakkar vers. 0.0.22(Hjortspring)
 * User: P.D.A. Srl
 * Date: 2017-11-27
 * Time: 18:25:51.906679
 */

namespace Click\Affitti\TblBase;
require_once 'CauzioniModel.php';

use Click\Affitti\TblBase\CauzioniModel;

class  Cauzioni extends CauzioniModel
{

    /** @var  TipiCauzione */
    protected $tipoCauzione;


    function __construct($pdo)
    {
        parent::__construct($pdo);
    }

    /**
     * @return TipiCauzione
     */
    public function getTipoCauzione()
    {
        return $this->tipoCauzione;
    }

    /**
     * @param TipiCauzione $tipoCauzione
     */
    public function setTipoCauzione($tipoCauzione)
    {
        $this->tipoCauzione = $tipoCauzione;
    }


    public function findByDataScadenza($dataInizio, $dataFine, $typeResult = self::FETCH_OBJ)
    {
        $query =
            "
            SELECT 
                *,
                DATE_SUB(data_scadenza,
                    INTERVAL mesi_preavviso_scadenza MONTH) AS data_preavviso
            FROM
                cauzioni
                    INNER JOIN
                contratti ON cauzioni.id_contratto = contratti.id
            WHERE
                contratti.cestino = 0
                    AND contratti.elaborato = 1
            HAVING data_preavviso BETWEEN ? AND ? 
            ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultArray($query, array($dataInizio, $dataFine), $typeResult);
    }


}