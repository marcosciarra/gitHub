<?php
/**
 * Created by Drakkar vers. 0.1.3(Hjortspring)
 * User: P.D.A. Srl
 * Date: 2018-11-16
 * Time: 17:08:38.073580
 */

namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';

use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class FatturazioneTestaModel extends PdaAbstractModel
{
    /** @var integer */
    protected $id;
    /** @var string */
    protected $codiceGruppo;
    /** @var integer */
    protected $idRata;
    /** @var integer */
    protected $idGruppoFatturazione;
    /** @var integer */
    protected $numeroDocumento;
    /** @var string */
    protected $tipoDocumento;
    /** @var string */
    protected $dataScadenza;
    /** @var string */
    protected $dataEmissione;
    /** @var integer */
    protected $contoCorrente;
    /** @var objext (string) */
    protected $recapito;
    /** @var objext (string) */
    protected $unitaImmobiliari;
    /** @var integer */
    protected $idLocatoreFattura;
    /** @var integer */
    protected $idConduttoreFattura;
    /** @var objext (string) */
    protected $proprietari;
    /** @var objext (string) */
    protected $conduttori;
    /** @var string (enum) N = NON ASSOGGETTO AD IVA<br/>S = ASSOGGETTO AD IVA */
    protected $tipoAssoggettazione;
    /** @var integer */
    protected $contabilizzato = 0;
    /** @var integer */
    protected $flussoControllato = 0;
    /** @var integer */
    protected $flussoInviato = 0;
    /** @var integer */
    protected $idFatturaPa = 0;

    function __construct($pdo)
    {
        parent::__construct($pdo);
        $this->nomeTabella = 'fatturazione_testa';
        $this->tableName = 'fatturazione_testa';
    }

    /**
     * find by tables' Primary Key:
     * @return FatturazioneTesta|array|string|null
     */
    public function findByPk($id, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResult($query, array($id), $typeResult);
    }

    /**
     * delete by tables' Primary Key:
     */
    public function deleteByPk($id)
    {
        $query = "DELETE FROM $this->tableName  WHERE id=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultValue($query, array($id));
    }

    /**
     * Find all record of table
     * @return FatturazioneTesta[]|array|string
     */
    public function findAll($distinct = false, $typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $distinctStr = ($distinct) ? 'DISTINCT' : '';
        $query = "SELECT $distinctStr * FROM $this->tableName ";
        if ($this->whereBase) $query .= " WHERE $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        $query .= $this->createLimitQuery($limit, $offset);
        return $this->createResultArray($query, null, $typeResult);
    }

    /**
     * find by tables' Key idx_codice_gruppo:
     * @return FatturazioneTesta[]|array|string
     */
    public function findByIdxCodiceGruppo($codiceGruppo, $typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $query = "SELECT * FROM $this->tableName USE INDEX(idx_codice_gruppo) WHERE codice_gruppo=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultArray($query, array($codiceGruppo), $typeResult);
    }

    /**
     * find by tables' Key idx_id_rata:
     * @return FatturazioneTesta[]|array|string
     */
    public function findByIdxIdRata($idRata, $typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $query = "SELECT * FROM $this->tableName USE INDEX(idx_id_rata) WHERE id_rata=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultArray($query, array($idRata), $typeResult);
    }

    /**
     * find by tables' Key idx_id_gruppo_fatturazione:
     * @return FatturazioneTesta[]|array|string
     */
    public function findByIdxIdGruppoFatturazione($idGruppoFatturazione, $typeResult = self::FETCH_OBJ, $limit = -1, $offset = -1)
    {
        $query = "SELECT * FROM $this->tableName USE INDEX(idx_id_gruppo_fatturazione) WHERE id_gruppo_fatturazione=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultArray($query, array($idGruppoFatturazione), $typeResult);
    }

    /**
     * delete by tables' Key idx_codice_gruppo:
     * @return boolean
     */
    public function deleteByIdxCodiceGruppo($codiceGruppo, $typeResult = self::FETCH_OBJ)
    {
        $query = "DELETE FROM $this->tableName WHERE codice_gruppo=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultValue($query, array($codiceGruppo));
    }

    /**
     * delete by tables' Key idx_id_rata:
     * @return boolean
     */
    public function deleteByIdxIdRata($idRata, $typeResult = self::FETCH_OBJ)
    {
        $query = "DELETE FROM $this->tableName WHERE id_rata=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultValue($query, array($idRata));
    }

    /**
     * delete by tables' Key idx_id_gruppo_fatturazione:
     * @return boolean
     */
    public function deleteByIdxIdGruppoFatturazione($idGruppoFatturazione, $typeResult = self::FETCH_OBJ)
    {
        $query = "DELETE FROM $this->tableName WHERE id_gruppo_fatturazione=? ";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultValue($query, array($idGruppoFatturazione));
    }

    /**
     * find by id
     * @return FatturazioneTesta[]
     */
    public function findById($id, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName WHERE id=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        return $this->createResultArray($query, array($id), $typeResult);
    }


    /**
     * find by codice_gruppo
     * @return FatturazioneTesta[]
     */
    public function findByCodiceGruppo($codiceGruppo, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName WHERE codice_gruppo=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        return $this->createResultArray($query, array($codiceGruppo), $typeResult);
    }


    /**
     * find like codice_gruppo
     * @return FatturazioneTesta[]
     */
    public function findLikeCodiceGruppo($codiceGruppo, $likeMatching = self::LIKE_MATCHING_BOTH, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName WHERE codice_gruppo like ?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultArray($query, array($this->prepareLikeMatching($codiceGruppo, $likeMatching)), $typeResult);
    }

    /**
     * find by id_rata
     * @return FatturazioneTesta[]
     */
    public function findByIdRata($idRata, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName WHERE id_rata=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        return $this->createResultArray($query, array($idRata), $typeResult);
    }


    /**
     * find by id_gruppo_fatturazione
     * @return FatturazioneTesta[]
     */
    public function findByIdGruppoFatturazione($idGruppoFatturazione, $typeResult = self::FETCH_OBJ)
    {
        $query = "SELECT * FROM $this->tableName WHERE id_gruppo_fatturazione=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        if ($this->orderBase) $query .= " ORDER BY $this->orderBase";
        return $this->createResultArray($query, array($idGruppoFatturazione), $typeResult);
    }


    /**
     * delete by codice_gruppo
     * @return boolean
     */
    public function deleteByCodiceGruppo($codiceGruppo)
    {
        $query = "DELETE FROM $this->tableName WHERE codice_gruppo=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultValue($query, array($codiceGruppo));
    }

    /**
     * delete by id_rata
     * @return boolean
     */
    public function deleteByIdRata($idRata)
    {
        $query = "DELETE FROM $this->tableName WHERE id_rata=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultValue($query, array($idRata));
    }

    /**
     * delete by id_gruppo_fatturazione
     * @return boolean
     */
    public function deleteByIdGruppoFatturazione($idGruppoFatturazione)
    {
        $query = "DELETE FROM $this->tableName WHERE id_gruppo_fatturazione=?";
        if ($this->whereBase) $query .= " AND $this->whereBase";
        return $this->createResultValue($query, array($idGruppoFatturazione));
    }

    /**
     * Transforms the object into a key array
     * @return array
     */
    public function toArrayAssoc()
    {
        $arrayValue = array();
        if (isset($this->id)) $arrayValue['id'] = $this->id;
        if (isset($this->codiceGruppo)) $arrayValue['codice_gruppo'] = ($this->codiceGruppo == self::NULL_VALUE) ? null : $this->codiceGruppo;
        if (isset($this->idRata)) $arrayValue['id_rata'] = $this->idRata;
        if (isset($this->idGruppoFatturazione)) $arrayValue['id_gruppo_fatturazione'] = $this->idGruppoFatturazione;
        if (isset($this->numeroDocumento)) $arrayValue['numero_documento'] = ($this->numeroDocumento == self::NULL_VALUE) ? null : $this->numeroDocumento;
        if (isset($this->tipoDocumento)) $arrayValue['tipo_documento'] = ($this->tipoDocumento == self::NULL_VALUE) ? null : $this->tipoDocumento;
        if (isset($this->dataScadenza)) $arrayValue['data_scadenza'] = ($this->dataScadenza == self::NULL_VALUE) ? null : $this->dataScadenza;
        if (isset($this->dataEmissione)) $arrayValue['data_emissione'] = ($this->dataEmissione == self::NULL_VALUE) ? null : $this->dataEmissione;
        if (isset($this->contoCorrente)) $arrayValue['conto_corrente'] = ($this->contoCorrente == self::NULL_VALUE) ? null : $this->contoCorrente;
        if (isset($this->recapito)) $arrayValue['recapito'] = $this->jsonEncode($this->recapito);
        if (isset($this->unitaImmobiliari)) $arrayValue['unita_immobiliari'] = $this->jsonEncode($this->unitaImmobiliari);
        if (isset($this->idLocatoreFattura)) $arrayValue['id_locatore_fattura'] = ($this->idLocatoreFattura == self::NULL_VALUE) ? null : $this->idLocatoreFattura;
        if (isset($this->idConduttoreFattura)) $arrayValue['id_conduttore_fattura'] = ($this->idConduttoreFattura == self::NULL_VALUE) ? null : $this->idConduttoreFattura;
        if (isset($this->proprietari)) $arrayValue['proprietari'] = $this->jsonEncode($this->proprietari);
        if (isset($this->conduttori)) $arrayValue['conduttori'] = $this->jsonEncode($this->conduttori);
        if (isset($this->tipoAssoggettazione)) $arrayValue['tipo_assoggettazione'] = ($this->tipoAssoggettazione == self::NULL_VALUE) ? null : $this->tipoAssoggettazione;
        if (isset($this->contabilizzato)) $arrayValue['contabilizzato'] = $this->contabilizzato;
        if (isset($this->flussoControllato)) $arrayValue['flusso_controllato'] = $this->flussoControllato;
        if (isset($this->flussoInviato)) $arrayValue['flusso_inviato'] = $this->flussoInviato;
        if (isset($this->idFatturaPa)) $arrayValue['id_fattura_pa'] = $this->idFatturaPa;
        return $arrayValue;
    }

    /**
     * It transforms the keyarray in an $positionalArray[%s]object
     */
    public function createObjKeyArray(array $keyArray)
    {
        $this->flagObjectDataValorized = false;
        if ((isset($keyArray['id'])) || (isset($keyArray['fatturazione_testa_id']))) {
            $this->setId(isset($keyArray['id']) ? $keyArray['id'] : $keyArray['fatturazione_testa_id']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['codice_gruppo'])) || (isset($keyArray['fatturazione_testa_codice_gruppo']))) {
            $this->setCodicegruppo(isset($keyArray['codice_gruppo']) ? $keyArray['codice_gruppo'] : $keyArray['fatturazione_testa_codice_gruppo']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['id_rata'])) || (isset($keyArray['fatturazione_testa_id_rata']))) {
            $this->setIdrata(isset($keyArray['id_rata']) ? $keyArray['id_rata'] : $keyArray['fatturazione_testa_id_rata']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['id_gruppo_fatturazione'])) || (isset($keyArray['fatturazione_testa_id_gruppo_fatturazione']))) {
            $this->setIdgruppofatturazione(isset($keyArray['id_gruppo_fatturazione']) ? $keyArray['id_gruppo_fatturazione'] : $keyArray['fatturazione_testa_id_gruppo_fatturazione']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['numero_documento'])) || (isset($keyArray['fatturazione_testa_numero_documento']))) {
            $this->setNumerodocumento(isset($keyArray['numero_documento']) ? $keyArray['numero_documento'] : $keyArray['fatturazione_testa_numero_documento']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['tipo_documento'])) || (isset($keyArray['fatturazione_testa_tipo_documento']))) {
            $this->setTipodocumento(isset($keyArray['tipo_documento']) ? $keyArray['tipo_documento'] : $keyArray['fatturazione_testa_tipo_documento']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['data_scadenza'])) || (isset($keyArray['fatturazione_testa_data_scadenza']))) {
            $this->setDatascadenza(isset($keyArray['data_scadenza']) ? $keyArray['data_scadenza'] : $keyArray['fatturazione_testa_data_scadenza']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['data_emissione'])) || (isset($keyArray['fatturazione_testa_data_emissione']))) {
            $this->setDataemissione(isset($keyArray['data_emissione']) ? $keyArray['data_emissione'] : $keyArray['fatturazione_testa_data_emissione']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['conto_corrente'])) || (isset($keyArray['fatturazione_testa_conto_corrente']))) {
            $this->setContocorrente(isset($keyArray['conto_corrente']) ? $keyArray['conto_corrente'] : $keyArray['fatturazione_testa_conto_corrente']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['recapito'])) || (isset($keyArray['fatturazione_testa_recapito']))) {
            $this->setRecapito(isset($keyArray['recapito']) ? $keyArray['recapito'] : $keyArray['fatturazione_testa_recapito']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['unita_immobiliari'])) || (isset($keyArray['fatturazione_testa_unita_immobiliari']))) {
            $this->setUnitaimmobiliari(isset($keyArray['unita_immobiliari']) ? $keyArray['unita_immobiliari'] : $keyArray['fatturazione_testa_unita_immobiliari']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['id_locatore_fattura'])) || (isset($keyArray['fatturazione_testa_id_locatore_fattura']))) {
            $this->setIdlocatorefattura(isset($keyArray['id_locatore_fattura']) ? $keyArray['id_locatore_fattura'] : $keyArray['fatturazione_testa_id_locatore_fattura']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['id_conduttore_fattura'])) || (isset($keyArray['fatturazione_testa_id_conduttore_fattura']))) {
            $this->setIdconduttorefattura(isset($keyArray['id_conduttore_fattura']) ? $keyArray['id_conduttore_fattura'] : $keyArray['fatturazione_testa_id_conduttore_fattura']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['proprietari'])) || (isset($keyArray['fatturazione_testa_proprietari']))) {
            $this->setProprietari(isset($keyArray['proprietari']) ? $keyArray['proprietari'] : $keyArray['fatturazione_testa_proprietari']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['conduttori'])) || (isset($keyArray['fatturazione_testa_conduttori']))) {
            $this->setConduttori(isset($keyArray['conduttori']) ? $keyArray['conduttori'] : $keyArray['fatturazione_testa_conduttori']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['tipo_assoggettazione'])) || (isset($keyArray['fatturazione_testa_tipo_assoggettazione']))) {
            $this->setTipoassoggettazione(isset($keyArray['tipo_assoggettazione']) ? $keyArray['tipo_assoggettazione'] : $keyArray['fatturazione_testa_tipo_assoggettazione']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['contabilizzato'])) || (isset($keyArray['fatturazione_testa_contabilizzato']))) {
            $this->setContabilizzato(isset($keyArray['contabilizzato']) ? $keyArray['contabilizzato'] : $keyArray['fatturazione_testa_contabilizzato']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['flusso_controllato'])) || (isset($keyArray['fatturazione_testa_flusso_controllato']))) {
            $this->setFlussoControllato(isset($keyArray['flusso_controllato']) ? $keyArray['flusso_controllato'] : $keyArray['fatturazione_testa_flusso_controllato']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['flusso_inviato'])) || (isset($keyArray['fatturazione_testa_flusso_inviato']))) {
            $this->setFlussoInviato(isset($keyArray['flusso_inviato']) ? $keyArray['flusso_inviato'] : $keyArray['fatturazione_testa_flusso_inviato']);
            $this->flagObjectDataValorized = true;
        }
        if ((isset($keyArray['id_fattura_pa'])) || (isset($keyArray['fatturazione_testa_id_fattura_pa']))) {
            $this->setIdFatturaPa(isset($keyArray['id_fattura_pa']) ? $keyArray['id_fattura_pa'] : $keyArray['fatturazione_testa_id_fattura_pa']);
            $this->flagObjectDataValorized = true;
        }
    }

    /**
     * @return array
     */
    public function createKeyArrayFromPositional($positionalArray)
    {
        $values = array();
        $values['id'] = $positionalArray[0];
        $values['codice_gruppo'] = ($positionalArray[1] == self::NULL_VALUE) ? null : $positionalArray[1];
        $values['id_rata'] = $positionalArray[2];
        $values['id_gruppo_fatturazione'] = $positionalArray[3];
        $values['numero_documento'] = ($positionalArray[4] == self::NULL_VALUE) ? null : $positionalArray[4];
        $values['tipo_documento'] = ($positionalArray[5] == self::NULL_VALUE) ? null : $positionalArray[5];
        $values['data_scadenza'] = ($positionalArray[6] == self::NULL_VALUE) ? null : $positionalArray[6];
        $values['data_emissione'] = ($positionalArray[7] == self::NULL_VALUE) ? null : $positionalArray[7];
        $values['conto_corrente'] = ($positionalArray[8] == self::NULL_VALUE) ? null : $positionalArray[8];
        $values['recapito'] = ($positionalArray[9] == self::NULL_VALUE) ? null : $positionalArray[9];
        $values['unita_immobiliari'] = ($positionalArray[10] == self::NULL_VALUE) ? null : $positionalArray[10];
        $values['id_locatore_fattura'] = ($positionalArray[11] == self::NULL_VALUE) ? null : $positionalArray[11];
        $values['id_conduttore_fattura'] = ($positionalArray[12] == self::NULL_VALUE) ? null : $positionalArray[12];
        $values['proprietari'] = ($positionalArray[13] == self::NULL_VALUE) ? null : $positionalArray[13];
        $values['conduttori'] = ($positionalArray[14] == self::NULL_VALUE) ? null : $positionalArray[14];
        $values['tipo_assoggettazione'] = ($positionalArray[15] == self::NULL_VALUE) ? null : $positionalArray[15];
        $values['contabilizzato'] = $positionalArray[16];
        $values['flusso_controllato'] = $positionalArray[17];
        $values['flusso_inviato'] = $positionalArray[18];
        $values['id_fattura_pa'] = $positionalArray[19];
        return $values;
    }

    /**
     * @return array
     */
    public function getEmptyDbKeyArray()
    {
        $values = array();
        $values['id'] = null;
        $values['codice_gruppo'] = null;
        $values['id_rata'] = null;
        $values['id_gruppo_fatturazione'] = null;
        $values['numero_documento'] = null;
        $values['tipo_documento'] = null;
        $values['data_scadenza'] = null;
        $values['data_emissione'] = null;
        $values['conto_corrente'] = null;
        $values['recapito'] = null;
        $values['unita_immobiliari'] = null;
        $values['id_locatore_fattura'] = null;
        $values['id_conduttore_fattura'] = null;
        $values['proprietari'] = null;
        $values['conduttori'] = null;
        $values['tipo_assoggettazione'] = null;
        $values['contabilizzato'] = 0;
        $values['flusso_controllato'] = 0;
        $values['flusso_inviato'] = 0;
        $values['id_fattura_pa'] = null;
        return $values;
    }

    /**
     * Return columns' list
     * @return string
     */
    public function getListColumns()
    {
        return 'fatturazione_testa.id as fatturazione_testa_id,fatturazione_testa.codice_gruppo as fatturazione_testa_codice_gruppo,fatturazione_testa.id_rata as fatturazione_testa_id_rata,fatturazione_testa.id_gruppo_fatturazione as fatturazione_testa_id_gruppo_fatturazione,fatturazione_testa.numero_documento as fatturazione_testa_numero_documento,fatturazione_testa.tipo_documento as fatturazione_testa_tipo_documento,fatturazione_testa.data_scadenza as fatturazione_testa_data_scadenza,fatturazione_testa.data_emissione as fatturazione_testa_data_emissione,fatturazione_testa.conto_corrente as fatturazione_testa_conto_corrente,fatturazione_testa.recapito as fatturazione_testa_recapito,fatturazione_testa.unita_immobiliari as fatturazione_testa_unita_immobiliari,fatturazione_testa.id_locatore_fattura as fatturazione_testa_id_locatore_fattura,fatturazione_testa.id_conduttore_fattura as fatturazione_testa_id_conduttore_fattura,fatturazione_testa.proprietari as fatturazione_testa_proprietari,fatturazione_testa.conduttori as fatturazione_testa_conduttori,fatturazione_testa.tipo_assoggettazione as fatturazione_testa_tipo_assoggettazione,fatturazione_testa.contabilizzato as fatturazione_testa_contabilizzato';
    }

    /**
     * DDL Table
     */
    public function createTable()
    {
        return $this->pdo->exec("CREATE TABLE `fatturazione_testa` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codice_gruppo` varchar(45) DEFAULT NULL,
  `id_rata` int(10) unsigned NOT NULL,
  `id_gruppo_fatturazione` int(10) unsigned NOT NULL,
  `numero_documento` int(10) unsigned DEFAULT NULL,
  `tipo_documento` varchar(45) DEFAULT NULL,
  `data_scadenza` date DEFAULT NULL,
  `data_emissione` date DEFAULT NULL,
  `conto_corrente` int(10) DEFAULT NULL,
  `recapito` json DEFAULT NULL,
  `unita_immobiliari` json DEFAULT NULL,
  `id_locatore_fattura` int(10) unsigned DEFAULT NULL,
  `id_conduttore_fattura` int(10) unsigned DEFAULT NULL,
  `proprietari` json DEFAULT NULL,
  `conduttori` json DEFAULT NULL,
  `tipo_assoggettazione` enum('N','S') DEFAULT NULL COMMENT 'N = NON ASSOGGETTO AD IVA\nS = ASSOGGETTO AD IVA',
  `contabilizzato` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_codice_gruppo` (`codice_gruppo`),
  KEY `idx_id_rata` (`id_rata`),
  KEY `idx_id_gruppo_fatturazione` (`id_gruppo_fatturazione`)
) ENGINE=InnoDB AUTO_INCREMENT=960 DEFAULT CHARSET=latin1 ");
    }

    /**
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param integer $id Id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return string
     */
    public function getCodiceGruppo()
    {
        return $this->codiceGruppo;
    }

    /**
     * @param string $codiceGruppo CodiceGruppo
     * @param int $encodeType
     */
    public function setCodiceGruppo($codiceGruppo, $encodeType = self::STR_DEFAULT)
    {
        $this->codiceGruppo = $this->decodeString($codiceGruppo, $encodeType);
    }

    /**
     * @return integer
     */
    public function getIdRata()
    {
        return $this->idRata;
    }

    /**
     * @param integer $idRata IdRata
     */
    public function setIdRata($idRata)
    {
        $this->idRata = $idRata;
    }

    /**
     * @return integer
     */
    public function getIdGruppoFatturazione()
    {
        return $this->idGruppoFatturazione;
    }

    /**
     * @param integer $idGruppoFatturazione IdGruppoFatturazione
     */
    public function setIdGruppoFatturazione($idGruppoFatturazione)
    {
        $this->idGruppoFatturazione = $idGruppoFatturazione;
    }

    /**
     * @return integer
     */
    public function getNumeroDocumento()
    {
        return $this->numeroDocumento;
    }

    /**
     * @param integer $numeroDocumento NumeroDocumento
     */
    public function setNumeroDocumento($numeroDocumento)
    {
        $this->numeroDocumento = $numeroDocumento;
    }

    /**
     * @return string
     */
    public function getTipoDocumento()
    {
        return $this->tipoDocumento;
    }

    /**
     * @param string $tipoDocumento TipoDocumento
     * @param int $encodeType
     */
    public function setTipoDocumento($tipoDocumento, $encodeType = self::STR_DEFAULT)
    {
        $this->tipoDocumento = $this->decodeString($tipoDocumento, $encodeType);
    }

    /**
     * @return string
     */
    public function getDataScadenza()
    {
        return $this->dataScadenza;
    }

    /**
     * @param string $dataScadenza DataScadenza
     * @param int $encodeType
     */
    public function setDataScadenza($dataScadenza, $encodeType = self::STR_DEFAULT)
    {
        $this->dataScadenza = $this->decodeString($dataScadenza, $encodeType);
    }

    /**
     * @return string
     */
    public function getDataEmissione()
    {
        return $this->dataEmissione;
    }

    /**
     * @param string $dataEmissione DataEmissione
     * @param int $encodeType
     */
    public function setDataEmissione($dataEmissione, $encodeType = self::STR_DEFAULT)
    {
        $this->dataEmissione = $this->decodeString($dataEmissione, $encodeType);
    }

    /**
     * @return integer
     */
    public function getContoCorrente()
    {
        return $this->contoCorrente;
    }

    /**
     * @param integer $contoCorrente ContoCorrente
     */
    public function setContoCorrente($contoCorrente)
    {
        $this->contoCorrente = $contoCorrente;
    }

    /**
     * @return objext (string)
     */
    public function getRecapito()
    {
        return $this->recapito;
    }

    /**
     * @param objext (string) $recapito Recapito
     */
    public function setRecapito($recapito)
    {
        $this->recapito = $recapito;
    }

    /**
     * @return objext (string)
     */
    public function getUnitaImmobiliari()
    {
        return $this->unitaImmobiliari;
    }

    /**
     * @param objext (string) $unitaImmobiliari UnitaImmobiliari
     */
    public function setUnitaImmobiliari($unitaImmobiliari)
    {
        $this->unitaImmobiliari = $unitaImmobiliari;
    }

    /**
     * @return integer
     */
    public function getIdLocatoreFattura()
    {
        return $this->idLocatoreFattura;
    }

    /**
     * @param integer $idLocatoreFattura IdLocatoreFattura
     */
    public function setIdLocatoreFattura($idLocatoreFattura)
    {
        $this->idLocatoreFattura = $idLocatoreFattura;
    }

    /**
     * @return integer
     */
    public function getIdConduttoreFattura()
    {
        return $this->idConduttoreFattura;
    }

    /**
     * @param integer $idConduttoreFattura IdConduttoreFattura
     */
    public function setIdConduttoreFattura($idConduttoreFattura)
    {
        $this->idConduttoreFattura = $idConduttoreFattura;
    }

    /**
     * @return objext (string)
     */
    public function getProprietari()
    {
        return $this->proprietari;
    }

    /**
     * @param objext (string) $proprietari Proprietari
     */
    public function setProprietari($proprietari)
    {
        $this->proprietari = $proprietari;
    }

    /**
     * @return objext (string)
     */
    public function getConduttori()
    {
        return $this->conduttori;
    }

    /**
     * @param objext (string) $conduttori Conduttori
     */
    public function setConduttori($conduttori)
    {
        $this->conduttori = $conduttori;
    }

    /**
     * @param bool $decode if true return decode value * @return string
     */
    public function getTipoAssoggettazione($decode = false)
    {
        return ($decode) ? $this->getTipoAssoggettazioneValuesList()[$this->tipoAssoggettazione] : $this->tipoAssoggettazione;
    }

    /**
     * @param bool $json if true return value json's array else return array values * @return array|string
     */
    public function getTipoAssoggettazioneValuesList($json = false)
    {
        $kv = ['N' => 'NON ASSOGGETTO AD IVA', 'S' => 'ASSOGGETTO AD IVA'];
        return ($json) ? $this->createJsonKeyValArray($kv) : $kv;
    }

    /**
     * @param string (enum) $tipoAssoggettazione TipoAssoggettazione
     */
    public function setTipoAssoggettazione($tipoAssoggettazione)
    {
        $this->tipoAssoggettazione = $tipoAssoggettazione;
    }

    /**
     * @return integer
     */
    public function getContabilizzato()
    {
        return $this->contabilizzato;
    }

    /**
     * @param integer $contabilizzato Contabilizzato
     */
    public function setContabilizzato($contabilizzato)
    {
        $this->contabilizzato = $contabilizzato;
    }

    /**
     * @return int
     */
    public function getFlussoControllato()
    {
        return $this->flussoControllato;
    }

    /**
     * @param int $flussoControllato
     */
    public function setFlussoControllato($flussoControllato)
    {
        $this->flussoControllato = $flussoControllato;
    }

    /**
     * @return int
     */
    public function getFlussoInviato()
    {
        return $this->flussoInviato;
    }

    /**
     * @param int $flussoInviato
     */
    public function setFlussoInviato($flussoInviato)
    {
        $this->flussoInviato = $flussoInviato;
    }

    /**
     * @return int
     */
    public function getIdFatturaPa()
    {
        return $this->idFatturaPa;
    }

    /**
     * @param int $idFatturaPa
     */
    public function setIdFatturaPa($idFatturaPa)
    {
        $this->idFatturaPa = $idFatturaPa;
    }
}