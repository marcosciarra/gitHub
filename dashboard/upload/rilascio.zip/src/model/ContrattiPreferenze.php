<?php
/**
* Created by Drakkar vers. 0.0.23(Hjortspring)
* User: P.D.A. Srl
* Date: 2017-12-06
* Time: 15:21:59.566271
*/
namespace Click\Affitti\TblBase;
require_once 'ContrattiPreferenzeModel.php';
use Click\Affitti\TblBase\ContrattiPreferenzeModel;

class  ContrattiPreferenze extends ContrattiPreferenzeModel {
function __construct($pdo){parent::__construct($pdo);}

}