<?php
/**
 * Created by PhpStorm.
 * User: Duca
 * Date: 28/05/18
 * Time: 16:02
 */

namespace Click\Affitti\Viste;
require_once 'ImpostaRegistro.php';
require_once 'Contratti.php';
require_once 'Anagrafiche.php';
require_once 'Rli.php';
require_once 'ContiCorrenti.php';
require_once 'UnitaImmobiliari.php';
require_once 'PianoRateTesta.php';

use Click\Affitti\TblBase\Anagrafiche;
use Click\Affitti\TblBase\Contratti;
use Click\Affitti\TblBase\ImpostaRegistro;
use Click\Affitti\TblBase\PdaAbstractModel;
use Click\Affitti\TblBase\Rli;
use Click\Affitti\TblBase\ContiCorrenti;
use Click\Affitti\TblBase\UnitaImmobiliari;
use Click\Affitti\TblBase\PianoRateTesta;

class PagamentoF24 extends PdaAbstractModel
{
    /** @var ImpostaRegistro */
    protected $impostaRegistro;

    /** @var Contratti */
    protected $contratto;

    /** @var Anagrafiche */
    protected $contribuente;

    /** @var Anagrafiche */
    protected $coobbligato;

    /** @var UnitaImmobiliari[] */
    protected $immobili;

    /** @var ContiCorrenti */
    protected $contoCorrente;

    /** @var string */
    protected $dataRegistrazione;

    /** @var string */
    protected $elementoIdentificativo;

    /** @var */
    protected $canoneAnnuo;

    /**
     * @inheritDoc
     */
    public function __construct($conn)
    {
        parent::__construct($conn);
        $this->impostaRegistro = null;
        $this->contratto = null;
        $this->contribuente = null;
        $this->coobbligato = null;
        $this->contoCorrente = null;
        $this->dataRegistrazione = null;
        $this->elementoIdentificativo = null;
        $this->canoneAnnuo = null;
        $this->immobili = [];
    }

    public function findProrogheByPeriodo($dataInizio, $dataFine, $typeResult = self::FETCH_OBJ)
    {
        $this->impostaRegistro = new ImpostaRegistro($this->conn);
        $result = [];
        /** @var ImpostaRegistro $impReg */
        foreach ($this->impostaRegistro->findProrogheByPeriodo($dataInizio, $dataFine) as $impReg) {
            $p = new self($this->conn);
            $p->setImpostaRegistro($impReg);
            $dataScadenza = explode('-', $impReg->getDataScadenza());
            $p->setDataRegistrazione(
                date('Y-m-d',mktime(null, null, null, $dataScadenza[1], $dataScadenza[2] , $dataScadenza[0]))
                );
            $contratto = new Contratti($this->conn);
            $contratto->findByPk($impReg->getIdContratto());

            if ($contratto->getTipoGestione() == 'S')
                continue;

            $p->setContratto($contratto);
            $rli = new Rli($this->conn);
            /** @var Rli $rli */
            foreach ($rli->findByIdContratto($contratto->getId()) as $rli) {
                //break;
            }
            $p->setElementoIdentificativo($rli->getCodiceIdentificativo());
            $pianoRateT = new PianoRateTesta($this->conn);
            $p->setCanoneAnnuo($pianoRateT->getImportoTotaleByIdGestione($impReg->getIdGestione(),'F'));

            $coobbligato = new Anagrafiche($this->conn);
            $p->setCoobbligato($coobbligato->findByPk($rli->getIdCoobbligato()));
            $contribuente = new Anagrafiche($this->conn);
            $p->setContribuente($contribuente->findByPk($rli->getIdContribuente()));
            $contoCorrente = new ContiCorrenti($this->conn);
            $p->setContoCorrente($contoCorrente->findByPk($rli->getIdContoCorrente()));
            $unitaImm = new UnitaImmobiliari($this->conn);
            $p->setImmobili($unitaImm->findByIdContratto($contratto->getId(), UnitaImmobiliari::FETCH_KEYARRAY));
            $result[] = $p;
        }

        if ($typeResult == self::FETCH_OBJ) {
            return $result;
        } else if ($typeResult == self::FETCH_KEYARRAY) {
            return $this->createResultKeyArray($result);
        }
    }


    public function findProrogheArretrate($oggi, $typeResult = self::FETCH_OBJ)
    {
        $this->impostaRegistro = new ImpostaRegistro($this->conn);
        $result = [];
        foreach ($this->impostaRegistro->findProrogheArretrate($oggi) as $impReg) {
            $p = new self($this->conn);
            $p->setImpostaRegistro($impReg);
            $contratto = new Contratti($this->conn);
            $contratto->findByPk($impReg->getIdContratto());

            if ($contratto->getTipoGestione() == 'S')
                continue;

            $p->setContratto($contratto);
            $rli = new Rli($this->conn);
            /** @var Rli $rli */
            foreach ($rli->findByIdContratto($contratto->getId()) as $rli) {
                break;
            }
            $coobbligato = new Anagrafiche($this->conn);
            $p->setCoobbligato($coobbligato->findByPk($rli->getIdCoobbligato()));
            $contribuente = new Anagrafiche($this->conn);
            $p->setContribuente($contribuente->findByPk($rli->getIdContribuente()));
            $contoCorrente = new ContiCorrenti($this->conn);
            $p->setContoCorrente($contoCorrente->findByPk($rli->getIdContoCorrente()));
            $unitaImm = new UnitaImmobiliari($this->conn);
            $p->setImmobili($unitaImm->findByIdContratto($contratto->getId(), UnitaImmobiliari::FETCH_KEYARRAY));
            $result[] = $p;
        }

        if ($typeResult == self::FETCH_OBJ) {
            return $result;
        } else if ($typeResult == self::FETCH_KEYARRAY) {
            return $this->createResultKeyArray($result);
        }
    }


    public function findByIdImpostaRegistro($idImpostaRegistro)
    {
        $this->impostaRegistro = new ImpostaRegistro($this->conn);
        $this->impostaRegistro->findByPk($idImpostaRegistro);
        $this->contratto = new Contratti($this->conn);
        $this->contratto->findByPk($this->impostaRegistro->getIdContratto());
    }


    public function createResultKeyArray($array)
    {
        if (is_array($array)) {
            $return = [];
            /** @var self $a */
            foreach ($array as $a) {
                $r = [];
                $r['imposta_registro'] = $a->getImpostaRegistro()->toArrayAssoc();
                $r['contratto'] = $a->getContratto()->toArrayAssoc();
                $r['contribuente'] = $a->getContribuente()->toArrayAssoc();
                $r['coobbligato'] = $a->getCoobbligato()->toArrayAssoc();
                $r['conto_corrente'] = $a->getContoCorrente()->toArrayAssoc();
                $r['immobili'] = $a->getImmobili();
                $r['data_registrazione'] = $a->getDataRegistrazione();
                $r['elemento_identificativo'] = $a->getElementoIdentificativo();
                $r['canone'] = $a->getCanoneAnnuo();
                $return[] = $r;
            }
        }

        return $return;
    }

    /**
     * @inheritDoc
     */
    public function toArrayAssoc()
    {

    }

    /**
     * @inheritDoc
     */
    public function createObjKeyArray(array $keyArray)
    {
        // TODO: Implement createObjKeyArray() method.
    }

    /**
     * @inheritDoc
     */
    public function createKeyArrayFromPositional($positionalArray)
    {
        // TODO: Implement createKeyArrayFromPositional() method.
    }

    /**
     * @inheritDoc
     */
    public function getListColumns()
    {
        // TODO: Implement getListColumns() method.
    }

    /**
     * @inheritDoc
     */
    public function createTable()
    {
        // TODO: Implement createTable() method.
    }

    public function getEmptyDbKeyArray()
    {
        // TODO: Implement getEmptyDbKeyArray() method.
    }

    /**
     * @return ImpostaRegistro
     */
    public function getImpostaRegistro(): ImpostaRegistro
    {
        return $this->impostaRegistro;
    }

    /**
     * @param ImpostaRegistro $impostaRegistro
     */
    public function setImpostaRegistro(ImpostaRegistro $impostaRegistro): void
    {
        $this->impostaRegistro = $impostaRegistro;
    }

    /**
     * @return Contratti
     */
    public function getContratto(): Contratti
    {
        return $this->contratto;
    }

    /**
     * @param Contratti $contratto
     */
    public function setContratto(Contratti $contratto): void
    {
        $this->contratto = $contratto;
    }

    /**
     * @return Anagrafiche
     */
    public function getContribuente(): Anagrafiche
    {
        return $this->contribuente;
    }

    /**
     * @param Anagrafiche $contribuente
     */
    public function setContribuente(Anagrafiche $contribuente): void
    {
        $this->contribuente = $contribuente;
    }

    /**
     * @return Anagrafiche
     */
    public function getCoobbligato(): Anagrafiche
    {
        return $this->coobbligato;
    }

    /**
     * @param Anagrafiche $coobbligato
     */
    public function setCoobbligato(Anagrafiche $coobbligato): void
    {
        $this->coobbligato = $coobbligato;
    }

    /**
     * @return ContiCorrenti
     */
    public function getContoCorrente(): ContiCorrenti
    {
        return $this->contoCorrente;
    }

    /**
     * @param ContiCorrenti $contoCorrente
     */
    public function setContoCorrente(ContiCorrenti $contoCorrente): void
    {
        $this->contoCorrente = $contoCorrente;
    }

    /**
     * @return UnitaImmobiliari[]
     */
    public function getImmobili(): array
    {
        return $this->immobili;
    }

    /**
     * @param UnitaImmobiliari[] $immobili
     */
    public function setImmobili(array $immobili): void
    {
        $this->immobili = $immobili;
    }

    /**
     * @return string
     */
    public function getDataRegistrazione()
    {
        return $this->dataRegistrazione;
    }

    /**
     * @param string $dataRegistrazione
     */
    public function setDataRegistrazione($dataRegistrazione)
    {
        $this->dataRegistrazione = $dataRegistrazione;
    }

    /**
     * @return string
     */
    public function getElementoIdentificativo()
    {
        return $this->elementoIdentificativo;
    }

    /**
     * @param string $elementoIdentificativo
     */
    public function setElementoIdentificativo($elementoIdentificativo)
    {
        $this->elementoIdentificativo = $elementoIdentificativo;
    }

    /**
     * @return mixed
     */
    public function getCanoneAnnuo()
    {
        return $this->canoneAnnuo;
    }

    /**
     * @param mixed $canoneAnnuo
     */
    public function setCanoneAnnuo($canoneAnnuo)
    {
        $this->canoneAnnuo = $canoneAnnuo;
    }

}