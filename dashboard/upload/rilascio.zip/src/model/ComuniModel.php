<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-15
* Time: 11:42:56.084300
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class ComuniModel extends PdaAbstractModel {
/** @var integer */
protected $id;
/** @var integer */
protected $codiceRegione;
/** @var integer */
protected $codiceCittaMetropolitana;
/** @var integer */
protected $codiceProvincia;
/** @var integer */
protected $progressivoComune;
/** @var string */
protected $codiceComuneAlfanum;
/** @var string */
protected $denominazione;
/** @var string */
protected $denominazioneAltraLingua;
/** @var string */
protected $codiceRipartizioneGeografica;
/** @var string */
protected $ripartizioneGeografica;
/** @var string */
protected $denominazioneRegione;
/** @var string */
protected $denominazioneCittaMetropolitana;
/** @var string */
protected $denominazioneProvincia;
/** @var integer */
protected $flgCapoluogo;
/** @var string */
protected $siglaAutomobilistica;
/** @var integer */
protected $codiceComuneNumerico;
/** @var integer */
protected $codiceComuneNumerico110;
/** @var integer */
protected $codiceComuneNumerico107;
/** @var integer */
protected $codiceComuneNumerico103;
/** @var string */
protected $codiceCatastale;
/** @var string */
protected $nuts1;
/** @var string */
protected $nuts2;
/** @var string */
protected $nuts3;
/** @var integer */
protected $idNazione;
/** @var string */
protected $prefissoTelefonico;
/** @var string */
protected $cap;
/** @var string */
protected $linkComuniItaliani;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='comuni';$this->tableName='comuni';}

/**
 * find by tables' Primary Key: 
 * @return Comuni|array|string|null
 */
public function findByPk($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($id), $typeResult);}
/**
 * delete by tables' Primary Key: 
 */
public function deleteByPk($id){$query = "DELETE FROM $this->tableName  WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($id));}
/**
 * Find all record of table
 * @return Comuni[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * find by tables' Key idx_id_nazione: 
 * @return Comuni[]|array|string
 */
public function findByIdxIdNazione($idNazione,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_id_nazione) WHERE id_nazione=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($idNazione), $typeResult);}

/**
 * find by tables' Key idx_denominazione: 
 * @return Comuni[]|array|string
 */
public function findByIdxDenominazione($denominazione,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_denominazione) WHERE denominazione=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($denominazione), $typeResult);}

/**
 * find by tables' Key idx_codice_comune_numerico: 
 * @return Comuni[]|array|string
 */
public function findByIdxCodiceComuneNumerico($codiceComuneNumerico,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_codice_comune_numerico) WHERE codice_comune_numerico=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($codiceComuneNumerico), $typeResult);}

/**
 * delete by tables' Key idx_id_nazione: 
 * @return boolean
 */
public function deleteByIdxIdNazione($idNazione,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_nazione=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idNazione));}
/**
 * delete by tables' Key idx_denominazione: 
 * @return boolean
 */
public function deleteByIdxDenominazione($denominazione,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE denominazione=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($denominazione));}
/**
 * delete by tables' Key idx_codice_comune_numerico: 
 * @return boolean
 */
public function deleteByIdxCodiceComuneNumerico($codiceComuneNumerico,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE codice_comune_numerico=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($codiceComuneNumerico));}
/**
 * find by id
 * @return Comuni[]
 */
public function findById($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($id), $typeResult);}


/**
 * find by denominazione
 * @return Comuni[]
 */
public function findByDenominazione($denominazione,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE denominazione=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($denominazione), $typeResult);}


/**
 * find like denominazione
 * @return Comuni[]
 */
public function findLikeDenominazione($denominazione,$likeMatching=self::LIKE_MATCHING_BOTH, $typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE denominazione like ?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($this->prepareLikeMatching($denominazione,$likeMatching)), $typeResult);}

/**
 * find by codice_comune_numerico
 * @return Comuni[]
 */
public function findByCodiceComuneNumerico($codiceComuneNumerico,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE codice_comune_numerico=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($codiceComuneNumerico), $typeResult);}


/**
 * find by id_nazione
 * @return Comuni[]
 */
public function findByIdNazione($idNazione,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id_nazione=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($idNazione), $typeResult);}


/**
 * delete by denominazione
 * @return boolean
 */
public function deleteByDenominazione($denominazione){$query = "DELETE FROM $this->tableName WHERE denominazione=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($denominazione));}

/**
 * delete by codice_comune_numerico
 * @return boolean
 */
public function deleteByCodiceComuneNumerico($codiceComuneNumerico){$query = "DELETE FROM $this->tableName WHERE codice_comune_numerico=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($codiceComuneNumerico));}

/**
 * delete by id_nazione
 * @return boolean
 */
public function deleteByIdNazione($idNazione){$query = "DELETE FROM $this->tableName WHERE id_nazione=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idNazione));}

/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->id))$arrayValue['id']=$this->id;if(isset($this->codiceRegione))$arrayValue['codice_regione']=($this->codiceRegione==self::NULL_VALUE)?null:$this->codiceRegione;if(isset($this->codiceCittaMetropolitana))$arrayValue['codice_citta_metropolitana']=($this->codiceCittaMetropolitana==self::NULL_VALUE)?null:$this->codiceCittaMetropolitana;if(isset($this->codiceProvincia))$arrayValue['codice_provincia']=($this->codiceProvincia==self::NULL_VALUE)?null:$this->codiceProvincia;if(isset($this->progressivoComune))$arrayValue['progressivo_comune']=($this->progressivoComune==self::NULL_VALUE)?null:$this->progressivoComune;if(isset($this->codiceComuneAlfanum))$arrayValue['codice_comune_alfanum']=($this->codiceComuneAlfanum==self::NULL_VALUE)?null:$this->codiceComuneAlfanum;if(isset($this->denominazione))$arrayValue['denominazione']=($this->denominazione==self::NULL_VALUE)?null:$this->denominazione;if(isset($this->denominazioneAltraLingua))$arrayValue['denominazione_altra_lingua']=($this->denominazioneAltraLingua==self::NULL_VALUE)?null:$this->denominazioneAltraLingua;if(isset($this->codiceRipartizioneGeografica))$arrayValue['codice_ripartizione_geografica']=($this->codiceRipartizioneGeografica==self::NULL_VALUE)?null:$this->codiceRipartizioneGeografica;if(isset($this->ripartizioneGeografica))$arrayValue['ripartizione_geografica']=($this->ripartizioneGeografica==self::NULL_VALUE)?null:$this->ripartizioneGeografica;if(isset($this->denominazioneRegione))$arrayValue['denominazione_regione']=($this->denominazioneRegione==self::NULL_VALUE)?null:$this->denominazioneRegione;if(isset($this->denominazioneCittaMetropolitana))$arrayValue['denominazione_citta_metropolitana']=($this->denominazioneCittaMetropolitana==self::NULL_VALUE)?null:$this->denominazioneCittaMetropolitana;if(isset($this->denominazioneProvincia))$arrayValue['denominazione_provincia']=($this->denominazioneProvincia==self::NULL_VALUE)?null:$this->denominazioneProvincia;if(isset($this->flgCapoluogo))$arrayValue['flg_capoluogo']=($this->flgCapoluogo==self::NULL_VALUE)?null:$this->flgCapoluogo;if(isset($this->siglaAutomobilistica))$arrayValue['sigla_automobilistica']=($this->siglaAutomobilistica==self::NULL_VALUE)?null:$this->siglaAutomobilistica;if(isset($this->codiceComuneNumerico))$arrayValue['codice_comune_numerico']=($this->codiceComuneNumerico==self::NULL_VALUE)?null:$this->codiceComuneNumerico;if(isset($this->codiceComuneNumerico110))$arrayValue['codice_comune_numerico_110']=($this->codiceComuneNumerico110==self::NULL_VALUE)?null:$this->codiceComuneNumerico110;if(isset($this->codiceComuneNumerico107))$arrayValue['codice_comune_numerico_107']=($this->codiceComuneNumerico107==self::NULL_VALUE)?null:$this->codiceComuneNumerico107;if(isset($this->codiceComuneNumerico103))$arrayValue['codice_comune_numerico_103']=($this->codiceComuneNumerico103==self::NULL_VALUE)?null:$this->codiceComuneNumerico103;if(isset($this->codiceCatastale))$arrayValue['codice_catastale']=($this->codiceCatastale==self::NULL_VALUE)?null:$this->codiceCatastale;if(isset($this->nuts1))$arrayValue['nuts1']=($this->nuts1==self::NULL_VALUE)?null:$this->nuts1;if(isset($this->nuts2))$arrayValue['nuts2']=($this->nuts2==self::NULL_VALUE)?null:$this->nuts2;if(isset($this->nuts3))$arrayValue['nuts3']=($this->nuts3==self::NULL_VALUE)?null:$this->nuts3;if(isset($this->idNazione))$arrayValue['id_nazione']=($this->idNazione==self::NULL_VALUE)?null:$this->idNazione;if(isset($this->prefissoTelefonico))$arrayValue['prefisso_telefonico']=($this->prefissoTelefonico==self::NULL_VALUE)?null:$this->prefissoTelefonico;if(isset($this->cap))$arrayValue['cap']=($this->cap==self::NULL_VALUE)?null:$this->cap;if(isset($this->linkComuniItaliani))$arrayValue['link_comuni_italiani']=($this->linkComuniItaliani==self::NULL_VALUE)?null:$this->linkComuniItaliani;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['id'])) || (isset($keyArray['comuni_id']))) {$this->setId(isset($keyArray['id'])?$keyArray['id']:$keyArray['comuni_id']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['codice_regione'])) || (isset($keyArray['comuni_codice_regione']))) {$this->setCodiceregione(isset($keyArray['codice_regione'])?$keyArray['codice_regione']:$keyArray['comuni_codice_regione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['codice_citta_metropolitana'])) || (isset($keyArray['comuni_codice_citta_metropolitana']))) {$this->setCodicecittametropolitana(isset($keyArray['codice_citta_metropolitana'])?$keyArray['codice_citta_metropolitana']:$keyArray['comuni_codice_citta_metropolitana']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['codice_provincia'])) || (isset($keyArray['comuni_codice_provincia']))) {$this->setCodiceprovincia(isset($keyArray['codice_provincia'])?$keyArray['codice_provincia']:$keyArray['comuni_codice_provincia']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['progressivo_comune'])) || (isset($keyArray['comuni_progressivo_comune']))) {$this->setProgressivocomune(isset($keyArray['progressivo_comune'])?$keyArray['progressivo_comune']:$keyArray['comuni_progressivo_comune']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['codice_comune_alfanum'])) || (isset($keyArray['comuni_codice_comune_alfanum']))) {$this->setCodicecomunealfanum(isset($keyArray['codice_comune_alfanum'])?$keyArray['codice_comune_alfanum']:$keyArray['comuni_codice_comune_alfanum']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['denominazione'])) || (isset($keyArray['comuni_denominazione']))) {$this->setDenominazione(isset($keyArray['denominazione'])?$keyArray['denominazione']:$keyArray['comuni_denominazione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['denominazione_altra_lingua'])) || (isset($keyArray['comuni_denominazione_altra_lingua']))) {$this->setDenominazionealtralingua(isset($keyArray['denominazione_altra_lingua'])?$keyArray['denominazione_altra_lingua']:$keyArray['comuni_denominazione_altra_lingua']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['codice_ripartizione_geografica'])) || (isset($keyArray['comuni_codice_ripartizione_geografica']))) {$this->setCodiceripartizionegeografica(isset($keyArray['codice_ripartizione_geografica'])?$keyArray['codice_ripartizione_geografica']:$keyArray['comuni_codice_ripartizione_geografica']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['ripartizione_geografica'])) || (isset($keyArray['comuni_ripartizione_geografica']))) {$this->setRipartizionegeografica(isset($keyArray['ripartizione_geografica'])?$keyArray['ripartizione_geografica']:$keyArray['comuni_ripartizione_geografica']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['denominazione_regione'])) || (isset($keyArray['comuni_denominazione_regione']))) {$this->setDenominazioneregione(isset($keyArray['denominazione_regione'])?$keyArray['denominazione_regione']:$keyArray['comuni_denominazione_regione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['denominazione_citta_metropolitana'])) || (isset($keyArray['comuni_denominazione_citta_metropolitana']))) {$this->setDenominazionecittametropolitana(isset($keyArray['denominazione_citta_metropolitana'])?$keyArray['denominazione_citta_metropolitana']:$keyArray['comuni_denominazione_citta_metropolitana']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['denominazione_provincia'])) || (isset($keyArray['comuni_denominazione_provincia']))) {$this->setDenominazioneprovincia(isset($keyArray['denominazione_provincia'])?$keyArray['denominazione_provincia']:$keyArray['comuni_denominazione_provincia']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['flg_capoluogo'])) || (isset($keyArray['comuni_flg_capoluogo']))) {$this->setFlgcapoluogo(isset($keyArray['flg_capoluogo'])?$keyArray['flg_capoluogo']:$keyArray['comuni_flg_capoluogo']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['sigla_automobilistica'])) || (isset($keyArray['comuni_sigla_automobilistica']))) {$this->setSiglaautomobilistica(isset($keyArray['sigla_automobilistica'])?$keyArray['sigla_automobilistica']:$keyArray['comuni_sigla_automobilistica']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['codice_comune_numerico'])) || (isset($keyArray['comuni_codice_comune_numerico']))) {$this->setCodicecomunenumerico(isset($keyArray['codice_comune_numerico'])?$keyArray['codice_comune_numerico']:$keyArray['comuni_codice_comune_numerico']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['codice_comune_numerico_110'])) || (isset($keyArray['comuni_codice_comune_numerico_110']))) {$this->setCodicecomunenumerico110(isset($keyArray['codice_comune_numerico_110'])?$keyArray['codice_comune_numerico_110']:$keyArray['comuni_codice_comune_numerico_110']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['codice_comune_numerico_107'])) || (isset($keyArray['comuni_codice_comune_numerico_107']))) {$this->setCodicecomunenumerico107(isset($keyArray['codice_comune_numerico_107'])?$keyArray['codice_comune_numerico_107']:$keyArray['comuni_codice_comune_numerico_107']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['codice_comune_numerico_103'])) || (isset($keyArray['comuni_codice_comune_numerico_103']))) {$this->setCodicecomunenumerico103(isset($keyArray['codice_comune_numerico_103'])?$keyArray['codice_comune_numerico_103']:$keyArray['comuni_codice_comune_numerico_103']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['codice_catastale'])) || (isset($keyArray['comuni_codice_catastale']))) {$this->setCodicecatastale(isset($keyArray['codice_catastale'])?$keyArray['codice_catastale']:$keyArray['comuni_codice_catastale']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['nuts1'])) || (isset($keyArray['comuni_nuts1']))) {$this->setNuts1(isset($keyArray['nuts1'])?$keyArray['nuts1']:$keyArray['comuni_nuts1']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['nuts2'])) || (isset($keyArray['comuni_nuts2']))) {$this->setNuts2(isset($keyArray['nuts2'])?$keyArray['nuts2']:$keyArray['comuni_nuts2']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['nuts3'])) || (isset($keyArray['comuni_nuts3']))) {$this->setNuts3(isset($keyArray['nuts3'])?$keyArray['nuts3']:$keyArray['comuni_nuts3']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_nazione'])) || (isset($keyArray['comuni_id_nazione']))) {$this->setIdnazione(isset($keyArray['id_nazione'])?$keyArray['id_nazione']:$keyArray['comuni_id_nazione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['prefisso_telefonico'])) || (isset($keyArray['comuni_prefisso_telefonico']))) {$this->setPrefissotelefonico(isset($keyArray['prefisso_telefonico'])?$keyArray['prefisso_telefonico']:$keyArray['comuni_prefisso_telefonico']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['cap'])) || (isset($keyArray['comuni_cap']))) {$this->setCap(isset($keyArray['cap'])?$keyArray['cap']:$keyArray['comuni_cap']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['link_comuni_italiani'])) || (isset($keyArray['comuni_link_comuni_italiani']))) {$this->setLinkcomuniitaliani(isset($keyArray['link_comuni_italiani'])?$keyArray['link_comuni_italiani']:$keyArray['comuni_link_comuni_italiani']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['id'] =$positionalArray[0];$values['codice_regione'] =($positionalArray[1]==self::NULL_VALUE)?null:$positionalArray[1];$values['codice_citta_metropolitana'] =($positionalArray[2]==self::NULL_VALUE)?null:$positionalArray[2];$values['codice_provincia'] =($positionalArray[3]==self::NULL_VALUE)?null:$positionalArray[3];$values['progressivo_comune'] =($positionalArray[4]==self::NULL_VALUE)?null:$positionalArray[4];$values['codice_comune_alfanum'] =($positionalArray[5]==self::NULL_VALUE)?null:$positionalArray[5];$values['denominazione'] =($positionalArray[6]==self::NULL_VALUE)?null:$positionalArray[6];$values['denominazione_altra_lingua'] =($positionalArray[7]==self::NULL_VALUE)?null:$positionalArray[7];$values['codice_ripartizione_geografica'] =($positionalArray[8]==self::NULL_VALUE)?null:$positionalArray[8];$values['ripartizione_geografica'] =($positionalArray[9]==self::NULL_VALUE)?null:$positionalArray[9];$values['denominazione_regione'] =($positionalArray[10]==self::NULL_VALUE)?null:$positionalArray[10];$values['denominazione_citta_metropolitana'] =($positionalArray[11]==self::NULL_VALUE)?null:$positionalArray[11];$values['denominazione_provincia'] =($positionalArray[12]==self::NULL_VALUE)?null:$positionalArray[12];$values['flg_capoluogo'] =($positionalArray[13]==self::NULL_VALUE)?null:$positionalArray[13];$values['sigla_automobilistica'] =($positionalArray[14]==self::NULL_VALUE)?null:$positionalArray[14];$values['codice_comune_numerico'] =($positionalArray[15]==self::NULL_VALUE)?null:$positionalArray[15];$values['codice_comune_numerico_110'] =($positionalArray[16]==self::NULL_VALUE)?null:$positionalArray[16];$values['codice_comune_numerico_107'] =($positionalArray[17]==self::NULL_VALUE)?null:$positionalArray[17];$values['codice_comune_numerico_103'] =($positionalArray[18]==self::NULL_VALUE)?null:$positionalArray[18];$values['codice_catastale'] =($positionalArray[19]==self::NULL_VALUE)?null:$positionalArray[19];$values['nuts1'] =($positionalArray[20]==self::NULL_VALUE)?null:$positionalArray[20];$values['nuts2'] =($positionalArray[21]==self::NULL_VALUE)?null:$positionalArray[21];$values['nuts3'] =($positionalArray[22]==self::NULL_VALUE)?null:$positionalArray[22];$values['id_nazione'] =($positionalArray[23]==self::NULL_VALUE)?null:$positionalArray[23];$values['prefisso_telefonico'] =($positionalArray[24]==self::NULL_VALUE)?null:$positionalArray[24];$values['cap'] =($positionalArray[25]==self::NULL_VALUE)?null:$positionalArray[25];$values['link_comuni_italiani'] =($positionalArray[26]==self::NULL_VALUE)?null:$positionalArray[26];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['id'] = null;$values['codice_regione'] = null;$values['codice_citta_metropolitana'] = null;$values['codice_provincia'] = null;$values['progressivo_comune'] = null;$values['codice_comune_alfanum'] = null;$values['denominazione'] = null;$values['denominazione_altra_lingua'] = null;$values['codice_ripartizione_geografica'] = null;$values['ripartizione_geografica'] = null;$values['denominazione_regione'] = null;$values['denominazione_citta_metropolitana'] = null;$values['denominazione_provincia'] = null;$values['flg_capoluogo'] = null;$values['sigla_automobilistica'] = null;$values['codice_comune_numerico'] = null;$values['codice_comune_numerico_110'] = null;$values['codice_comune_numerico_107'] = null;$values['codice_comune_numerico_103'] = null;$values['codice_catastale'] = null;$values['nuts1'] = null;$values['nuts2'] = null;$values['nuts3'] = null;$values['id_nazione'] = null;$values['prefisso_telefonico'] = null;$values['cap'] = null;$values['link_comuni_italiani'] = null;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'comuni.id as comuni_id,comuni.codice_regione as comuni_codice_regione,comuni.codice_citta_metropolitana as comuni_codice_citta_metropolitana,comuni.codice_provincia as comuni_codice_provincia,comuni.progressivo_comune as comuni_progressivo_comune,comuni.codice_comune_alfanum as comuni_codice_comune_alfanum,comuni.denominazione as comuni_denominazione,comuni.denominazione_altra_lingua as comuni_denominazione_altra_lingua,comuni.codice_ripartizione_geografica as comuni_codice_ripartizione_geografica,comuni.ripartizione_geografica as comuni_ripartizione_geografica,comuni.denominazione_regione as comuni_denominazione_regione,comuni.denominazione_citta_metropolitana as comuni_denominazione_citta_metropolitana,comuni.denominazione_provincia as comuni_denominazione_provincia,comuni.flg_capoluogo as comuni_flg_capoluogo,comuni.sigla_automobilistica as comuni_sigla_automobilistica,comuni.codice_comune_numerico as comuni_codice_comune_numerico,comuni.codice_comune_numerico_110 as comuni_codice_comune_numerico_110,comuni.codice_comune_numerico_107 as comuni_codice_comune_numerico_107,comuni.codice_comune_numerico_103 as comuni_codice_comune_numerico_103,comuni.codice_catastale as comuni_codice_catastale,comuni.nuts1 as comuni_nuts1,comuni.nuts2 as comuni_nuts2,comuni.nuts3 as comuni_nuts3,comuni.id_nazione as comuni_id_nazione,comuni.prefisso_telefonico as comuni_prefisso_telefonico,comuni.cap as comuni_cap,comuni.link_comuni_italiani as comuni_link_comuni_italiani';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `comuni` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codice_regione` int(11) DEFAULT NULL,
  `codice_citta_metropolitana` int(11) DEFAULT NULL,
  `codice_provincia` int(11) DEFAULT NULL,
  `progressivo_comune` int(11) DEFAULT NULL,
  `codice_comune_alfanum` varchar(6) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `denominazione` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `denominazione_altra_lingua` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `codice_ripartizione_geografica` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `ripartizione_geografica` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `denominazione_regione` varchar(60) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `denominazione_citta_metropolitana` varchar(45) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `denominazione_provincia` varchar(45) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `flg_capoluogo` tinyint(1) DEFAULT NULL,
  `sigla_automobilistica` varchar(2) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `codice_comune_numerico` int(11) DEFAULT NULL,
  `codice_comune_numerico_110` int(11) DEFAULT NULL,
  `codice_comune_numerico_107` int(11) DEFAULT NULL,
  `codice_comune_numerico_103` int(11) DEFAULT NULL,
  `codice_catastale` varchar(4) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `nuts1` varchar(3) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `nuts2` varchar(4) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `nuts3` varchar(5) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `id_nazione` int(11) DEFAULT NULL,
  `prefisso_telefonico` varchar(5) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `cap` varchar(5) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `link_comuni_italiani` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_id_nazione` (`id_nazione`),
  KEY `idx_denominazione` (`denominazione`) USING BTREE,
  KEY `idx_codice_comune_numerico` (`codice_comune_numerico`),
  CONSTRAINT `fk_comuni_1` FOREIGN KEY (`id_nazione`) REFERENCES `nazioni` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7961 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ");}
/**
 * @return integer
 */
public function getId(){return $this->id;}
/**
 * @param integer $id Id
 */
public function setId($id){$this->id=$id;}
/**
 * @return integer
 */
public function getCodiceRegione(){return $this->codiceRegione;}
/**
 * @param integer $codiceRegione CodiceRegione
 */
public function setCodiceRegione($codiceRegione){$this->codiceRegione=$codiceRegione;}
/**
 * @return integer
 */
public function getCodiceCittaMetropolitana(){return $this->codiceCittaMetropolitana;}
/**
 * @param integer $codiceCittaMetropolitana CodiceCittaMetropolitana
 */
public function setCodiceCittaMetropolitana($codiceCittaMetropolitana){$this->codiceCittaMetropolitana=$codiceCittaMetropolitana;}
/**
 * @return integer
 */
public function getCodiceProvincia(){return $this->codiceProvincia;}
/**
 * @param integer $codiceProvincia CodiceProvincia
 */
public function setCodiceProvincia($codiceProvincia){$this->codiceProvincia=$codiceProvincia;}
/**
 * @return integer
 */
public function getProgressivoComune(){return $this->progressivoComune;}
/**
 * @param integer $progressivoComune ProgressivoComune
 */
public function setProgressivoComune($progressivoComune){$this->progressivoComune=$progressivoComune;}
/**
 * @return string
 */
public function getCodiceComuneAlfanum(){return $this->codiceComuneAlfanum;}
/**
 * @param string $codiceComuneAlfanum CodiceComuneAlfanum
 * @param int $encodeType
 */
public function setCodiceComuneAlfanum($codiceComuneAlfanum,$encodeType = self::STR_DEFAULT){$this->codiceComuneAlfanum=$this->decodeString($codiceComuneAlfanum,$encodeType);}
/**
 * @return string
 */
public function getDenominazione(){return $this->denominazione;}
/**
 * @param string $denominazione Denominazione
 * @param int $encodeType
 */
public function setDenominazione($denominazione,$encodeType = self::STR_DEFAULT){$this->denominazione=$this->decodeString($denominazione,$encodeType);}
/**
 * @return string
 */
public function getDenominazioneAltraLingua(){return $this->denominazioneAltraLingua;}
/**
 * @param string $denominazioneAltraLingua DenominazioneAltraLingua
 * @param int $encodeType
 */
public function setDenominazioneAltraLingua($denominazioneAltraLingua,$encodeType = self::STR_DEFAULT){$this->denominazioneAltraLingua=$this->decodeString($denominazioneAltraLingua,$encodeType);}
/**
 * @return string
 */
public function getCodiceRipartizioneGeografica(){return $this->codiceRipartizioneGeografica;}
/**
 * @param string $codiceRipartizioneGeografica CodiceRipartizioneGeografica
 * @param int $encodeType
 */
public function setCodiceRipartizioneGeografica($codiceRipartizioneGeografica,$encodeType = self::STR_DEFAULT){$this->codiceRipartizioneGeografica=$this->decodeString($codiceRipartizioneGeografica,$encodeType);}
/**
 * @return string
 */
public function getRipartizioneGeografica(){return $this->ripartizioneGeografica;}
/**
 * @param string $ripartizioneGeografica RipartizioneGeografica
 * @param int $encodeType
 */
public function setRipartizioneGeografica($ripartizioneGeografica,$encodeType = self::STR_DEFAULT){$this->ripartizioneGeografica=$this->decodeString($ripartizioneGeografica,$encodeType);}
/**
 * @return string
 */
public function getDenominazioneRegione(){return $this->denominazioneRegione;}
/**
 * @param string $denominazioneRegione DenominazioneRegione
 * @param int $encodeType
 */
public function setDenominazioneRegione($denominazioneRegione,$encodeType = self::STR_DEFAULT){$this->denominazioneRegione=$this->decodeString($denominazioneRegione,$encodeType);}
/**
 * @return string
 */
public function getDenominazioneCittaMetropolitana(){return $this->denominazioneCittaMetropolitana;}
/**
 * @param string $denominazioneCittaMetropolitana DenominazioneCittaMetropolitana
 * @param int $encodeType
 */
public function setDenominazioneCittaMetropolitana($denominazioneCittaMetropolitana,$encodeType = self::STR_DEFAULT){$this->denominazioneCittaMetropolitana=$this->decodeString($denominazioneCittaMetropolitana,$encodeType);}
/**
 * @return string
 */
public function getDenominazioneProvincia(){return $this->denominazioneProvincia;}
/**
 * @param string $denominazioneProvincia DenominazioneProvincia
 * @param int $encodeType
 */
public function setDenominazioneProvincia($denominazioneProvincia,$encodeType = self::STR_DEFAULT){$this->denominazioneProvincia=$this->decodeString($denominazioneProvincia,$encodeType);}
/**
 * @return integer
 */
public function getFlgCapoluogo(){return $this->flgCapoluogo;}
/**
 * @param integer $flgCapoluogo FlgCapoluogo
 */
public function setFlgCapoluogo($flgCapoluogo){$this->flgCapoluogo=$flgCapoluogo;}
/**
 * @return string
 */
public function getSiglaAutomobilistica(){return $this->siglaAutomobilistica;}
/**
 * @param string $siglaAutomobilistica SiglaAutomobilistica
 * @param int $encodeType
 */
public function setSiglaAutomobilistica($siglaAutomobilistica,$encodeType = self::STR_DEFAULT){$this->siglaAutomobilistica=$this->decodeString($siglaAutomobilistica,$encodeType);}
/**
 * @return integer
 */
public function getCodiceComuneNumerico(){return $this->codiceComuneNumerico;}
/**
 * @param integer $codiceComuneNumerico CodiceComuneNumerico
 */
public function setCodiceComuneNumerico($codiceComuneNumerico){$this->codiceComuneNumerico=$codiceComuneNumerico;}
/**
 * @return integer
 */
public function getCodiceComuneNumerico110(){return $this->codiceComuneNumerico110;}
/**
 * @param integer $codiceComuneNumerico110 CodiceComuneNumerico110
 */
public function setCodiceComuneNumerico110($codiceComuneNumerico110){$this->codiceComuneNumerico110=$codiceComuneNumerico110;}
/**
 * @return integer
 */
public function getCodiceComuneNumerico107(){return $this->codiceComuneNumerico107;}
/**
 * @param integer $codiceComuneNumerico107 CodiceComuneNumerico107
 */
public function setCodiceComuneNumerico107($codiceComuneNumerico107){$this->codiceComuneNumerico107=$codiceComuneNumerico107;}
/**
 * @return integer
 */
public function getCodiceComuneNumerico103(){return $this->codiceComuneNumerico103;}
/**
 * @param integer $codiceComuneNumerico103 CodiceComuneNumerico103
 */
public function setCodiceComuneNumerico103($codiceComuneNumerico103){$this->codiceComuneNumerico103=$codiceComuneNumerico103;}
/**
 * @return string
 */
public function getCodiceCatastale(){return $this->codiceCatastale;}
/**
 * @param string $codiceCatastale CodiceCatastale
 * @param int $encodeType
 */
public function setCodiceCatastale($codiceCatastale,$encodeType = self::STR_DEFAULT){$this->codiceCatastale=$this->decodeString($codiceCatastale,$encodeType);}
/**
 * @return string
 */
public function getNuts1(){return $this->nuts1;}
/**
 * @param string $nuts1 Nuts1
 * @param int $encodeType
 */
public function setNuts1($nuts1,$encodeType = self::STR_DEFAULT){$this->nuts1=$this->decodeString($nuts1,$encodeType);}
/**
 * @return string
 */
public function getNuts2(){return $this->nuts2;}
/**
 * @param string $nuts2 Nuts2
 * @param int $encodeType
 */
public function setNuts2($nuts2,$encodeType = self::STR_DEFAULT){$this->nuts2=$this->decodeString($nuts2,$encodeType);}
/**
 * @return string
 */
public function getNuts3(){return $this->nuts3;}
/**
 * @param string $nuts3 Nuts3
 * @param int $encodeType
 */
public function setNuts3($nuts3,$encodeType = self::STR_DEFAULT){$this->nuts3=$this->decodeString($nuts3,$encodeType);}
/**
 * @return integer
 */
public function getIdNazione(){return $this->idNazione;}
/**
 * @param integer $idNazione IdNazione
 */
public function setIdNazione($idNazione){$this->idNazione=$idNazione;}
/**
 * @return string
 */
public function getPrefissoTelefonico(){return $this->prefissoTelefonico;}
/**
 * @param string $prefissoTelefonico PrefissoTelefonico
 * @param int $encodeType
 */
public function setPrefissoTelefonico($prefissoTelefonico,$encodeType = self::STR_DEFAULT){$this->prefissoTelefonico=$this->decodeString($prefissoTelefonico,$encodeType);}
/**
 * @return string
 */
public function getCap(){return $this->cap;}
/**
 * @param string $cap Cap
 * @param int $encodeType
 */
public function setCap($cap,$encodeType = self::STR_DEFAULT){$this->cap=$this->decodeString($cap,$encodeType);}
/**
 * @return string
 */
public function getLinkComuniItaliani(){return $this->linkComuniItaliani;}
/**
 * @param string $linkComuniItaliani LinkComuniItaliani
 * @param int $encodeType
 */
public function setLinkComuniItaliani($linkComuniItaliani,$encodeType = self::STR_DEFAULT){$this->linkComuniItaliani=$this->decodeString($linkComuniItaliani,$encodeType);}
}