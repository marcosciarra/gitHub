<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-15
* Time: 11:42:47.505660
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class GestioniModel extends PdaAbstractModel {
/** @var integer */
protected $id;
/** @var integer */
protected $idPeriodoContrattuale;
/** @var string */
protected $dataInizio;
/** @var string */
protected $dataFine;
/** @var string */
protected $descrizione;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='gestioni';$this->tableName='gestioni';}

/**
 * find by tables' Primary Key: 
 * @return Gestioni|array|string|null
 */
public function findByPk($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($id), $typeResult);}
/**
 * delete by tables' Primary Key: 
 */
public function deleteByPk($id){$query = "DELETE FROM $this->tableName  WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($id));}
/**
 * Find all record of table
 * @return Gestioni[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * find by tables' Key fk_id_periodo_contrattuale_idx: 
 * @return Gestioni[]|array|string
 */
public function findByFkIdPeriodoContrattualeIdx($idPeriodoContrattuale,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(fk_id_periodo_contrattuale_idx) WHERE id_periodo_contrattuale=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($idPeriodoContrattuale), $typeResult);}

/**
 * delete by tables' Key fk_id_periodo_contrattuale_idx: 
 * @return boolean
 */
public function deleteByFkIdPeriodoContrattualeIdx($idPeriodoContrattuale,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_periodo_contrattuale=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idPeriodoContrattuale));}
/**
 * find by id
 * @return Gestioni[]
 */
public function findById($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($id), $typeResult);}


/**
 * find by id_periodo_contrattuale
 * @return Gestioni[]
 */
public function findByIdPeriodoContrattuale($idPeriodoContrattuale,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id_periodo_contrattuale=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($idPeriodoContrattuale), $typeResult);}


/**
 * delete by id_periodo_contrattuale
 * @return boolean
 */
public function deleteByIdPeriodoContrattuale($idPeriodoContrattuale){$query = "DELETE FROM $this->tableName WHERE id_periodo_contrattuale=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idPeriodoContrattuale));}

/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->id))$arrayValue['id']=$this->id;if(isset($this->idPeriodoContrattuale))$arrayValue['id_periodo_contrattuale']=$this->idPeriodoContrattuale;if(isset($this->dataInizio))$arrayValue['data_inizio']=$this->dataInizio;if(isset($this->dataFine))$arrayValue['data_fine']=$this->dataFine;if(isset($this->descrizione))$arrayValue['descrizione']=$this->descrizione;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['id'])) || (isset($keyArray['gestioni_id']))) {$this->setId(isset($keyArray['id'])?$keyArray['id']:$keyArray['gestioni_id']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_periodo_contrattuale'])) || (isset($keyArray['gestioni_id_periodo_contrattuale']))) {$this->setIdperiodocontrattuale(isset($keyArray['id_periodo_contrattuale'])?$keyArray['id_periodo_contrattuale']:$keyArray['gestioni_id_periodo_contrattuale']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['data_inizio'])) || (isset($keyArray['gestioni_data_inizio']))) {$this->setDatainizio(isset($keyArray['data_inizio'])?$keyArray['data_inizio']:$keyArray['gestioni_data_inizio']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['data_fine'])) || (isset($keyArray['gestioni_data_fine']))) {$this->setDatafine(isset($keyArray['data_fine'])?$keyArray['data_fine']:$keyArray['gestioni_data_fine']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['descrizione'])) || (isset($keyArray['gestioni_descrizione']))) {$this->setDescrizione(isset($keyArray['descrizione'])?$keyArray['descrizione']:$keyArray['gestioni_descrizione']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['id'] =$positionalArray[0];$values['id_periodo_contrattuale'] =$positionalArray[1];$values['data_inizio'] =$positionalArray[2];$values['data_fine'] =$positionalArray[3];$values['descrizione'] =$positionalArray[4];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['id'] = null;$values['id_periodo_contrattuale'] = null;$values['data_inizio'] = null;$values['data_fine'] = null;$values['descrizione'] = null;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'gestioni.id as gestioni_id,gestioni.id_periodo_contrattuale as gestioni_id_periodo_contrattuale,gestioni.data_inizio as gestioni_data_inizio,gestioni.data_fine as gestioni_data_fine,gestioni.descrizione as gestioni_descrizione';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `gestioni` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_periodo_contrattuale` int(10) unsigned NOT NULL,
  `data_inizio` date NOT NULL,
  `data_fine` date NOT NULL,
  `descrizione` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_id_periodo_contrattuale_idx` (`id_periodo_contrattuale`),
  CONSTRAINT `fk_id_periodo_contrattuale` FOREIGN KEY (`id_periodo_contrattuale`) REFERENCES `periodi_contrattuali` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=756 DEFAULT CHARSET=latin1 ");}
/**
 * @return integer
 */
public function getId(){return $this->id;}
/**
 * @param integer $id Id
 */
public function setId($id){$this->id=$id;}
/**
 * @return integer
 */
public function getIdPeriodoContrattuale(){return $this->idPeriodoContrattuale;}
/**
 * @param integer $idPeriodoContrattuale IdPeriodoContrattuale
 */
public function setIdPeriodoContrattuale($idPeriodoContrattuale){$this->idPeriodoContrattuale=$idPeriodoContrattuale;}
/**
 * @return string
 */
public function getDataInizio(){return $this->dataInizio;}
/**
 * @param string $dataInizio DataInizio
 * @param int $encodeType
 */
public function setDataInizio($dataInizio,$encodeType = self::STR_DEFAULT){$this->dataInizio=$this->decodeString($dataInizio,$encodeType);}
/**
 * @return string
 */
public function getDataFine(){return $this->dataFine;}
/**
 * @param string $dataFine DataFine
 * @param int $encodeType
 */
public function setDataFine($dataFine,$encodeType = self::STR_DEFAULT){$this->dataFine=$this->decodeString($dataFine,$encodeType);}
/**
 * @return string
 */
public function getDescrizione(){return $this->descrizione;}
/**
 * @param string $descrizione Descrizione
 * @param int $encodeType
 */
public function setDescrizione($descrizione,$encodeType = self::STR_DEFAULT){$this->descrizione=$this->decodeString($descrizione,$encodeType);}
}