<?php
/**
* Created by Drakkar vers. 0.1.3(Hjortspring)
* User: P.D.A. Srl
* Date: 2018-11-15
* Time: 11:42:47.357587
*/
namespace Click\Affitti\TblBase;
require_once 'PdaAbstractModel.php';
use Click\Affitti\TblBase\PdaAbstractModel;

/**
 * @property string nomeTabella
 * @property string tableName
 */
class CauzioniModel extends PdaAbstractModel {
/** @var integer */
protected $id;
/** @var integer */
protected $idContratto;
/** @var integer */
protected $idTipoCauzione;
/** @var string */
protected $descrizione;
/** @var string */
protected $dataCauzione;
/** @var string */
protected $dataScadenza;
/** @var integer */
protected $mesiPreavvisoScadenza=0;
/** @var double */
protected $importo;
/** @var string (enum) N=Nessuna restituzione interessi<br/>A=Restituzione interessi annuale<br/>C=Restituzione interessi a risoluzione contratto (sul capitale)<br/>V=Restituzione interessi a risoluzione contratto (sul versato)*/
protected $tipoRestituzioneInteressi='N';
/** @var integer */
protected $meseRestituzioneInteressi;
/** @var integer */
protected $cestino=0;

function __construct($pdo){parent::__construct($pdo);$this->nomeTabella='cauzioni';$this->tableName='cauzioni';}

/**
 * find by tables' Primary Key: 
 * @return Cauzioni|array|string|null
 */
public function findByPk($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName USE INDEX(PRIMARY) WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResult($query, array($id), $typeResult);}
/**
 * delete by tables' Primary Key: 
 */
public function deleteByPk($id){$query = "DELETE FROM $this->tableName  WHERE id=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($id));}
/**
 * Find all record of table
 * @return Cauzioni[]|array|string
 */
public function findAll($distinct=false,$typeResult=self::FETCH_OBJ,$limit = -1,$offset = -1){ $distinctStr=($distinct) ? 'DISTINCT' : ''; $query="SELECT $distinctStr * FROM $this->tableName ";if($this->whereBase) $query.=" WHERE $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";$query .= $this->createLimitQuery($limit,$offset);return $this->createResultArray($query, null,$typeResult);}

/**
 * find by tables' Key idx_id_tipo_cauzione: 
 * @return Cauzioni[]|array|string
 */
public function findByIdxIdTipoCauzione($idTipoCauzione,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_id_tipo_cauzione) WHERE id_tipo_cauzione=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($idTipoCauzione), $typeResult);}

/**
 * find by tables' Key idx_id_contratto: 
 * @return Cauzioni[]|array|string
 */
public function findByIdxIdContratto($idContratto,$typeResult = self::FETCH_OBJ,$limit = -1,$offset = -1){$query = "SELECT * FROM $this->tableName USE INDEX(idx_id_contratto) WHERE id_contratto=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultArray($query, array($idContratto), $typeResult);}

/**
 * delete by tables' Key idx_id_tipo_cauzione: 
 * @return boolean
 */
public function deleteByIdxIdTipoCauzione($idTipoCauzione,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_tipo_cauzione=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idTipoCauzione));}
/**
 * delete by tables' Key idx_id_contratto: 
 * @return boolean
 */
public function deleteByIdxIdContratto($idContratto,$typeResult = self::FETCH_OBJ){$query = "DELETE FROM $this->tableName WHERE id_contratto=? ";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idContratto));}
/**
 * find by id
 * @return Cauzioni[]
 */
public function findById($id,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($id), $typeResult);}


/**
 * find by id_contratto
 * @return Cauzioni[]
 */
public function findByIdContratto($idContratto,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id_contratto=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($idContratto), $typeResult);}


/**
 * find by id_tipo_cauzione
 * @return Cauzioni[]
 */
public function findByIdTipoCauzione($idTipoCauzione,$typeResult = self::FETCH_OBJ){$query = "SELECT * FROM $this->tableName WHERE id_tipo_cauzione=?";if ($this->whereBase) $query.=" AND $this->whereBase";if($this->orderBase) $query.=" ORDER BY $this->orderBase";return $this->createResultArray($query, array($idTipoCauzione), $typeResult);}


/**
 * delete by id_contratto
 * @return boolean
 */
public function deleteByIdContratto($idContratto){$query = "DELETE FROM $this->tableName WHERE id_contratto=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idContratto));}

/**
 * delete by id_tipo_cauzione
 * @return boolean
 */
public function deleteByIdTipoCauzione($idTipoCauzione){$query = "DELETE FROM $this->tableName WHERE id_tipo_cauzione=?";if ($this->whereBase) $query.=" AND $this->whereBase";return $this->createResultValue($query, array($idTipoCauzione));}

/**
 * Transforms the object into a key array
 * @return array
 */
public function toArrayAssoc(){$arrayValue=array();if(isset($this->id))$arrayValue['id']=$this->id;if(isset($this->idContratto))$arrayValue['id_contratto']=$this->idContratto;if(isset($this->idTipoCauzione))$arrayValue['id_tipo_cauzione']=$this->idTipoCauzione;if(isset($this->descrizione))$arrayValue['descrizione']=$this->descrizione;if(isset($this->dataCauzione))$arrayValue['data_cauzione']=$this->dataCauzione;if(isset($this->dataScadenza))$arrayValue['data_scadenza']=($this->dataScadenza==self::NULL_VALUE)?null:$this->dataScadenza;if(isset($this->mesiPreavvisoScadenza))$arrayValue['mesi_preavviso_scadenza']=($this->mesiPreavvisoScadenza==self::NULL_VALUE)?null:$this->mesiPreavvisoScadenza;if(isset($this->importo))$arrayValue['importo']=$this->importo;if(isset($this->tipoRestituzioneInteressi))$arrayValue['tipo_restituzione_interessi']=$this->tipoRestituzioneInteressi;if(isset($this->meseRestituzioneInteressi))$arrayValue['mese_restituzione_interessi']=$this->meseRestituzioneInteressi;if(isset($this->cestino))$arrayValue['cestino']=$this->cestino;return $arrayValue;}

/**
 * It transforms the keyarray in an $positionalArray[%s]object
 */
public function createObjKeyArray(array $keyArray){$this->flagObjectDataValorized = false;if ((isset($keyArray['id'])) || (isset($keyArray['cauzioni_id']))) {$this->setId(isset($keyArray['id'])?$keyArray['id']:$keyArray['cauzioni_id']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_contratto'])) || (isset($keyArray['cauzioni_id_contratto']))) {$this->setIdcontratto(isset($keyArray['id_contratto'])?$keyArray['id_contratto']:$keyArray['cauzioni_id_contratto']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['id_tipo_cauzione'])) || (isset($keyArray['cauzioni_id_tipo_cauzione']))) {$this->setIdtipocauzione(isset($keyArray['id_tipo_cauzione'])?$keyArray['id_tipo_cauzione']:$keyArray['cauzioni_id_tipo_cauzione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['descrizione'])) || (isset($keyArray['cauzioni_descrizione']))) {$this->setDescrizione(isset($keyArray['descrizione'])?$keyArray['descrizione']:$keyArray['cauzioni_descrizione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['data_cauzione'])) || (isset($keyArray['cauzioni_data_cauzione']))) {$this->setDatacauzione(isset($keyArray['data_cauzione'])?$keyArray['data_cauzione']:$keyArray['cauzioni_data_cauzione']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['data_scadenza'])) || (isset($keyArray['cauzioni_data_scadenza']))) {$this->setDatascadenza(isset($keyArray['data_scadenza'])?$keyArray['data_scadenza']:$keyArray['cauzioni_data_scadenza']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['mesi_preavviso_scadenza'])) || (isset($keyArray['cauzioni_mesi_preavviso_scadenza']))) {$this->setMesipreavvisoscadenza(isset($keyArray['mesi_preavviso_scadenza'])?$keyArray['mesi_preavviso_scadenza']:$keyArray['cauzioni_mesi_preavviso_scadenza']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['importo'])) || (isset($keyArray['cauzioni_importo']))) {$this->setImporto(isset($keyArray['importo'])?$keyArray['importo']:$keyArray['cauzioni_importo']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['tipo_restituzione_interessi'])) || (isset($keyArray['cauzioni_tipo_restituzione_interessi']))) {$this->setTiporestituzioneinteressi(isset($keyArray['tipo_restituzione_interessi'])?$keyArray['tipo_restituzione_interessi']:$keyArray['cauzioni_tipo_restituzione_interessi']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['mese_restituzione_interessi'])) || (isset($keyArray['cauzioni_mese_restituzione_interessi']))) {$this->setMeserestituzioneinteressi(isset($keyArray['mese_restituzione_interessi'])?$keyArray['mese_restituzione_interessi']:$keyArray['cauzioni_mese_restituzione_interessi']);$this->flagObjectDataValorized = true; }if ((isset($keyArray['cestino'])) || (isset($keyArray['cauzioni_cestino']))) {$this->setCestino(isset($keyArray['cestino'])?$keyArray['cestino']:$keyArray['cauzioni_cestino']);$this->flagObjectDataValorized = true; }}

/**
 * @return array
 */
public function createKeyArrayFromPositional($positionalArray){$values=array();$values['id'] =$positionalArray[0];$values['id_contratto'] =$positionalArray[1];$values['id_tipo_cauzione'] =$positionalArray[2];$values['descrizione'] =$positionalArray[3];$values['data_cauzione'] =$positionalArray[4];$values['data_scadenza'] =($positionalArray[5]==self::NULL_VALUE)?null:$positionalArray[5];$values['mesi_preavviso_scadenza'] =($positionalArray[6]==self::NULL_VALUE)?null:$positionalArray[6];$values['importo'] =$positionalArray[7];$values['tipo_restituzione_interessi'] =$positionalArray[8];$values['mese_restituzione_interessi'] =$positionalArray[9];$values['cestino'] =$positionalArray[10];return $values;}

/**
 * @return array
 */
public function getEmptyDbKeyArray(){$values=array();$values['id'] = null;$values['id_contratto'] = null;$values['id_tipo_cauzione'] = null;$values['descrizione'] = null;$values['data_cauzione'] = null;$values['data_scadenza'] = null;$values['mesi_preavviso_scadenza'] = 0;$values['importo'] = null;$values['tipo_restituzione_interessi'] = 'N';$values['mese_restituzione_interessi'] = null;$values['cestino'] = 0;return $values;}

/**
 * Return columns' list
 * @return string
 */
public function getListColumns(){return 'cauzioni.id as cauzioni_id,cauzioni.id_contratto as cauzioni_id_contratto,cauzioni.id_tipo_cauzione as cauzioni_id_tipo_cauzione,cauzioni.descrizione as cauzioni_descrizione,cauzioni.data_cauzione as cauzioni_data_cauzione,cauzioni.data_scadenza as cauzioni_data_scadenza,cauzioni.mesi_preavviso_scadenza as cauzioni_mesi_preavviso_scadenza,cauzioni.importo as cauzioni_importo,cauzioni.tipo_restituzione_interessi as cauzioni_tipo_restituzione_interessi,cauzioni.mese_restituzione_interessi as cauzioni_mese_restituzione_interessi,cauzioni.cestino as cauzioni_cestino';}

/**
 * DDL Table
 */
public function createTable(){ return $this->pdo->exec("CREATE TABLE `cauzioni` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_contratto` int(10) unsigned NOT NULL,
  `id_tipo_cauzione` int(10) unsigned NOT NULL,
  `descrizione` varchar(45) NOT NULL,
  `data_cauzione` date NOT NULL,
  `data_scadenza` date DEFAULT NULL,
  `mesi_preavviso_scadenza` int(11) DEFAULT '0',
  `importo` double unsigned NOT NULL,
  `tipo_restituzione_interessi` enum('N','A','C','V') NOT NULL DEFAULT 'N' COMMENT 'N=Nessuna restituzione interessi\nA=Restituzione interessi annuale\nC=Restituzione interessi a risoluzione contratto (sul capitale)\nV=Restituzione interessi a risoluzione contratto (sul versato)',
  `mese_restituzione_interessi` int(10) unsigned NOT NULL,
  `cestino` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_id_tipo_cauzione` (`id_tipo_cauzione`),
  KEY `idx_id_contratto` (`id_contratto`),
  CONSTRAINT `fk_id_tipo_cauzione` FOREIGN KEY (`id_tipo_cauzione`) REFERENCES `tipi_cauzione` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1 ");}
/**
 * @return integer
 */
public function getId(){return $this->id;}
/**
 * @param integer $id Id
 */
public function setId($id){$this->id=$id;}
/**
 * @return integer
 */
public function getIdContratto(){return $this->idContratto;}
/**
 * @param integer $idContratto IdContratto
 */
public function setIdContratto($idContratto){$this->idContratto=$idContratto;}
/**
 * @return integer
 */
public function getIdTipoCauzione(){return $this->idTipoCauzione;}
/**
 * @param integer $idTipoCauzione IdTipoCauzione
 */
public function setIdTipoCauzione($idTipoCauzione){$this->idTipoCauzione=$idTipoCauzione;}
/**
 * @return string
 */
public function getDescrizione(){return $this->descrizione;}
/**
 * @param string $descrizione Descrizione
 * @param int $encodeType
 */
public function setDescrizione($descrizione,$encodeType = self::STR_DEFAULT){$this->descrizione=$this->decodeString($descrizione,$encodeType);}
/**
 * @return string
 */
public function getDataCauzione(){return $this->dataCauzione;}
/**
 * @param string $dataCauzione DataCauzione
 * @param int $encodeType
 */
public function setDataCauzione($dataCauzione,$encodeType = self::STR_DEFAULT){$this->dataCauzione=$this->decodeString($dataCauzione,$encodeType);}
/**
 * @return string
 */
public function getDataScadenza(){return $this->dataScadenza;}
/**
 * @param string $dataScadenza DataScadenza
 * @param int $encodeType
 */
public function setDataScadenza($dataScadenza,$encodeType = self::STR_DEFAULT){$this->dataScadenza=$this->decodeString($dataScadenza,$encodeType);}
/**
 * @return integer
 */
public function getMesiPreavvisoScadenza(){return $this->mesiPreavvisoScadenza;}
/**
 * @param integer $mesiPreavvisoScadenza MesiPreavvisoScadenza
 */
public function setMesiPreavvisoScadenza($mesiPreavvisoScadenza){$this->mesiPreavvisoScadenza=$mesiPreavvisoScadenza;}
/**
 * @param null|int $decimals=null * @param string $dec_point decimal's point * @param string $thousands_sep thousands' separator * @return double|string
 */
public function getImporto($decimals=null,$dec_point=',',$thousands_sep='.'){return is_null($decimals)?$this->importo:number_format($this->importo,$decimals,$dec_point,$thousands_sep);}
/**
 * @param double $importo Importo
 */
public function setImporto($importo){$this->importo=$importo;}
/**
 * @param bool $decode if true return decode value * @return string
 */
public function getTipoRestituzioneInteressi($decode=false){return ($decode)?$this->getTipoRestituzioneInteressiValuesList()[$this->tipoRestituzioneInteressi]:$this->tipoRestituzioneInteressi;}
/**
 * @param bool $json if true return value json's array else return array values * @return array|string
 */
public function getTipoRestituzioneInteressiValuesList($json=false){$kv=['N'=>'Nessuna restituzione interessi','A'=>'Restituzione interessi annuale','C'=>'Restituzione interessi a risoluzione contratto (sul capitale)','V'=>'Restituzione interessi a risoluzione contratto (sul versato)'];return ($json)?$this->createJsonKeyValArray($kv):$kv;}
/**
 * @param string (enum) $tipoRestituzioneInteressi TipoRestituzioneInteressi
 */
public function setTipoRestituzioneInteressi($tipoRestituzioneInteressi){$this->tipoRestituzioneInteressi=$tipoRestituzioneInteressi;}
/**
 * @return integer
 */
public function getMeseRestituzioneInteressi(){return $this->meseRestituzioneInteressi;}
/**
 * @param integer $meseRestituzioneInteressi MeseRestituzioneInteressi
 */
public function setMeseRestituzioneInteressi($meseRestituzioneInteressi){$this->meseRestituzioneInteressi=$meseRestituzioneInteressi;}
/**
 * @return integer
 */
public function getCestino(){return $this->cestino;}
/**
 * @param integer $cestino Cestino
 */
public function setCestino($cestino){$this->cestino=$cestino;}
}