

/*-----------------------------------------17/12/2018-----------------------------------------------------------------*/
CREATE TABLE `regime_fiscale` (
`codice` VARCHAR(4) NOT NULL,
`descrizione` VARCHAR(100) NOT NULL,
PRIMARY KEY (`codice`));


CREATE TABLE `tipo_documento` (
`codice` VARCHAR(4) NOT NULL,
`descrizione` VARCHAR(100) NOT NULL,
PRIMARY KEY (`codice`));


INSERT INTO `tipo_documento` (`codice`, `descrizione`) VALUES ('TD01', 'fattura');
INSERT INTO `tipo_documento` (`codice`, `descrizione`) VALUES ('TD02', 'acconto/anticipo su fattura');
INSERT INTO `tipo_documento` (`codice`, `descrizione`) VALUES ('TD03', 'acconto/anticipo su parcella');
INSERT INTO `tipo_documento` (`codice`, `descrizione`) VALUES ('TD04', 'nota di credito');
INSERT INTO `tipo_documento` (`codice`, `descrizione`) VALUES ('TD05', 'nota di debito');
INSERT INTO `tipo_documento` (`codice`, `descrizione`) VALUES ('TD06', 'parcella');


INSERT INTO `regime_fiscale` (`codice`, `descrizione`) VALUES ('RF01', 'Ordinario');
INSERT INTO `regime_fiscale` (`codice`, `descrizione`) VALUES ('RF02', 'Contribuenti minimi (art.1, c.96-117, L. 244/07) ');
INSERT INTO `regime_fiscale` (`codice`, `descrizione`) VALUES ('RF04', 'Agricoltura e attività connesse e pesca (artt.34 e 34-bis, DPR 633/72) ');
INSERT INTO `regime_fiscale` (`codice`, `descrizione`) VALUES ('RF05', 'Vendita sali e tabacchi (art.74, c.1, DPR. 633/72) ');
INSERT INTO `regime_fiscale` (`codice`, `descrizione`) VALUES ('RF06', 'Commercio fiammiferi (art.74, c.1, DPR  633/72) ');
INSERT INTO `regime_fiscale` (`codice`, `descrizione`) VALUES ('RF07', 'Editoria (art.74, c.1, DPR  633/72)');
INSERT INTO `regime_fiscale` (`codice`, `descrizione`) VALUES ('RF08', 'Gestione servizi telefonia pubblica (art.74, c.1, DPR 633/72) ');
INSERT INTO `regime_fiscale` (`codice`, `descrizione`) VALUES ('RF09', 'Rivendita documenti di trasporto pubblico e di sosta (art.74, c.1, DPR  633/72) ');
INSERT INTO `regime_fiscale` (`codice`, `descrizione`) VALUES ('RF10', 'Intrattenimenti, giochi e altre attività di cui alla tariffa allegata al DPR 640/72 (art.74, c.6, DPR 633/72) ');
INSERT INTO `regime_fiscale` (`codice`, `descrizione`) VALUES ('RF11', 'Agenzie viaggi e turismo (art.74-ter, DPR 633/72) ');
INSERT INTO `regime_fiscale` (`codice`, `descrizione`) VALUES ('RF12', 'Agriturismo (art.5, c.2, L. 413/91) ');
INSERT INTO `regime_fiscale` (`codice`, `descrizione`) VALUES ('RF13', 'Vendite a domicilio (art.25-bis, c.6, DPR  600/73) ');
INSERT INTO `regime_fiscale` (`codice`, `descrizione`) VALUES ('RF14', 'Rivendita beni usati, oggetti d’arte, d’antiquariato o da collezione (art.36, DL 41/95) ');
INSERT INTO `regime_fiscale` (`codice`, `descrizione`) VALUES ('RF15', 'Agenzie di vendite all’asta di oggetti d’arte, antiquariato o da collezione (art.40-bis, DL 41/95) ');
INSERT INTO `regime_fiscale` (`codice`, `descrizione`) VALUES ('RF16', 'IVA per cassa P.A. (art.6, c.5, DPR 633/72) ');
INSERT INTO `regime_fiscale` (`codice`, `descrizione`) VALUES ('RF17', 'IVA per cassa (art. 32-bis, DL 83/2012) ');
INSERT INTO `regime_fiscale` (`codice`, `descrizione`) VALUES ('RF18', 'Altro');
INSERT INTO `regime_fiscale` (`codice`, `descrizione`) VALUES ('RF19', 'Regime forfettario (art.1, c.54-89, L. 190/2014)');


/*-----------------------------------------10/10/2018-----------------------------------------------------------------*/
CREATE TABLE `conti` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tipo_conto` enum('A','F','B','X','S','U') DEFAULT 'F' COMMENT 'A = ANAGRAFICA\\nF = FATTURE\\nB = SPESE BANCARIE\\nX = SPESE EXTRA\\nS = FATTURE STUDIO\\nU = UNITA IMMOBILIARI',
  `codice_conto` int(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1


ALTER TABLE `interessi_legali`
ADD COLUMN `anno` INT UNSIGNED NOT NULL AFTER `id`,
ADD COLUMN `interesse` DECIMAL(8,4) NOT NULL AFTER `anno`;

INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1942', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1943', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1944', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1945', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1946', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1947', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1948', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1949', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1950', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1951', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1952', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1953', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1954', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1955', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1956', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1957', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1958', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1959', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1960', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1961', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1962', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1963', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1964', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1965', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1966', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1967', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1968', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1969', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1970', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1971', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1972', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1973', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1974', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1975', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1976', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1977', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1978', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1979', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1980', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1981', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1982', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1983', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1984', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1985', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1986', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1987', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1988', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1989', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1990', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1991', '10');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1992', '10');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1993', '10');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1994', '10');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1995', '10');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1996', '10');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1997', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1998', '5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('1999', '2.5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('2000', '2.5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('2001', '3.5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('2002', '3');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('2003', '3');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('2004', '2.5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('2005', '2.5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('2006', '2.5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('2007', '2.5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('2008', '3');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('2009', '3');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('2010', '1');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('2011', '1.5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('2012', '2.5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('2013', '2.5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('2014', '1');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('2015', '0.5');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('2016', '0.2');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('2017', '0.1');
INSERT INTO `interessi_legali` (`anno`, `interesse`) VALUES ('2018', '0.3');
