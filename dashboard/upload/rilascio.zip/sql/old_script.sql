
/*-----------------------------------------19/12/2018-----------------------------------------------------------------*/
ALTER TABLE `gruppi_fatturazione`
ADD COLUMN `flag_numero_zero` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0' AFTER `flag_fattura`;

/*-----------------------------------------17/12/2018-----------------------------------------------------------------*/
ALTER TABLE `gruppi_fatturazione`
ADD COLUMN `flag_fattura` TINYINT(1) NOT NULL DEFAULT '0' AFTER `id_anagrafica`;

ALTER TABLE `fatturazione_testa`
ADD COLUMN `flusso_controllato` TINYINT(1) NULL DEFAULT '0' AFTER `contabilizzato`,
ADD COLUMN `flusso_inviato` TINYINT(1) NULL DEFAULT '0' AFTER `flusso_controllato`;


ALTER TABLE `anagrafiche`
ADD COLUMN `regime_fiscale` VARCHAR(4) NULL DEFAULT 'RF01' AFTER `fattura_elettronica_destinatario_codice`;

ALTER TABLE `fatturazione_testa`
ADD COLUMN `id_fattura_pa` INT(10) UNSIGNED NULL DEFAULT NULL AFTER `flusso_inviato`;

CREATE TABLE `progressivo_efattura` (
  `id` INT(10) UNSIGNED NOT NULL,
  `id_fatturazione_testa` INT(10) UNSIGNED NULL,
  PRIMARY KEY (`id`));

ALTER TABLE `anagrafiche`
ADD COLUMN `efattura` TINYINT(1) NULL DEFAULT '1' AFTER `regime_fiscale`;

ALTER TABLE `unita_immobiliari`
ADD COLUMN `dettagli` JSON NULL DEFAULT NULL AFTER `scadenza_esercizio`;

ALTER TABLE `progressivo_efattura`
CHANGE COLUMN `id` `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT ;

/*-----------------------------------------21/11/2018-----------------------------------------------------------------*/
ALTER TABLE `contratti_dettagli`
ADD COLUMN `intestatario_locatore` INT(11) UNSIGNED NULL DEFAULT NULL AFTER `bollo_registrazione`,
ADD COLUMN `intestatario_conduttore` INT(11) UNSIGNED NULL DEFAULT NULL AFTER `intestatario_locatore`;

ALTER TABLE `contratti_dettagli`
ADD INDEX `idx_intestatario_locatore` (`intestatario_locatore` ASC) VISIBLE;

ALTER TABLE `contratti_dettagli`
ADD INDEX `idx_intestatario_conduttore` (`intestatario_conduttore` ASC) VISIBLE;

ALTER TABLE `fatturazione_testa`
ADD COLUMN `id_conduttore_fattura` INT(10) UNSIGNED NULL DEFAULT NULL AFTER `unita_immobiliari`,
ADD COLUMN `id_locatore_fattura` INT(10) UNSIGNED NULL DEFAULT NULL AFTER `id_conduttore_fattura`;

ALTER TABLE `fatturazione_testa`
CHANGE COLUMN `id_locatore_fattura` `id_locatore_fattura` INT(10) UNSIGNED NULL DEFAULT NULL AFTER `unita_immobiliari`;


UPDATE contratti_dettagli join contratti on contratti_dettagli.id=contratti.id
SET contratti_dettagli.intestatario_locatore = JSON_EXTRACT(`contratti`.`proprietari`, '$[0].id'),
contratti_dettagli.intestatario_conduttore = JSON_EXTRACT(`contratti`.`conduttori`, '$[0].id');

UPDATE fatturazione_testa
SET id_conduttore_fattura = JSON_EXTRACT(`fatturazione_testa`.`conduttori`, '$[0].id'),
id_locatore_fattura = JSON_EXTRACT(`fatturazione_testa`.`proprietari`, '$[0].id');
/*-----------------------------------------17/10/2018-----------------------------------------------------------------*/
ALTER TABLE `canoni_oneri` DROP COLUMN `data_fine_esercizio`;

ALTER TABLE `stabili` ADD COLUMN `scadenza_esercizio` JSON NULL DEFAULT NULL AFTER `fornitori_riferimento`;

ALTER TABLE `unita_immobiliari` ADD COLUMN `scadenza_esercizio` JSON NULL DEFAULT NULL AFTER `fornitori_riferimento`;

/*-----------------------------------------10/10/2018-----------------------------------------------------------------*/
INSERT INTO `opzioni` (`id`, `descrizione`, `valore`, `categoria`) VALUES ('10', 'Estratto Conto dettagliato', '0', 'S');
INSERT INTO `opzioni` (`id`, `descrizione`, `valore`, `categoria`) VALUES ('11', 'Mostra dettagli Intestatari', '0', 'S');


/*------------------------------------------CATEGORIA SPESE-----------------------------------------------------------*/
ALTER TABLE `categorie_spesa`
ADD COLUMN `codice_sottoconto` VARCHAR(10) NULL DEFAULT NULL AFTER `descrizione`;

ALTER TABLE `fatturazione_testa`
CHANGE COLUMN `conto_corrente` `conto_corrente` INT(10) NULL DEFAULT NULL ;


/*------------------------------------------FATTURAZIONE TESTA--------------------------------------------------------*/
ALTER TABLE `fatturazione_testa`
ADD COLUMN `contabilizzato` TINYINT(1) NOT NULL DEFAULT '0' AFTER `tipo_assoggettazione`;

/*------------------------------------------MOVIMENTI TESTA-----------------------------------------------------------*/
CREATE TABLE `movimenti_testa` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_contratto` int(10) unsigned DEFAULT NULL,
  `id_fattura_testa` int(10) unsigned DEFAULT NULL,
  `id_movimenti_banca_dettagli` int(11) DEFAULT NULL,
  `id_conto_corrente` int(10) unsigned DEFAULT NULL,
  `tipo_pagamento` enum('A','B','C') DEFAULT NULL COMMENT 'A= ASSEGNO\\nB = BONIFICO\\nC = CONTANTI',
  `codice_gruppo` int(10) unsigned DEFAULT NULL,
  `anno_protocollo` int(2) DEFAULT '0',
  `protocollo` int(10) unsigned NOT NULL,
  `numero_documento` varchar(45) DEFAULT NULL,
  `data_registrazione` date NOT NULL,
  `data_documento` date DEFAULT NULL,
  `data_scadenza` date DEFAULT NULL,
  `tipo_movimento` enum('R','I') DEFAULT 'R' COMMENT 'R = AUTOREGISTRAZIONE DOCUMENTO\nI = INCASSO',
  PRIMARY KEY (`id`),
  KEY `idx_id_contratto` (`id_contratto`),
  KEY `idx_anno_protocollo_protocollo` (`anno_protocollo`,`protocollo`),
  KEY `idx_id_contratto_codice_gruppo` (`id_contratto`,`codice_gruppo`)
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=latin1;
/*------------------------------------------MOVIMENTI DETTAGLI--------------------------------------------------------*/
CREATE TABLE `movimenti_dettagli` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_movimenti_testa` int(10) NOT NULL,
  `id_movimenti_testa_pagamento` int(10) DEFAULT NULL,
  `id_conto` int(11) DEFAULT NULL,
  `id_sottoconto` int(11) DEFAULT NULL,
  `partita` enum('D','A') DEFAULT 'D' COMMENT 'D = DARE\\\\nA = AVERE',
  `id_tipo_iva` int(10) unsigned DEFAULT NULL,
  `descrizione` varchar(250) DEFAULT NULL,
  `imponibile` decimal(10,2) DEFAULT '0.00',
  `importo` decimal(10,2) DEFAULT '0.00',
  `movimenti_dettaglicol` varchar(45) DEFAULT NULL,
  `tipo_dettaglio` enum('P','C') DEFAULT 'P' COMMENT 'P = PARTITA\nC = CONTROPARTITA',
  PRIMARY KEY (`id`),
  KEY `idx_id_movimenti_testa` (`id_movimenti_testa`),
  KEY `idx_id_conto_id_sottoconto` (`id_conto`,`id_sottoconto`),
  KEY `idx_id_movimenti_testa_tipo_dettaglio` (`id_movimenti_testa`,`tipo_dettaglio`)
) ENGINE=InnoDB AUTO_INCREMENT=373 DEFAULT CHARSET=latin1;
/*------------------------------------------MOVIMENTI BANCA TESTA-----------------------------------------------------*/
CREATE TABLE `movimenti_banca_testa` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_conti_corrente` int(10) unsigned DEFAULT NULL,
  `data_contabile` date DEFAULT NULL,
  `data_valuta` date DEFAULT NULL,
  `descrizione` varchar(255) DEFAULT NULL,
  `importo` decimal(10,2) DEFAULT NULL,
  `causale` varchar(10) DEFAULT NULL,
  `contabilizzato` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_id_conti_corrente` (`id_conti_corrente`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*------------------------------------------MOVIMENTI BANCA DETTAGLI--------------------------------------------------*/
CREATE TABLE `movimenti_banca_dettagli` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_movimenti_banca_testa` int(10) unsigned NOT NULL,
  `id_movimenti_testa` int(10) unsigned NOT NULL,
  `importo` decimal(10,2) NOT NULL DEFAULT '0.00',
  `descrizione` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_id_movimenti_banca_testa` (`id_movimenti_banca_testa`),
  KEY `idx_id_movimenti_testa` (`id_movimenti_testa`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*-------------------------------------------OPZIONI------------------------------------------------------------------*/


/*-----------------------------------------02/10/2018-----------------------------------------------------------------*/
ALTER TABLE `opzioni`
CHANGE COLUMN `categoria` `categoria` ENUM('S', 'I', 'A') NULL DEFAULT NULL COMMENT 'S = STAMPE\\nI= IMPOSTE\\nA= AGGIORNAMENTO ISTAT' ;

INSERT INTO `opzioni` (`id`, `descrizione`, `valore`, `categoria`) VALUES ('8', 'Imposta a zero ISTAT se negativo', '1', 'A');

ALTER TABLE `opzioni`
CHANGE COLUMN `categoria` `categoria` ENUM('S', 'I', 'A', 'C') NULL DEFAULT NULL COMMENT 'S = STAMPE\\nI= IMPOSTE\\nA= AGGIORNAMENTO ISTAT\\nC= CONTRATTO' ;

INSERT INTO `opzioni` (`id`, `descrizione`, `valore`, `categoria`) VALUES ('9', 'Richiesta imposta posticipata', '1', 'I');

/*-----------------------------------------18/09/2018-----------------------------------------------------------------*/
INSERT INTO `test1`.`opzioni` (`id`, `descrizione`, `valore`, `categoria`) VALUES ('5', 'Stampa leggi per contratti assoggettati ad IVA', '1', 'S');
INSERT INTO `test1`.`opzioni` (`id`, `descrizione`, `valore`, `categoria`) VALUES ('6', 'Stampa leggi per contratti non assoggettati ad IVA', '1', 'S');
INSERT INTO `test1`.`opzioni` (`id`, `descrizione`, `valore`, `categoria`) VALUES ('7', 'Arrotonda imposta di registro', '1', 'I');

ALTER TABLE `test1`.`rate_dettagli`
ADD COLUMN `id_conduttore_associato` INT(10) UNSIGNED NULL DEFAULT NULL AFTER `id_imposta_registro`;

CREATE TABLE `test1`.`subentro` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `data_subentro` DATE NULL,
  `tipo` ENUM('L', 'C') NOT NULL DEFAULT 'C' COMMENT 'L = LOCATORE\nC = CONDUTTORE',
  `entrante` JSON NOT NULL,
  `uscente` JSON NOT NULL,
  PRIMARY KEY (`id`));

ALTER TABLE `test1`.`unita_immobiliari_dettagli`
ADD COLUMN `tipo` ENUM('A', 'C', 'E', 'M') NULL DEFAULT 'A' COMMENT 'A = ALTRO\nC = CATASTO\nE = CERTIFICAZIONE ENERGETICA\nM = MAPPA' AFTER `nome_file`;
ALTER TABLE `test1`.`unita_immobiliari_dettagli`
CHANGE COLUMN `tipo` `tipo` ENUM('A', 'C', 'E', 'M') NULL DEFAULT 'A' COMMENT 'A = ALTRO\\nC = CATASTO\\nE = CERTIFICAZIONE ENERGETICA\\nM = MAPPA' AFTER `id_unita_immobiliari`;

/*-----------------------------------------10/09/2018-----------------------------------------------------------------*/
CREATE
    ALGORITHM = UNDEFINED
    DEFINER = `root`@`%`
    SQL SECURITY DEFINER
VIEW `immobili_allocati` AS
    SELECT
        `unita_immobiliari`.`id` AS `id`,
        SUM(`unita_immobiliari_contratti`.`percentuale`) AS `percentuale`
    FROM
        ((`unita_immobiliari`
        JOIN `unita_immobiliari_contratti` ON ((`unita_immobiliari`.`id` = `unita_immobiliari_contratti`.`id_unita_immobiliare`)))
        JOIN `contratti` ON ((`unita_immobiliari_contratti`.`id_contratto` = `contratti`.`id`)))
    WHERE
        ((`contratti`.`cestino` = 0)
            AND (`unita_immobiliari`.`cestino` = 0))
    GROUP BY `unita_immobiliari`.`id`

/*-----------------------------------------02/09/2018-----------------------------------------------------------------*/
ALTER TABLE `stabili`
ADD COLUMN `codice_stabile` VARCHAR(10) NULL DEFAULT NULL AFTER `id_amministratore`;

ALTER TABLE `contratti_dettagli`
ADD COLUMN `descrizione_bollo_registrazione` VARCHAR(150) NULL DEFAULT 'Bollo per la registrazione del contratto' AFTER `luogo_stipula`,
ADD COLUMN `bollo_registrazione` DECIMAL(10,2) NULL DEFAULT 0 AFTER `descrizione_bollo_registrazione`;

CREATE TABLE `opzioni` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descrizione` varchar(250) DEFAULT NULL,
  `valore` tinyint(1) unsigned DEFAULT '0',
  `categoria` enum('S','I') DEFAULT NULL COMMENT 'S = STAMPE\nI= IMPOSTE',
  PRIMARY KEY (`id`)
)

ALTER TABLE `click_affitti`.`contratti_preferenze`
ADD COLUMN `divisione_conduttori` VARCHAR(250) NULL DEFAULT NULL AFTER `tipo_pagamento`,
ADD COLUMN `divisione_locatori` VARCHAR(250) NULL DEFAULT NULL AFTER `divisione_conduttori`;

ALTER TABLE `login`
ADD COLUMN `id_news_letta` INT UNSIGNED NULL AFTER `data_scadenza`;

ALTER TABLE `anagrafiche`
ADD COLUMN `documento` JSON NULL DEFAULT NULL AFTER `fornitore`;

ALTER TABLE `contratti_preferenze`
ADD COLUMN `divisione_conduttori` JSON NULL DEFAULT NULL AFTER `fornitore`;

ALTER TABLE `contratti_preferenze`
ADD COLUMN `divisione_conduttori` JSON NULL DEFAULT NULL AFTER `tipo_pagamento`,
ADD COLUMN `divisione_locatori` JSON NULL DEFAULT NULL AFTER `divisione_conduttori`;
/*##########################################CREARE VISTA INQUILINI####################################################*/
/*##########################################CREARE VISTA PROPRIETARI##################################################*/